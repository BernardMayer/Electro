Bienvenue à toutes et à tous pour un tutoriel sur l'électronique et l'informatique ensemble ! :)

Ce que nous allons apprendre aujourd'hui est un mélange d'électronique et de programmation. On va en effet parler d'informatique embarquée qui est un sous-domaine de l'électronique et qui a l'habileté d'unir la puissance de la programmation à la puissance de l'électronique.

Nous allons, dans un premier temps, voir ce qu'est l'électronique et la programmation. Puis nous enchaînerons sur la prise en main du système Arduino, un système d'informatique embarquée grand public. Enfin, je vous ferai un cours très rapide sur le langage Arduino, mais il posera les bases de la programmation. Une fois ces étapes préliminaires achevées, nous pourrons entamer notre premier programme et faire un pas dans l’informatique embarquée.

### Apprentissage des bases

Le cours est composé de façon à ce que les bases essentielles soient regroupées dans les premières parties. C'est-à-dire, pour commencer la lecture, vous devrez lire les parties 1 et 2. Ensuite, les parties 3 et 4 sont également essentielles et sont à lire dans l'ordre.

Après cela, vous aurez acquis toutes les bases nécessaires pour poursuivre la lecture sereinement. C'est seulement alors que vous pourrez sélectionner les chapitres selon les connaissances que vous souhaitez acquérir.