## Le but

Je l'ai dit, c'est de réaliser des feux de signalisation.
Alors, vu le nombre de LED, vous vous doutez bien qu'il faut réaliser 2 feux. Ces feux devront être synchronisés.
Là encore, je vous ai préparé une belle image animée :

->![Les feux](/media/galleries/954/b03037b0-dd3e-4975-b53a-70d546ccbd0d.gif)<-

## Le temps de la séquence

Vous allez mettre un délai de 3 secondes entre le feu vert et le feu orange.
Un délai de 1 seconde entre le feu orange et le feu rouge. Et un délai de 3 secondes entre le feu rouge et le feu vert.

## Par où commencer ?

D'abord, vous devez faire l'organigramme. Oui je ne vous le donne pas !
Ensuite, vous commencez un nouveau programme. Dans ce programme, vous devez définir quelles sont les broches du micro-contrôleur que vous utilisez.
Puis définir si ce sont des entrées, des sorties, ou s'il y a des deux.
Pour terminer, vous allez faire le programme complet dans la fonction qui réalise une boucle.

## C'est parti !

Allez, c'est parti ! A vous de m'épater. :P Vous avez théoriquement toutes les bases nécessaires pour réaliser ce TP.
En plus on a presque déjà tout fait. Mince, j'en ai trop dit...
Pendant ce temps, moi je vais me faire une raclette. ^^ Et voici un résultat possible :

->!(https://www.youtube.com/watch?v=ByPDsyHhf-g)<-