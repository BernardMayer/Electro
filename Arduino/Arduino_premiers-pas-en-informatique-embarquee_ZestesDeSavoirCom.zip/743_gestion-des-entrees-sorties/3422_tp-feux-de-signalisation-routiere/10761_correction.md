## Fini !

Vous avez fini ? Votre code ne fonctionne pas, mais vous avez eu beau chercher pourquoi, vous n'avez pas trouvé ?

Très bien. Dans ce cas, vous pouvez lire la correction.

Ceux qui n'ont pas cherché ne sont pas les bienvenus ici ! :diable: 

## L'organigramme

Cette fois, l'organigramme a changé de forme, c'est une liste.
Comment le lire ? De haut en bas ! Le premier élément du programme commence après le début, le deuxième élément, après le premier, etc.

- **DEBUT**
- `/* première partie du programme, on s'occupe principalement du deuxième feu */`
- Allumer led_rouge_feux_1
- Allumer led_verte_feux_2
- Attendre 3 secondes
- Éteindre led_verte_feux_2
- Allumer led_jaune_feux_2
- Attendre 1 seconde
- Éteindre led_jaune_feux_2
- Allumer led_rouge_feux_2
- `/* deuxième partie du programme, pour l'instant : led_rouge_feux_1 et led_rouge_feux_2 sont allumées; on éteint donc la led_rouge_feux_1 pour allumer la led_verte_feux_1 */`
- Attendre 3 secondes
- Éteindre led_rouge_feux_1
- Allumer led_verte_feux_1
- Attendre 3 secondes
- Éteindre led_verte_feux_1
- Allumer led_jaune_feux_1
- Attendre 1 seconde
- Éteindre led_jaune_feux_1
- Allumer led_rouge_feux_1
- **FIN**

Voilà donc ce qu'il faut suivre pour faire le programme.
Si vous avez trouvé comme ceci, c'est très bien, sinon il faut s'entraîner car c'est très important d'organiser son code et en plus cela permet d'éviter certaines erreurs !

# La correction, enfin !

Voilà le moment que vous attendez tous : la correction !
Alors, je préviens tout de suite, le code que je vais vous montrer n'est pas absolu, on peut le faire de différentes manières

## La fonction setup

Normalement ici aucune difficulté, on va nommer les broches, puis les placer en sortie et les mettre dans leur état de départ.

[[secret]]
| ```cpp
| // définition des broches
| const int led_rouge_feux_1 = 2;
| const int led_jaune_feux_1 = 3;
| const int led_verte_feux_1 = 4;
| const int led_rouge_feux_2 = 5;
| const int led_jaune_feux_2 = 6;
| const int led_verte_feux_2 = 7;
|
| void setup()
| {
|     // initialisation en sortie de toutes les broches
|     pinMode(led_rouge_feux_1, OUTPUT);
|     pinMode(led_jaune_feux_1, OUTPUT);
|     pinMode(led_verte_feux_1, OUTPUT);
|     pinMode(led_rouge_feux_2, OUTPUT);
|     pinMode(led_jaune_feux_2, OUTPUT);
|     pinMode(led_verte_feux_2, OUTPUT);
|
|     // on initialise toutes les LED éteintes au début du programme
|     // (sauf les deux feux rouges)
|     digitalWrite(led_rouge_feux_1, LOW);
|     digitalWrite(led_jaune_feux_1, HIGH);
|     digitalWrite(led_verte_feux_1, HIGH);
|     digitalWrite(led_rouge_feux_2, LOW);
|     digitalWrite(led_jaune_feux_2, HIGH);
|     digitalWrite(led_verte_feux_2, HIGH);
| }
| ```
| Code: La fonction setup

Vous remarquerez l'utilité d'avoir des variables bien nommées.

## Le code principal

Si vous êtes bien organisé, vous ne devriez pas avoir de problème ici non plus! Point trop de paroles, la solution arrive

[[secret]]
| ```cpp
| void loop()
| {
|     // première séquence
|     digitalWrite(led_rouge_feux_1, HIGH);
|     digitalWrite(led_verte_feux_1, LOW);
|
|     delay(3000);
|
|     // deuxième séquence
|     digitalWrite(led_verte_feux_1, HIGH);
|     digitalWrite(led_jaune_feux_1, LOW);
|
|     delay(1000);
|
|     // troisième séquence
|     digitalWrite(led_jaune_feux_1, HIGH);
|     digitalWrite(led_rouge_feux_1, LOW);
|
|     delay(1000);
|
|     /* deuxième partie du programme, on s'occupe du feux numéro 2 */
|
|     // première séquence
|     digitalWrite(led_rouge_feux_2, HIGH);
|     digitalWrite(led_verte_feux_2, LOW);
|
|     delay(3000);
|
|     // deuxième séquence
|     digitalWrite(led_verte_feux_2, HIGH);
|     digitalWrite(led_jaune_feux_2, LOW);
|
|     delay(1000);
|
|     // deuxième séquence
|     digitalWrite(led_jaune_feux_2, HIGH);
|     digitalWrite(led_rouge_feux_2, LOW);
|
|     delay(1000);
|
|     /* le programme va reboucler et revenir au début */
| }
| ```
| Code: La fonction principale

Si ça marche, tant mieux, sinon référez vous à la résolution des problèmes en annexe du cours.
Ce TP est donc terminé, vous pouvez modifier le code pour par exemple changer les temps entre chaque séquence, ou bien même modifier les séquences elles-mêmes, ...