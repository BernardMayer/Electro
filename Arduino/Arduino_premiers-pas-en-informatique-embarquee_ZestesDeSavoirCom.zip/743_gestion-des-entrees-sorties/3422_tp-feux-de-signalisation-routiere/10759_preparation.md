Ce dont nous avons besoin pour réaliser ces feux.

## Le matériel

Le matériel est la base de notre besoin. On a déjà utilisé 6 LED et résistances, mais elles étaient pour moi en l'occurrence toutes rouges. Pour faire un feu routier, il va nous falloir 6 LED, mais dont les couleurs ne sont plus les mêmes.

- LED : un nombre de 6, dont 2 **rouges**, 2 **jaune** (ou **orange**) et 2 **vertes**;
- Résistors : 6 également, de la même valeur que ceux que vous avez utilisés.
- Arduino : une carte Arduino évidemment !

## Le schéma

C'est le même que pour le montage précédent, seul la couleur des LED change, comme ceci :

->![Shéma TP feux de signalisation](/media/galleries/954/82add40a-550f-42b2-a2a8-b9757a2581b1.png.960x960_q85.png)<-

Vous n'avez donc plus qu'à reprendre le dernier montage et changer la couleur de 4 LED, pour obtenir ceci :

->![Montage TP feux de signalisation](/media/galleries/954/9b2055ea-e2f3-4fc8-b356-e5115612d06f.png.960x960_q85.png)<-

[[e]]
|N'oubliez pas de tester votre matériel en chargeant un programme qui fonctionne !
|Cela évite de s'acharner à faire un nouveau programme qui ne fonctionne pas à cause d'un matériel défectueux. On est jamais sûr de rien, croyez-moi ! ;)