Vous vous en doutez peut-être, lorsque l'on veut utiliser plusieurs afficheur il va nous falloir beaucoup de broches.
Imaginons, nous voulons afficher un nombre entre 0 et 99, il nous faudra utiliser deux afficheurs avec $2*7 = 14$ broches connectées sur la carte Arduino.
Rappel : une carte Arduino UNO possède... 14 broches entrées/sorties classiques.
Si on ne fais rien d'autre que d'utiliser les afficheurs, cela ne nous gène pas, cependant, il est fort probable que vous serez amener à utiliser d'autres entrées avec votre carte Arduino.
Mais si on ne libère pas de place vous serez embêté.

Nous allons donc voir deux techniques qui, une fois cumulées, vont nous permettre d'utiliser seulement 4 broches pour obtenir le même résultat qu'avec 14 broches !

# Les décodeurs "4 bits -> 7 segments"

La première technique que nous allons utiliser met en œuvre un circuit intégré.
Vous vous souvenez quand je vous ai parlé de ces bêtes là ?
Oui, c'est le même type que le microcontrôleur de la carte Arduino.
Cependant, le circuit que nous allons utiliser ne fait pas autant de choses que celui sur votre carte Arduino.

## Décodeur BCD -> 7 segments

C'est le nom du circuit que nous allons utiliser. Son rôle est simple. Vous vous souvenez des conversions ?
Pour passer du binaire au décimal ?
Et bien c'est le moment de vous en servir, donc si vous ne vous rappelez plus de ça, allez revoir un peu [le cours](https://zestedesavoir.com/contenus/686/arduino-premiers-pas-en-informatique-embarquee/742_decouverte-de-larduino/3415_quelques-bases-elementaires/#4-10781_les-bases-de-comptage-210-et-16).
Je disais donc que son rôle est simple.
Et vous le constaterez par vous même, il va s'agir de convertir du binaire codé sur 4 bits vers un "code" utilisé pour afficher les chiffres.
Ce code correspond en quelque sorte au tableau précédemment évoqué.

## Principe du décodeur

Sur un afficheur 7 segments, on peut représenter aisément les chiffres de 0 à 9.
En informatique, pour représenter ces chiffres, il nous faut au maximum 4 bits.
Comme vous êtes des experts et que vous avez bien lu la partie sur le binaire, vous n'avez pas de mal à le comprendre.
$(0000)_2$ fera $(0)_{10}$ et $(1111)_2$ fera $(15)_{10}$ ou $(F)_{16}$.
Pour faire 9 par exemple on utilisera les bits 1001.
En partant de se constat, des ingénieurs ont inventé un composant au doux nom de "décodeur" ou "driver" 7 segments.
Il reçoit sur 4 broches les 4 bits de la valeur à afficher, et sur 7 autres broches ils pilotent les segments pour afficher ladite valeur.
Ajouter à cela une broche d'alimentation et une broche de masse on obtient 13 broches !
Et ce n'est pas fini. La plupart des circuits intégrés de type décodeur possède aussi une broche d'activation et une broche pour tester si tous les segments fonctionnent.

## Choix du décodeur

Nous allons utiliser le composant nommé MC14543B comme exemple (un equivalent utilisable et trouvable facilement est le CD4543BE).
Tout d'abord, ouvrez ce lien dans un nouvel onglet, il vous menera directement vers le pdf du décodeur :

->[Datasheet du MC14543B](http://www.datasheetcatalog.org/datasheet2/4/09lwz6g28frlr15ayl6w0srxwz7y.pdf)<-

Les datasheets se composent souvent de la même manière. On trouve tout d'abord un résumé des fonctions du produit puis un schéma de son boîtier.
Dans notre cas, on voit qu'il est monté sur un DIP 16 (DIP : Dual Inline Package, en gros "boîtier avec deux lignes de broches").
Si l'on continue, on voit la **table de vérité** faisant le lien entre les signaux d'entrées (INPUT) et les sorties (OUTPUT).
On voit ainsi plusieurs choses :

- Si l'on met la broche Bl (Blank, n°7) à un, toutes les sorties passent à zéro. En effet, comme son nom l'indique cette broche sert à effacer l'afficheur. Si vous ne voulez pas l'utiliser il faut donc la connecter à la masse pour la désactiver ;
- Les entrées A, B, C et D (broches 5,3,2 et 4 respectivement) sont actives à l'état HAUT. Les sorties elles sont actives à l'état BAS (pour piloter un afficheur à anode commune) **OU** HAUT selon l'état de la broche PH (6). C'est là un gros avantage de ce composant, il peut inverser la logique de la sortie, le rendant alors compatible avec des afficheurs à anode commune (broche PH à l'état 1) ou cathode commune (Ph = 0) ;
- La broche BI (Blank Input, n°7) sers à inhiber les entrées. On ne s'en servira pas et donc on la mettra à l'état HAUT (+5V) ;
- LD (n°1) sert à faire une mémoire de l'état des sorties, on ne s'en servira pas ici. Elle signifie "Latch Disable". En la mettant à 1 on désactive donc le "latch" (verrou) et nos entrées sont alors bien prises en considération ;
- Enfin, les deux broches d'alimentation sont la 8 (GND/VSS, masse) et la 16 (VCC, +5V).

[[a]]
|N'oubliez pas de mettre des résistances de limitations de courant entre chaque segment et la broche de signal du circuit!

## Fonctionnement

[[q]]
|C'est bien beau tout ça mais comment je lui dis au décodeur d'afficher le chiffre 5 par exemple ?

Il suffit de regarder le datasheet et sa table de vérité (c'est le tableau avec les entrées et les sorties).
Ce que reçoit le décodeur sur ses entrées (A, B, C et D) défini les états de ses broches de sortie (a,b,c,d,e,f et g).
C'est tout ! Donc, on va donner un code binaire sur 4 bits à notre décodeur et en fonction de ce code, le décodeur affichera le caractère voulu.
En plus le fabricant est sympa, il met à disposition des notes d'applications à la page 6 pour bien brancher le composant :

![Branchement du MC14543B](/media/galleries/954/173796d5-df34-4b05-8e7d-bd411bf641d8.png.960x960_q85.jpg)
Figure: Branchement du MC14543B - (source: datasheet)

On voit alors qu'il suffit simplement de brancher la résistance entre le CI et les segments et s'assurer que PH à la bonne valeur et c'est tout !
En titre d'exercice afin de vous permettre de mieux comprendre, je vous propose de changer les états des entrées A, B, C et D du décodeur pour observer ce qu'il affiche. Après avoir réaliser votre schéma, regarder s'il correspond avec celui présent dans cette balise secrète. Cela vous évitera peut-être un mauvais branchement, qui sait ?

[[secret]]
| ![Montage 7 segments - Schéma](/media/galleries/954/1ad0e0b6-59a1-4fbf-8b39-1a987ee252cf.png.960x960_q85.png)
|
| ![Montage 7 segments - Montage](/media/galleries/954/2ad54518-6564-4fe2-9b55-ee30b4a6899c.png.960x960_q85.png)


# L'affichage par alternance

La seconde technique est utilisée dans le cas où l'on veut faire un affichage avec plusieurs afficheurs.
Elle utilise le phénomène de [persistance rétinienne](http://fr.wikipedia.org/wiki/Persistance_r%C3%A9tinienne).
Pour faire simple, c'est grâce à cela que le cinéma vous parait fluide.
On change une image toutes les 40 ms et votre œil n'a pas le temps de le voir, donc les images semble s'enchainer sans transition.
Bref... Ici, la même stratégie sera utilisée. On va allumer un afficheur un certain temps, puis nous allumerons l'autre en éteignant le premier.
Cette action est assez simple à réaliser, mais nécessite l'emploi de deux broche supplémentaires, de quatre autres composants et d'un peu de code.
Nous l'étudierons un petit peu plus tard, lorsque nous saurons géré un afficheur seul.

*[BCD]: Binary Coded Decimal ou Binaire Codé Décimal