Pour commencer, nous allons prendre en main un afficheur et lui faire s'afficher notre premier chiffre ! C'est assez simple et ne requiert qu'un programme très simple, mais un peu rébarbatif.

# Schéma de connexion

Je vais reprendre le schéma précédent, mais je vais connecter chaque broche de l'afficheur à une sortie de la carte Arduino. Comme ceci :

![7 segments schéma](/media/galleries/954/170f4f69-7cd4-4aed-bb39-0257ab5fdc35.png.960x960_q85.jpg)

![Afficheur 7 segments montage](/media/galleries/954/2ad69e5b-aa6c-469e-ba0d-8e29ded10521.png.960x960_q85.png)

Vous voyez donc que chaque LED de l'afficheur va être commandée séparément les unes des autres.
Il n'y a rien de plus à faire, si ce n'est qu'à programmer...

# Le programme

L'objectif du programme va être d'afficher un chiffre. Eh bien... c'est partit ! Quoi ?!
Vous voulez de l'aide ? o_O Ben je vous ai déjà tout dit y'a plus qu'à faire.
En plus vous avez un tableau avec lequel vous pouvez vous aider pour afficher votre chiffre.
Cherchez, je vous donnerais la solution ensuite.


[[secret]]
| ```cpp
| /* On assigne chaque LED à une broche de l'arduino */
| const int A = 2;
| const int B = 3;
| const int C = 4;
| const int D = 5;
| const int E = 6;
| const int F = 7;
| const int G = 8;
| // notez que l'on ne gère pas l'affichage du point,
| // mais vous pouvez le rajouter si cela vous chante
|
| void setup()
| {
|     // définition des broches en sortie
|     pinMode(A, OUTPUT);
|     pinMode(B, OUTPUT);
|     pinMode(C, OUTPUT);
|     pinMode(D, OUTPUT);
|     pinMode(E, OUTPUT);
|     pinMode(F, OUTPUT);
|     pinMode(G, OUTPUT);
|
|     // mise à l'état HAUT de ces sorties pour éteindre les LED de l'afficheur
|     digitalWrite(A, HIGH);
|     digitalWrite(B, HIGH);
|     digitalWrite(C, HIGH);
|     digitalWrite(D, HIGH);
|     digitalWrite(E, HIGH);
|     digitalWrite(F, HIGH);
|     digitalWrite(G, HIGH);
| }
|
| void loop()
| {
|     // affichage du chiffre 5, d'après le tableau précédent
|     digitalWrite(A, LOW);
|     digitalWrite(B, HIGH);
|     digitalWrite(C, LOW);
|     digitalWrite(D, LOW);
|     digitalWrite(E, HIGH);
|     digitalWrite(F, LOW);
|     digitalWrite(G, LOW);
| }
| ```
| Code: Solution

Vous le voyez par vous-même, c'est un code hyper simple.
Essayez de le bidouiller pour afficher des messages, par exemple, en utilisant les fonctions introduisant le temps.
Ou bien compléter ce code pour afficher tous les chiffres, en fonction d'une variable définie au départ (ex: var = 1, affiche le chiffre 1 ; etc.).