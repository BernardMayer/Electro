Vous connaissez les afficheurs 7 segments ? Ou alors vous ne savez pas que ça s'appelle comme ça ? Il s'agit des petites lumières qui forment le chiffre 8 et qui sont de couleur rouge ou verte, la plupart du temps, mais peuvent aussi être bleus, blancs, etc. On en trouve beaucoup dans les radio-réveils, car ils servent principalement à afficher l'heure. Autre particularité, non seulement de pouvoir afficher des chiffres (0 à 9), ils peuvent également afficher certaines lettres de l'alphabet.

## Matériel

Pour ce chapitre, vous aurez besoin de :

- Un (et plus) afficheur 7 segments (évidemment)
- 8 résistances de $330\Omega$
- Un (ou deux) décodeurs BCD 7 segments
- Une carte Arduino ! Mais dans un premier temps on va d'abord bien saisir le truc avant de faire du code :) 

Nous allons commencer par une découverte de l'afficheur, comment il fonctionne et comment le branche-t-on. Ensuite nous verrons comment l'utiliser avec la carte Arduino. Enfin, le chapitre suivant amènera un TP résumant les différentes parties vues.