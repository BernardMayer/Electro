Nous y sommes, nous allons (enfin) utiliser la carte Arduino pour faire un affichage plus poussé qu'un unique afficheur.
Pour cela, nous allons très simplement utiliser le montage précédent composé du décodeur BCD, de l'afficheur 7 segments et bien entendu des résistances de limitations de courant pour les LED de l'afficheur.
Je vais vous montrer deux techniques qui peuvent être employées pour faire le programme.

# Initialisation

Vous avez l'habitude maintenant, nous allons commencer par définir les différentes broches d'entrées/sorties.
Pour débuter (et conformément au schéma), nous utiliserons seulement 4 broches, en sorties, correspondantes aux entrées du décodeur 7 segments.
Voici le code pouvant traduire cette explication :

```cpp
const int bit_A = 2;
const int bit_B = 3;
const int bit_C = 4;
const int bit_D = 5;

void setup()
{
    // on met les broches en sorties
    pinMode(bit_A, OUTPUT);
    pinMode(bit_B, OUTPUT);
    pinMode(bit_C, OUTPUT);
    pinMode(bit_D, OUTPUT);

    // on commence par écrire le chiffre 0, donc toutes les sorites à l'état bas
    digitalWrite(bit_A, LOW);
    digitalWrite(bit_B, LOW);
    digitalWrite(bit_C, LOW);
    digitalWrite(bit_D, LOW);
}
```
Code: Initialisation des broches

Ce code permet juste de déclarer les quatre broches à utiliser, puis les affectes en sorties.
On les met ensuite toutes les quatre à zéro. Maintenant que l'afficheur est prêt, nous allons pouvoir commencer à afficher un chiffre !

# Programme principal

Si tout se passe bien, en ayant la boucle vide pour l'instant vous devriez voir un superbe 0 sur votre afficheur.
Nous allons maintenant mettre en place un petit programme pour afficher les nombres de 0 à 9 en les incrémentant (à partir de 0) toutes les secondes. C'est donc un compteur.
Pour cela, on va utiliser une boucle, qui comptera de 0 à 9. Dans cette boucle, on exécutera appellera la fonction `afficher()` qui s'occupera donc de l'affichage (belle démonstration de ce qui est une évidence :P ^^ ).

```cpp
void loop()
{
    char i=0; // variable "compteur"
    for(i=0; i<10; i++)
    {
        afficher(i); // on appel la fonction d'affichage
        delay(1000); // on attend 1 seconde
    }
}
```
Code: Le compteur

# Fonction d'affichage

Nous touchons maintenant au but ! Il ne nous reste plus qu'à réaliser la fonction d'affichage pour pouvoir convertir notre variable en chiffre sur l'afficheur. Pour cela, il existe différentes solutions.
Nous allons en voir ici une qui est assez simple à mettre en œuvre mais qui nécessite de bien être comprise.
Dans cette méthode, on va faire des opérations mathématiques (tout de suite c'est moins drôle :lol: ) successives pour déterminer quels bits mettre à l'état haut. Rappelez-vous, nous avons quatre broches à notre disposition, avec chacune un poids différent (8, 4, 2 et 1). En combinant ces différentes broches ont peu obtenir n'importe quel nombre de 0 à 15. Voici une démarche mathématique envisageable :

->![Organigramme décodeur 7 segments](/media/galleries/954/7fc21f7c-3d4d-4207-827e-5ebbb3f35c9a.png.960x960_q85.jpg)<-

On peut coder cette méthode de manière assez simple et direct, en suivant cet organigramme :

```cpp
// fonction écrivant sur un seul afficheur
void afficher(char chiffre)
{
    // on met à zéro tout les bits du décodeur
    digitalWrite(bit_A, LOW);
    digitalWrite(bit_B, LOW);
    digitalWrite(bit_C, LOW);
    digitalWrite(bit_D, LOW);

    // On allume les bits nécessaires
    if(chiffre >= 8)
    {
        digitalWrite(bit_D, HIGH);
        chiffre = chiffre - 8;
    }
    if(chiffre >= 4)
    {
        digitalWrite(bit_C, HIGH);
        chiffre = chiffre - 4;
    }
    if(chiffre >= 2)
    {
        digitalWrite(bit_B, HIGH);
        chiffre = chiffre - 2;
    }
    if(chiffre >= 1)
    {
        digitalWrite(bit_A, HIGH);
        chiffre = chiffre - 1;
    }
}
```
Code: Implémentation de l'affichage

Quelques explications s'imposent...
Le code gérant l'affichage réside sur les valeurs binaires des chiffres. Rappelons les valeurs binaires des chiffres :

->

+---------------+------------------+
|Chiffre        |DCBA              |
+===============+==================+
|0              |$(0000)_2$        |
+---------------+------------------+
|1              |$(0001)_2$        |
+---------------+------------------+
|2              |$(0010)_2$        |
+---------------+------------------+
|3              |$(0011)_2$        |
+---------------+------------------+
|4              |$(0100)_2$        |
+---------------+------------------+
|5              |$(0101)_2$        |
+---------------+------------------+
|6              |$(0110)_2$        |
+---------------+------------------+
|7              |$(0111)_2$        |
+---------------+------------------+
|8              |$(1000)_2$        |
+---------------+------------------+
|9              |$(1001)_2$        |
+---------------+------------------+

Table: La représentation binaires des chiffres

<-

D'après ce tableau, si on veut le chiffre 8, on doit allumer le segment D, car 8 s'écrit $(1000)_2$ ayant pour segment respectif DCBA.
Soit D=1, C=0, B=0 et A=0.
En suivant cette logique, on arrive à déterminer les entrées du décodeur qui sont à mettre à l'état HAUT ou BAS.
D'une manière plus lourde, on aurait pu écrire un code ressemblant à ça :

```cpp
// fonction écrivant sur un seul afficheur
void afficher(char chiffre)
{
    switch(chiffre)
    {
    case 0 :
        digitalWrite(bit_A, LOW);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, LOW);
        break;
    case 1 :
        digitalWrite(bit_A, HIGH);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, LOW);
        break;
    case 2 :
        digitalWrite(bit_A, LOW);
        digitalWrite(bit_B, HIGH);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, LOW);
        break;
    case 3 :
        digitalWrite(bit_A, HIGH);
        digitalWrite(bit_B, HIGH);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, LOW);
        break;
    case 4 :
        digitalWrite(bit_A, LOW);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, HIGH);
        digitalWrite(bit_D, LOW);
        break;
    case 5 :
        digitalWrite(bit_A, HIGH);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, HIGH);
        digitalWrite(bit_D, LOW);
        break;
    case 6 :
        digitalWrite(bit_A, LOW);
        digitalWrite(bit_B, HIGH);
        digitalWrite(bit_C, HIGH);
        digitalWrite(bit_D, LOW);
        break;
    case 7 :
        digitalWrite(bit_A, HIGH);
        digitalWrite(bit_B, HIGH);
        digitalWrite(bit_C, HIGH);
        digitalWrite(bit_D, LOW);
        break;
    case 8 :
        digitalWrite(bit_A, LOW);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, HIGH);
        break;
    case 9 :
        digitalWrite(bit_A, HIGH);
        digitalWrite(bit_B, LOW);
        digitalWrite(bit_C, LOW);
        digitalWrite(bit_D, HIGH);
        break;
    }
}
```
Code: L'affichage DCBA version longue

Mais, c'est bien trop lourd à écrire. Enfin c'est vous qui voyez. ;)