Maintenant que nous avons affiché un chiffre sur un seul afficheur, nous allons pouvoir apprendre à en utiliser plusieurs (avec un minimum de composants en plus !). Comme expliqué précédemment, la méthode employée ici va reposer sur le principe de la persistance rétinienne, qui donnera *l'impression* que les deux afficheurs fonctionnent en *même temps*.

# Problématique

Nous souhaiterions utiliser deux afficheurs, mais nous ne disposons que de seulement 6 broches sur notre Arduino, le reste des broches étant utilisé pour une autre application.
Pour réduire le nombre de broches, on peut d'ores et déjà utilisé un décodeur BCD, ce qui nous ferait 4 broches par afficheurs, soit 8 broches au total. Bon, ce n'est toujours pas ce que l'on veut.
Et si on connectait les deux afficheurs ensemble, en parallèle, sur les sorties du décodeur ?
Oui mais dans ce cas, on ne pourrait pas afficher des chiffres différents sur chaque afficheur.
Tout à l'heure, je vous ai parlé de *commutation*. Oui, la seule solution qui soit envisageable est d'allumer un afficheur et d'éteindre l'autre tout en les connectant ensemble sur le même décodeur.
Ainsi un afficheur s'allume, il affiche le chiffre voulu, puis il s'éteint pour que l'autre puisse s'allumer à son tour.
Cette opération est en fait un clignotement de chaque afficheur par alternance.

# Un peu d'électronique...

Pour faire commuter nos deux afficheurs, vous allez avoir besoin d'un nouveau composant, j'ai nommé : le **transistor** !

[[q]]
|Transistor ? J'ai entendu dire qu'il y en avait plusieurs milliards dans nos ordinateurs ?

Et c'est tout à fait vrai.
Des transistors, il en existe de différents types et pour différentes applications :
amplification de courant/tension, commutation, etc. répartis dans plusieurs familles.
Bon je ne vais pas faire trop de détails, si vous voulez en savoir plus, allez lire la première partie de **ce chapitre** ~(*lien à rajouter, en attente de la validation du chapitre en question*)~.

## Le transistor bipolaire : présentation

Je le disais, je ne vais pas faire de détails. On va voir comment fonctionne un transistor bipolaire selon les besoins de notre application, à savoir, faire commuter les afficheurs.
Un transistor, cela ressemble à ça :

![Photo d'un transistor](http://zestedesavoir.com/media/galleries/954/717ba214-cdf0-4ef9-b782-10d831c35fe0.jpg.960x960_q85.jpg)
Figure: Photo d'un transistor - (CC-BY-SA, [Marvelshine](http://commons.wikimedia.org/wiki/File:BC548.jpg))

Pour notre application, nous allons utiliser des **transistors bipolaires**.
Je vais vous expliquer comment cela fonctionne.
Déjà, vous pouvez observer qu'un transistor possède trois pattes.
Cela n'est pas de la moindre importance, au contraire il s'agit là d'une chose essentielle !
En fait, le transistor bipolaire à une *broche d'entrée* (**collecteur**), une *broche de sortie* (**émetteur**) et une *broche de commande* (**base**).
Son symbole est le suivant :

![Symbole du transistor bipôlaire](/media/galleries/954/0b618389-3a8c-4b38-9158-7292be1c3590.png.960x960_q85.png)

[[i]]
|Ce symbole est celui d'un transistor bipolaire de **type NPN**.

Il en existe qui sont de **type PNP**, mais ils sont beaucoup moins utilisés que les NPN.
Quoi qu'il en soit, nous n'utiliserons que des transistors NPN dans ce chapitre.


## Fonctionnement en commutation du transistor bipolaire

Pour faire simple, **le transistor bipolaire NPN** (c'est la dernière fois que je précise ce point) est un **interrupteur commandé en courant**.

[[a]]
|Ceci est une présentation très vulgarisée et simplifiée sur le transistor pour l'utilisation que nous en ferons ici.
|Les usages et possibilités des transistors sont très nombreux et ils mériteraient un grand livre à eux seuls !
|Si vous voulez plus d'informations, rendez-vous sur le cours sur l'électronique ou approfondissez en cherchant des tutoriels sur le web. ;)

C'est tout ce qu'il faut savoir, pour ce qui est du fonctionnement.
Après, on va voir ensemble comment l'utiliser et sans le faire griller ! ^^

## Utilisation générale

On peut utiliser notre transistor de deux manières différentes (pour notre application toujours, mais on peut bien évidemment utiliser le transistor avec beaucoup plus de flexibilités).
A commencer par le câblage :

![Câblage du transistor en commutation](/media/galleries/954/5a941448-52f6-49a9-b0a1-d5c655c3ad86.png.960x960_q85.jpg)

Dans le cas présent, le collecteur (qui est l'entrée du transistor) se trouve être après l'ampoule, elle-même connectée à l'alimentation.
L'émetteur (broche où il y a la flèche) est relié à la masse du montage.
Cette disposition est "universelle", on ne peut pas inverser le sens de ces broches et mettre le collecteur à la place de l'émetteur et vice versa.
Sans quoi, le montage ne fonctionnerait pas. Pour le moment, l'ampoule est éteinte car le transistor ne conduit pas.
On dit qu'il est **bloqué** et empêche donc le courant $I_C$ de circuler à travers l'ampoule.
Soit $I_C = 0$ car $I_B = 0$. A présent, appuyons sur l'interrupteur :

![Allumage de la lampe](/media/galleries/954/865e0f9d-e814-409a-8d12-16623929291c.png.960x960_q85.jpg)

Que se passe-t-il ? Eh bien la base du transistor, qui était jusqu'à présent "en l'air", est parcourue par un courant électrique. Cette cause à pour conséquence de rendre le transistor **passant** ou **saturé** et permet au courant de s'établir à travers l'ampoule. Soit $I_C \ne 0$ car $I_B \ne 0$.

[[i]]
|La résistance sur la base du transistor permet de le protéger des courants trop forts.
|Plus la résistance est de faible valeur, plus l'ampoule sera lumineuse.
|A l'inverse, une résistance trop forte sur la base du transistor pourra l'empêcher de conduire et de faire s'allumer l'ampoule.
|Rassurez_vous, je vous donnerais les valeurs de résistances à utiliser. ;)


## Utilisation avec nos afficheurs

Voyons un peu comment on va pouvoir utiliser ce transistor avec notre Arduino.
La carte Arduino est en fait le générateur de tension (schéma précédent) du montage.
Elle va définir si sa sortie est de 0V (transistor bloqué) ou de 5V (transistor saturé).
Ainsi, on va pouvoir allumer ou éteindre les afficheurs.
Voilà le modèle équivalent de la carte Arduino et de la commande de l'afficheur :

![Montage de la commande](/media/galleries/954/7224932a-6bf9-454d-948e-956af31d706c.png)

La carte Arduino va soit mettre à la masse la base du transistor, soit la mettre à +5V.
Dans le premier cas, il sera bloqué et l'afficheur sera éteint, dans le second il sera saturé et l'afficheur allumé.
Il en est de même pour chaque broche de l'afficheur. Elles seront au +5V ou à la masse selon la configuration que l'on aura définie dans le programme.

## Schéma final

Et comme vous l’attendez surement depuis tout à l'heure, voici le schéma tant attendu (nous verrons juste après comment programmer ce nouveau montage) !

![2*7 segments - Schéma](/media/galleries/954/92eeb2ec-3a61-4da4-8d67-0834aa83a43d.png.960x960_q85.png)

![2*7 segments - Montage](/media/galleries/954/9e9db3ba-3600-4228-85ea-b73381ae2736.png.960x960_q85.png)

# Quelques détails techniques


- Dans notre cas (et je vous passe les détails vraiment techniques et calculatoires), la résistance sur la base du transistor sera de $2.2k\Omega$ (si vous n'avez pas cette valeur, elle pourra être de $3.3k\Omega$, ou encore de $3.9k\Omega$, voir même de $4.7k\Omega$).
- Les transistors seront des transistors bipolaires NPN de référence 2N2222, ou bien un équivalent qui est le BC547. Il en faudra deux donc.
- Le décodeur BCD est le même que précédemment (ou équivalent).

Et avec tout ça, on est prêt pour programmer ! :)

# ...et de programmation

Nous utilisons deux nouvelles broches servant à piloter chacun des interrupteurs (transistors).
Chacune de ces broches doivent donc être déclarées en global (pour son numéro) puis régler comme sortie.
Ensuite, il ne vous restera plus qu'à alimenter chacun des transistors au bon moment pour allumer l'afficheur souhaité.
En synchronisant l'allumage avec la valeur envoyé au décodeur, vous afficherez les nombres souhaités comme bon vous semble.
Voici un exemple de code complet, de la fonction setup() jusqu'à la fonction d'affichage.
Ce code est commenté et vous ne devriez donc avoir aucun mal à le comprendre !
Ce programme est un compteur sur 2 segments, il compte donc de 0 à 99 et recommence au début dès qu'il a atteint 99.
La vidéo se trouve juste après ce code.

```cpp
// définition des broches du décodeur 7 segments
// (vous pouvez changer les numéros si vous voulez)
const int bit_A = 2;
const int bit_B = 3;
const int bit_C = 4;
const int bit_D = 5;

// définitions des broches des transistors pour chaque afficheur
const int alim_dizaine = 6; // les dizaines
const int alim_unite = 7;   // les unites

void setup()
{
    // Les broches sont toutes des sorties
    pinMode(bit_A, OUTPUT);
    pinMode(bit_B, OUTPUT);
    pinMode(bit_C, OUTPUT);
    pinMode(bit_D, OUTPUT);
    pinMode(alim_dizaine, OUTPUT);
    pinMode(alim_unite, OUTPUT);

    // Les broches sont toutes mises à l'état bas
    digitalWrite(bit_A, LOW);
    digitalWrite(bit_B, LOW);
    digitalWrite(bit_C, LOW);
    digitalWrite(bit_D, LOW);
    digitalWrite(alim_dizaine, LOW);
    digitalWrite(alim_unite, LOW);
}

void loop() // fonction principale
{
    // boucle qui permet de compter de 0 à 99 (= 100 valeurs)
    for(char i = 0; i<100; i++)
    {
        // appel de la fonction affichage avec envoi du nombre à afficher
        afficher_nombre(i);
    }
}

// fonction permettant d'afficher un nombre sur deux afficheurs
void afficher_nombre(char nombre)
{
    long temps; // variable utilisée pour savoir le temps écoulé...
    char unite = 0, dizaine = 0; // variable pour chaque afficheur

    if(nombre > 9) // si le nombre reçu dépasse 9
    {
        dizaine = nombre / 10; // on récupère les dizaines
    }

    unite = nombre - (dizaine*10); // on récupère les unités

    temps = millis(); // on récupère le temps courant

    // tant qu'on a pas affiché ce chiffre pendant au moins 500 millisecondes
    // permet donc de pouvoir lire le nombre affiché
    while((millis()-temps) < 500)
    {
        // on affiche le nombre

        // d'abord les dizaines pendant 10 ms

        // le transistor de l'afficheur des dizaines est saturé,
        // donc l'afficheur est allumé
        digitalWrite(alim_dizaine, HIGH);
        // on appel la fonction qui permet d'afficher le chiffre dizaine
        afficher(dizaine);
        // l'autre transistor est bloqué et l'afficheur éteint
        digitalWrite(alim_unite, LOW);
        delay(10);

        // puis les unités pendant 10 ms

        // on éteint le transistor allumé
        digitalWrite(alim_dizaine, LOW);
        // on appel la fonction qui permet d'afficher le chiffre unité
        afficher(unite);
        // et on allume l'autre
        digitalWrite(alim_unite, HIGH);
        delay(10);
    }
}

// fonction écrivant sur un seul afficheur
// on utilise le même principe que vu plus haut
void afficher(char chiffre)
{
    digitalWrite(bit_A, LOW);
    digitalWrite(bit_B, LOW);
    digitalWrite(bit_C, LOW);
    digitalWrite(bit_D, LOW);

    if(chiffre >= 8)
    {
        digitalWrite(bit_D, HIGH);
        chiffre = chiffre - 8;
    }
    if(chiffre >= 4)
    {
        digitalWrite(bit_C, HIGH);
        chiffre = chiffre - 4;
    }
    if(chiffre >= 2)
    {
        digitalWrite(bit_B, HIGH);
        chiffre = chiffre - 2;
    }
    if(chiffre >= 1)
    {
        digitalWrite(bit_A, HIGH);
        chiffre = chiffre - 1;
    }
}
```
Code: Le compteur de 0 à 99


Voilà donc la vidéo présentant le résultat final :

->!(https://www.youtube.com/watch?v=zgvV25s_ilQ)<-