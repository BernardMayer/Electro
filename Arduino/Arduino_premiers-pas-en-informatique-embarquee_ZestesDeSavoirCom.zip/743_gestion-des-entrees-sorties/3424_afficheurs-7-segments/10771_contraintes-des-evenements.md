Comme vous l'avez vu juste avant, afficher de manière alternative n'est pas trop difficile.
Cependant, vous avez surement remarqué, nous avons utilisé des fonctions bloquantes (delay).
Si jamais un évènement devait arriver pendant ce temps, nous aurions beaucoup de chance de le rater car il pourrait arriver "pendant" un délai d'attente pour l'affichage.
Pour parer à cela, je vais maintenant vous expliquer une autre méthode, préférable, pour faire de l'affichage.
Elle s'appuiera sur l'utilisation de la fonction millis(), qui nous permettra de générer une boucle de rafraîchissement de l'affichage.
Voici un organigramme qui explique le principe :

->![organigramme de rafraichissement](/media/galleries/954/84ec07aa-5f32-48f9-aa61-6ba52a52eb47.png.960x960_q85.jpg)<-

Comme vous pouvez le voir, il n'y a plus de fonction qui "attend".
Tout se passe de manière continue, sans qu'il n'y ai jamais de pause.
Ainsi, aucun évènement ne sera raté (en théorie, un évènement trèèèèèès rapide pourra toujours passer inaperçu).
Voici un exemple de programmation de la boucle principal (suivi de ses fonctions annexes) :

```cpp
bool afficheur = false; // variable pour le choix de l'afficheur

// --- setup() ---

void loop()
{
    // gestion du rafraichissement
    // si ça fait plus de 10 ms qu'on affiche,
    // on change de 7 segments (alternance unité <-> dizaine)
    if((millis() - temps) > 10)
    {
        // on inverse la valeur de "afficheur"
        // pour changer d'afficheur (unité ou dizaine)
        afficheur = !afficheur;
        // on affiche la valeur sur l'afficheur
        // afficheur : true->dizaines, false->unités
        afficher_nombre(valeur, afficheur);
        temps = millis(); // on met à jour le temps
    }

    // ici, on peut traiter les évènements (bouton...)
}

// fonction permettant d'afficher un nombre
// elle affiche soit les dizaines soit les unités
void afficher_nombre(char nombre, bool afficheur)
{
    char unite = 0, dizaine = 0;
    if(nombre > 9)
        dizaine = nombre / 10; // on recupere les dizaines
    unite = nombre - (dizaine*10); // on recupere les unités

    // si "
    if(afficheur)
    {
        // on affiche les dizaines
        digitalWrite(alim_unite, LOW);
        afficher(dizaine);
        digitalWrite(alim_dizaine, HIGH);
    }
    else // égal à : else if(!afficheur)
    {
        // on affiche les unités
        digitalWrite(alim_dizaine, LOW);
        afficher(unite);
        digitalWrite(alim_unite, HIGH);
    }
}

// fonction écrivant sur un seul afficheur
void afficher(char chiffre)
{
    digitalWrite(bit_A, LOW);
    digitalWrite(bit_B, LOW);
    digitalWrite(bit_C, LOW);
    digitalWrite(bit_D, LOW);

    if(chiffre >= 8)
    {
        digitalWrite(bit_D, HIGH);
        chiffre = chiffre - 8;
    }
    if(chiffre >= 4)
    {
        digitalWrite(bit_C, HIGH);
        chiffre = chiffre - 4;
    }
    if(chiffre >= 2)
    {
        digitalWrite(bit_B, HIGH);
        chiffre = chiffre - 2;
    }
    if(chiffre >= 1)
    {
        digitalWrite(bit_A, HIGH);
        chiffre = chiffre - 1;
    }
}
```
Code: L'affichage de deux chiffres en utilisant `millis`

[[i]]
|Si vous voulez tester le phénomène de persistance rétinienne, vous pouvez changer le temps de la boucle de rafraichissement (ligne 9). Si vous l'augmenter, vous commencerez à vois les afficheurs clignoter.
|En mettant une valeur d'un peu moins de une seconde vous verrez les afficheurs s'illuminer l'un après l'autre.