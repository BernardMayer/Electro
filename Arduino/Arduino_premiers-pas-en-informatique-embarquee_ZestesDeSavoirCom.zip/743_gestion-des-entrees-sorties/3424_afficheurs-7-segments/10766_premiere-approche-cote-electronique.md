# Un peu (beaucoup) d'électronique

Comme son nom l'indique, l'afficheur 7 segments possède... 7 segments.
Mais un segment c'est quoi au juste ? Et bien c'est une portion de l'afficheur, qui est allumée ou éteinte pour réaliser l'affichage.
Cette portion n'est en fait rien d'autre qu'une LED qui au lieu d'être ronde comme d'habitude est plate et encastré dans un boiter.
On dénombre donc 8 portions en comptant le point de l'afficheur (mais il ne compte pas en tant que segment à part entière car il n'est pas toujours présent).
Regardez à quoi ça ressemble :

![Un afficheur 7 segments](http://zestedesavoir.com/media/galleries/954/4469fc50-e3e7-4bcb-be45-59799915e007.jpg.960x960_q85.jpg)
Figure: Un afficheur 7 segments - (CC-BY-SA, [Pengo](http://commons.wikimedia.org/wiki/File:Seven_segment_02_Pengo.jpg))

## Des LED, encore des LED

Et des LED, il y en a ! Entre 7 et 8 selon les modèles (c'est ce que je viens d'expliquer), voir beaucoup plus, mais on ne s'y attardera pas dessus.
Voici un schéma vous présentant un modèle d'afficheur sans le point (qui au final est juste une LED supplémentaire rappelez-vous) :

![Schéma de l'afficheur 7segments](/media/galleries/954/a5c2a7b9-9adf-458b-895b-308cc60ccfb8.gif.960x960_q85.png)

*Les interrupteurs a,b,c,d,e,f,g représentent les signaux pilotant chaque segments*

Comme vous le voyez sur ce schéma, toutes les LED possèdent une broche commune, reliée entre elle.
Selon que cette broche est la cathode ou l'anode on parlera d'afficheur à cathode commune ou... anode commune (vous suivez ?).
Dans l'absolu, ils fonctionnent de la même façon, seule la manière de les brancher diffère (actif sur état bas ou sur état haut).

## Cathode commune ou Anode commune

Dans le cas d'un afficheur à cathode commune, toutes les cathodes sont reliées entre elles en un seul point lui-même connecté à la masse.
Ensuite, chaque anode de chaque segment sera reliée à une broche de signal.
Pour allumer chaque segment, le signal devra être une tension positive.
En effet, si le signal est à 0, il n'y a pas de différence de potentiel entre les deux broches de la LED et donc elle ne s'allumera pas !
Si nous sommes dans le cas d'une anode commune, les anodes de toutes les LED sont reliées entre elles en un seul point qui sera connecté à l'alimentation.
Les cathodes elles seront reliées une par une aux broches de signal. En mettant une broche de signal à 0, le courant passera et le segment en question s'allumera.
Si la broche de signal est à l'état haut, le potentiel est le même de chaque côté de la LED, donc elle est bloquée et ne s'allume pas !
Que l'afficheur soit à anode ou à cathode commune, on doit toujours prendre en compte qu'il faut ajouter une résistance de limitation de courant entre la broche isolée et la broche de signal.
Traditionnellement, on prendra une résistance de $330\Omega$ pour une tension de +5V, mais cela se calcul (cf. chapitre 1, partie 2).

+ Si vous voulez augmenter la luminosité, il suffit de diminuer cette valeur.
+ Si au contraire vous voulez diminuer la luminosité, augmenter la résistance.

## Choix de l'afficheur

Pour la rédaction j'ai fait le choix d'utiliser des afficheurs à anode commune et ce n'est pas anodin.
En effet et on l'a vu jusqu'à maintenant, on branche les LED du +5V vers la broche de la carte Arduino.
Ainsi, dans le cas d'un afficheur à anode commune, les LED seront branchés d'un côté au +5V, et de l'autre côté aux broches de signaux.
Ainsi, pour allumer un segment on mettra la broche de signal à 0 et on l'éteindra en mettant le signal à 1. On a toujours fait comme ça depuis le début, ça ne vous posera donc aucun problème. ;)

# Branchement "complet" de l'afficheur

Nous allons maintenant voir comment brancher l'afficheur à anode commune.

## Présentation du boîtier

Les afficheurs 7 segments se présentent sur un *boîtier* de type DIP 10.*
Le format DIP régie l'espacement entre les différentes broches du circuit intégré ainsi que d'autres contraintes (présence d'échangeur thermique etc...).
Le chiffre 10 signifie qu'il possède 10 broches (5 de part et d'autre du boitier).
Voici une représentation de ce dernier (à gauche) :

![Boîtier du 7 segments](/media/galleries/954/c4601ac3-40d1-4ecf-bca4-dfc67c1203e3.gif.960x960_q85.jpg)
Figure: Boîtier du 7 segments - (source: datasheet)

![7 segments](/media/galleries/954/2fd1990f-9bba-47d6-9aae-ca89c66eaed6.png.960x960_q85.png)
Figure: Dénomination des segments - (CC-BY-SA, [h2g2bob](http://commons.wikimedia.org/wiki/File:7_segment_display_labeled.svg))

Voici la signification des différentes broches :

1. LED de la cathode E
2. LED de la cathode D
3. Anode commune des LED
4. LED de la cathode C
5. (facultatif) le point décimal.
6. LED de la cathode B
7. LED de la cathode A
8. Anode commune des LED
9. LED de la cathode F
10. LED de la cathode G

Pour allumer un segment c'est très simple, il suffit de le relier à la masse !

[[e]]
|Nous cherchons à allumer les LED de l'afficheur, il est donc impératif de ne pas oubliez les résistances de limitations de courant !

## Exemple

Pour commencer, vous allez tout d'abord mettre l'afficheur à cheval sur la plaque d'essai (breadboard).
Ensuite, trouvez la broche représentant l'anode commune et reliez la à la future colonne du +5V. Prochaine étape, mettre une résistance sur chaque broche de signal.
Enfin, reliez quelques une de ces résistances à la masse. Si tous se passe bien, les segments reliés à la masse via leur résistance doivent s'allumer lorsque vous alimentez le circuit.
Voici un exemple de branchement :

![7 segments schéma](/media/galleries/954/170f4f69-7cd4-4aed-bb39-0257ab5fdc35.png.960x960_q85.jpg)

![7 segments breadboard](/media/galleries/954/2f66a59b-d203-47ee-a1f5-e0b56d3260ee.png.960x960_q85.png)

Dans cet exemple de montage, vous verrez que tous les segment de l'afficheur s'allument ! Vous pouvez modifier le montage en déconnectant quelques unes des résistance de la masse et afficher de nombreux caractères.

[[a]]
|Pensez à couper l'alimentation lorsque vous changer des fils de place.
Les composants n'aiment pas forcément être (dé)branchés lorsqu'ils sont alimentés. Vous pourriez éventuellement leur causer des dommages.


## Seulement 7 segments mais plein de caractère(s) !

Vous l'avez peut-être remarqué avec "l'exercice" précédent, un afficheurs 7 segments ne se limite pas à afficher juste des chiffres.
Voici un tableau illustrant les caractères possibles et quels segments allumés.
Attention, il est possible qu'il manque certains caractères !

->

+---------------+--------+--------+--------+--------+--------+--------+--------+
|Caractère      |seg. A  |seg. B  |seg. C  |seg. D  |seg. E  |seg. F  |seg. G  |
+===============+========+========+========+========+========+========+========+
|0              |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|1              |        |->x<-   |->x<-   |        |        |        |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|2              |->x<-   |->x<-   |        |->x<-   |->x<-   |        |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|3              |->x<-   |->x<-   |->x<-   |->x<-   |        |        |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|4              |        |->x<-   |->x<-   |        |        |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|5              |->x<-   |        |->x<-   |->x<-   |        |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|6              |->x<-   |        |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|7              |->x<-   |->x<-   |->x<-   |        |        |        |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|8              |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|9              |->x<-   |->x<-   |->x<-   |->x<-   |        |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|A              |->x<-   |->x<-   |->x<-   |        |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|b              |        |        |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|C              |->x<-   |        |        |->x<-   |->x<-   |->x<-   |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|d              |        |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|E              |->x<-   |        |        |->x<-   |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|F              |->x<-   |        |        |        |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|H              |        |->x<-   |->x<-   |        |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|I              |        |->x<-   |->x<-   |        |        |        |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|J              |        |->x<-   |->x<-   |->x<-   |->x<-   |        |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|L              |        |        |        |->x<-   |->x<-   |->x<-   |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|o              |        |        |->x<-   |->x<-   |->x<-   |        |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|P              |->x<-   |->x<-   |        |        |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|S              |->x<-   |        |->x<-   |->x<-   |->x<-   |        |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|t              |        |        |        |        |->x<-   |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|U              |        |->x<-   |->x<-   |->x<-   |->x<-   |->x<-   |        |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|u              |        |->x<-   |->x<-   |->x<-   |->x<-   |        |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+
|°              |->x<-   |->x<-   |        |        |        |->x<-   |->x<-   |
+---------------+--------+--------+--------+--------+--------+--------+--------+

Table: Caractères affichage avec un afficheur 7 segments

<-

[[i]]
|Aidez-vous de ce tableau lorsque vous aurez à coder l'affichage de caractères ! ;)


*[DIP]: Dual Inline Package