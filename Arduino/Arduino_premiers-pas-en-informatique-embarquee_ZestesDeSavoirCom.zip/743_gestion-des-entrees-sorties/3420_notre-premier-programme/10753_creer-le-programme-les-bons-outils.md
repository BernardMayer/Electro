# La référence Arduino

## Qu'est ce que c'est ?

L'Arduino étant un projet dont la communauté est très active, nous offre sur son site internet une **référence**.
Mais qu'est ce que c'est ? Eh bien il s'agit simplement de "la notice d'utilisation" du langage Arduino.
Plus exactement, une page internet de leur site est dédiée au référencement de chaque code que l'on peut utiliser pour faire un programme.

## Comment l'utiliser ?

Pour l'utiliser, il suffit d'aller sur [la page de leur site](http://arduino.cc/en/Reference/HomePage), malheureusement en anglais, mais dont il existe une traduction pas tout à fait complète sur le site Français Arduino.
Ce que l'on voit en arrivant sur la page : trois colonnes avec chacune un type d'éléments qui forment les langages Arduino.

- *Structure* : cette colonne référence les éléments de la structure du langage Arduino. On y retrouve les conditions, les opérations, etc.
- *Variables* : comme son nom l'indique, elle regroupe les différents types de variables utilisables, ainsi que certaines opérations particulières
- *Functions* : ici c'est tout le reste, mais surtout les fonctions de lecture/écriture des broches du microcontrôleur (ainsi que d'autres fonctions bien utiles)

[[a]]
|Il est très important de savoir utiliser la documentation que nous offre Arduino !
|Car en sachant cela, vous pourrez faire des programmes sans avoir appris préalablement à utiliser telle fonction ou telle autre. Vous pourrez devenir les maitres du monde !!!
|Euh, non, je crois pas en fait... ^^

# Allumer notre LED

## 1ère étape

Il faut avant tout définir les broches du micro-contrôleur. Cette étape constitue elle-même deux sous étapes.
La première étant de créer une variable définissant la broche utilisée, ensuite, définir si la broche utilisée doit être une entrée du micro-contrôleur ou une sortie.
Premièrement, donc, définissons la broche utilisée du microcontrôleur :

```cpp
const int led_rouge = 2;   // définition de la broche 2 de la carte en tant que variable
```

Le terme `const` signifie que l'on définit la variable comme étant constante.
Par conséquent, on change la nature de la variable qui devient alors constante et sa valeur ne pourra jamais être changée.
Le terme `int` correspond à un type de variable.
En définissant une variable de ce type, elle peut stocker un nombre allant de -2147483648 à +2147483647 !
Cela nous suffit amplement ! ;) Nous sommes donc en présence d'une variable, nommée `led_rouge`, qui est en fait une constante, qui peut prendre une valeur allant de -2147483648 à +2147483647.
Dans notre cas, cette variable, pardon constante, est assignée à 2. Le chiffre 2.

[[i]]
|Lorsque votre code sera compilé, le micro-contrôleur saura ainsi que sur sa broche numéro 2, il y a un élément connecté.

Bon, cela ne suffit pas de définir la broche utilisée.
Il faut maintenant dire si cette broche est une **entrée** ou une **sortie**.
Oui, car le micro-contrôleur a la capacité d'utiliser certaines de ses broches en entrée ou en sortie.
C'est fabuleux ! En effet, il suffit simplement d’interchanger UNE ligne de code pour dire qu'il faut utiliser une broche en entrée (récupération de données) ou en sortie (envoi de données).
Cette ligne de code justement, parlons-en !
Elle doit se trouver dans la fonction `setup()`.
Dans la référence, ce dont nous avons besoin se trouve dans la catégorie **Functions**, puis dans **Digital I/O**.
I/O pour Input/Output, ce qui signifie dans la langue de Molière : Entrée/Sortie.
La fonction se trouve être `pinMode()`. Pour utiliser cette fonction, il faut lui envoyer deux paramètres :

- Le nom de la variable que l'on a défini à la broche
- Le type de broche que cela va être (entrée ou sortie)

```cpp
// fonction d'initialisation de la carte
void setup()
{
    // initialisation de la broche 2 comme étant une sortie
    pinMode(led_rouge, OUTPUT);
}
```
Code: Initialisation de la sortie

Ce code va donc définir la led_rouge (qui est la broche numéro 2 du micro-contrôleur) en sortie, car `OUTPUT` signifie en français : *sortie*.
Maintenant, tout est prêt pour créer notre programme. Voici le code quasiment complet :

```cpp
// définition de la broche 2 de la carte en tant que variable
const int led_rouge = 2;

// fonction d'initialisation de la carte
void setup()
{
    // initialisation de la broche 2 comme étant une sortie
    pinMode(led_rouge, OUTPUT);
}

// fonction principale, elle se répète (s’exécute) à l'infini
void loop()
{
    // contenu de votre programme
}
```

##2e étape

Cette deuxième étape consiste à créer le contenu de notre programme.
Celui qui va aller remplacer le commentaire dans la fonction `loop()`, pour réaliser notre objectif : allumer la LED !
Là encore, on ne claque pas des doigts pour avoir le programme tout prêt ! :P
Il faut retourner chercher dans la référence Arduino ce dont on a besoin.

[[q]]
|Oui, mais là, on ne sait pas ce que l'on veut ? o_O

On cherche une fonction qui va nous permettre d'allumer cette LED.
Il faut donc que l'on se débrouille pour la trouver.
Et avec notre niveau d'anglais, on va facilement trouver. Soyons un peu logique, si vous le voulez bien.
Nous savons que c'est une fonction qu'il nous faut (je l'ai dit il y a un instant), on regarde donc dans la catégorie **Functions** de la référence.
Si on garde notre esprit logique, on va s'occuper d'allumer une LED, donc de dire quel est l'état de sortie de la broche numéro 2 où laquelle est connectée notre LED.
Donc, il est fort à parier que cela se trouve dans **Digital I/O**.
Tiens, il y a une fonction suspecte qui se prénomme `digitalWrite()`.
En français, cela signifie "écriture numérique".
C'est donc l'écriture d'un état logique (0 ou 1).
Quelle se trouve être la première phrase dans la description de cette fonction ?
Celle-ci : "Write a HIGH or a LOW value to a digital pin".
D'après notre niveau bilingue, on peut traduire par :
*Ecriture d'une valeur HAUTE ou une valeur BASSE sur une sortie numérique*.
Bingo ! C'est ce que l'on recherchait ! Il faut dire que je vous ai un peu aidé. ^^

[[q]]
| Ça signifie quoi "valeur HAUTE ou valeur BASSE" ?

En électronique numérique, un niveau haut correspondra à une tension de +5V et un niveau dit bas sera une tension de 0V (généralement la masse).
Sauf qu'on a connecté la LED au pôle positif de l'alimentation, donc pour qu'elle s'allume, il faut qu'elle soit reliée au 0V.
Par conséquent, on doit mettre un état bas sur la broche du microcontrôleur.
Ainsi, la différence de potentiel aux bornes de la LED permettra à celle-ci de s'allumer.
Voyons un peu le fonctionnement de `digitalWrite()` en regardant dans sa syntaxe.
Elle requiert deux paramètres. Le nom de la broche que l'on veut mettre à un état logique et la valeur de cet état logique. Nous allons donc écrire le code qui suit, d'après cette syntaxe :

```cpp
digitalWrite(led_rouge, LOW); // écriture en sortie (broche 2) d'un état BAS
```

Si on teste le code entier :

```cpp
// définition de la broche 2 de la carte en tant que variable
const int led_rouge = 2;

// fonction d'initialisation de la carte
void setup()
{
    // initialisation de la broche 2 comme étant une sortie
    pinMode(led_rouge, OUTPUT);
}

// fonction principale, elle se répète (s’exécute) à l'infini
void loop()
{
    // écriture en sortie (broche 2) d'un état BAS
    digitalWrite(led_rouge, LOW);
}
```
Code: Allumage de la led

On voit s'éclairer la LED !!! C'est fantastique ! o_O