## Le but

Le but de ce premier programme est... de vous faire programmer ! :P
Non, je ne rigole pas ! Car c'est en pratiquant la programmation que l'on retient le mieux les commandes utilisées.
De plus, en faisant des erreurs, vous vous forgerez de bonnes bases qui vous seront très utiles ensuite, lorsqu'il s'agira de gagner du temps.
Mais avant tout, c'est aussi parce que ce tuto est centré sur la programmation que l'on va programmer !

## Objectif

L'objectif de ce premier programme va consister à allumer une LED. C'est nul me direz vous.
J'en conviens. Cependant, vous verrez que ce n'est pas très simple.
Bien entendu, je n'allais pas créer un chapitre entier dont le but ultime aurait été d'allumer une LED !
Non. Alors j'ai prévu de vous montrer deux trois trucs qui pourront vous aider dès lors que vous voudrez sortir du nid et prendre votre envol vers de nouveaux cieux ! ;)

## Matériel

Pour pouvoir programmer, il vous faut, bien évidemment, une carte Arduino et un câble USB pour relier la carte au PC.
Mais pour voir le résultat de votre programme, vous aurez besoin d'éléments supplémentaires.
Notamment, une LED et une résistance.

# Un outil formidable : la breadboard !

Je vais maintenant vous présenter un outil très pratique lorsque l'on fait ses débuts en électronique ou lorsque l'on veut tester rapidement/facilement un montage.
Cet accessoire s'appelle une **breadboard** (littéralement : planche à pain, techniquement : plaque d'essai sans soudure).
Pour faire simple, c'est une plaque pleine de trous !

## Principe de la breadboard

Certes la plaque est pleine de trous, mais pas de manière innocente !
En effet, la plupart d'entre eux sont reliés. Voici un petit schéma rapide qui va aider à la compréhension.

->![Une breadboard](/media/galleries/954/d5a5b9fc-addc-4d0e-8485-85f34c937661.png.960x960_q85.png)<-

Comme vous pouvez le voir sur l'image, j'ai dessiné des zones.
Les zones rouges et noires correspondent à l'alimentation.
Souvent, on retrouve deux lignes comme celles-ci permettant de relier ses composants aux alimentations nécessaires.
Par convention, le noir représente la masse et le rouge est l'alimentation (+5V, +12V, -5V... ce que vous voulez y amener).
Habituellement tous les trous d'une même **ligne** sont reliés sur cette zone.
Ainsi, vous avez une ligne d'alimentation parcourant tout le long de la carte.
Ensuite, on peut voir des zones en bleu. Ces zones sont reliées entre elles par **colonne**.
Ainsi, tous les trous sur une même colonne sont reliés entre eux.
En revanche, chaque colonne est distincte. En faisant chevaucher des composants sur plusieurs colonnes vous pouvez les connecter entre eux.
Dernier point, vous pouvez remarquer un espace coupant la carte en deux de manière symétrique.
Cet espace coupe aussi la liaison des colonnes.
Ainsi, sur le dessin ci-dessus on peut voir que chaque colonne possède cinq trous reliés entre eux. Cet espace au milieu est normalisé et doit faire la largeur des circuits intégrés standards.
En posant un circuit intégré à cheval au milieu, chaque patte de ce dernier se retrouve donc sur une colonne, isolée de la précédente et de la suivante.

[[i]]
|Si vous voulez voir plus concrètement ce fonctionnement, je vous conseille d'essayer le logiciel [Fritzing](http://fritzing.org/), qui permet de faire des circuits de manière assez simple et intuitive.
|Vous verrez ainsi comment les colonnes sont séparées les unes des autres.
|De plus, ce logiciel sera utilisé pour le reste du tuto pour les captures d'écrans des schémas électroniques.

# Réalisation

Avec le brochage de la carte Arduino, vous devrez connecter la plus grande patte au +5V (broche *5V*).
La plus petite patte étant reliée à la résistance, elle-même reliée à la broche numéro 2 de la carte.
Tout ceci a une importance.
En effet, on pourrait faire le contraire, brancher la LED vers la masse et l'allumer en fournissant le 5V depuis la broche de signal.
Cependant, les composants comme les microcontrôleurs n'aiment pas trop délivrer du courant, ils préfèrent l'absorber.
Pour cela, on préférera donc alimenter la LED en la placant au +5V et en mettant la broche de Arduino à la masse pour faire passer le courant.
Si on met la broche à 5V, dans ce cas le potentiel est le même de chaque côté de la LED et elle ne s'allume pas !
Ce n'est pas plus compliqué que ça ! ;)
Schéma de la réalisation (un exemple de branchement sans breadboard et deux exemples avec) :

![réalisation montage, schéma de la carte](/media/galleries/954/ede03831-3c47-4125-a343-b3707da1c43a.png.960x960_q85.jpg)

![Montage avec une LED et sans breadboard](/media/galleries/954/54584383-5785-4333-9069-aa2d6143a81c.png.960x960_q85.png)

![Montage une LED sur breadboard](/media/galleries/954/dc892af3-8b5d-4cfb-b590-1c70d8000bbd.png.960x960_q85.png)

![Montage une LED sur breadboard](/media/galleries/954/911285a0-0d15-49c5-8c49-2f0496becb01.png.960x960_q85.png)

# Créer un nouveau projet

Pour pouvoir programmer notre carte, il faut que l'on créer un nouveau programme.
Ouvrez votre logiciel Arduino. Allez dans le menu *File* et choisissez l'option *Save as...* :

![Enregistrer sous...](/media/galleries/954/f16728b8-57ba-40c8-92a2-b1ebb3455cb3.png.960x960_q85.jpg)

Vous arrivez dans cette nouvelle fenêtre :

![Enregistrer](/media/galleries/954/26c52302-1934-4def-acd6-6d47be875f24.png.960x960_q85.jpg)

Tapez le nom du programme, dans mon cas, je l'ai appelé *test_1*. Enregistrez.
Vous arrivez dans votre nouveau programme, qui est vide pour l'instant, et dont le nom s'affiche en Haut de la fenêtre et dans un petit onglet :

![Votre nouveau programme !](/media/galleries/954/3a6da91e-3fa6-4771-a5b5-7b6b2dbc9509.png.960x960_q85.jpg)

## Le code minimal

Pour commencer le programme, il nous faut un code minimal.
Ce code va nous permettre d'initialiser la carte et va servir à écrire notre propre programme.
Ce code, le voici :

```cpp
// fonction d'initialisation de la carte
void setup()
{
    // contenu de l'initialisation
}

// fonction principale, elle se répète (s’exécute) à l'infini
void loop()
{
    // contenu de votre programme
}
```
Code: Squelette minimal d'un programme Arduino