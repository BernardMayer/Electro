[[q]]
|Et comment ça se passe à l'intérieur ?? o_O
|Je comprends pas comment le microcontrôleur fait pour tout comprendre et tout faire.
|Je sais qu'il utilise les 0 et les 1 du programme qu'on lui a envoyé, mais comment il sait qu'il doit aller chercher le programme, le lire, l’exécuter, etc. ?


Eh bien, eh bien ! En voilà des questions !
Je vais essayer d'y répondre simplement, sans entrer dans le détail qui est quand même très compliqué.
Bon, si vous êtes prêt, c'est parti !
D'abord, tout se passe dans le cerveau du microcontrôleur...

# Le démarrage

Un peu comme vous démarreriez un ordinateur, la carte Arduino aussi démarre.
Alors c'est un peu transparent parce qu'elle démarre dans deux cas principaux : le premier c'est lorsque vous la branchez sur le port USB ou une sur autre source d'alimentation ; le deuxième c'est lorsque le compilateur a fini de charger le programme dans la carte, il la redémarre.
Et au démarrage de la carte, il se passe des trucs.

## Chargez !

Vous vous souvenez du chapitre où je vous présentais un peu le fonctionnement global de la carte ?
Oui, [celui-là](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/742/decouverte-de-larduino/3417/le-materiel/#3-fonctionnement-global).
Je vous parlais alors de l'exécution du programme.
Au démarrage, la carte (après un petit temps de vérification pour voir si le compilateur ne lui charge pas un nouveau programme) commence par aller charger les variables en mémoire de données.
C'est un petit mécanisme électronique qui va simplement faire en sorte de copier les variables inscrites dans le programme vers la mémoire de données.
En l'occurrence, dans le programme que l'on vient de créer, il n'y a qu'une variable et elle est constante en plus.
Ce ne sera donc pas bien long à mettre ça en mémoire !
Ensuite, vient la lecture du programme. Et là, que peut-il bien se passer à l'intérieur du microcontrôleur ?
En fait, ce n'est pas très compliqué (sur le principe :P ).

## La vraie forme du programme

À présent, le cerveau du microcontrôleur va aller lire la première instruction du programme, celle qui se trouve dans la fonction `setup()`.
Sauf que, l'instruction n'est plus sous la même forme.
Non, cette fois-ci je ne parle pas des 0 et des 1, mais bien d'une transformation de l'instruction.
C'est le compilateur qui a découpé chaque instruction du programme en plusieurs petites instructions beaucoup plus simples.

[[q]]
|Et pourquoi cela ? Le microcontrôleur ne sais pas faire une instruction aussi simple que de déclarer une broche en sortie ou allumer une LED ? o_O

Oui. C'est pourquoi il a besoin que le programme soit non plus sous forme de "grandes instructions" comme on l'a écrit, mais bien sous forme de plusieurs petites instructions.
Et cela est dû au fait qu'il ne sait exécuter que des instructions très simples !

->![Découpage en instructions](/media/galleries/954/7a858b9f-c1dd-4082-9803-03cb828eb9bb.png.960x960_q85.jpg)<-

Bien entendu, il n'y a pas de limite à six instructions, il peut y en avoir beaucoup plus ou beaucoup moins !
Donc, en mémoire de programme, là où le programme de la carte est stocké, on va avoir plutôt quelque chose qui ressemble à ça :

->![Le programme dans la mémoire](/media/galleries/954/d75b6f0d-46da-415d-94af-d95e5138c46f.png.960x960_q85.jpg)<-

Chaque grande instruction est découpée en petites instructions par le compilateur et est ensuite stockée dans la mémoire de programme.
Pour être encore plus détaillé, chaque instruction agit sur un *registre*.
Un registre, c'est la forme la plus simplifiée de la mémoire en terme de programmation.
On en trouve plusieurs, par exemple le registre des timers ou celui des entrées/sorties du port A (ou B, ou C) ou encore des registres généraux pour manipuler les variables.
Par exemple, pour additionner 3 à la variable 'a' le microcontrôleur fera les opérations suivantes :

1. chargement de la variable 'a' dans le registre général 8 (par exemple) depuis la RAM
2. chargement de la valeur 3 dans le registre général 9
3. mise du résultat de "registre 8 + registre 9" dans le registre 8
4. changement de la valeur de 'a' en RAM depuis le registre 8

# Et l'exécution du programme

À présent que l'on a plein de petites instructions, qu'avons nous de plus ? Pas grand chose me direz-vous.
Le Schmilblick n'a guère avancé... ^^
Pour comprendre, il faut savoir que le microcontrôleur ne sais faire que quelques instructions.
Ces instructions sont encore plus simple que d'allumer une LED !
Il peut par exemple faire des opérations logiques (ET, OU, NON, décalage de bits, ...), des opérations numériques (addition et soustraction, les multiplications et divisions sont faites avec des opérations du types décalage de bits) ou encore copier et stocker des données.
Il sait en faire, donc, mais pas tant que ça. Tout ce qu'il sait faire est régi par son **jeu d'instructions**.
C'est-à-dire qu'il a une liste des instructions possibles qu'il sait exécuter et il s'y tient.
Le compilateur doit donc absolument découper chaque instruction du programme en instructions que le microcontrôleur sait exécuter.

![Interaction entre les éléments du microcontrôleur](/media/galleries/954/5d82659b-00ed-43a5-a160-d7d1c58b836d.png.960x960_q85.jpg)

Le cerveau du microcontrôleur va aller lire le programme, il compare ensuite chaque instruction à son registre d'instructions et les exécute.
Pour allumer une LED, il fera peut-être un ET logique, chargera une donnée, fera une soustraction, ... on ne sait pas mais il va y arriver.
Et pour terminer, il communiquera à son gestionnaire d'entrées/sortie pour lui informer qu'il faut activer tel transistor interne pour mettre une tension sur telle broche de la carte pour ainsi allumer la LED qui y est connectée.

[[q]]
|Waoou ! Et ça va vite tout ça ?

Extrêmement vite ! Cela dit, tout dépend de sa vitesse d'exécution...

# La vitesse d'exécution

Le microcontrôleur est capable de faire un très grand nombre d'opérations par seconde.
Ce nombre est défini par sa vitesse, entre autre.
Sur la carte Arduino Duemilanove ou Uno, il y a un composant, que l'on appel un **quartz**, qui va définir à quelle vitesse va aller le microcontrôleur.
Ce quartz permet de **cadencer** le microcontrôleur. C'est en fait une **horloge** qui permet au microcontrôleur de se repérer.
À chaque top de l'horloge, le microcontrôleur va faire quelque chose.
Ce quelque chose peut, par exemple, être l'exécution d'une instruction, ou une lecture en mémoire.
Cependant, chaque action ne dure pas qu'un seul top d'horloge.
Suivant l'action réalisée, cela peut prendre plus ou moins de temps (de nombre de "coups d'horloge").

![L'horloge dans le système](/media/galleries/954/8b206470-2156-4c60-a7af-0cf8dd287048.png.960x960_q85.jpg)

La carte Arduino atteint au moins le million d'instructions par seconde !
Cela peut paraître énorme, mais comme je le disais, si il y a des instructions qui prennent beaucoup de temps, eh bien il se peut qu'elle n'exécute qu'une centaine d'instructions en une seconde.
Tout dépend du temps pris par une instruction à être exécutée. Certaines opérations sont aussi parallélisées. Par exemple, le microcontrôleur peut faire une addition d'un côté pour une variable et en même temps il va mesurer le nombre de coups d'horloge pour faire s'incrémenter un compteur pour gérer un timer.
Ces opérations sont **réellement** faites en parallèle, ce n'est pas un faux multi-tâche comme sur un ordinateur.
Ici les deux registres travaillent en même temps. Le nombre de la fin ? 62.5 nanosecondes.
C'est le temps qu'il faut au microcontrôleur d'Arduino pour faire une instruction la plus simple possible (en prenant en compte l'Arduino Uno et son quartz à 16MHz).