Vous voilà enfin arrivé au moment fatidique où vous allez devoir programmer ! Mais avant cela, je vais vous montrer ce qui va nous servir pour ce chapitre. 

En l'occurrence, apprendre à utiliser une LED et la référence, présente sur le site `arduino.cc` qui vous sera très utile lorsque vous aurez besoin de faire un programme utilisant une notion qui n'est pas traitée dans ce cours.

*[LED]: Light Emitting Device/Diode