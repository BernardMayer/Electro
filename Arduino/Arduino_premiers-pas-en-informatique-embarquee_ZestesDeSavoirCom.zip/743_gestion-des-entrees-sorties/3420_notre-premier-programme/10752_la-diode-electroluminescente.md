# DEL / LED ?

La question n'est pas de savoir quelle abréviation choisir mais plutôt de savoir ce que c'est. Une **DEL** / **LED** : **D**iode **E**lectro-**L**uminescente, ou bien "**L**ight **E**mitting **D**iode" en anglais.
Il s'agit d'un composant électronique qui crée de la lumière quand il est parcouru par un courant électrique.
Je vous en ai faits acheter de différentes couleurs. Vous pouvez, pour ce chapitre, utiliser celle que vous voudrez, cela m'est égal. ;) Vous voyez, ci-dessous sur votre droite, la photo d'une DEL de couleur rouge.
La taille n'est pas réelle, sa "tête" (en rouge) ne fait que 5mm de diamètre.
C'est ce composant que nous allons essayer d'allumer avec notre carte Arduino. Mais avant, voyons un peu comment il fonctionne.

[[i]]
|J’appellerai la diode électroluminescente, tout au long du cours, une LED.
|Une LED est en fait une **diode** qui émet de la lumière.
|Je vais donc vous parler du fonctionnement des diodes en même temps que celui des LED.

![Des LED / DEL](http://zestedesavoir.com/media/galleries/954/bd36e03f-795d-483a-b8b7-e10ab2f7a9e5.png.960x960_q85.jpg)
Figure: Des LED / DEL - (CC-BY-SA, [Saperaud](http://commons.wikimedia.org/wiki/File:Diodos_LED_foto.png))

## Symbole

Sur un schéma électronique, chaque composant est repéré par un symbole qui lui est propre.
Celui de la diode est le suivant :

->![Symbole de la diode](/media/galleries/954/ee140ce6-0909-402b-a7c6-b9e17d0d79a8.png.960x960_q85.jpg)<-

Celui de la LED est :

->![Symbole de la LED](/media/galleries/954/2410ac06-c42d-4cdd-89cf-38755d08342c.png.960x960_q85.jpg)<-

Il y a donc très peu de différence entre les deux.
La LED est simplement une diode qui émet de la lumière, d'où les flèches sur son symbole.

## Astuce mnémotechnique

Pour ce souvenir de quel côté est l'anode ou la cathode, voici un moyen mnémotechnique simple et en image :) ...

->

![](/media/galleries/954/74ddd784-c8c3-4f35-afc7-acb843f7c4e3.png.960x960_q85.png)|![](/media/galleries/954/c0d8453c-4611-433a-bec5-5af84637eccf.png.960x960_q85.png)
---------------------------------------------------------|--------------------------------------------
K comme K-thode|A comme A-node

Table: Moyen mnémotechnique pour se souvenir de l'anode et de la cathode

<-

# Fonctionnement

## Polarisation directe

On parle de **polarisation** lorsqu'un composant électronique est utilisé dans un circuit électronique de la "bonne manière".
En fait lorsqu'il est polarisé, c'est qu'on l'utilise de la façon souhaitée.
Pour polariser la diode, on doit faire en sorte que le courant la parcours de l'anode vers la cathode. Autrement dit, la tension doit être plus élevée à l'anode qu'à la cathode.

->![Diode polarisée directement](/media/galleries/954/e8b28c03-fc51-432f-a6ee-ebbe6af38aef.png.960x960_q85.jpg)<-

## Polarisation inverse

La polarisation inverse d'une diode est l'opposé de la polarisation directe. Pour créer ce type de montage, il suffit simplement, dans notre cas, de "retourner" la diode enfin la brancher "à l'envers". Dans ce cas, le courant ne passe pas.

->![Diode polarisée en inverse](/media/galleries/954/9e3424ea-ea1f-4a14-8538-fdf2fb71fff2.png.960x960_q85.jpg)<-

[[i]]
|Note : une diode polarisée en inverse ne grillera pas si elle est utilisée dans de bonnes conditions.
|En fait, elle fonctionne de "la même façon" pour le courant positif et négatif.

## Utilisation

[[a]]
|Si vous ne voulez pas faire partir votre première diode en fumée, je vous conseille de lire les prochaines lignes attentivement :P

En électronique, deux paramètres sont à prendre en compte : le courant et la tension.
Pour une diode, deux tensions sont importantes.
Il s'agit de la tension maximum en polarisation directe, et la tension maximum en polarisation inverse. Ensuite, pour un bon fonctionnement des LED, le courant a lui aussi son importance.

## La tension maximum directe

Lorsque l'on utilise un composant, on doit prendre l'habitude d'utiliser la *"datasheet"* ("documentation technique" en anglais) qui nous donne toutes les caractéristiques sur le composant.
Dans cette datasheet, on retrouvera quelque chose appelé "Forward Voltage", pour la diode.
Cette indication représente la chute de tension aux bornes de la diode lorsque du courant la traverse en sens direct.
Pour une diode classique (type [1N4148](http://pdf1.alldatasheet.com/datasheet-pdf/view/196195/PHILIPS/1N4148.html)), cette tension sera d'environ 1V.
Pour une LED, on considérera plutôt une tension de 1,2 à 1,6V.

[[i]]
|Bon, pour faire nos petits montages, on ne va pas chipoter, mais c'est la démarche à faire lorsque l'on conçoit un schéma électrique et que l'on dimensionne ses composants.

## La tension maximum inverse

Cette tension représente la différence maximum admissible entre l'anode et la cathode lorsque celle-ci est branchée "à l'envers".
En effet, si vous mettez une tension trop importante à ces bornes, la jonction ne pourra pas le supporter et partira en fumée.
En anglais, on retrouve cette tension sous le nom de "Reverse Voltage" (ou même "Breakdown Voltage").
Si l'on reprend la diode 1N4148, elle sera comprise entre 75 et 100V.
Au-delà de cette tension, la jonction casse et la diode devient inutilisable.
Dans ce cas, la diode devient soit un court-circuit, soit un circuit ouvert.
Parfois cela peu causer des dommages importants dans nos appareils électroniques !
Quoi qu'il en soit, on ne manipulera jamais du 75V ! :P

## Le courant de passage

Le courant qui traverse une LED a son importance.
Si l'on branche directement la LED sur une pile, elle va s'allumer, puis tôt ou tard finira par s'éteindre... définitivement.
En effet, si on ne limite pas le courant traversant la LED, elle prendra le courant maximum, et ça c'est pas bon car ce n'est pas le courant maximum qu'elle peut supporter.
Pour limiter le courant, on place une résistance avant (ou après) la LED.
Cette résistance, savamment calculée, lui permettra d'assurer un fonctionnement optimal.

[[q]]
|Mais comment on la calcule cette résistance ?

Simplement avec la formule de base, la loi d'Ohm. ;) Petit rappel:
$$ U = R * I$$

Dans le cas d'une LED, on considère, en général, que l'intensité la traversant doit être de 20 mA.
Si on veut être rigoureux, il faut aller chercher cette valeur dans le datasheet.
On a donc $I = 20 mA$. Ensuite, on prendra pour l'exemple une tension d'alimentation de 5V (en sortie de l'Arduino, par exemple) et une tension aux bornes de la LED de 1,2V en fonctionnement normal.
On peut donc calculer la tension qui sera aux bornes de la résistance : $Ur = 5 - 1,2 = 3,8 V$.
Enfin, on peut calculer la valeur de la résistance à utiliser :
$$
R = \frac{U}{I} \\\\
R = \frac{3,8}{0,02}\\\
R = 190\Omega
$$
 Et voilà, vous connaissez la valeur de la résistance à utiliser pour être sûr de ne pas griller des LED à tour de bras. :)
 À votre avis, vaut-il mieux utiliser une résistance de plus forte valeur ou de plus faible valeur ?

[[secret]]
| **Réponse :**
|
| Si on veut être sûr de ne pas détériorer la LED à cause d'un courant trop fort, on doit placer une résistance dont la valeur est plus grande que celle calculée. Autrement, la diode recevra le courant maximal pouvant la traverser.
|