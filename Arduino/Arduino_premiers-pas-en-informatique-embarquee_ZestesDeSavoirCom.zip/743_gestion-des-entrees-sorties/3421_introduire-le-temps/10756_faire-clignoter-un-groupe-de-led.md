Vous avouerez facilement que ce n'était pas bien difficile d'arriver jusque-là. Alors, à présent, accentuons la difficulté.
Notre but : faire clignoter *un groupe* de LED.

## Le matériel et les schémas

Ce groupe de LED sera composé de six LED, nommées L1, L2, L3, L4, L5 et L6. Vous aurez par conséquent besoin d'un nombre identique de résistances. Le schéma de la réalisation :

![Schéma avec 6 leds](/media/galleries/954/7c964fb3-d38e-4231-8150-1fa632bd7315.png.960x960_q85.png)

![Montage avec 6 leds](/media/galleries/954/9c19033d-2871-45e1-9d60-a1a4f6636024.png.960x960_q85.png)

## Le programme

Le programme est un peu plus long que le précédent, car il ne s'agit plus d'allumer une seule LED, mais six !
Voilà l'organigramme que va suivre notre programme :

![Description du programme](/media/galleries/954/466dd245-be9d-41ec-88c5-bc093b0f2a35.png.960x960_q85.jpg)

Cet organigramme n'est pas très beau, mais il a le mérite d'être assez lisible.
Nous allons essayer de le suivre pour créer notre programme.
Traduction des six premières instructions :

```cpp
digitalWrite(L1, LOW); // notez que le nom de la broche a changé
digitalWrite(L2, LOW); // et ce pour toutes les LED connectées
digitalWrite(L3, LOW); // au micro-controleur
digitalWrite(L4, LOW);
digitalWrite(L5, LOW);
digitalWrite(L6, LOW);
```

Ensuite, on attend 1,5 seconde :

```cpp
delay(1500);
```

Puis on traduit les six autres instructions :

```cpp
digitalWrite(L1, HIGH); // on éteint les LED
digitalWrite(L2, HIGH);
digitalWrite(L3, HIGH);
digitalWrite(L4, HIGH);
digitalWrite(L5, HIGH);
digitalWrite(L6, HIGH);
```

Enfin, la dernière ligne de code, disons que nous attendrons 4,32 secondes :

```cpp
delay(4320);
```

Tous ces bouts de code sont à mettre à la suite et dans la fonction `loop()` pour qu'ils se répètent.

```cpp
void loop()
{
    digitalWrite(L1, LOW);  // allumer les LED
    digitalWrite(L2, LOW);
    digitalWrite(L3, LOW);
    digitalWrite(L4, LOW);
    digitalWrite(L5, LOW);
    digitalWrite(L6, LOW);

    delay(1500);             // attente du programme de 1,5 secondes

    digitalWrite(L1, HIGH);   // on éteint les LED
    digitalWrite(L2, HIGH);
    digitalWrite(L3, HIGH);
    digitalWrite(L4, HIGH);
    digitalWrite(L5, HIGH);
    digitalWrite(L6, HIGH);

    delay(4320);             // attente du programme de 4,32 secondes
}
```
Code: la boucle complète

Je l'ai mentionné dans un de mes commentaires entre les lignes du programme, les noms attribués aux broches sont à changer.
En effet, car si on définit des noms de variables identiques, le compilateur n'aimera pas ça et vous affichera une erreur.
En plus, le micro-contrôleur ne pourrait pas exécuter le programme car il ne saurait pas quelle broche mettre à l'état HAUT ou BAS.
Pour définir les broches, on fait la même chose qu'à notre premier programme :

```cpp
const int L1 = 2; // broche 2 du micro-contrôleur se nomme maintenant : L1
const int L2 = 3; // broche 3 du micro-contrôleur se nomme maintenant : L2
const int L3 = 4; // ...
const int L4 = 5;
const int L5 = 6;
const int L6 = 7;
```
Code: Définition des broches

Maintenant que les broches utilisées sont définies, il faut dire si ce sont des entrées ou des sorties :

```cpp
pinMode(L1, OUTPUT); // L1 est une broche de sortie
pinMode(L2, OUTPUT); // L2 est une broche de sortie
pinMode(L3, OUTPUT); // ...
pinMode(L4, OUTPUT);
pinMode(L5, OUTPUT);
pinMode(L6, OUTPUT);
```

## Le programme final

Il n'est certes pas très beau, mais il fonctionne :

```cpp
const int L1 = 2; // broche 2 du micro-contrôleur se nomme maintenant : L1
const int L2 = 3; // broche 3 du micro-contrôleur se nomme maintenant : L2
const int L3 = 4; // ...
const int L4 = 5;
const int L5 = 6;
const int L6 = 7;

void setup()
{
    pinMode(L1, OUTPUT); // L1 est une broche de sortie
    pinMode(L2, OUTPUT); // L2 est une broche de sortie
    pinMode(L3, OUTPUT); // ...
    pinMode(L4, OUTPUT);
    pinMode(L5, OUTPUT);
    pinMode(L6, OUTPUT);
}

void loop()
{
    // allumer les LED
    digitalWrite(L1, LOW);
    digitalWrite(L2, LOW);
    digitalWrite(L3, LOW);
    digitalWrite(L4, LOW);
    digitalWrite(L5, LOW);
    digitalWrite(L6, LOW);

    // attente du programme de 1,5 secondes
    delay(1500);

    // on éteint les LED
    digitalWrite(L1, HIGH);
    digitalWrite(L2, HIGH);
    digitalWrite(L3, HIGH);
    digitalWrite(L4, HIGH);
    digitalWrite(L5, HIGH);
    digitalWrite(L6, HIGH);

    // attente du programme de 4,32 secondes
    delay(4320);
}
```
Code: Allumage puis extinction en boucle d'un groupe de leds

Voilà, vous avez en votre possession un magnifique clignotant, que vous pouvez attacher à votre vélo ! :P

[[q]]
|Une question me chiffonne. Doit-on toujours écrire l'état d'une sortie, ou peut-on faire plus simple ?

C'est là un un point intéressant.
Si je comprends bien, vous vous demandez comment faire pour remplacer l’intérieur de la fonction `loop()` ?
C'est vrai que c'est très lourd à écrire et à lire ! Il faut en effet s'occuper de définir l'état de chaque LED.
C'est rébarbatif, surtout si vous en aviez mis autant qu'il y a de broches disponibles sur la carte !
Il y a une solution pour faire ce que vous dites. Nous allons la voir dans quelques chapitres, ne soyez pas impatient ! ;)
En attendant, voici une vidéo d'illustration du clignotement :

->!(https://www.youtube.com/watch?v=2SgxKU67mn8)<-