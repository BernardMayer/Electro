Nous allons terminer ce chapitre par un point qui peut être utile, notamment dans certaines situations où l'on ne veut pas arrêter le programme.
En effet, si on veut faire clignoter une LED sans arrêter l’exécution du programme, on ne peut pas utiliser la fonction `delay()` qui met en pause le programme durant le temps défini.

# Les limites de la fonction delay()

Vous avez probablement remarqué, lorsque vous utilisez la fonction `delay()` tout notre programme s’arrête le temps d'attendre.
Dans certains cas ce n'est pas un problème mais dans certains cas ça peut être plus gênant.
Imaginons, vous êtes en train de faire avancer un robot. Vous mettez vos moteurs à une vitesse moyenne, tranquille, jusqu'à ce qu'un petit bouton sur l'avant soit appuyé (il clic lorsqu'on touche un mur par exemple).
Pendant ce temps-là, vous décidez de faire des signaux en faisant clignoter vos LED.
Pour faire un joli clignotement, vous allumez une LED rouge pendant une seconde puis l’éteignez pendant une autre seconde.
Voilà par exemple ce qu'on pourrait faire comme code

```cpp
void setup()
{
    pinMode(moteur, OUTPUT);
    pinMode(led, OUTPUT);
    pinMode(bouton, INPUT);
    // on met le moteur en marche (en admettant qu'il soit en marche à HIGH)
    digitalWrite(moteur, HIGH);
    // on allume la LED
    digitalWrite(led, LOW);
}

void loop()
{
    // si le bouton est cliqué (on rentre dans un mur)
    if(digitalRead(bouton)==HIGH)
    {
        // on arrête le moteur
        digitalWrite(moteur, LOW);
    }
    else // sinon on clignote
    {
        digitalWrite(led, HIGH);
        delay(1000);
        digitalWrite(led, LOW);
        delay(1000);
    }
}
```

[[a]]
|Attention ce code n'est pas du tout rigoureux voire faux dans son écriture, il sert juste à comprendre le principe !

Maintenant imaginez. Vous roulez, tester que le bouton n'est pas appuyé, donc faites clignoter les LED (cas du `else`).
Le temps que vous fassiez l'affichage en entier s'écoule 2 longues secondes !
Le robot a pu pendant cette éternité se prendre le mur en pleine poire et les moteurs continuent à avancer tête baissée jusqu'à fumer !
Ce n'est pas bon du tout ! Voici pourquoi la fonction millis() peut nous sauver.

# Découvrons et utilisons millis()

Tout d'abord, quelques précisions à son sujet, avant d'aller s'en servir.
À l'intérieur du cœur de la carte Arduino se trouve un chronomètre. Ce chrono mesure l'écoulement du temps depuis le lancement de l'application.
Sa granularité (la précision de son temps) est la milliseconde.
La fonction millis() nous sert à savoir quelle est la valeur courante de ce compteur. Attention, comme ce compteur est capable de mesurer une durée allant jusqu'à 50 jours, la valeur retournée doit être stockée dans une variable de type "long".

[[q]]
|C'est bien gentil mais concrètement on l'utilise comment ?

Eh bien c'est très simple. On sait maintenant "lire l'heure".
Maintenant, au lieu de dire "allume-toi pendant une seconde et ne fais surtout rien pendant ce temps", on va faire un truc du genre "Allume-toi, fais tes petites affaires, vérifie l'heure de temps en temps et si une seconde est écoulée, alors réagis !".
Voici le code précédent transformé selon la nouvelle philosophie :

```cpp
long temps; // variable qui stocke la mesure du temps
boolean etat_led;

void setup()
{
    pinMode(moteur, OUTPUT);
    pinMode(led, OUTPUT);
    pinMode(bouton, INPUT);
    // on met le moteur en marche
    digitalWrite(moteur, HIGH);
    // par défaut la LED sera éteinte
    etat_led = 0;
    // on éteint la LED
    digitalWrite(led, etat_led);

    // on initialise le temps
    temps = millis();
}

void loop()
{
    // si le bouton est cliqué (on rentre dans un mur)
    if(digitalRead(bouton)==HIGH)
    {
        // on arrête le moteur
        digitalWrite(moteur, LOW);
    }
    else // sinon on clignote
    {
        // on compare l'ancienne valeur du temps et la valeur sauvée
        // si la comparaison (l'un moins l'autre) dépasse 1000...
        // ...cela signifie qu'au moins une seconde s'est écoulée
        if((millis() - temps) > 1000)
        {
            etat_led = !etat_led; // on inverse l'état de la LED
            digitalWrite(led, etat_led); // on allume ou éteint
            temps = millis(); // on stocke la nouvelle heure
        }
    }
}
```
Code: Clignotement avec `millis`

Et voilà, grâce à cette astuce plus de fonction bloquante.
L'état du bouton est vérifié très fréquemment ce qui permet de s'assurer que si jamais on rentre dans un mur, on coupe les moteurs très vite. Dans ce code, tout s'effectue de manière fréquente.
En effet, on ne reste jamais bloqué à attendre que le temps passe. À la place, on avance dans le programme et teste souvent la valeur du chronomètre.
Si cette valeur est de 1000 itérations supérieures à la dernière valeur mesurée, alors cela signifie qu'une seconde est passée.

[[a]]
|Attention, au `if` de la ligne 25 ne faites surtout pas `millis() - temps == 1000`.
|Cela signifierait que vous voulez vérifier que 1000 millisecondes EXACTEMENT se sont écoulées, ce qui est très peu probable (vous pourrez plus probablement mesurer plus ou moins mais rarement exactement)