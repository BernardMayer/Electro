## Trouver la commande...

Je vous laisse cherche un peu par vous-même, cela vous entrainera ! :pirate: ...
Pour ceux qui ont fait l'effort de chercher et n'ont pas trouvé (à cause de l'anglais ?), je vous donne la fonction qui va bien :
on va utiliser : `delay()`.
Petite description de la fonction : elle va servir à mettre en pause le programme pendant un temps prédéterminé.

## Utiliser la commande

La fonction admet un paramètre qui est le temps pendant lequel on veut mettre en pause le programme. Ce temps doit être donné en millisecondes.
C'est-à-dire que si vous voulez arrêter le programme pendant une seconde, il va falloir donner à la fonction ce même temps, écrit en millisecondes, soit 1000ms. La fonction est simple à utiliser :

```cpp
// on fait une pause du programme pendant 1000ms, soit 1 seconde
delay(1000);
```

Rien de plus simple donc. Pour 20 secondes de pause, il aurait fallu écrire :

```cpp
// on fait une pause du programme pendant 20000ms, soit 20 secondes
delay(20000);
```
## Mettre en pratique : faire clignoter une LED

Du coup, si on veut faire clignoter notre LED, on peut utiliser cette fonction.
Voyons un peu le schéma de principe du clignotement d'une LED :

![Schéma de principe du clignotement](/media/galleries/954/fb2eefde-69b8-4fdf-85b2-a4df5daffe25.png.960x960_q85.jpg)

Vous le voyez, la LED s'allume. Puis, on fait intervenir la fonction `delay()`, qui va mettre le programme en pause pendant un certain temps.
Ensuite, on éteint la LED. On met en pause le programme. Puis on revient au début du programme.
On recommence et ainsi de suite.
C'est cette suite de commandes qui forme le processus faisant clignoter la LED.

[[i]]
| Dorénavant, prenez l'habitude de faire ce genre de schéma lorsque vous faites un programme.
| Cela aide grandement la réflexion, croyez moi ! ;) C'est le principe de perdre du temps pour en gagner. Autrement dit : l'**organisation** !

Maintenant, il faut que l'on traduise ce schéma, portant le nom d'**organigramme**, en code.

Il suffit pour cela de remplacer les phrases dans chaque cadre par une ligne de code.
Par exemple, "on allume la LED", va être traduit par l'instruction que l'on a vue dans le chapitre précédent :

```cpp
digitalWrite(led_rouge, LOW);   // allume la LED
```

Ensuite, on traduit le cadre suivant, ce qui donne :

```cpp
// fait une pause de 1 seconde (= 1000ms)
delay(1000);
```

Puis, on traduit la ligne suivante :

```cpp
// éteint la LED
digitalWrite(led_rouge, HIGH);
```

Enfin, la dernière ligne est identique à la deuxième, soit :

```cpp
// fait une pause de 1 seconde
delay(1000);
```

On se retrouve avec le code suivant :

```cpp
// allume la LED
digitalWrite(led_rouge, LOW);
// fait une pause de 1 seconde
delay(1000);
// éteint la LED
digitalWrite(led_rouge, HIGH);
// fait une pause de 1 seconde
delay(1000);
```

La fonction qui va boucler à l'infini le code précédent est la fonction `loop()`.
On inscrit donc le code précédent dans cette fonction :

```cpp
void loop()
{
    // allume la LED
    digitalWrite(led_rouge, LOW);
    // fait une pause de 1 seconde
    delay(1000);
    // éteint la LED
    digitalWrite(led_rouge, HIGH);
    // fait une pause de 1 seconde
    delay(1000);
}
```

Et on n'oublie pas de définir la broche utilisée par la LED, ainsi que d'initialiser cette broche en tant que sortie. Cette fois, le code est terminé !

```cpp
// définition de la broche 2 de la carte en tant que variable
const int led_rouge = 2;

// fonction d'initialisation de la carte
void setup()
{
    // initialisation de la broche 2 comme étant une sortie
    pinMode(led_rouge, OUTPUT);
}

void loop()
{
    // allume la LED
    digitalWrite(led_rouge, LOW);
    // fait une pause de 1 seconde
    delay(1000);
    // éteint la LED
    digitalWrite(led_rouge, HIGH);
    // fait une pause de 1 seconde
    delay(1000);
}
```

Vous n'avez plus qu'à charger le code dans la carte et admirer ~~mon~~ votre travail ! La LED clignote !
Libre à vous de changer le temps de clignotement : vous pouvez par exemple éteindre la LED pendant 40ms et l'allumer pendant 600ms :

[[secret]]
| ```cpp
| // définition de la broche 2 de la carte en tant que variable
| const int led_rouge = 2;
| 
| // fonction d'initialisation de la carte
| void setup()
| {
|     // initialisation de la broche 2 comme étant une sortie
|     pinMode(led_rouge, OUTPUT);
| }
| 
| void loop()
| {
|     // allume la LED
|     digitalWrite(led_rouge, LOW);
|     // fait une pause de 600 ms
|     delay(600);
|     // éteint la LED
|     digitalWrite(led_rouge, HIGH);
|     // fait une pause de 40 ms
|     delay(40);
| }
| ```

Et hop, une petite vidéo d'illustration !

->!(https://www.youtube.com/watch?v=YAOakcEoIfk)<-