C'est bien beau d'allumer une LED, mais si elle ne fait rien d'autre, ce n'est pas très utile. Autant la brancher directement sur une pile (avec une résistance tout de même ! :P ).
Alors voyons comment rendre intéressante cette LED en la faisant clignoter !
Ce que ne sait pas faire une pile... Pour cela il va nous falloir introduire la notion de temps. Eh bien devinez quoi ?
Il existe une fonction toute prête là encore ! Je ne vous en dis pas plus, passons à la pratique !