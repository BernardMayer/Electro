## Le but du programme

Le but du programme que nous allons créer va consister à réaliser un chenillard. Pour ceux qui ne savent pas ce qu'est un chenillard, je vous ai préparé une petite image .gif animée :

->![Chenillard](/media/galleries/954/c7070381-dd76-46a9-a6d3-c8f2505adf13.gif)<-

Comme on dit souvent, une image vaut mieux qu'un long discours ! :P Voilà donc ce qu'est un chenillard.
Chaque LED s'allume alternativement et dans l'ordre. De la gauche vers la droite ou l'inverse, c'est au choix.

## Organigramme

Comme j'en ai marre de faire des dessins avec paint.net, je vous laisse réfléchir tout seuls comme des grands à l'organigramme du programme. ...
Bon, aller, le voilà cet organigramme ! Attention, il n'est pas complet, mais si vous avez compris le principe, le compléter ne vous posera pas de problèmes :

[[secret]]
|->![Organigramme](/media/galleries/954/f4a2eaf0-7cda-48b6-a710-9de8c4a6be39.png.960x960_q85.jpg)<-


À vous de jouer !

## Le programme

Normalement, sa conception ne devrait pas vous poser de problèmes.
Il suffit en effet de récupérer le code du programme précédent ("allumer un groupe de LED") et de le modifier en fonction de notre besoin.
Ce code, je vous le donne, avec les commentaires qui vont bien :

```cpp
const int L1 = 2; // broche 2 du micro-contrôleur se nomme maintenant : L1
const int L2 = 3; // broche 3 du micro-contrôleur se nomme maintenant : L2
const int L3 = 4; // ...
const int L4 = 5;
const int L5 = 6;
const int L6 = 7;

void setup()
{
    pinMode(L1, OUTPUT); // L1 est une broche de sortie
    pinMode(L2, OUTPUT); // L2 est une broche de sortie
    pinMode(L3, OUTPUT); // ...
    pinMode(L4, OUTPUT);
    pinMode(L5, OUTPUT);
    pinMode(L6, OUTPUT);
}

// on change simplement l’intérieur de la boucle pour atteindre notre objectif

void loop() // la fonction loop() exécute le code qui suit en le répétant en boucle
{
    digitalWrite(L1, LOW);   // allumer L1
    delay(1000);             // attendre 1 seconde
    digitalWrite(L1, HIGH);  // on éteint L1
    digitalWrite(L2, LOW);   // on allume L2 en même temps que l'on éteint L1
    delay(1000);             // on attend 1 seconde
    digitalWrite(L2, HIGH);  // on éteint L2 et
    digitalWrite(L3, LOW);   // on allume immédiatement L3
    delay(1000);             // ...
    digitalWrite(L3, HIGH);
    digitalWrite(L4, LOW);
    delay(1000);
    digitalWrite(L4, HIGH);
    digitalWrite(L5, LOW);
    delay(1000);
    digitalWrite(L5, HIGH);
    digitalWrite(L6, LOW);
    delay(1000);
    digitalWrite(L6, HIGH);
}
```
Code: Votre premier chenillard

Vous le voyez, ce code est très lourd et n'est pas pratique.
Nous verrons plus loin comment faire en sorte de l’alléger.
Mais avant cela, un TP arrive... Au fait, voici un exemple de ce que vous pouvez obtenir !

->!(https://www.youtube.com/watch?v=hKNqRAi-kKI)<-