# Montage de base

Pour cette partie, nous allons apprendre à lire l'état d'une entrée numérique.
Tout d'abord, il faut savoir qu'une entrée numérique ne peut prendre que deux états, HAUT (`HIGH`) ou BAS (`LOW`).
L'état haut correspond à une tension de +5V sur la broche, tandis que l'état bas est une tension de 0V.
Dans notre exemple, nous allons utiliser un simple bouton.
Dans la réalité, vous pourriez utiliser n'importe quel capteur qui possède une sortie numérique. Nous allons donc utiliser :

- Un bouton poussoir (et une résistance de 10k de pull-up et un condensateur anti-rebond de 10nF)
- Une LED (et sa résistance de limitation de courant)
- La carte Arduino

Voici maintenant le schéma à réaliser :

![Un bouton et une LED - Schéma](/media/galleries/954/e8fdd9e5-95aa-469a-96e9-3d53e260d140.png.960x960_q85.jpg)

![Un bouton et une LED - Montage](/media/galleries/954/1dc2f2c3-c8d4-4318-82b9-b69549de23cc.png.960x960_q85.png)

# Paramétrer la carte

Afin de pouvoir utiliser le bouton, il faut spécifier à Arduino qu'il y a un bouton de connecté sur une de ses broches.
Cette broche sera donc une **entrée**.
Bien entendu, comme vous êtes de bons élèves, vous vous souvenez que tous les paramétrages initiaux se font dans la fonction `setup()`.
Vous vous souvenez également que pour définir le type (entrée ou sortie) d'une broche, on utilise la fonction : [pinMode()](http://arduino.cc/en/Reference/PinMode).
Notre bouton étant branché sur la pin 2, on écrira :

```cpp
pinMode(2, INPUT);
```

*Pour plus de clarté dans les futurs codes, on considérera que l'on a déclaré une variable globale nommée "bouton" et ayant la valeur 2*.

Comme ceci :

```cpp
const int bouton = 2;

void setup()
{
    pinMode(bouton, INPUT);
}
```

Voilà, maintenant notre carte Arduino sait qu'il y a quelque chose de connecté sur sa broche 2 et que cette broche est configurée en entrée.

# Récupérer l'état du bouton

Maintenant que le bouton est paramétré, nous allons chercher à savoir quel est son état (appuyé ou relâché).

- S'il est relâché, la tension à ses bornes sera de +5V, donc un état logique HIGH.
- S'il est appuyé, elle sera de 0V, donc LOW.


Un petit tour sur la référence et nous apprenons qu'il faut utiliser la fonction [digitalRead()](http://arduino.cc/en/Reference/DigitalRead) pour lire l'état logique d'une entrée logique.
Cette fonction prend un paramètre qui est la broche à tester et elle retourne une variable de type `int`.
Pour lire l'état de la broche 2 nous ferons donc :

```cpp
int etat;

void loop()
{
    etat = digitalRead(bouton); // Rappel : bouton = 2

    if(etat == HIGH)
        actionRelache(); // le bouton est relaché
    else
        actionAppui(); // le bouton est appuyé
}
```

[[a]]
|Observez dans ce code, on appelle deux fonctions qui dépendent de l'état du bouton.
|Ces fonctions ne sont pas présentes dans ce code, si vous le testez ainsi, il ne fonctionnera pas. Pour ce faire, vous devrez créer les fonctions `actionAppui()`.

# Test simple

Nous allons passer à un petit test, que *vous* allez faire. Moi je regarde ! :diable:

## But

L'objectif de ce test est assez simple : lorsque l'on appuie sur le bouton, la LED doit s'éteindre.
Lorsque l'on relâche le bouton, la LED doit s'allumer.
Autrement dit, tant que le bouton est **éteint**, la LED est **allumée**.

## Correction

Allez, c'est vraiment pas dur, en plus je vous donne le montage dans la première partie... Voici la correction :


```cpp
// le bouton est connecté à la broche 2 de la carte Adruino
const int bouton = 2;
// la LED à la broche 13
const int led = 13;

// variable qui enregistre l'état du bouton
int etatBouton;
```
Code: Les variables globales

```cpp
void setup()
{
    pinMode(led, OUTPUT); // la led est une sortie
    pinMode(bouton, INPUT); // le bouton est une entrée
    etatBouton = HIGH; // on initialise l'état du bouton comme "relaché"
}
```
Code: La fonction setup()

```cpp
void loop()
{
    etatBouton = digitalRead(bouton); // Rappel : bouton = 2

    if(etatBouton == HIGH) // test si le bouton a un niveau logique HAUT
    {
        digitalWrite(led, LOW); //le bouton est relâché, la LED est allumée
    }
    else  // test si le bouton a un niveau logique différent de HAUT (donc BAS)
    {
        digitalWrite(led, HIGH); //la LED reste éteinte
    }
}
```
Code: La fonction loop()

J’espère que vous y êtes parvenu sans trop de difficultés ! Si oui, passons à l'exercice suivant...


->!(https://www.youtube.com/watch?v=Eb3Q36zu-S8)<-