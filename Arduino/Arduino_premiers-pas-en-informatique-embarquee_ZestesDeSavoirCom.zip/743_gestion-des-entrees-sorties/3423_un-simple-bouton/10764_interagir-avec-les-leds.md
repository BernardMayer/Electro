Nous allons maintenant faire un exemple d'application ensemble.

# Montage à faire

[[i]]
|Pour cet exercice, nous allons utiliser deux boutons et quatre LEDs de n'importe quelles couleurs.

- Les deux boutons seront considérés actifs (appuyés) à l'état bas (0V) comme dans la partie précédente. Ils seront connectés sur les broches 2 et 3 de l'Arduino.
- Ensuite, les 4 LEDs seront connectées sur les broches 10 à 13 de l'Arduino.

Voilà donc le montage à effectuer :

![Deux boutons et quatre LEDs - Schéma](/media/galleries/954/59b025a7-9026-4ea4-9d71-6fd3f766d36d.png.960x960_q85.jpg)

![Deux boutons et quatre LEDs - Montage](/media/galleries/954/d74b6b96-ee74-4256-9c39-f23734c0b11e.png.960x960_q85.png)

# Objectif : Barregraphe à LED

Dans cet exercice, nous allons faire un mini-barregraphe.
Un barregraphe est un afficheur qui indique une quantité, provenant d'une information quelconque (niveau d'eau, puissance sonore, etc.), sous une forme lumineuse.
Le plus souvent, on utilise des LEDs alignées en guise d'affichage.
Chaque LED se verra allumée selon un niveau qui sera une fraction du niveau total.
Par exemple, si je prends une information qui varie entre 0 et 100, chacune des 4 LED correspondra au quart du maximum de cette variation.
Soit 100 / 4 = 25. En l'occurrence, l'information entrante c'est l'appui des boutons.
Par conséquent un appui sur un bouton allume une LED, un appui sur un autre bouton éteint une LED.
En fait ce n'est pas aussi direct, il faut incrémenter ou décrémenter la valeur d'une variable et en fonction de cette valeur, on allume telle quantité de LED.

## Cahier des charges

La réalisation prévue devra :

- posséder 4 LED (ou plus pour les plus téméraires)
- posséder 2 boutons : un qui incrémentera le nombre de LED allumées, l'autre qui le décrémentera

Vous devrez utiliser une variable qui voit sa valeur augmenter ou diminuer entre 1 et 4 selon l'appui du bouton d'incrémentation ou de décrémentation.

[[i]]
|Vous pouvez maintenant vous lancer dans l'aventure.
|Pour ceux qui se sentiraient encore un peu mal à l'aise avec la programmation, je vous autorise à poursuivre la lecture qui vous expliquera pas à pas comment procéder pour arriver au résultat final. ;)

# Correction

## Initialisation

Pour commencer, on créer et on initialise toutes les variables dont on a besoin dans notre programme :

```cpp
/* déclaration des constantes pour les noms des broches ; ceci selon le schéma*/
const int btn_minus = 2;
const int btn_plus = 3;
const int led_0 = 10;
const int led_1 = 11;
const int led_2 = 12;
const int led_3 = 13;


/* déclaration des variables utilisées pour le comptage et le décomptage */

// le nombre qui sera incrémenté et décrémenté
int nombre_led = 0;
// lecture de l'état des boutons (un seul à la fois mais une variable suffit)
int etat_bouton;

/* initilisation des broches en entrée/sortie */
void setup()
{
    pinMode(btn_plus, INPUT);
    pinMode(btn_minus, INPUT);
    pinMode(led_0, OUTPUT);
    pinMode(led_1, OUTPUT);
    pinMode(led_2, OUTPUT);
    pinMode(led_3, OUTPUT);
}

void loop()
{
    // les instructions de votre programme
}
```

## Détection des différences appuyé/relâché

Afin de détecter un appui sur un bouton, nous devons comparer son état **courant** avec son état **précédent**.
C'est-à-dire qu'avant qu'il soit appuyé ou relâché, on lit son état et on l'inscrit dans une variable. Ensuite, on relit si son état à changé.
Si c'est le cas alors on incrémente la variable `nombre_led`.
*Pour faire cela, on va utiliser une variable de plus par bouton :

```cpp
int memoire_plus = HIGH; // état relâché par défaut
int memoire_minus = HIGH;
```

## Détection du changement d'état

Comme dit précédemment, nous devons détecter le changement de position du bouton, sinon on ne verra rien car tout se passera trop vite. Voilà le programme de la boucle principale :

```cpp
void loop()
{
    // lecture de l'état du bouton d'incrémentation
    etat_bouton = digitalRead(btn_plus);

    // Si le bouton a un état différent de celui enregistré ET
    // que cet état est "appuyé"
    if((etat_bouton != memoire_plus) && (etat_bouton == LOW))
    {
        // on incrémente la variable qui indique
        // combien de LED devrons s'allumer
        nombre_led++;
    }

    // on enregistre l'état du bouton pour le tour suivant
    memoire_plus = etat_bouton;


    // et maintenant pareil pour le bouton qui décrémente
    etat_bouton = digitalRead(btn_minus); // lecture de son état

    // Si le bouton a un état différent que celui enregistré ET
    // que cet état est "appuyé"
    if((etat_bouton != memoire_minus) && (etat_bouton == LOW))
    {
        nombre_led--; // on décrémente la valeur de nombre_led
    }
    // on enregistre l'état du bouton pour le tour suivant
    memoire_minus = etat_bouton;

    // on applique des limites au nombre pour ne pas dépasser 4 ou 0
    if(nombre_led > 4)
    {
        nombre_led = 4;
    }
    if(nombre_led < 0)
    {
        nombre_led = 0;
    }

    // appel de la fonction affiche() que l'on aura créée
    // on lui passe en paramètre la valeur du nombre de LED à éclairer
    affiche(nombre_led);
}
```
Code: Programme de detection d'évènements sur un bouton

Nous avons terminé de créer le squelette du programme et la détection d'évènements, il ne reste plus qu'à afficher le résultat du nombre !

## L'affichage

Pour éviter de se compliquer la vie et d'alourdir le code, on va créer une fonction d'affichage.
Celle dont je viens de vous parler : `affiche(int le_parametre)`.
Cette fonction reçoit un paramètre représentant le nombre à afficher.
A présent, nous devons allumer les LEDs selon la valeur reçue.
On sait que l'on doit afficher une LED lorsque l'on reçoit le nombre 1, 2 LEDs lorsqu'on reçoit le nombre 2, ...

```cpp
void affiche(int valeur_recue)
{
    // on éteint toutes les LEDs
    digitalWrite(led_0, HIGH);
    digitalWrite(led_1, HIGH);
    digitalWrite(led_2, HIGH);
    digitalWrite(led_3, HIGH);

    // Puis on les allume une à une
    if(valeur_recue >= 1)
    {
        digitalWrite(led_0, LOW);
    }
    if(valeur_recue >= 2)
    {
        digitalWrite(led_1, LOW);
    }
    if(valeur_recue >= 3)
    {
        digitalWrite(led_2, LOW);
    }
    if(valeur_recue >= 4)
    {
        digitalWrite(led_3, LOW);
    }
}
```
Code: Fonction d'affichage

Donc, si la fonction reçoit le nombre 1, on allume la LED 1. Si elle reçoit le nombre 2, elle allume la LED 1 et 2. Si elle reçoit 3, elle allume la LED 1, 2 et 3. Enfin, si elle reçoit 4, alors elle allume toutes les LEDs. Le code au grand complet :

[[secret]]
|
| ```cpp
| // déclaration des constantes pour les nom des broches ; selon le schéma
| const int btn_minus = 2;
| const int btn_plus = 3;
| const int led_0 = 10;
| const int led_1 = 11;
| const int led_2 = 12;
| const int led_3 = 13;
|
|
| // déclaration des variables utilisées pour le comptage et le décomptage
|
| // le nombre qui sera incrémenté et décrémenté
| int nombre_led = 0;
| // lecture de l'état des boutons (un seul à la fois mais une variable suffit)
| int etat_bouton;
|
| int memoire_plus = HIGH; // état relâché par défaut
| int memoire_minus = HIGH;
|
|
| /* initilisation des broches en entrée/sortie */
| void setup()
| {
|     pinMode(btn_plus, INPUT);
|     pinMode(btn_minus, INPUT);
|     pinMode(led_0, OUTPUT);
|     pinMode(led_1, OUTPUT);
|     pinMode(led_2, OUTPUT);
|     pinMode(led_3, OUTPUT);
| }
|
| void loop()
| {
|     // lecture de l'état du bouton d'incrémentation
|     etat_bouton = digitalRead(btn_plus);
|
|     // Si le bouton a un état différent que celui enregistré ET
|     // que cet état est "appuyé"
|     if((etat_bouton != memoire_plus) && (etat_bouton == LOW))
|     {
|         // on incrémente la variable qui indique
|         // combien de LED devrons s'allumer
|         nombre_led++;
|     }
|
|     // on enregistre l'état du bouton pour le tour suivant
|     memoire_plus = etat_bouton;
|
|
|     // et maintenant pareil pour le bouton qui décrémente
|     etat_bouton = digitalRead(btn_minus); // lecture de son état
|
|     // Si le bouton a un état différent que celui enregistré ET
|     // que cet état est "appuyé"
|     if((etat_bouton != memoire_minus) && (etat_bouton == LOW))
|     {
|         nombre_led--; // on décrémente la valeur de nombre_led
|     }
|     // on enregistre l'état du bouton pour le tour suivant
|     memoire_minus = etat_bouton;
|
|     // on applique des limites au nombre pour ne pas dépasser 4 ou 0
|     if(nombre_led > 4)
|     {
|         nombre_led = 4;
|     }
|     if(nombre_led < 0)
|     {
|         nombre_led = 0;
|     }
|
|     // appel de la fonction affiche() que l'on aura créée
|     // on lui passe en paramètre la valeur du nombre de LED à éclairer
|     affiche(nombre_led);
| }
|
| void affiche(int valeur_recue)
| {
|     // on éteint toutes les leds
|     digitalWrite(led_0, HIGH);
|     digitalWrite(led_1, HIGH);
|     digitalWrite(led_2, HIGH);
|     digitalWrite(led_3, HIGH);
|
|     // Puis on les allume une à une
|     if(valeur_recue >= 1)
|     {
|         digitalWrite(led_0, LOW);
|     }
|     if(valeur_recue >= 2)
|     {
|         digitalWrite(led_1, LOW);
|     }
|     if(valeur_recue >= 3)
|     {
|         digitalWrite(led_2, LOW);
|     }
|     if(valeur_recue >= 4)
|     {
|         digitalWrite(led_3, LOW);
|     }
| }
| ```
| Code: Le code final

 Une petite vidéo du résultat que vous devriez obtenir, même si votre code est différent du mien :

->!(https://www.youtube.com/watch?v=2fK6nk5NDAU)<-