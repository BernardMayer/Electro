Derrière ce titre trivial se cache un composant de base très utile, possédant de nombreux détails que vous ignorez peut-être.
Commençons donc dès maintenant l'autopsie de ce dernier.

# Mécanique du bouton

Vous le savez sûrement déjà, un bouton n'est jamais qu'un fil qui est connecté ou non selon sa position.
En pratique, on en repère plusieurs, qui diffèrent selon leur taille, leurs caractéristiques électriques, les positions mécaniques possibles, etc.

## Le bouton poussoir normalement ouvert (NO)

Dans cette partie du tutoriel, nous allons utiliser ce type de boutons poussoirs (ou BP).
Ces derniers ont deux positions :

- **Relâché** : le courant ne passe pas, le circuit est déconnecté ; on dit que le circuit est "**ouvert**".
- **Appuyé** : le courant passe, on dit que le circuit est **fermé**.

[[a]]
| Retenez bien ces mots de vocabulaire !

## Le bouton poussoir normalement fermé (NF)

Ce type de bouton est l'opposé du type précédent, c'est-à-dire que lorsque le bouton est relâché, il laisse passer le courant.
Et inversement :

- **Relâché** : le courant passe, le circuit est connecté ; on dit que le circuit est "**fermé**".
- **Appuyé** : le courant ne passe pas, on dit que le circuit est **ouvert**.

## Les interrupteurs

À la différence d'un bouton poussoir, l'interrupteur agit comme une bascule.
Un appui ferme le circuit et il faut un second appui pour l'ouvrir de nouveau.
Il possède donc des états stables (ouvert ou fermé).
On dit qu'un interrupteur est **bistable**.
Vous en rencontrez tous les jours lorsque vous allumez la lumière ;) .

# L'électronique du bouton

## Symbole

Le BP et l'interrupteur ne possèdent pas le même symbole pour les schémas électroniques.
Le premier est représenté par une barre qui doit venir faire contact pour fermer le circuit ou défaire le contact pour ouvrir le circuit.
Le second est représenté par un fil qui ouvre un circuit et qui peut bouger pour le fermer.
Voici leurs symboles, il est important de s'en rappeler :

->

![symbole BP NO](/media/galleries/954/ae3d828a-469b-47ff-9d79-f9c17bc69c2f.jpg.960x960_q85.jpg)|![symbole BP NF](/media/galleries/954/3b9c2d26-44ba-4efd-bc0c-7b753d59502d.png.960x960_q85.jpg)|![symbole d'un interrupteur](/media/galleries/954/65558460-2136-45fd-a686-f1477a3b0403.png.960x960_q85.jpg)
-----------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------
Bouton Poussoir NO|Bouton Poussoir NF|Interrupteur

Table: Symboles conventionnels des boutons

<-

## Tension et courant

Voici maintenant quelques petites précisions sur les boutons :

- Lorsqu'il est ouvert, la tension à ses bornes ne peut être nulle (ou alors c'est que le circuit n'est pas alimenté). En revanche, lorsqu'il est fermé cette même tension doit être nulle. En effet, aux bornes d'un fil la tension est de 0V.
- Ensuite, lorsque le bouton est ouvert, aucun courant ne peut passer, le circuit est donc déconnecté. Par contre, lorsqu'il est fermé, le courant nécessaire au bon fonctionnement des différents composants le traverse. Il est donc important de prendre en compte cet aspect. Un bouton devant supporter deux ampères ne sera pas aussi gros qu'un bouton tolérant 100 ampères (et pas aussi cher :P ).

[[a]]
|Il est très fréquent de trouver des boutons dans les starters kit.


![Quelques boutons poussoirs](http://zestedesavoir.com/media/galleries/954/cb22f56e-7ae5-4dcd-9f4e-668916680113.jpg.960x960_q85.jpg)
Figure: Quelques boutons poussoirs - (CC-BY-SA [Scwerllguy](http://commons.wikimedia.org/wiki/File:Tactile_switches.jpg))

Souvent ils ont quatre pattes (comme sur l'image ci-dessus). Si c'est le cas, sachez que les broches sont reliées deux à deux. Cela signifie quelles fonctionnent par paire. Il faut donc se méfier lorsque vous le brancher sinon vous obtiendrez le même comportement qu'un fil (si vous connectez deux broches reliées).
Utilisez un multimètre pour déterminer quelles broches sont distinctes. **Pour ne pas se tromper, on utilise en général deux broches qui sont opposées sur la diagonale du bouton.**

# Contrainte pour les montages

Voici maintenant un point très important, soyez donc attentif car je vais vous expliquer le rôle d'une résistance de pull-up !

[[q]]
|C'est quoi c't'animal, le poule-eup ?

Lorsque l'on fait de l'électronique, on a toujours peur des perturbations (générées par plein de choses : des lampes à proximité, un téléphone portable, un doigt sur le circuit, l'électricité statique, ...).
On appelle ça des contraintes de **CEM**.
Ces perturbations sont souvent inoffensives, mais perturbent beaucoup les montages électroniques.
Il est alors nécessaire de les prendre en compte lorsque l'on fait de l'électronique de signal.
Par exemple, dans certains cas on peut se retrouver avec un bit de signal qui vaut 1 à la place de 0, les données reçues sont donc fausses.

Pour contrer ces effets nuisibles, on place en série avec le bouton une résistance de pull-up.
Cette résistance sert à "tirer" ("to pull" in english) le potentiel vers le haut (up) afin d'avoir un signal clair sur la broche étudiée.
Sur le schéma suivant, on voit ainsi qu'en temps normal le "signal" a un potentiel de 5V.
Ensuite, lorsque l'utilisateur appuiera sur le bouton une connexion sera faite avec la masse.
On lira alors une valeur de 0V pour le signal.
Voici donc un deuxième intérêt de la résistance de pull-up, éviter le court-circuit qui serait généré à l'appui !

![Résistance Pull up](/media/galleries/954/32c84ea3-a6b3-47ba-bac4-bae6abdc1d74.png.960x960_q85.jpg)

## Filtrer les rebonds

Les boutons ne sont pas des systèmes mécaniques parfaits.
Du coup, lorsqu'un appui est fait dessus, le signal ne passe pas immédiatement et proprement de 5V à 0V.
En l'espace de quelques millisecondes, le signal va "sauter" entre 5V et 0V plusieurs fois avant de se stabiliser.
Il se passe le même phénomène lorsque l'utilisateur relâche le bouton.

Ce genre d'effet n'est pas désirable, car il peut engendrer des parasites au sein de votre programme (si vous voulez détecter un appui, les rebonds vont vous en générer une dizaine en quelques millisecondes, ce qui peut-être très gênant dans le cas d'un compteur par exemple).
Voilà un exemple de chronogramme relevé lors du relâchement d'un bouton poussoir :

![Chronogramme avec rebond](/media/galleries/954/3de19943-d82d-4ecc-a48d-12375d694883.png.960x960_q85.jpg)

Pour atténuer ce phénomène, nous allons utiliser un condensateur en parallèle avec le bouton.
Ce composant servira ici "d'amortisseur" qui absorbera les rebonds (comme sur une voiture avec les cahots de la route).
Le condensateur, initialement chargé, va se décharger lors de l'appui sur le bouton.
S'il y a des rebonds, ils seront encaissés par le condensateur durant cette décharge.
Il se passera le phénomène inverse (charge du condensateur) lors du relâchement du bouton.
Ce principe est illustré à la figure suivante :

![Filtre anti-rebond](/media/galleries/954/f5975e1c-edf4-4406-ac09-30c1168dcbb0.png.960x960_q85.jpg)

## Schéma résumé

En résumé, voilà un montage que vous pourriez obtenir avec un bouton, sa résistance de pull-up et son filtre anti-rebond sur votre carte Arduino :

![Un bouton + résistance pullup - Schéma](/media/galleries/954/4f88ce9f-8734-4272-bedb-4dd8fa41e88a.png.960x960_q85.png)

![Un bouton + résistance pullup - Montage](/media/galleries/954/c6d50dc4-2f7d-4282-ae1b-83fa2532f5f8.png.960x960_q85.png)

# Les pull-ups internes

Comme expliqué précédemment, pour obtenir des signaux clairs et éviter les courts-circuits, on utilise des résistances de pull-up.
Cependant, ces dernières existent aussi en interne du microcontrôleur de l'Arduino, ce qui évite d'avoir à les rajouter par nous-mêmes par la suite.
Ces dernières ont une valeur de 20 kilo-Ohms.
Elles peuvent être utilisées sans aucune contrainte technique.

Cependant, si vous les mettez en marche, il faut se souvenir que cela équivaut à mettre la broche à l'état haut (et en entrée évidemment).
Donc si vous repassez à un état de sortie ensuite, rappelez-vous bien que tant que vous ne l'avez pas changée elle sera à l'état haut.
Ce que je viens de dire permet de mettre en place ces dernières dans le logiciel :

```cpp
const int unBouton = 2; // un bouton sur la broche 2

void setup()
{
    // on met le bouton en entrée
    pinMode(unBouton, INPUT);
    // on active la résistance de pull-up en mettant la broche à l'état haut
    // (mais cela reste toujours une entrée)
    digitalWrite(unBouton, HIGH);
}

void loop()
{
    // votre programme
}
```
Code: Initialisation d'un bouton

[[i]]
| Depuis la version 1.0.1 d'Arduino, une pull-up peut être simplement mise en oeuvre en utilisant le deuxième argument de `pinMode`. La syntaxe devient `pinMode(unBouton, INPUT_PULLUP)` et il n'y a plus besoin de faire un `digitalWrite()` ensuite.

## Schéma résumé

![Un bouton + résistance pullup interne - Schéma](/media/galleries/954/0d8e0ef1-39f5-4514-939f-b3284b10b438.png.960x960_q85.png)

![Un bouton + résistance pullup interne - Montage](/media/galleries/954/e0e389dc-c962-42d1-9844-f684da000987.png.960x960_q85.png)

*[CEM]: Compatibilité ÉlectroMagnétique