[[a]]
|Voici maintenant un sujet plus délicat (mais pas tant que ça ! :ninja: ) qui demande votre attention.

Comme vous l'avez remarqué dans la partie précédente, pour récupérer l'état du bouton il faut surveiller régulièrement l'état de ce dernier.
Cependant, si le programme a quelque chose de long à traiter, par exemple s'occuper de l'allumage d'une LED et faire une pause avec `delay()` (bien que l'on puisse utiliser `millis()` ), l'appui sur le bouton ne sera pas très réactif et lent à la détente.
Pour certaines applications, cela peut gêner.

**Problème :** si l'utilisateur appuie et relâche rapidement le bouton, vous pourriez ne pas détecter l'appui (si vous êtes dans un traitement long).

**Solution :** utiliser le mécanisme d'**interruption**.

# Principe

Dans les parties précédentes de ce chapitre, la lecture d'un changement d'état se faisait en comparant régulièrement l'état du bouton à un moment avec son état précédent.
Cette méthode fonctionne bien, mais pose un problème : l'appui ne peut pas être détecté s'il est trop court.
Autre situation, si l'utilisateur fait un appui très long, mais que vous êtes déjà dans un traitement très long (calcul de la millième décimale de PI, soyons fous), le temps de réponse à l'appui ne sera pas du tout optimal, l'utilisateur aura une impression de lag (= pas réactif).
Pour pallier ce genre de problème, les constructeurs de microcontrôleurs ont mis en place des systèmes qui permettent de détecter des évènements et d’exécuter des fonctions dès la détection de ces derniers.
Par exemple, lorsqu'un pilote d'avion de chasse demande au siège de s'éjecter, le siège doit réagir au moment de l'appui, pas une minute plus tard (trop tard).

[[q]]
|Qu'est-ce qu'une interruption ?

Une interruption est en fait un déclenchement qui arrête l’exécution du programme pour faire une tâche demandée.
Par exemple, imaginons que le programme compte jusqu'à l'infini.
Moi, programmeur, je veux que le programme arrête de compter lorsque j'appuie sur un bouton.
Or, il s'avère que la fonction qui compte est une boucle for(), dont on ne peut sortir sans avoir atteint l'infini (autrement dit jamais, en théorie).
Nous allons donc nous tourner vers les interruptions qui, dès que le bouton sera appuyé, interromprons le programme pour lui dire : "*Arrête de compter, c'est l'utilisateur qui le demande !*".

Pour résumer : **une interruption du programme est générée lors d'un événement attendu. Ceci dans le but d'effectuer une tâche, puis de reprendre l'exécution du programme**.
Arduino propose aussi ce genre de gestion d’évènements.
On les retrouvera sur certaines broches, sur des timers, des liaisons de communication, etc.

# Mise en place

Nous allons illustrer ce mécanisme avec ce qui nous concerne ici, les boutons.
Dans le cas d'une carte Arduino UNO, on trouve deux broches pour gérer des interruptions externes (qui ne sont pas dues au programme lui-même), la 2 et la 3.
Pour déclencher une interruption, plusieurs cas de figure sont possibles :

- **LOW** : Passage à l'état bas de la broche
- **FALLING** : Détection d'un front descendant (passage de l'état haut à l'état bas)
- **RISING** : Détection d'un front montant (pareil qu'avant, mais dans l'autre sens)
- **CHANGE** : Changement d'état de la broche

Autrement dit, s'il y a un changement d'un type énuméré au-dessus, alors le programme sera interrompu pour effectuer une action.

## Créer une nouvelle interruption

Comme d'habitude, nous allons commencer par faire des réglages dans la fonction setup(). La fonction importante à utiliser est [`attachInterrupt(interrupt, function, mode)`](http://arduino.cc/en/Reference/AttachInterrupt). Elle accepte trois paramètres :

- `interrupt` : qui est le numéro de la broche utilisée pour l'interruption (0 pour la broche 2 et 1 pour la broche 3)
- `function` : qui est le nom de la fonction à appeler lorsque l'interruption est déclenchée
- `mode` : qui est le type de déclenchement (cf. ci-dessus)

Si l'on veut appeler une fonction nommée `Reagir()` lorsque l'utilisateur appuie sur un bouton branché sur la broche 2 on fera :

```cpp
attachInterrupt(0, Reagir, FALLING);
```

[[i]]
|Vous remarquerez l'absence des parenthèses après le nom de la fonction "Reagir".

Ensuite, il vous suffit de coder votre fonction `Reagir()` un peu plus loin.

[[e]]
|Attention, cette fonction ne peut pas prendre d'argument et ne retournera aucun résultat.


Lorsque quelque chose déclenchera l'interruption, le programme principal sera mis en pause.
Ensuite, lorsque l'interruption aura été exécutée et traitée, il reprendra comme si rien ne s'était produit (avec peut-être des variables mises à jour).

# Mise en garde

Si je fais une partie entière sur les interruptions, ce n'est pas que c'est difficile mais c'est surtout pour vous mettre en garde sur certains points.
Tout d'abord, **les interruptions ne sont pas une solution miracle**.
En effet, gardez bien en tête que leur utilisation répond à un besoin **justifié**.
Elles mettent tout votre programme en pause, et une mauvaise programmation (ce qui n'arrivera pas, je vous fais confiance ;) ) peut entraîner une altération de l'état de vos variables.
De plus, les fonctions `delay()` et `millis()` n'auront pas un comportement correct.
En effet, pendant ce temps le programme principal est complètement stoppé, donc les fonctions gérant le temps ne fonctionneront plus, elles seront aussi en pause et laisseront la priorité à la fonction d'interruption.

La fonction `delay()` est donc désactivée et la valeur retournée par `millis()` ne changera pas.
Justifiez donc votre choix avant d'utiliser les interruptions. ;)