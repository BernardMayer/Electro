Il est pas magnifique ce parking ? J’espère que vous avez apprécié sa réalisation.
Nous allons maintenant continuer à apprendre de nouvelles choses, toujours plus sympas les unes que les autres.
Un conseil, gardez votre travail quelques part au chaud, vous pourriez l'améliorer avec vos connaissances futures !