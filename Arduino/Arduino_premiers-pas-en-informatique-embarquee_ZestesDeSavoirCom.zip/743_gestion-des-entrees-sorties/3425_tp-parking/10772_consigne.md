Après tant de connaissances chacune séparée dans son coin, nous allons pouvoir mettre en œuvre tout ce petit monde dans un TP traitant sur un sujet de la vie courante : les **parkings!

## Histoire

Le maire de zCity à décidé de rentabiliser le parking communal d'une capacité de 99 places (pas une de plus ni de moins).
En effet, chaque jour des centaines de zTouristes viennent se promener en voiture et ont besoin de la garer quelque part.
Le parking, n'étant pour le moment pas rentable, servira à financer l'entretien de la ville.
Pour cela, il faut rajouter au parking existant un afficheur permettant de savoir le nombre de places disponibles en temps réel (le système de paiement du parking ne sera pas traité).
Il dispose aussi dans la ville des lumières vertes et rouges signalant un parking complet ou non.
Enfin, l'entrée du parking est équipée de deux barrières (une pour l'entrée et l'autre pour la sortie).
Chaque entrée de voiture ou sortie génère un signal pour la gestion du nombre de places.
Le maire vous a choisi pour vos compétences, votre esprit de créativité et il sait que vous aimez les défis. Vous acceptez évidemment en lui promettant de réussir dans les plus brefs délais !

## Matériel

Pour mener à bien ce TP voici la liste des courses conseillée :

- Une carte Arduino (évidemment)
- 2 LEDs avec leur résistance de limitations de courant (habituellement 330 Ohms) -> Elles symbolisent les témoins lumineux disposés dans la ville
- 2 boutons (avec 2 résistances de 10 kOhms et 2 condensateurs de 10 nF) -> Ce sont les "capteurs" d'entrée et de sortie.
- 2 afficheurs 7 segments -> pour afficher le nombre de places disponibles</li>
- 1 décodeur 4 bits vers 7 segments
- 7 résistances de 330 Ohms (pour les 7 segments)
- Une breadboard pour assembler le tout
- Un paquet de fils
- Votre cerveau et quelques doigts...


Voici une vidéo pour vous montrer le résultat attendu par le maire :

->!(https://www.youtube.com/watch?v=pZWYGTFN7nM)<-


->**Bon courage !**<-