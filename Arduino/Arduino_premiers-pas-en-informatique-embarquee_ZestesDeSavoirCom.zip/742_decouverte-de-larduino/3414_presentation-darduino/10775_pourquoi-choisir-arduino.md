# Que va-t-on faire avec ?
Avec Arduino, nous allons commencer par apprendre à programmer puis à utiliser des composants électroniques. En fin de compte, nous saurons créer des systèmes électroniques plus ou moins complexes. Mais ce n'est pas tout...
## D'abord, Arduino c'est...
... une carte électronique programmable et un logiciel gratuit :

![Carte Arduino Uno](/media/galleries/954/4d259bf8-aae4-4476-9bd3-84dc431f2fec.png.960x960_q85.jpg)
Figure: Carte Arduino Uno - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardUno))

## Mais aussi
- Un prix dérisoire étant donné l'étendue des applications possibles. On comptera 20 euros pour la carte que l'on va utiliser dans le cours. Le logiciel est fourni gratuitement !
- Une compatibilité sous toutes les plateformes, à savoir : Windows, Linux et Mac OS.
- Une communauté ultra développée ! Des milliers de forums d'entre-aide, de présentations de projets, de propositions de programmes et de bibliothèques, ...
- Un site en anglais [arduino.cc](http://www.arduino.cc/) et un autre en français [arduino.cc](http://www.arduino.cc/fr/) où vous trouverez tout de la référence Arduino, le matériel, des exemples d'utilisations, de l'aide pour débuter, des explications sur le logiciel et le matériel, etc.
- Une liberté quasi absolue. Elle constitue en elle-même deux choses :
     - Le logiciel : gratuit et open source, développé en Java, dont la simplicité d'utilisation relève du savoir cliquer sur la souris.
     - Le matériel : cartes électroniques dont les schémas sont en libre circulation sur internet.

[[attention]]
| Cette liberté a une condition : le nom « Arduino » ne doit être employé que pour les cartes « officielles ». En somme, vous ne pouvez pas fabriquer votre propre carte sur le modèle Arduino et lui assigner le nom « Arduino ».

## Et enfin, les applications possibles
Voici une liste non exhaustive des applications possibles réalisées grâce à Arduino :

- contrôler des appareils domestiques
- donner une "intelligence" à un robot
- réaliser des jeux de lumières
- permettre à un ordinateur de communiquer avec une carte électronique et différents capteurs
- télécommander un appareil mobile (modélisme)
- etc.

Il y a une infinité d'autres utilisations, vous pouvez simplement chercher sur votre moteur de recherche préféré ou sur Youtube le mot "Arduino" pour découvrir les milliers de projets réalisés avec !

## Arduino dans ce tutoriel

Je vais quand même rappeler les principaux objectifs de ce cours. Nous allons avant tout découvrir Arduino dans son ensemble et apprendre à l'utiliser. Dans un premier temps, il s'agira de vous présenter ce qu'est Arduino, comment cela fonctionne globalement, pour ensuite entrer un peu plus dans le détail. Nous allons alors apprendre à utiliser le langage Arduino pour pouvoir créer des programmes très simples pour débuter. Nous enchaînerons ensuite avec les différentes fonctionnalités de la carte et ferons de petits TP qui vous permettront d'assimiler chaque notion abordée. Dès lors que vous serez plutôt à l'aise avec toutes les bases, nous nous rapprocherons de l'utilisation de composants électroniques plus ou moins complexes et finirons par un plus "gros" TP alliant la programmation et l'électronique. De quoi vous mettre de l'eau à la bouche ! :P

# Arduino à l'école

Pédagogiquement, Arduino a aussi pas mal d'atouts. En effet, ses créateurs ont d'abord pensé ce projet pour qu'il soit facile d'accès. Il permet ainsi une très bonne approche de nombreux domaines et ainsi d'apprendre plein de choses assez simplement.
## Des exemples

Voici quelques exemples d'utilisation possible :

- Simuler le fonctionnement des portes logiques
- Permettre l'utilisation de différents capteurs
- Mettre en œuvre et faciliter la compréhension d'un réseau informatique
- Se servir d'Arduino pour créer des maquettes animées montrant le fonctionnement des collisions entres les plaques de la croûte terrestre, par exemple ^^
- Donner un exemple concret d'utilisation des matrices avec un clavier alphanumérique 16 touches ou plus
- Être la base pour des élèves ayant un TPE à faire pour le BAC
- ...

De plus, énormément de ressources et tutoriels (mais souvent en anglais) se trouvent sur internet, ce qui offre un autonomie particulière à l'apprenant.

## Des outils existant :

Enfin, pour terminer de vous convaincre d'utiliser Arduino pour découvrir le monde merveilleux de l'embarqué, il existe différents outils qui peuvent être utilisés avec Arduino. Je vais en citer deux qui me semblent être les principaux : [Ardublock](blog.ardublock.com) est un outil qui se greffe au logiciel Arduino et qui permet de programmer avec des blocs. Chaque bloc est une instruction. On peut aisément faire des programmes avec cet outil et même des plutôt complexes. Cela permet par exemple de se concentrer sur ce que l'on doit faire avec Arduino et non se concentrer sur Arduino pour ensuite ce que l'on doit comprendre avec. Citons entre autre la simulation de porte logique : il vaut mieux créer des programmes rapidement sans connaitre le langage pour comprendre plus facilement comment fonctionne une porte logique. Et ce n'est qu'un exemple. Cela permet aussi à de jeunes enfants de commencer à programmer sans de trop grandes complications.

![Exemple de programme avec Ardublock](/media/galleries/954/b217f285-f7bc-49a0-8568-d47e54c7eabc.png.960x960_q85.png)

[Processing](http://processing.org) est une autre plateforme en lien avec Arduino. Là il n'y a pas de matériel, uniquement un logiciel. Il permet entre autre de créer des interfaces graphiques avec un langage de programmation très similaire à celui d'Arduino. Par contre, cela demande un niveau un peu plus élevé pour pouvoir l'utiliser, même si cela reste simple dans l'ensemble.

Voilà un exemple de ce que j'avais réalisé avec Processing pour faire communiquer mon ordinateur avec ma carte Arduino :

![Une interface réalisée avec Processing](/media/galleries/954/8cd338b2-2534-4cf5-a177-d92af79f1004.png.960x960_q85.jpg)

J'espère avoir été assez convaincant afin que vous franchissiez le pas et ayez du plaisir à apprendre ! :)