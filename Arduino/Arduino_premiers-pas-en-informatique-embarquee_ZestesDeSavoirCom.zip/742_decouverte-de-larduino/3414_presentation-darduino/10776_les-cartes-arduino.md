Le matériel que j’ai choisi d’utiliser tout au long de ce cours n’a pas un prix excessif et, je l'ai dit, tourne aux alentours de 25 € TTC. Il existe plusieurs magasins en ligne et en boutiques qui vendent des cartes Arduino. Je vais vous en donner quelques-uns, mais avant, il va falloir différencier certaines choses.

# Les fabricants

Le projet Arduino est libre et les schémas des cartes circulent librement sur internet. D'où la mise en garde que je vais faire : il se peut qu'un illustre inconnu fabrique *lui-même* ses cartes Arduino. Cela n'a rien de mal en soi, s’il veut les commercialiser, il peut. Mais s'il est malhonnête, il peut vous vendre un produit défectueux. Bien sûr, tout le monde ne cherchera pas à vous arnaquer. Mais la prudence est de rigueur. Faites donc attention *où vous achetez vos cartes*.
#### Les types de cartes

![Logo Arduino](/media/galleries/954/9a636e7c-68b9-4c9a-9e26-a2f4e7bdeddd.gif.960x960_q85.jpg)

Il y a trois types de cartes :

- Lesdites « officielles », qui sont fabriquées en Italie par le fabricant officiel : *Smart Projects*.
- Lesdits « compatibles », qui ne sont pas fabriqués par *Smart Projects*, mais qui sont totalement compatibles avec les Arduino officielles.
- Les « autres », fabriquées par diverses entreprises et commercialisées sous un nom différent (Freeduino, Seeduino, Femtoduino, ...).

# Les différentes cartes
Des cartes Arduino il en existe beaucoup ! Voyons celles qui nous intéressent... **Les cartes *Uno* et *Duemilanove* **. Nous choisirons d'utiliser la carte portant le nom de « Uno » ou « Duemilanove ». Ces deux versions sont presque identiques.

![](http://zestedesavoir.com/media/galleries/954/e0c39fb1-ba60-4e03-8e95-416d01721e89.png)
Figure: Carte Arduino Duemilanove - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardDuemilanove))

![](http://zestedesavoir.com/media/galleries/954/ca768b2a-5580-4a88-9b22-25e3f58cf9d3.gif)
Figure: Carte Arduino Uno - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardUno))

**La carte *Mega* **. La carte Arduino Mega est une autre carte qui offre toutes les fonctionnalités de la carte précédente, mais avec des fonctionnalités supplémentaires. On retrouve notamment un nombre d’entrées et de sorties plus important ainsi que plusieurs liaisons séries. Bien sûr, le prix est plus élevé : > 40 € !

![Une carte Arduino "Mega"](/media/galleries/954/133bb101-4625-4edd-bcd4-5a0f91726902.png.960x960_q85.jpg)
Figure: Carte Arduino Mega - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardMega2560))

**Les autres cartes**. Il existe encore beaucoup d'autres cartes, je vous laisse vous débrouiller pour trouver celle qui conviendra à vos projets. Cela dit, je vous conseil dans un premier temps d'utiliser la carte Arduino Uno ou Duemilanove d'une part car elle vous sera largement suffisante pour débuter et d'autre part car c'est avec celle-ci que nous présentons le cours.

# Où acheter ?
Il existe sur le net une multitude de magasins (des vendeurs professionnels, des importateurs mais aussi des petits détaillants de quartier) qui proposent des cartes Arduino.

[[question]]
| J'ai vu des cartes officielles "édition SMD/CMS". Ça à l'air bien aussi, c'est quoi la différence ? Je peux m'en servir ?

Il n'y a pas de différence ! Enfin presque... "SMD" signifie **Surface Mount Device**, en français on appelle ça des "CMS" pour **Composants Montés en Surface**. Ces composants sont soudés directement sur le cuivre de la carte, il ne la traverse pas comme les autres. Pour les cartes Arduino, on retrouve le composant principal en édition SMD dans ces cartes. La carte est donc la même, aucune différence pour le tuto. Les composants sont les mêmes, seule l'allure "physique" est différente. Par exemple, ci-dessus la "Mega" est en SMD et la Uno est "classique".