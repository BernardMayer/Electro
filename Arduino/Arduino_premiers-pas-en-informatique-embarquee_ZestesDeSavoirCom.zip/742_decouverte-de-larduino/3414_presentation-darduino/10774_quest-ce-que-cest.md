Une équipe de développeurs composée de *Massimo Banzi, David Cuartielles, Tom Igoe, Gianluca Martino, David Mellis* et *Nicholas Zambetti* a imaginé un projet répondant au doux nom de **Arduino** et mettant en œuvre une petite carte électronique programmable et un logiciel multiplateforme, qui puisse être accessible à tout un chacun dans le but de créer facilement des systèmes électroniques. Étant donné qu'il y a des débutants parmi nous, commençons par voir un peu le vocabulaire commun propre au domaine de l'électronique et de l'informatique.

### Une carte électronique
Une **carte électronique** est un support plan, flexible ou rigide, généralement composé d'[epoxy](http://fr.wikipedia.org/wiki/Poly%C3%A9poxyde) ou de fibre de verre. Elle possède des pistes électriques disposées sur une, deux ou plusieurs couches (en surface et/ou en interne) qui permettent la mise en relation électrique des composants électroniques. Chaque piste relie tel composant à tel autre, de façon à créer un système électronique qui fonctionne et qui réalise les opérations demandées.

![Exemple de carte électronique : Arduino Severino](http://zestedesavoir.com/media/galleries/954/ac61e99a-b23f-4f46-b72d-9127583c4007.jpg.960x960_q85.jpg)
Figure: Exemple de carte électronique : Arduino Severino - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/Boards))

![](http://zestedesavoir.com/media/galleries/954/f5db282c-cfa7-4b76-bd06-a14aaa4665be.png)
Figure: Carte Arduino Duemilanove - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardDuemilanove))

Évidemment, tous les composants d'une carte électronique ne sont pas forcément reliés entre eux. Le câblage des composants suit un plan spécifique à chaque carte électronique, qui se nomme le **schéma électronique**.

![Exemple de schéma électronique - carte Arduino Uno](/media/galleries/954/46a27fd4-4c04-4076-8692-f3ca0a2b8250.png.960x960_q85.jpg)
Figure: Exemple de schéma électronique - carte Arduino Uno - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardUno))

Enfin, avant de passer à la réalisation d'un carte électronique, il est nécessaire de transformer le schéma électronique en un **schéma de câblage**, appelé **typon**.

![Exemple de typon - carte Arduino](/media/galleries/954/5abb6899-f6a9-4a48-b384-3feb916a66e9.png.960x960_q85.jpg)
Figure: Exemple de typon - carte Arduino - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardUno))

[[question]]
| Une fois que l'on a une carte électronique, on fait quoi avec ?

Eh bien une fois que la carte électronique est faite, nous n'avons plus qu'à la tester et l'utiliser ! Dans notre cas, avec Arduino, nous n'aurons pas à fabriquer la carte et encore moins à la concevoir. Elle existe, elle est déjà prête à l'emploi et nous n'avons plus qu'à l'utiliser. Et pour cela, vous allez devoir apprendre comment l'utiliser, ce que je vais vous montrer dans ce tutoriel.

### Programmable ?
J'ai parlé de **carte électronique programmable** au début de ce chapitre. Mais savez-vous ce que c'est exactement ? Non pas vraiment. Alors voyons ensemble de quoi il s'agit. La carte Arduino est une carte électronique *qui ne sait rien faire* sans qu'on lui dise *quoi faire*. Pourquoi ? Eh bien c'est dû au fait qu'elle est **programmable**. Cela signifie qu'elle a besoin d'un **programme** pour fonctionner.
#### Un programme
Un programme est une liste d'instructions qui est exécutée par un système. Par exemple votre navigateur internet, avec lequel vous lisez probablement ce cours, est un programme. On peut analogiquement faire référence à une liste de course :

![Exemple, une liste de course](/media/galleries/954/d25ace62-4445-4b4e-b7cb-c3dcb7317544.png.960x960_q85.jpg)

Chaque élément de cette liste est une **instruction** qui vous dit : "Va chercher le lait" ou "Va chercher le pain", etc. Dans un programme le fonctionnement est similaire :

- Attendre que l'utilisateur rentre un site internet à consulter
- Rechercher sur internet la page demandée
- Afficher le résultat

Tel pourrait être le fonctionnement de votre navigateur internet. Il va attendre que vous lui demandiez quelque chose pour aller le chercher et ensuite vous le montrer. Eh bien, tout aussi simplement que ces deux cas, une carte électronique programmable suit une liste d'instructions pour effectuer les opérations demandées par le programme.

[[question]]
| Et on les trouves où ces programmes ? Comment on fait pour le mettre dans la carte ? o_O

Des programmes, on peut en trouver de partout. Mais restons concentrés sur Arduino. Le programme que nous allons mettre dans la carte Arduino, c'est nous qui allons le réaliser. Oui, vous avez bien lu : nous allons programmer cette carte Arduino. Bien sûr, ce ne sera pas aussi simple qu'une liste de course, mais rassurez-vous cependant car nous allons réussir quand même ! Je vous montrerai comment y parvenir, puisque avant tout c'est un des objectifs de ce tutoriel. Voici un exemple de programme :

```cpp
// définition de la broche 2 de la carte en tant que variable
const int led_rouge = 2;

// fonction d'initialisation de la carte
void setup()
{
    // initialisation de la broche 2 comme étant une sortie
    pinMode(led_rouge, OUTPUT);
}

void loop()
{
    // allume la LED
    digitalWrite(led_rouge, LOW);
    // fait une pause de 1 seconde
    delay(1000);
    // éteint la LED
    digitalWrite(led_rouge, HIGH);
    // fait une pause de 1 seconde
    delay(1000);
}
```
Code: Un exemple de programme simple

Vous le voyez comme moi, il s'agit de plusieurs lignes de texte, chacune étant une instruction. Ce langage ressemble à un véritable baragouin et ne semble vouloir *a priori* rien dire du tout... Et pourtant, c'est ce que nous saurons faire dans quelques temps ! Car nous apprendrons le **langage informatique** utilisé pour programmer la carte Arduino. Je ne m'attarde pas sur les détails, nous aurons amplement le temps de revenir sur le sujet plus tard. Pour répondre à la deuxième question, nous allons avoir besoin d'un logiciel...

### Et un logiciel ?
Bon, je ne vais pas vous faire le détail de ce qu'est un logiciel, vous savez sans aucun doute de quoi il s'agit. Ce n'est autre qu'un programme informatique exécuté sur un ordinateur. Oui, pour programmer la carte Arduino, nous allons utiliser un programme ! En fait, il va s'agir d'un **compilateur**. Alors qu'est-ce que c'est exactement ?
#### Un compilateur
En informatique, ce terme désigne un logiciel qui est capable de traduire un langage informatique, ou plutôt un programme utilisant un langage informatique, vers un langage plus approprié afin que la machine qui va le lire puisse le comprendre. C'est un peu comme si le patron anglais d'une firme Chinoise donnait des instructions en anglais à un de ses ouvriers chinois. L'ouvrier ne pourrait comprendre ce qu'il doit faire. Pour cela, il a besoin que l'on traduise ce que lui dit son patron. C'est le rôle du **traducteur**. Le compilateur va donc traduire les instructions du programme précédent, écrites en langage texte, vers un langage dit "machine". Ce langage utilise uniquement des 0 et des 1. Nous verrons plus tard pourquoi. Cela pourrait être imagé de la façon suivante :

![Le rôle du compilateur](/media/galleries/954/2575329f-0088-4c95-8a8e-da4bfc1d8c06.png.960x960_q85.jpg)

Donc, pour traduire le langage texte vers le langage machine (avec des 0 et des 1), nous aurons besoin de ce fameux compilateur. Et pas n'importe lequel, il faut celui qui soit capable de traduire le *langage texte Arduino* vers le *langage machine Arduino*. Et oui, sinon rien ne va fonctionner. Si vous mettez un traducteur Français vers Allemand entre notre patron anglais et son ouvrier chinois, ça ne fonctionnera pas mieux que s'ils discutaient directement. Vous comprenez ?

[[question]]
| Et pourquoi on doit utiliser un traducteur, on peut pas simplement apprendre le langage machine directement ?

Comment dire... non ! Non parce que le langage machine est quasiment impossible à utiliser tel quel. Par exemple, comme il est composé de 0 et de 1, si je vous montre ça : "0001011100111010101000111", vous serez incapable, tout comme moi, de dire ce que cela signifie ! Et même si je vous dis que la suite "01000001" correspond à la lettre "A", je vous donne bien du courage pour coder rien qu'une phrase ! :P Bref, oubliez cette idée. C'est quand même plus facile d'utiliser des mots anglais (car oui nous allons être obligés de faire un peu d'anglais pour programmer, mais rien de bien compliqué rassurez-vous) que des suites de 0 et de 1. Vous ne croyez pas ?
#### Envoyer le programme dans la carte
Là, je ne vais pas vous dire grand chose car c'est l'environnement de développement qui va gérer tout ça. Nous n'aurons qu'à apprendre comment utiliser ce dernier et il se débrouillera tout seul pour envoyer le programme dans la carte. Nah ! Nous n'aurons donc qu'à créer le programme sans nous soucier du reste.