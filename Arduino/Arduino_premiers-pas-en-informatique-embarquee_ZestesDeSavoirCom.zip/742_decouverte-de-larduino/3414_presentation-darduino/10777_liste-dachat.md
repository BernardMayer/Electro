Tout au long du cours, nous allons utiliser du matériel en supplément de la carte. Rassurez-vous le prix est bien moindre. Je vous donne cette liste, cela vous évitera d’acheter en plusieurs fois. Vous allez devoir me croire sur parole sur leur intérêt. Nous découvrirons comment chaque composant fonctionne et comment les utiliser tout au long du tutoriel. :)

[[attention]]
| Attention, cette liste ne contient que les composants en quantités minimales strictes. Libre à vous de prendre plus de LED et de résistances par exemple (au cas où vous en perdriez ou détruisiez…). Pour ce qui est des prix, j’ai regardé sur différents sites grand public (donc pas Farnell par exemple), ils peuvent donc paraître plus élevés que la normale dans la mesure où ces sites amortissent moins sur des ventes à des clients fidèles qui prennent tout en grande quantité…

Avant que j’oublie, quatre éléments n'apparaîtront pas dans la liste et sont indispensables :

->

Une Arduino Uno ou Duemilanove     |   Un câble USB A mâle/B mâle
------|-----
![](http://zestedesavoir.com/media/galleries/954/fd4789fe-b607-4b67-9fba-9f88a6cb9b79.gif)|   ![](http://zestedesavoir.com/media/galleries/954/d5f0021b-9590-415c-9024-54bf2516fe85.png)

Une BreadBoard (plaque d’essai)     |   Un lot de fils pour brancher le tout !
------|-----
![](http://zestedesavoir.com/media/galleries/954/016bdd3e-0207-41ad-8e5b-cf432808c911.jpg)|   ![](http://zestedesavoir.com/media/galleries/954/99d85f2b-af7e-4d16-8825-9e9a91aaff75.png)

<-

# Liste Globale

Voici donc la liste du matériel nécessaire pour suivre le cours. Libre à vous de tout acheter ou non.

![Liste du matériel nécessaire](/media/galleries/954/9983e5d0-4ca2-4087-9bb5-62f82213e998.png.960x960_q85.png)

# Les revendeurs

De nombreux revendeurs existent sur internet, allant du très professionnel avec un grand choix au petit détaillant de quartier sans oublier les grands importateurs chinois aux tarifs imbattables si vous savez être patient.

# Les kits

Enfin, il existe des kits tout prêts chez certains revendeurs.
Nous n'en conseillerons aucun pour plusieurs raisons. Tout d'abord, pour ne pas faire trop de publicité et rester conforme avec la charte du site. Ensuite, car il est difficile de trouver un kit "complet". Ils ont tous des avantages et des inconvénients mais aucun (au moment de la publication de ces lignes) ne propose absolument tous les composants que nous allons utiliser. Nous ne voulons donc pas que vous reveniez vous plaindre sur les forums car nous vous aurions fait dépenser votre argent inutilement !

[[erreur]]
| Cela étant dit, merci de **ne pas nous spammer de MP** pour que l'on donne notre avis sur tel ou tel kit !
|Usez des forums pour cela, il y a toujours quelqu'un qui sera là pour vous aider.
|Et puis nous n'avons pas les moyens de tous les acheter et tester leur qualité !