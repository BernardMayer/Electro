Pour commencer notre découverte de la carte Arduino, je vais vous présenter la carte en elle-même. Nous allons voir comment s'en servir et avec quoi. J'ai représenté en rouge sur cette photo les points importants de la carte :

![Présentation de la carte Arduino](/media/galleries/954/247e96db-9b50-402b-8d94-9f797141a2bf.gif.960x960_q85.png)
Figure: Présentation de la carte Arduino - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/ArduinoBoardUno))

# Constitution de la carte

Voyons quels sont ces points importants et à quoi ils servent.

## Le micro-contrôleur

Voilà le cerveau de notre carte (en **1**). C’est lui qui va recevoir le programme que vous aurez créé et qui va le stocker dans sa mémoire puis l’exécuter. Grâce à ce programme, il va savoir faire des choses, qui peuvent être : faire clignoter une LED, afficher des caractères sur un écran, envoyer des données à un ordinateur, ...
## Alimentation

Pour fonctionner, la carte a besoin d'une alimentation. Le microcontrôleur fonctionnant sous 5V, la carte peut être alimentée en 5V par le port USB (en **2**) ou bien par une alimentation externe (en **3**) qui est comprise entre 7V et 12V. Cette tension doit être continue et peut par exemple être fournie par une pile 9V. Un régulateur se charge ensuite de réduire la tension à 5V pour le bon fonctionnement de la carte. Pas de danger de tout griller donc! Veuillez seulement à respecter l'intervalle de 7V à 15V (même si le régulateur peut supporter plus, pas la peine de le retrancher dans ses limites)
## Visualisation

Les trois "points blancs" entourés en rouge (**4**) sont en fait des LED dont la taille est de l'ordre du millimètre. Ces LED servent à deux choses :

* Celle tout en haut du cadre : elle est connectée à une broche du microcontrôleur et va servir pour tester le matériel. *Nota* : Quand on branche la carte au PC, elle clignote quelques secondes.
* Les deux LED du bas du cadre : servent à visualiser l'activité sur la voie série (une pour l'émission et l'autre pour la réception). Le téléchargement du programme dans le microcontrôleur se faisant par cette voie, on peut les voir clignoter lors du chargement.

## La connectique

La carte Arduino ne possédant pas de composants qui peuvent être utilisés pour un programme, mis à part la LED connectée à la broche 13 du microcontrôleur, il est nécessaire de les rajouter. Mais pour ce faire, il faut les connecter à la carte. C'est là qu'intervient la connectique de la carte (en **5a** et **5b**). Par exemple, on veut connecter une LED sur une sortie du microcontrôleur. Il suffit juste de la connecter, avec une résistance en série, à la carte, sur les fiches de connexion de la carte.

Cette connectique est importante et a un brochage qu'il faudra respecter. Nous le verrons quand nous apprendrons à faire notre premier programme. C'est avec cette connectique que la carte est "extensible" car l'on peut y brancher tous types de montages et modules ! Par exemple, la carte Arduino Uno peut être étendue avec des shields, comme le « **Shield Ethernet** » qui permet de connecter cette dernière à internet.

![Le shield Ethernet Arduino](http://zestedesavoir.com/media/galleries/954/58dbaa80-5ba1-4052-bc9f-3bed8e317795.jpg.960x960_q85.jpg)
Figure: Le shield Ethernet Arduino - (CC-BY-SA - [arduino.cc](http://arduino.cc/en/Main/ArduinoEthernetShield))