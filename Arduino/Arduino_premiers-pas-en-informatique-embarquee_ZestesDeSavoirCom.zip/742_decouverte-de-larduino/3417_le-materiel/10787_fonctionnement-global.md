Nous avons vu précédemment ce qu'était une carte électronique programmable. Nous avons également vu de quels éléments se basait une carte électronique pour fonctionner (schéma électronique, schéma de câblage). Je viens de vous présenter la carte, de quoi elle est principalement constituée. Enfin, je vous ai montré comment l'utiliser de manière à faire clignoter une petite lumière. Dorénavant, nous allons voir comment elle fonctionne de façon globale et répondre à quelques questions qui pourraient vous trotter dans la tête : "Comment la carte sait qu'il y a une LED de connectée ?", "Et comment sait-elle que c'est sur telle broche ?", "Et le programme, où-est-ce qu'il se trouve et sous quelle forme ?", "Comment la carte fait pour comprendre ce qu'elle doit faire ?", ... De nombreuses questions, effectivement ! :P
# Partons du programme

## Le contenu

Le contenu du programme, donc le programme en lui-même, est ce qui va définir chaque action que va exécuter la carte Arduino. Mais ce n'est pas tout ! Dans le programme il y a plusieurs zones, que nous verrons plus en détail tout au long de la lecture de ce cours, qui ont chacune un rôle particulier. Voici leur présentation accompagnée d'un exemple.

* La première zone sert principalement (je ne vais pas m'étendre) à dire à la carte de **garder en mémoire quelques informations** qui peuvent être : l'emplacement d'un élément connecté à la carte, par exemple une LED en broche 13, ou bien une valeur quelconque qui sera utile dans le programme :

```cpp
// déclaration de variables globales (broches...)
const int ledPin = 13;
```

* La zone secondaire est l'endroit où l'on va **initialiser certains paramètres** du programme. Par exemple, on pourra dire à la carte qu'elle devra communiquer avec l'ordinateur ou simplement lui dire ce qu'elle devra faire de la LED qui est connectée sur sa broche 13. On peut encore faire d'autres choses, mais nous le verrons plus tard.

```cpp
void setup()
{
    // Declaration de la broche en sortie
    pinMode(ledPin, OUTPUT);
}
```

* La dernière zone est la **zone principale où se déroulera le programme**. Tout ce qui va être écrit dans cette zone sera exécuté par la carte, ce sont les actions que la carte fera. Par exemple, c'est ici qu'on pourra lui dire de faire clignoter la LED sur sa broche 13. On pourra également lui demander de faire une opération telle que `2+2` ou bien d'autres choses encore !

```cpp
void loop() {
    digitalWrite(13, HIGH); // led a l'etat haut
    delay(1000);            // attendre 1 seconde
    digitalWrite(13, LOW);  // led a l'etat bas
    delay(1000);            // attendre 1 seconde
}
```
Code: Exemple de boucle

En conclusion, tout (vraiment tout !) ce que va faire la carte est inscrit dans le programme. Sans programme, la carte ne sert à **rien** ! C'est grâce au programme que la carte Arduino va savoir qu'une LED est connectée sur sa broche 13 et ce qu'elle va devoir faire avec, allumer et éteindre la LED alternativement pour la faire clignoter.

## Et l'envoi

Le programme est envoyé dans la carte lorsque vous cliquez sur le bouton ![Bouton d'envoi du programme à la carte](/media/galleries/954/0a70e532-8f37-4f36-9d1d-d03bcd812f8b.png.960x960_q85.jpg). Le logiciel Arduino va alors vérifier si le programme ne contient pas d'erreur et ensuite le compiler (le traduire) pour l'envoyer dans la carte :

![Au départ, le programme est sous forme de texte, puis il est transformé](/media/galleries/954/f418708d-a788-4591-a3d3-858e559e8469.png.960x960_q85.jpg)

L'envoi du programme est géré par votre ordinateur : le programme passe, sous forme de 0 et de 1, dans le câble USB qui relie votre ordinateur à votre carte et arrive dans la carte. Le reste se passe dans la carte elle-même...

# Réception du programme

Le programme rentre donc dans la carte en passant en premier par le connecteur USB de celle-ci. Il va alors subir une petite transformation qui permet d'adapter le signal électrique correspondant au programme (oui car le programme transite dans le câble USB sous forme de signal électrique) vers un signal plus approprié pour le microcontrôleur. On passe ainsi d'un signal codé pour la norme USB à un signal codé pour une simple voie série (que l'on étudiera plus tard d'ailleurs). Puis, ce "nouveau" signal est alors intercepté par le microcontrôleur.

![Réception du programme](/media/galleries/954/02364b24-df6b-4a82-bcb4-c1872fbd4592.png.960x960_q85.jpg)

Tout le reste se passe alors...

![À l'intérieur du microcontrôleur](/media/galleries/954/b964661e-6e76-4bfc-b0b6-d5684c217b59.png.960x960_q85.jpg)

# À l'intérieur du microcontrôleur

## L'emplacement du programme

Le microcontrôleur reçoit le programme sous forme de signal électrique sur ses broches Tx et Rx, d'ailleurs disponible sur les broches de la carte (cf. image). Une fois qu'il est reçu, il est intégralement stocké dans une mémoire de type Flash que l'on appellera "la mémoire de programme". Ensuite, lorsque la carte démarre "normalement" (qu'aucun programme n'est en train d'être chargé), le cerveau va alors gérer les données et les répartir dans les différentes mémoires :

* La **mémoire programme** est celle qui va servir à savoir où l'on en est dans le programme, à quelle instruction on est rendu. C'est à dire, en quelque sorte, pointer sur des morceaux des zones 2 et 3 que l'on a vu dans le précédent exemple de programme.
* La **mémoire de données**, aussi appelé "RAM" (comme dans votre ordinateur) va stocker les variables telles que le numéro de la broche sur laquelle est connectée une LED, ou bien une simple valeur comme un chiffre, un nombre, des caractères, etc.

Voici un petit synoptique qui vous montre un peu l'intérieur du microcontrôleur (c'est très simplifié !) :

![Intérieur du microcontrôleur](/media/galleries/954/d19c2587-19c3-4762-b171-2f76b241175e.png.960x960_q85.jpg)

## Démarrage du microcontrôleur

Lorsque le microcontrôleur démarre, il va commencer par lancer un bout de code particulier : le *bootloader*. C'est ce dernier qui va surveiller si un nouveau programme arrive sur la voie USB et s'il faut donc changer l'ancien en mémoire par le nouveau. Si rien n'arrive, il donne la main à votre programme, celui que vous avez créé. Ce dernier va alors défiler, instruction par instruction. Chaque fois qu'une nouvelle variable sera nécessaire, elle sera mise en RAM pour que l'on ait une mémoire de cette dernière (et supprimée lorsqu'elle n'est plus nécessaire). Sinon, les instructions vont se suivre une par une, dans l'ordre que vous les avez écrites.