Afin d’utiliser la carte, il faut l'installer. Normalement, les *drivers* (pilote, en français) sont déjà installés sous GNU/Linux. Sous mac, il suffit de double cliquer sur le fichier *.mkpg* inclus dans le téléchargement de l'application Arduino et l’installation des drivers s’exécute de façon automatique.

# Sous Windows

Lorsque vous connectez la carte à votre ordinateur sur le port USB, un petit message en bas de l'écran apparaît. Théoriquement, la carte que vous utilisez doit s'installer toute seule. Cependant, si vous êtes sous Windows 7 comme moi, il se peut que cela ne marche pas du premier coup. Dans ce cas, laissez la carte branchée puis allez dans le panneau de configuration. Cliquez ensuite sur "Système" puis, dans le panneau de gauche sélectionnez "gestionnaire de périphériques". Une fois ce menu ouvert, vous devriez voir un composant avec un panneau "attention" jaune. Faites un clic droit sur le composant et cliquez sur "Mettre à jour les pilotes". Dans le nouveau menu, sélectionnez l'option "Rechercher le pilote moi-même". Enfin, il ne vous reste plus qu'à aller sélectionner le bon dossier contenant le driver. Il se trouve dans le dossier d'Arduino que vous avez du décompresser un peu plus tôt et se nomme "drivers" (attention, ne descendez pas jusqu'au dossier "FTDI"). Par exemple, pour moi le chemin sera : `le-chemin-du-dossier\arduino-0022\arduino-0022\drivers`

[[attention]]
|Il semblerait qu'il y est des problèmes en utilisant la version francaise d'Arduino (les drivers sont absents du dossier). Si c'est le cas, il vous faudra télécharger la version originale (anglaise) pour pouvoir installer les drivers.

Après l'installation et une suite de clignotement sur les micro-LED de la carte, celle-ci devrait être fonctionnelle. Une petite LED verte témoigne de la bonne alimentation de la carte :

![Carte connectée et alimentée](/media/galleries/954/1940e7e1-d917-4862-b460-fa2bc5d5a8a0.png.960x960_q85.jpg)

# Tester son matériel

Avant de commencer à programmer la tête baissée, il faut, avant toutes choses, tester le bon fonctionnement de la carte. Ce serait idiot de programmer la carte et chercher les erreurs dans le programme alors que le problème vient de la carte ! ^^ Nous allons tester notre matériel en chargeant un programme qui fonctionne dans la carte.

[[question]]
|Mais, on n'en a pas encore fait de programmes ? o_O

Tout juste ! Mais le logiciel Arduino contient des exemples de programmes. Et bien ce sont ces exemples que nous allons utiliser pour tester la carte.

## 1ère étape : ouvrir un programme

Nous allons choisir un exemple tout simple qui consiste à faire clignoter une LED. Son nom est *Blink* et vous le trouverez dans la catégorie *Basics* :

![Menu de choix d'un exemple](/media/galleries/954/f42351b2-12b6-4d9c-b3be-bd75fb10e1f1.png.960x960_q85.jpg)

Une fois que vous avez cliqué sur *Blink*, une nouvelle fenêtre va apparaître. Elle va contenir le programme *Blink*. Vous pouvez fermer l'ancienne fenêtre qui va ne nous servir plus à rien.

![Fenêtre du programme blink](/media/galleries/954/8ef97284-8587-48b6-9f6a-8e5c099140b6.png.960x960_q85.png)

## 2e étape

Avant d'envoyer le programme *Blink* vers la carte, il faut dire au logiciel quel est le nom de la carte et sur quel port elle est branchée. **Choisir la carte que l'on va programmer**. Ce n'est pas très compliqué, le nom de votre carte est indiqué sur elle. Pour nous, il s'agit de la carte "Uno". Allez dans le menu *Tools* ("outils" en français) puis dans *Board* ("carte" en français). Vérifiez que c'est bien le nom "Arduin Uno" qui est coché. Si ce n'est pas le cas, cochez-le.

![Menu de sélection de la carte cible](/media/galleries/954/03585cca-c935-4e55-9da7-7a1af47a87e1.png.960x960_q85.jpg)

**Choisissez le port de connexion de la carte.** Allez dans le menu *Tools*, puis *Serial port*. Là, vous choisissez le port COMX, X étant le numéro du port qui est affiché. Ne choisissez pas COM1 car il n'est quasiment jamais connecté à la carte. Dans mon cas, il s'agit de COM18 :

![Menu de sélection du port com](/media/galleries/954/3c72aac5-2d4e-4119-9934-b16885c320bd.png.960x960_q85.jpg)

Pour trouver le port de connexion de la carte, vous pouvez aller dans le **gestionnaire de périphériques** qui se trouve dans le **panneau de configuration**. Regardez à la ligne **Ports (COM et LPT)** et là, vous devriez avoir **Arduino Uno (COMX)**. Aller, une image pour le plaisir :

![Le panneau de configuration Windows et la carte Arduino](/media/galleries/954/d45d12ab-f240-437f-97ab-5202d164be3c.png.960x960_q85.jpg)

## Dernière étape

Très bien. Maintenant, il va falloir envoyer le programme dans la carte. Pour ce faire, il suffit de cliquer sur le bouton *Téléverser*, en jaune-orangé sur la photo :

![Compilation en cours...](/media/galleries/954/6a6e2f3c-6336-46bb-a14b-623208498445.png.960x960_q85.png)

Vous verrez tout d'abord le message "Compilation du croquis en cours..." pour vous informer que le programme est en train d'être compilé en langage machine avant d'être envoyé. Ensuite vous aurez ceci :

![Chargement du programme en cours...](/media/galleries/954/8ea755fa-d3df-4add-a8ee-878e39e6c2a3.png.960x960_q85.png)

En bas de l'image, vous voyez le texte : "*Téléversement...*", cela signifie que le logiciel est en train d'envoyer le programme dans la carte. Une fois terminé, il affiche un autre message :

![Le chargement est terminé !](/media/galleries/954/204c398c-1158-4323-80ea-a0cf2f6ad087.png.960x960_q85.png)

Le message affiché : "*Téléversement terminé*" signale que le programme a bien été chargé dans la carte. Si votre matériel fonctionne, vous devriez avoir une LED sur la carte qui clignote :

[[attention]]
|Si vous n'obtenez pas ce message mais plutôt un truc en rouge, pas d'inquiétude, le matériel n'est pas forcément défectueux!

En effet, plusieurs erreurs sont possibles:

+ l'IDE recompile avant d'envoyer le code, vérifiez la présence d'erreurs.
+ La voie série est peut-être mal choisie, vérifiez les branchements et le choix de la voie série.
+ l'IDE est codé en JAVA, il peut-être capricieux et bugger de temps en temps (surtout avec la voie série...) : réessayez l'envoi !

![LED sur la carte qui clignote](/media/galleries/954/74a078f7-7a5a-4d22-9347-2ba930b2f336.png.960x960_q85.jpg)