Comme son nom l'indique, cette partie va parler des tableaux.

[[q]]
| Quel est l’intérêt de parler de cette surface ennuyeuse qu'utilisent nos chers enseignants ?

Eh bien détrompez-vous, en informatique un tableau ça n'a rien à voir !
Si on devait (beaucoup) résumer, un tableau est une grosse variable.
Son but est de **stocker des éléments de mêmes types en les mettant dans des cases**.
Par exemple, un prof qui stocke les notes de ses élèves.
Il utilisera un tableau de `float` (nombre à virgule), avec une case par élèves.
Nous allons utiliser cet exemple tout au long de cette partie. Voici quelques précisions pour bien tout comprendre :

- chaque élève sera identifié par un numéro allant de 0 (le premier élève) à 19 (le vingtième élève de la classe)
- on part de 0 car en informatique la première valeur dans un tableau est 0 !

# Un tableau en programmation

Un tableau, tout comme sous Excel, c'est un ensemble constitué de cases, lesquels vont contenir des informations.
En programmation, ces informations seront des **nombres**. Chaque case d'un tableau contiendra une valeur.
En reprenant l'exemple des notes des élèves, le tableau répertoriant les notes de chaque élève ressemblerait à ceci :

->

élève 0 | élève 1 | élève 2 | [...] | élève n-1 | élève n
--------|---------|---------|-------|-----------|---------|
10 | 15,5 | 8 | [...] | 18 | 7

Table: Un tableau en informatique

<-

## A quoi ça sert ?

On va principalement utiliser des tableaux lorsque l'on aura besoin de stocker des informations sans pour autant créer une variable pour chaque information.
Toujours avec le même exemple, au lieu de créer une variable `eleve2` et ainsi de suite pour chaque élève, on inscrit les notes des élèves dans un tableau.

[[q]]
| Mais, concrètement c'est quoi un tableau : une variable ? une fonction ?

Ni l'un, ni l'autre. En fait, on pourrait comparer cela avec un index qui pointe vers les valeurs de variables qui sont contenus dans chaque case du tableau.
Un petit schéma pour simplifier :

->

élève 0 | élève 1
--------|---------
variable dont on ne connaît pas le nom mais qui stocke une valeur | idem, mais variable différente de la case précédente

<-

Par exemple, cela donnerait :

->

élève 0 | élève 1
--------|---------
variable `note_eleve0` | variable `note_eleve1`

<-

Avec notre exemple :

->

élève 0 | élève 1
--------|---------
10 | 15,5

<-

Soit, lorsque l'on demandera la valeur de la case 1 (correspondant à la note de l'élève 1), le tableau nous renverra le nombre : 15,5. Alors, dans un premier temps, on va voir comment déclarer un tableau et l'initialiser. Vous verrez qu'il y a différentes manières de procéder. Après, on finira par apprendre comment utiliser un tableau et aller chercher des valeurs dans celui-ci. Et pour finir, on terminera ce chapitre par un exemple. Il y a encore du boulot ! ;)

# Déclarer un tableau

Comme expliqué plus tôt, un tableau contient des éléments *de même type*. On le déclare donc avec un type semblable, et une taille représentant le nombre d'éléments qu'il contiendra. Par exemple, pour notre classe de 20 étudiants :
```cpp
float notes[20];
```
Code: déclarer un tableau de 20 cases

On veut stocker des notes, donc des valeurs décimales entre 0 et 20.
On va donc créer un tableau de float (car c'est le type de variable qui accepte les nombres à virgule, souvenez-vous ! ;) ). Dans cette classe, il y a 20 élèves (de 0 à 19) donc le tableau contiendra 20 éléments. Si on voulait faire un tableau de 100 étudiants dans lesquels on recense leurs nombres d'absence, on ferait le tableau suivant:
```cpp
char absenteisme[100];
```
Code: un tableau de `char`

# Accéder et modifier une case du tableau

Pour accéder à une case d'un tableau, il suffit de connaître **l'indice** de la case à laquelle on veut accéder.
L'indice c'est le numéro de la case qu'on veut lire/écrire. Par exemple, pour lire la valeur de la case 10 (donc indice 9 car on commence à 0):

```cpp
float notes[20]; // notre tableau
float valeur; // une variable qui contiendra une note

// valeur contient désormais la note du dixième élève
valeur = notes[9];
```
Code: Accéder à une valeur

Ce code se traduit par l'enregistrement de la valeur contenue dans la dixième case du tableau, dans une variable nommée `valeur`.
A présent, si on veut aller modifier cette même valeur, on fait comme avec une variable normale, il suffit d'utiliser l'opérateur ' = ' :

```cpp
notes[9] = 10,5;   // on change la note du dixième élève
```
Code: Modifier une valeur

En fait, on procède de la même manière que pour changer la valeur d'une variable, car, je vous l'ai dit, chaque case d'un tableau est une variable qui contient une valeur ou non.

[[a]]
| Faites attention aux indices utilisés. Si vous essayez de lire/écrire dans une case de tableau trop loin (indice trop grand, par exemple 987362598412 :P ), le comportement pourrait devenir imprévisible.
Car en pratique vous modifierez des valeurs qui seront peut-être utilisées par le système pour autre chose. Ce qui pourrait avoir de graves conséquences !

[[i]]
| Vous avez sûrement rencontré des crashs de programme sur votre ordinateur, ils sont souvent dû à la modification de variable qui n'appartiennent pas au programme, donc l'OS "tue" ce programme qui essai de manipuler des trucs qui ne lui appartiennent pas.

*[OS]: Operating System

# Initialiser un tableau

Au départ, notre tableau était vide :
```cpp
float notes[20];
// on créer un tableau dont le contenu est vide, on sait simplement qu'il contiendra 20 nombres
```

Ce que l'on va faire, c'est **initialiser** notre tableau. On a la possibilité de remplir chaque case *une par une* ou bien utiliser une boucle qui remplira le tableau à notre place.
Dans le premier cas, on peut mettre la valeur que l'on veut dans chaque case du tableau, tandis qu'avec la deuxième solution, on remplira les cases du tableau avec la même valeur, bien que l'on puisse le remplir avec des valeur différentes mais c'est un peu plus compliqué.
Dans notre exemple des notes, on part du principe que 6l'examen n'est pas passé, donc tout le monde à 0. :P Pour cela, on parcourt toutes les cases en leur mettant la valeur 0 :

```cpp
char i=0; // une variable que l'on va incrémenter
float notes[20];  // notre tableau

void setup()
{
    // boucle for qui remplira le tableau pour nous
    for(i = 0; i < 20; i++)
    {
        notes[i] = 0; // chaque case du tableau vaudra 0
    }
}
```
Code: Initialisation d'un tableau

[[i]]
| L'initialisation d'un tableau peut se faire directement lors de sa création, comme ceci :

```cpp
float note[] = {0,0,0,0 /*, etc.*/ };
// Le tableau aura alors autant de case que de nombre passé en paramètres
```
Code: Initialisation à la déclaration

# Exemple de traitement

[[q]]
| Bon c'est bien beau tout ça, on a des notes coincées dans un tableau, on en fait quoi ? :roll:

Excellente question, et ça dépendra de l'usage que vous en aurez :) ! Voyons des cas d'utilisations pour notre tableau de notes (en utilisant des fonctions ;) ).

## La note maximale

Comme le titre l'indique, on va rechercher la note maximale (le meilleur élève de la classe). La fonction recevra en paramètre le tableau de float, le nombre d'éléments dans ce tableau et renverra la meilleure note.
```cpp
float meilleurNote(float tableau[], int nombreEleve)
{
    int i = 0;
    int max = 0; // variable contenant la future meilleure note

    for(i=0; i<nombreEleve, i++)
    {
        // si la note lue est meilleure que la meilleure actuelle
        if(tableau[i] > max)
        {
            // alors on l'enregistre
            max = tableau[i];
        }
    }
    // on retourne la meilleure note
    return max;
}
```
Code: Recherche de la note maximale

Ce que l'on fait, pour lire un tableau, est exactement la même chose que lorsqu'on l'initialise avec une boucle `for`.

[[i]]
| Il est tout à fait possible de mettre la valeur de la case recherché dans une variable :

```cpp
int valeur = tableau[5]; // on enregistre la valeur de la case 6 du tableau dans une variable
```

Voila, ce n'était pas si dur, vous pouvez faire pareil pour chercher la valeur minimale afin vous entrainer !

## Calcul de moyenne

Ici, on va chercher la moyenne des notes. La signature de la fonction sera exactement la même que celle de la fonction précédente, à la différence du nom ! Je vous laisse réfléchir, voici la signature de la fonction, le code est plus bas mais essayez de le trouver vous-même avant :
```cpp
float moyenneNote(float tableau[], int nombreEleve)
```

**Une solution :**
[[s]]
| ```cpp
| float moyenneNote(float tableau[], int nombreEleve)
| {
|     int i = 0;
|     double total = 0; // addition de toutes les notes
|     float moyenne = 0; // moyenne des notes
|     for(i = 0; i < nombreEleve; i++)
|     {
|         total = total + tableau[i];
|     }
|     moyenne = total / nombreEleve;
|     return moyenne;
| }
| ```
|Code: Calcul de la moyenne des notes

On en termine avec les tableaux, on verra peut être plus de choses en pratique. :)