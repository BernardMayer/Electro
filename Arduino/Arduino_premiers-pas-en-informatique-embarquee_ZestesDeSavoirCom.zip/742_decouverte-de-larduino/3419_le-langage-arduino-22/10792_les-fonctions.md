Dans un programme, les lignes sont souvent très nombreuses.
Il devient alors impératif de séparer le programme en petits bouts afin d'améliorer la lisibilité de celui-ci, en plus d'améliorer le fonctionnement et de faciliter le débogage.
Nous allons voir ensemble ce qu'est une fonction, puis nous apprendrons à les créer et les appeler.

# Qu'est-ce qu'une fonction ?

Une **fonction** est un "conteneur" mais différent des variables.
En effet, une variable ne peut contenir qu'un nombre, tandis qu'une fonction peut contenir un *programme entier* ! Par exemple ce code est une fonction :

```cpp
void setup()
{
    // instructions
}
```
Code: un exemple de fonction

En fait, lorsque l'on va programmer notre carte Arduino, on va écrire notre programme dans des fonctions.
Pour l'instant nous n'en connaissons que 2 : **`setup()`** et **`loop()`**.
Dans l'exemple précédent, à la place du commentaire, on peut mettre des instructions (conditions, boucles, variables, ...).
Ce sont ces instructions qui vont constituer le programme en lui même. Pour être plus concret, une fonction est un bout de programme qui permet de réaliser une tâche bien précise.
Par exemple, pour mettre en forme un texte, on peut colorier un *mot* en bleu, mettre le *mot* en gras ou encore grossir ce *mot*. A chaque fois, on a utilisé une fonction :

- **gras**, pour mettre le mot en gras
- **colorier**, pour mettre le mot en bleu
- **grossir**, pour augmenter la taille du mot

En programmation, on va utiliser des fonctions. Alors ces fonctions sont "réparties dans deux grandes familles".
Ce que j'entends par là, c'est qu'il existe des fonctions toutes prêtes dans le langage Arduino et d'autres que l'on va devoir *créer nous même*. C'est ce dernier point qui va nous intéresser.

[[e]]
| On ne peut pas écrire un programme sans mettre de fonctions à l'intérieur !
|On est obligé d'utiliser la fonction **setup**() et **loop**() (même si on ne met rien dedans).
|Si vous écrivez des instructions en dehors d'une fonction, le logiciel Arduino refusera systématiquement de compiler votre programme.
|Il n'y a que les variables globales que vous pourrez déclarer en dehors des fonctions.

[[q]]
| J'ai pas trop compris à quoi ça sert ? o_O

L'utilité d'une fonction réside dans sa capacité à simplifier le code et à le séparer en "petits bouts" que l'on assemblera ensemble pour créer le programme final
Si vous voulez, c'est un peu comme les jeux de construction en plastique : chaque pièce à son propre mécanisme et réalise une fonction.
Par exemple une roue permet de rouler ; un bloc permet de réunir plusieurs autres blocs entre eux ; un moteur va faire avancer l'objet créé...
Et bien tous ces éléments seront assemblés entre eux pour former un objet (voiture, maison, ...).
Tout comme, les fonctions seront assemblées entre elles pour former un programme. On aura par exemple la fonction : "mettre au carré un nombre" ; la fonction : "additionner a + b" ; etc. Qui au final donnera le résultat souhaité.

# Fabriquer une fonction

Pour fabriquer une fonction, nous avons besoin de savoir trois choses :

- Quel est le **type** de la fonction que je souhaite créer ?
- Quel sera son **nom** ?
- Quel(s) **paramètre(s)** prendra-t-elle ?

## Nom de la fonction

Pour commencer, nous allons, en premier lieu, choisir le nom de la fonction.
Par exemple, si votre fonction doit récupérer la température d'une pièce fournie par un capteur de température : vous appellerez la fonction **lireTemperaturePiece**, ou bien **lire_temperature_piece**, ou encore **lecture_temp_piece**.
Bon, des noms on peut lui en donner plein, mais soyez logique quant au choix de ce dernier.
Ce sera plus facile pour comprendre le code que si vous l'appelez **tmp** (pour température ;) ).

[[a]]
| Un nom de fonction explicite garantit une lecture rapide et une compréhension aisée du code.
|Un lecteur doit savoir ce que fait la fonction juste grâce à son nom, sans lire le contenu !

## Les types et les paramètres

Les fonctions ont pour but de découper votre programme en différentes unités logiques.
Idéalement, le programme principal ne devrait utiliser que des appels de fonctions, en faisant un minimum de traitement.
Afin de pouvoir fonctionner, elles utilisent, la plupart du temps, des "choses" en **entrées** et renvoient "quelque chose" en **sortie**. Les entrées seront appelées des **paramètres de la fonction** et *la* sortie sera appelée **valeur de retour**.

[[i]]
| Notez qu'une fonction ne peut renvoyer qu'un seul résultat à la fois. Notez également qu'une fonction ne renvoie pas obligatoirement un résultat. Elle n'est pas non plus obligée d'utiliser des paramètres.

## Les paramètres

Les paramètres servent à nourrir votre fonction. Ils servent à donner des informations au traitement qu'elle doit effectuer. Prenons un exemple concret. Pour changer l'état d'une sortie du microcontrôleur, Arduino nous propose la fonction suivante: [digitalWrite(pin, value)](http://arduino.cc/en/Reference/DigitalWrite). Ainsi, la référence nous explique que la fonction a les caractéristiques suivantes:

- paramètre **pin**: le numéro de la broche à changer
- paramètre **value**: l'état dans lequel mettre la broche (HIGH, (haut, +5V) ou LOW (bas, masse))
- retour: pas de retour de résultat

Comme vous pouvez le constater, l'exemple est explicite sans lire le code de la fonction.
Son nom, digitalWrite ("écriture numérique" pour les anglophobes), signifie qu'on va changer l'état d'une broche **numérique** (donc pas analogique).
Ses paramètres ont eux aussi des noms explicites, **pin** pour la broche à changer et **value** pour l'état à lui donner.
Lorsque vous aller créer des fonctions, c'est à vous de voir si elles ont besoin de paramètres ou non.
Par exemple, vous voulez faire une fonction qui met en pause votre programme, vous pouvez faire une fonction `Pause()` et déterminera la durée pendant laquelle le programme sera en pause.
On obtiendra donc, par exemple, la syntaxe suivante : `void Pause(char duree)`.
Pour résumer un peu, on a le choix de créer des **fonctions vides**, donc sans paramètres, ou bien des **fonctions "typées"** qui acceptent *un ou plusieurs* paramètres.

[[q]]
| Mais c'est quoi ça "void" ?

J'y arrive ! Souvenez vous, un peu plus haut je vous expliquais qu'une fonction pouvait retourner une valeur, la fameuse valeur de sortie, je vais maintenant vous expliquer son fonctionnement.

# Le type void

On vient de voir qu'une fonction pouvait accepter des paramètres et éventuellement renvoyer quelque chose.
Mais ce n'est pas obligatoire. En effet, si l'on reprend notre fonction "Pause", elle ne renvoie rien car ce n'est pas nécessaire de signaler quoi que ce soit.
Dans ce cas, on préfixera le nom de notre fonction avec le mot-clé "void".
La syntaxe utilisée est la suivante :
```cpp
void nom_de_la_fonction()
{
    // instructions
}
```
Code: une fonction sans valeur de retour

On utilise donc le type `void` pour dire que la fonction n'aura pas de retour. Une fonction de type void ne peut donc pas retourner de valeur. Par exemple :
```cpp
void fonction()
{
    int var = 24;
    return var; // ne fonctionnera pas car la fonction est de type void
}
```
Code: Impossible pour une fonction void de retourner un entier

Ce code ne fonctionnera pas, parce que la fonction `int`.
Ce qui est impossible ! Le compilateur le refusera et votre code final ne sera pas généré.
Vous connaissez d'ailleurs déjà au moins deux fonctions qui n'ont pas de retour...
Et oui, la fonction "setup" et la fonction "loop" ;) . Il n'y en a pas plus à savoir. ;)

# Les fonctions "typées"

Là, cela devient légèrement plus intéressant. En effet, si on veut créer une fonction qui calcule le résultat d'une addition de deux nombres (ou un calcul plus complexe), il serait bien de pouvoir renvoyer directement le résultat plutôt que de le stocker dans une variable qui a une portée globale et d’accéder à cette variable dans une autre fonction. En clair, l'appel de la fonction nous donne directement le résultat.
On peut alors faire "ce que l'on veut" avec ce résultat (le stocker dans une variable, l'utiliser dans une fonction, lui faire subir une opération, ...)

## Comment créer une fonction typée ?

En soit, cela n'a rien de compliqué, il faut simplement remplacer `long`, ...) Voilà un exemple :

```cpp
int maFonction()
{
    int resultat = 44;  // déclaration de ma variable résultat
    return resultat;
}
```
Code: Une fonction typée "entier"

**Notez que je n'ai pas mis les deux fonctions principales, à savoir `loop()`, mais elles sont obligatoires !** Lorsqu'elle sera appelée, la fonction `resultat`. Voyez cet exemple :

```cpp
int calcul = 0;

void loop()
{
    calcul = 10 * maFonction();
}

int maFonction()
{
    int resultat = 44;  // déclaration de ma variable résultat
    return resultat;
}
```
Code: Appel d'une fonction typée

Dans la fonction `calcul = 10 * 44;` Ce qui nous donne : calcul = 440.
Bon ce n'est qu'un exemple très simple pour vous montrer le fonctionnement.
Plus tard, lorsque vous serez au point, vous utiliserez certainement cette combinaison de façon plus complexe. ;)

[[a]]
| Comme cet exemple est très simple, je n'ai pas inscrit la valeur retournée par la fonction `maFonction()` dans une variable, mais il est préférable de le faire. Du moins, lorsque c'est utile, ce qui n'est pas le cas ici.

# Les fonctions avec paramètres

C'est bien gentil tout ça, mais maintenant vous allez voir quelque chose de bien plus intéressant. Voilà un code, nous verrons ce qu'il fait après :

```cpp
int x = 64;
int y = 192;

void loop()
{
    maFonction(x, y);
}

int maFonction(int param1, int param2)
{
    int somme = 0;
    somme = param1 + param2;
    // somme = 64 + 192 = 255

    return somme;
}
```
Code: Une fonction avec deux paramètres

[[q]]
| Que se passe-t-il ?

J'ai défini trois variables : `maFonction()` est "typée" et accepte des **paramètres**. Lisons le code du début :

- On déclare nos variables
- La fonction `maFonction()` que l'on a créée

C'est sur ce dernier point que l'on va se pencher. En effet, on a donné à la fonction des paramètres. Ces paramètres servent à "nourrir" la fonction. Pour faire simple, on dit à la fonction : "**Voilà deux paramètres, je veux que tu t'en serves pour faire le calcul que je veux**" Ensuite arrive le prototype de la fonction.

[[q]]
| Le prototype... de quoi tu parles ?

Le prototype c'est le "titre complet" de la fonction. Grâce à elle on connait le **nom** de la fonction, le **type** de la valeur retourné, et le type des différents **paramètres**.

```cpp
int maFonction(int param1, int param2)
```
Code: le prototype de la fonction.

La fonction récupère dans des variables les paramètres que l'on lui a envoyés. Autrement dit, dans la variable `y`. Soit : `param2 = y = 192`. Pour finir, on utilise ces deux variables créées "à la volée" dans le prototype de la fonction pour réaliser le calcul souhaité (une somme dans notre cas).

[[i]]
|On parle aussi parfois de signature, pour désigner le nom et les paramètres de la fonction.

[[q]]
| A quoi ça sert de faire tout ça ? Pourquoi on utilise pas simplement les variables x et y dans la fonction ?

Cela va nous servir à simplifier notre code. Mais pas seulement ! Par exemple, vous voulez faire plusieurs opérations différentes (addition, soustraction, etc.) et bien au lieu de créer plusieurs fonctions, on ne va en créer qu'une qui les fait toutes !
Mais, afin de lui dire quelle opération faire, vous lui donnerez un paramètre lui disant : "**Multiplie ces deux nombres**" ou bien "**additionne ces deux nombres**". Ce que cela donnerait :

```cpp
unsigned char operation = 0;
int x = 5;
int y = 10;

void loop()
{
    // le paramètre "opération" donne le type d'opération à faire
    maFonction(x, y, operation);
}

int maFonction(int param1, int param2, int param3)
{
    int resultat = 0;
    switch(param3)
    {
    case 0 : // addition, resultat = 15
        resultat = param1 + param2;
        break;
    case 1 : // soustraction, resultat = -5
        resultat = param1 - param2;
        break;
    case 2 : // multiplication, resultat = 50
        resultat = param1 * param2;
        break;
    case 3 : // division, resultat = 0 (car nombre entier)
        resultat = param1 / param2;
        break;
    default :
        resultat = 0;
        break;
    }

    return resultat;
}
```
Code: Une fonction générique