[[q]]
|Qu'est-ce qu'une boucle ?

En programmation, une **boucle** est une instruction qui permet de répéter un bout de code. Cela va nous permettre de faire se répéter un bout de programme ou un programme entier. Il existe deux types principaux de boucles :


+ La **boucle conditionnelle**, qui teste une condition et qui exécute les instructions qu'elle contient tant que la condition testée est vraie.
+ La **boucle de répétition**, qui exécute les instructions qu'elle contient, un nombre de fois prédéterminé.

# La boucle **while**

Problème : **Je veux que le volet électrique de ma fenêtre se ferme automatiquement quand la nuit tombe.
*Nous ne nous occuperons pas de faire le système qui ferme le volet à l'arrivée de la nuit*.
La carte Arduino dispose d'un capteur qui indique la position du volet (ouvert ou fermé). Ce que nous cherchons à faire : c'est créer un bout de code qui fait descendre le volet **tant qu'il n'est pas fermé**.** Pour résoudre le problème posé, il va falloir que l'on utilise une boucle.

```cpp
/* ICI, un bout de programme permet de faire les choses suivantes :
1. un capteur détecte la tombée de la nuit et la levée du jour
     - Si c'est la nuit, alors on doit fermer le volet
     - Sinon, si c'est le jour, on doit ouvrir le volet
2. le programme lit l'état du capteur qui indique si le volet est ouvert ou fermé
3. enregistrement de cet état dans la variable de type String : position_volet
     - Si le volet est ouvert, alors : position_volet = "ouvert";
     - Sinon, si le volet est fermé : position_volet = "ferme";
*/

while(position_volet == "ouvert")
{
    // instructions qui font descendre le volet
}
```
Code: La boucle while

## Comment lire ce code ?

En anglais, le mot **while** signifie "tant que". Donc si on lit la ligne :
```cpp
while(position_volet == "ouvert") {/* instructions */}
```

Il faut la lire : "TANT QUE la position du volet est **ouvert**", on boucle/répète les instructions de la boucle (entre les accolades).

## Construction d'une boucle **while**

Voilà donc la syntaxe de cette boucle qu'il faut retenir :
```cpp
while(/* condition à tester */)
{
    // les instructions entre ces accolades sont répétées
    // tant que la condition est vraie
}
```
Code: Syntaxe de la boucle while

## Un exemple

Prenons un exemple simple, réalisons un compteur !

```cpp
// variable compteur qui va stocker le nombre de fois que la boucle
int compteur = 0;
// aura été exécutée

// tant que compteur est différent de 5, on boucle
while(compteur != 5)
{
    compteur++; // on incrémente la variable compteur à chaque tour de boucle
}
```
Code: Un petit compteur

Si on teste ce code (dans la réalité rien ne s'affiche, c'est juste un exemple pour vous montrer), cela donne :

```text
compteur = 0
compteur = 1
compteur = 2
compteur = 3
compteur = 4
compteur = 5
```
Code: Résultat de notre compteur

Donc au départ, la variable **compteur** vaut 0, on exécute la boucle et on incrémente **compteur**.
Mais **compteur** ne vaut pour l'instant que 1, donc on ré-exécute la boucle. Maintenant **compteur** vaut 2. On répète la boucle, ... jusqu'à 5. Si **compteur** vaut 5, la boucle n'est pas ré-exécutée et on continu le programme. Dans notre cas, le programme se termine.

# La boucle **do...while**

Cette boucle est similaire à la précédente. Mais il y a une différence qui a son importance ! En effet, si on prête attention à la place la condition dans la boucle **while**, on s’aperçoit qu'elle est testée avant de rentrer dans la boucle. Tandis que dans une boucle do...while, la condition est testée seulement lorsque le programme est rentré dans la boucle :

```cpp
do
{
    // les instructions entre ces accolades sont répétées
    // TANT QUE la condition est vrai
}while(/* condition à tester */);
```
Code: Syntaxe de la boucle do...while

[[i]]
| Le mot **do** vient de l'anglais et se traduis par **faire**.
|Donc la boucle do...while signifie "faire les instructions, tant que la condition testée est fausse".
|Tandis que dans une boucle while on pourrait dire : "tant que la condition est fausse, fais ce qui suit".

[[q]]
| Qu'est-ce que ça change ?

Et bien, dans une **while**, si la condition est fausse dès le départ, on entrera jamais dans cette boucle.
A l'inverse, avec une boucle **do...while**, on entre dans la boucle *puis* on test la condition.
Reprenons notre compteur :

```cpp
// variable compteur = 5
int compteur = 5;

do
{
    compteur++;  // on incrémente la variable compteur à chaque tour de boucle
}while(compteur < 5);  // tant que compteur est inférieur à 5, on boucle
```
Code: un compteur avec do...while

Dans ce code, on définit dès le départ la valeur de **compteur** à 5.
Or, le programme va rentrer dans la boucle alors que la condition est fausse. Donc **la boucle est au moins exécutée une fois** ! Et ce quelle que soit la véracité de la condition. En test cela donne :

```text
compteur = 6
```
Code: Résultat de la boucle do...while

## Concaténation

Une boucle est une instruction qui a été répartie sur plusieurs lignes.
Mais on peut l'écrire sur une seule ligne :

```cpp
// variable compteur = 5
int compteur = 5;

do{compteur++;}while(compteur < 5);
```
Code: La boucle sur une seule ligne

[[e]]
| C'est pourquoi il ne faut pas oublier le point virgule à la fin (après le while).
|Alors que dans une simple boucle **while** le point virgule **ne doit pas** être mis !

# La boucle **for**

Voilà une boucle bien particulière. Ce qu'elle va nous permettre de faire est assez simple.
Cette boucle est exécutée X fois. Contrairement aux deux boucles précédentes, on doit lui donner trois paramètres.

```cpp
for(int compteur = 0; compteur < 5; compteur++)
{
    // code à exécuter
}
```
Code: la boucle for

## Fonctionnement

```cpp
for(int compteur = 0; compteur < 5; compteur++)
```

D'abord, on crée la boucle avec le terme **for** (signifie "pour que"). Ensuite, entre les parenthèses, on doit donner trois **paramètres** qui sont :

- la création et l'assignation de la variable à une valeur de départ
- suivit de la définition de la condition à tester
- suivit de l'instruction à exécuter

Donc, si on lit cette ligne : "POUR compteur allant de 0 jusque 5, on incrémente compteur".
De façon plus concise, la boucle est exécutée autant de fois qu'il sera nécessaire à **compteur** pour arriver à 5.
Donc ici, le code qui se trouve à l'intérieur de la boucle sera exécuté 5 fois.

## A retenir

La structure de la boucle :
```cpp
for(/*initialisation de la variable*/ ; /*condition à laquelle la boucle s'arrête*/ ; /*instruction à exécuter*/)
```
Code: syntaxe de la boucle for

# La boucle infinie

La boucle infinie est très simple à réaliser, d'autant plus qu'elle est parfois très utile.
Il suffit simplement d'utiliser une **while** et de lui assigner comme condition une valeur qui ne change jamais.
En l'occurrence, on met souvent le chiffre 1.

```cpp
while(1)
{
    // instructions à répéter jusqu'à l'infinie
}
```
Code: La boucle infinie

On peut lire : "TANT QUE la condition est égale à 1, on exécute la boucle".
Et cette condition sera toujours remplie puisque "1" n'est pas une variable mais bien un chiffre. Également, il est possible de mettre tout autre chiffre entier, ou bien le booléen "TRUE" :

```cpp
while(TRUE)
{
    // instructions à répéter jusqu'à l'infinie
}
```
Code: La boucle infinie avec un booléen

[[a]]
| Cela ne fonctionnera pas avec la valeur **0**.
|En effet, 0 signifie "condition fausse" donc la boucle s’arrêtera aussitôt...

[[i]]
| La fonction loop() se comporte comme une boucle infinie, puisqu'elle se répète après avoir fini d’exécuter ses tâches.