Nous avons déjà un peu abordé le sujet dans la présentation du cours. Je vous ai expliqué "brièvement" comment fonctionnait un programme et surtout ce que c'était ! ^^ Bon, dès à présent, je vais rentrer un petit peu plus dans le détail en vous introduisant des notions basées sur le matériel étroitement lié à la programmation. Nous allons en effet aborder le microcontrôleur dans un niveau de complexité supérieur à ce que je vous avais introduit tout à l'heure. Oh, rien de bien insurmontable, soyez sans craintes. ;)

# La programmation en électronique

Aujourd'hui, l'électronique est de plus en plus composée de composants numériques programmables. Leur utilisation permet de simplifier les schémas électroniques et par conséquent, réduire le coût de fabrication d’un produit. Il en résulte des systèmes plus complexes et performants pour un espace réduit.

## Comment programmer de l'électronique ?

Pour faire de l’électronique programmée, il faut un ordinateur et un **composant programmable**. Il existe tout plein de variétés différentes de composants programmables, à noter : les microcontrôleurs, les circuits logiques programmables, ... Nous, nous allons programmer des microcontrôleurs. Mais, à ce propos, vous ai-je dit qu'est ce que c'était qu'un microcontrôleur ?

[[question]]
| Qu'est ce que c'est ?

Je l’ai dit à l’instant, le microcontrôleur est un composant électronique programmable. On le programme par le biais d’un ordinateur grâce à un langage informatique, souvent propre au type de microcontrôleur utilisé. Je n’entrerai pas dans l’utilisation poussée de ces derniers car le niveau est rudement élevé et la compréhension difficile.

![Des microcontrôleurs de différentes tailles](http://zestedesavoir.com/media/galleries/954/b4a37f58-b232-4d8e-81f8-420a641d4403.jpg.960x960_q85.jpg)
Figure: Des microcontrôleurs de différentes tailles (licence CC-0)

C'est donc le microcontrôleur qui va être le cerveau de la carte Arduino, pour en revenir à nos moutons. C'est lui que nous allons programmer. On aura le temps d'en rediscuter, pour l'instant je veux uniquement vous présenter les éléments principaux qui le composent.

## Composition des éléments internes d'un micro-contrôleur

Un microcontrôleur est constitué par un ensemble d’éléments qui ont chacun une fonction bien déterminée. Il est en fait composé des mêmes éléments que sur la carte mère d’un ordinateur. Si l'on veut, c’est un ordinateur (sans écran, sans disque dur, sans lecteur de disque) dans un espace très restreint. Parmi les différents éléments d'un microcontrôleur typique, je vais vous présenter ceux qui vont nous être utiles. 

#### La mémoire
La mémoire du microcontrôleur sert à plusieurs choses. On peut aisément citer le stockage du programme et de données autres que le programme. Il existe cinq types de mémoire :

* La mémoire Flash : c'est celle qui contiendra le programme à exécuter (celui que vous allez créer !). Cette mémoire est effaçable et ré-inscriptible (c'est la même que celle d'une clé USB par exemple).
* RAM : c'est la mémoire dite "vive", elle va contenir les variables de votre programme. Elle est dite "volatile" car elle s'efface si on coupe l'alimentation du micro-contrôleur (comme sur un ordinateur).
* EEPROM : c'est le "disque dur" du microcontrôleur. Vous pourrez y enregistrer des infos qui ont besoin de survivre dans le temps, même si la carte doit être arrêtée et coupée de son alimentation. Cette mémoire ne s'efface pas lorsque l'on éteint le microcontrôleur ou lorsqu'on le reprogramme.
* Les registres : c'est un type particulier de mémoire utilisé par le processeur. Nous n'en parlerons pas tout de suite.
* La mémoire cache : c'est une mémoire qui fait la liaison entre les registres et la RAM. Nous n'en parlerons également pas tout de suite.

[[information]]
| [Une annexe au tutoriel](https://zestedesavoir.com/tutoriels/638/gestion-de-la-memoire-sur-arduino/) vous fournit plus de détails concernant les mémoires utilisables dans vos programmes.

#### Le processeur 
C'est le composant principal du microcontrôleur. C'est lui qui va exécuter le programme que nous lui donnerons à traiter. On le nomme souvent le CPU. 

#### Diverses choses
Nous verrons plus en détail l'intérieur d'un microcontrôleur, mais pas tout de suite, c'est bien trop compliqué. Je ne voudrais pas perdre la moitié des visiteurs en un instant ! :P

## Fonctionnement

Avant tout, pour que le microcontrôleur fonctionne, il lui faut une alimentation ! Cette alimentation se fait en générale par du +5V. D'autres ont besoin d'une tension plus faible, du +3,3V (c'est le cas de la Arduino Due par exemple). En plus d'une alimentation, il a besoin d'un signal d'horloge. C'est en fait une succession de 0 et de 1 ou plutôt une succession de tensions 0V et 5V. Elle permet en outre de cadencer le fonctionnement du microcontrôleur à un rythme régulier. Grâce à elle, il peut introduire la notion de temps en programmation. Nous le verrons plus loin. Bon, pour le moment, vous n'avez pas besoin d'en savoir plus. Passons à autre chose.

*[RAM]: en anglais 'Random Access Memory'
*[EEPROM]: en anglais 'Electricaly-Erasable Programmable Read-Only Memory'
*[CPU]: pour Central Processing Unit