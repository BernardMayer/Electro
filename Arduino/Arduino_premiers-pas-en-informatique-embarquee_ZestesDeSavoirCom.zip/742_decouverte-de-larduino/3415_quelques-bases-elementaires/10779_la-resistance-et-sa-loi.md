En électronique, il existe plein de composants qui ont chacun une ou plusieurs fonctions. Nous allons voir quels sont ces composants dans le cours, mais pas tout de suite. Car, maintenant, on va aborder la résistance qui est LE composant de base en électronique.

## Présentation

C'est le composant le plus utilisé en électronique. Sa principale fonction est de réduire l'intensité du courant (mais pas uniquement). Ce composant se présente sous la forme d'un petit boitier fait de divers matériaux et repéré par des anneaux de couleur indiquant la valeur de la résistance.

![Photo de résistance](/media/galleries/954/4189837b-c10f-4139-a658-6d26a4660bb5.png.960x960_q85.jpg)

## Symbole

Le symbole de la résistance ressemble étrangement à la forme de son boitier :

![Symbole de la résistance](/media/galleries/954/c23e023b-f6a5-4cd7-9352-4380323f0cec.png.960x960_q85.png)

## Loi d'ohm

Le courant traversant une résistance est régi par une formule assez simple qui se nomme **la loi d'Ohm** :

$I = \frac{U}{R}$

- **I** : intensité qui traverse la résistance en Ampères, notée $A$
- **U** : tension aux bornes de la résistance en Volts, notée $V$
- **R** : valeur de la résistance en Ohms, notée $\Omega$

En général, on retient mieux la formule sous cette forme : $U = R \times I$

## Unité

L'unité de la résistance est l'**ohm**. On le note avec le symbole grec oméga majuscule : $\Omega$.

## Le code couleur

La résistance possède une suite d'anneaux de couleurs différentes sur son boitier. Ces couleurs servent à expliciter la valeur de la résistance sans avoir besoin d'écrire en chiffre dessus (car vous avez déjà essayé d'écrire sur un cylindre :P ?) Le premier anneau représente le chiffre des centaines, le second celui des dizaines et le troisième celui des unités. Enfin, après un petit espace vient celui du coefficient multiplicateur. Avec ces quatre anneaux et un peu d'entrainement vous pouvez alors deviner la valeur de la résistance en un clin d'oeil ;) . Ce tableau vous permettra de lire ce code qui correspond à la valeur de la résistance :

->

|  Couleur  |  Chiffre  |  Coefficient multiplicateur  |  Puissance  |   Tolérance   |
|-----------|-----------|------------------------------|-------------|---------------|
| **Noir**  |     0     |             1                |   $10^{0}$  |      -        |
| **Brun**  |     1     |             10               |   $10^{1}$  |   $\pm$ 1 %   |
| **Rouge** |     2     |             100              |   $10^{2}$  |   $\pm$ 2 %   |
| **Orange**|     3     |             1000             |   $10^{3}$  |      -        |
| **Jaune** |     4     |             10 000           |   $10^{4}$  |      -        |
| **Vert**  |     5     |             100 000          |   $10^{5}$  |  $\pm$ 0.5 %  |
| **Bleu**  |     6     |             1 000 000        |   $10^{6}$  |  $\pm$ 0.25 % |
| **Violet**|     7     |             10 000 000       |   $10^{7}$  |  $\pm$ 0.10 % |
| **Gris**  |     8     |             100 000 000      |   $10^{8}$  |  $\pm$ 0.05 % |
| **Blanc** |     9     |             1 000 000 000    |   $10^{9}$  |      -        |
|     -     |     -     |             -                |      -      |      -        |
| **Or**    |    0.1    |             0.1              |   $10^{-1}$ |  $\pm$ 5 %    |
| **Argent**|    0.01   |             0.01             |   $10^{-2}$ |  $\pm$ 10 %   |
| (absent)  |     -     |             -                |      -      |  $\pm$ 20 %   |

Table: Tableau du code couleurs des résistances

<-