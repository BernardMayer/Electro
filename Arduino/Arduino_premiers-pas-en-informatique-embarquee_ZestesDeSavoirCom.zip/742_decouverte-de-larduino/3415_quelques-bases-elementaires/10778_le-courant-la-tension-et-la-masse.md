Pour faire de l'électronique, il est indispensable de connaître sur le bout des doigts ce que sont les grandeurs physiques. Alors, avant de commencer à voir lesquelles on va manipuler, voyons un peu ce qu'est une grandeur physique. Une **grandeur physique** est quelque chose qui se mesure. Plus précisément, il s'agit d'un élément mesurable, grâce à un appareil ou dispositif de mesure, régit par les lois de la physique. Par exemple, la pression atmosphérique est une grandeur physique, ou bien la vitesse à laquelle circule une voiture. En électronique cependant, nous ne mesurons pas ces grandeurs-là, nous avons nos propres grandeurs, qui sont : **le courant** et **la tension**.

## La source d'énergie

L'énergie que l'on va manipuler (courant et tension) provient d'un **générateur**. Par exemple, on peut citer : la pile électrique, la batterie électrique, le secteur électrique. Cette énergie qui est fournie par le générateur est restituée à un ou plusieurs **récepteurs**. Le récepteur, d'après son nom, reçoit de l'énergie. On dit qu'il la **consomme**. On peut citer pour exemples : un chauffage d’appoint, un sèche-cheveux, une perceuse.

# Le courant électrique

## Charges électriques

Les charges électriques sont des grandeurs physiques mesurables. Elles constituent la matière en elle-même. Dans un atome, qui est élément primaire de la matière, il y a trois charges électriques différentes : les charges **positives**, **négatives** et **neutres**, appelées respectivement **protons**, **électrons** et **neutrons**. Bien, maintenant nous pouvons définir le courant : il s'agit d'un **déplacement ordonné de charges électriques**.

## Conductibilité des matériaux

La notion de conductibilité est importante à connaître car elle permet de comprendre pas mal de phénomènes. On peut définir la **conductibilité** comme étant la capacité d'un matériau à se laisser traverser par un courant électrique. De ces matériaux, on peut distinguer quatre grandes familles :

* les isolants : leurs propriétés empêchent le passage d'un courant électrique (plastique, bois, verre)
* les semi-conducteurs : ce sont des isolants, mais qui laissent passer le courant dès lors que l'on modifie légèrement leur structure interne (diode, transistor, LED)
* les conducteurs : pour eux, le courant peut passer librement à travers tout en opposant une faible résistance selon le matériau utilisé (or, cuivre, métal en général)
* les supraconducteurs : ce sont des types bien particuliers qui, à une température extrêmement basse, n'opposent quasiment aucune résistance au passage d'un courant électrique

## Sens du courant

Le courant électrique se déplace selon un sens de circulation. Un générateur électrique, par exemple une pile, produit un courant. Et bien ce courant va circuler du pôle positif vers le pôle négatif de la pile si, et seulement si, ces deux pôles sont reliés entre eux par un fil métallique ou un autre conducteur. C'est que l'on appelle le **sens conventionnel** du courant. On note le courant par une flèche qui indique le sens conventionnel de circulation du courant :

->![Indication du sens du courant](/media/galleries/954/08921932-5ed1-4bf3-9934-ceb91c560cb3.png.960x960_q85.jpg)<-

## Intensité du courant

[[attention]]
| L’intensité du courant est la vitesse à laquelle circule ce courant. Tandis que le courant est un déplacement ordonné de charges électriques. Voilà un point à ne pas confondre.  
| On mesure la vitesse du courant, appelée **intensité**, en **Ampères** (noté **A**) avec un *Ampèremètre*. En général, en électronique de faible puissance, on utilise principalement le milli-Ampère (**mA**) et le micro-Ampère (**µA**), mais jamais bien au-delà. C'est tout ce qu'il faut savoir sur le courant, pour l'instant.

# Tension

Autant le courant se déplace, ou du moins est un déplacement de charges électriques, autant la **tension** est quelque chose de **statique**. Pour bien définir ce qu'est la tension, sachez qu'on la compare à la pression d'un fluide. Par exemple, lorsque vous arrosez votre jardin (ou une plante, comme vous préférez) avec un tuyau d'arrosage, eh bien dans ce tuyau, il y a une certaine pression exercée par l'eau fournie par le robinet. Cette pression permet le déplacement de l'eau dans le tuyau, donc crée un courant. Mais si la pression n'est pas assez forte, le courant ne sera lui non plus pas assez fort. Pour preuve, vous n'avez qu'à pincer le tuyau pour constater que le courant ne circule plus. On appelle ce "phénomène de pression" : la **tension**. Je n'en dis pas plus car ce serait vous embrouiller. ;)

## Notation et unité

La tension est mesurée en **Volts** (notée **V**) par un *Voltmètre*. On utilise principalement le Volt, mais aussi son sous-multiple qui est le milli-Volt (**mV**). On représente la tension, d'une pile par exemple, grâce à une flèche toujours orientée dans le sens du courant aux bornes d'un générateur et toujours opposée au courant, aux bornes d'un récepteur :

->![Fléchage de la tension](/media/galleries/954/16c37e78-4eb5-4dcc-891d-6d7ac9256476.png.960x960_q85.jpg)<-

## La différence de potentiel

Sur le schéma précédent, on a au point M une tension de 0V et au point P, une tension de 5V. Prenons notre Voltmètre et mesurons la tension aux bornes du générateur. La borne COM du Voltmètre doit être reliée au point M et la borne "+" au point P. Le potentiel au point P, soustrait par le potentiel au point M vaut : $U_P - U_M = 5 - 0 = 5V$ . On dit que la **différence de potentiel** entre ces deux points est de 5V. Cette mesure se note donc : $U_{P_M}$. Si on inverse le sens de branchement du Voltmètre, la borne "+" est reliée au point M et la borne COM au point P. La mesure que l'on prend est la différence de tension (= potentiel) entre le point M et le point P : $U_M - U_P = 0 - 5 = -5V$ Cette démonstration un peu surprenante vient du fait que la masse est arbitraire.

# La masse

Justement, parlons-en ! La **masse** est, en électronique, un point de référence.

## Notion de référentiel

Quand on prend une mesure, en général, on la prend entre deux points bien définis. Par exemple, si vous vous mesurez, vous prenez la mesure de la plante de vos pieds jusqu'au sommet de votre tête. Si vous prenez la plante de vos pieds pour référence (c'est-à-dire le chiffre zéro inscrit sur le mètre), vous lirez 1m70 (par exemple). Si vous inversez, non pas la tête, mais le mètre et que le chiffre zéro de celui-ci se retrouve donc au sommet de votre tête, vous serez obligé de lire la mesure à -1m70. Eh bien, ce chiffre zéro est la référence qui vous permet de vous mesurer. En électronique, cette référence existe, on l'appelle la **masse**.

## Qu'est ce que c'est ?

La masse, c'est un référentiel. En électronique, on voit la masse d'un montage comme étant le zéro Volt (0V). C'est le point qui permet de mesurer une bonne partie des tensions présentes dans un montage.

## Représentation et notation

Elle se représente par ce symbole, sur un schéma électronique :

->![Symbole de la masse](/media/galleries/954/2cd44b66-a6e3-4520-a1b1-2dc999cc08c8.png.960x960_q85.jpg)<-

Vous ne le verrez pas souvent dans les schémas de ce cours, pour la simple raison qu'elle est présente sur la carte que l'on va utiliser sous un autre nom : **GND**. GND est une abréviation du terme anglais "*Ground*" qui veut dire terre/sol. Donc, pour nous et tous les montages que l'on réalisera, ce sera le point de référence pour la mesure des tensions présentes sur nos circuits et le zéro Volt de tous nos circuits.

## Une référence arbitraire

Pour votre culture, sachez que la masse est quelque chose d'arbitraire. Je l'ai bien montré dans l'exemple au début de ce paragraphe. On peut changer l'emplacement de cette référence et, par exemple, très bien dire que le 5V est la masse. Ce qui aura pour conséquence de modifier l'ancienne masse en -5V.