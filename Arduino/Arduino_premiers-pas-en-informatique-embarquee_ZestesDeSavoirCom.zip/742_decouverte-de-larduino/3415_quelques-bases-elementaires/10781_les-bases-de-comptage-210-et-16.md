# Les bases ~~du~~ de comptage

[[question]]
| On va apprendre à compter ? o_O

Non, je vais simplement vous expliquer ce que sont les **bases de comptage**. C'est en fait un **système de numération** qui permet de compter en utilisant des caractères de numérations, on appelle ça des **chiffres**.

## Cas simple, la base 10

La base 10, vous la connaissez bien, c'est celle que l'on utilise tous les jours pour compter. Elle regroupe un ensemble de 10 chiffres : 0,1,2,3,4,5,6,7,8,9. Avec ces chiffres, on peut créer une infinité de nombres (ex : 42, 89, 12872, 14.56, 9.3, etc...). Cependant, voyons cela d'un autre œil...

* L'*unité* sera représenté par un chiffre multiplié par 10 à la puissance 0.
* La *dizaine* sera représenté par un chiffre multiplié par 10 à la puissance 1.
* La *centaine* sera représenté par un chiffre multiplié par 10 à la puissance 2.
* [...]
* Le *million* sera représenté par un chiffre multiplié par 10 à la puissance 6.
* etc...

En généralisant, on peut donc dire qu'un nombre (composé de chiffres) est la somme des chiffres multipliés par 10 à une certaine puissance. Par exemple, si on veut écrire 1024, on peut l'écrire : $1\times 1000 + 0\times 100 + 2\times 10 + 4\times 1 = 1024$ ce qui est équivalent à écrire : $1\times 10^3 + 0\times 10^2 + 2\times 10^1 + 4\times 10^0 = 1024$. Eh bien c'est ça, compter en base 10 ! Vous allez mieux comprendre avec la partie suivante.

## Cas informatique, la base 2 et la base 16

En informatique, on utilise beaucoup les bases 2 et 16. Elles sont composées des chiffres suivants :

* pour la **base 2** : les chiffres 0 et 1.
* pour la **base 16** : on retrouve les chiffres de la base 10, plus quelques lettres : 0,1,2,3,4,5,6,7,8,9,A,B,C,D,E,F

On appelle la base 2, la **base binaire**. Elle représente des états logiques 0 ou 1. Dans un signal numérique, ces états correspondent à des niveaux de tension. En électronique numérique, très souvent il s'agira d'une tension de 0V pour un état logique 0 ; d'une tension de 5V pour un état logique 1. On parle aussi de niveau HAUT ou BAS (in english : HIGH or LOW). Elle existe à cause de la conception physique des ordinateurs. En effet, ces derniers utilisent des millions de transistors, utilisés pour traiter des données binaires, donc deux états distincts uniquement (0 ou 1). Pour compter en base 2, ce n'est pas très difficile si vous avez saisi ce qu'est une base. Dans le cas de la base 10, chaque chiffre était multiplié par 10 à une certaine puissance en partant de la puissance 0. Eh bien en base 2, plutôt que d'utiliser 10, on utilise 2. Par exemple, pour obtenir 11 en base 2 on écrira : 1011... En effet, cela équivaut à faire : $1\times 2^3 + 0\times 2^2 + 1\times 2^1 + 1\times 2^0$ soit : $1\times 8 + 0\times 4 + 1\times 2 + 1\times 1$

[[information]]
| Un chiffre en base 2 s'appelle un **bit**. Un regroupement de 8 bits s'appelle un **octet**. Ce vocabulaire est très important donc retenez-le !

La base 16, ou **base hexadécimale** est utilisée en programmation, notamment pour représenter des octets facilement. Reprenons nos bits. Si on en utilise quatre, on peut représenter des nombres de 0 (0000) à 15 (1111). Ça tombe bien, c'est justement la portée d'un nombre hexadécimale ! En effet, comme dit plus haut il va de 0 (0000 ou 0) à F (1111 ou 15), ce qui représente 16 "chiffres" en hexadécimal. Grâce à cela, on peut représenter "simplement" des octets, en utilisant juste deux chiffres hexadécimaux.

## Les notations

Ici, rien de très compliqué, je vais simplement vous montrer comment on peut noter un nombre en disant à quelle base il appartient.

* Base binaire : (10100010)~2~
* Base décimale : (162)~10~
* Base hexadécimale : (A2)~16~

À présent, voyons les différentes méthodes pour passer d'une base à l'autre grâce aux **conversions**.

# Conversions

Souvent, on a besoin de convertir les nombres dans des bases différentes. On retrouvera deux méthodes, bonnes à savoir l'une comme l'autre. La première vous apprendra à faire les conversions "à la main", vous permettant de bien comprendre les choses. La seconde, celle de la calculatrice, vous permettra de faire des conversions sans vous fatiguer.

## Décimale - Binaire

Pour convertir un nombre décimal (en base 10) vers un nombre binaire (en base 2, vous suivez c'est bien !), il suffit de savoir diviser par ... 2 ! Ça ira ? Prenez votre nombre, puis divisez le par 2. Divisez ensuite le quotient obtenu par 2... puis ainsi de suite jusqu'à avoir un quotient nul. Il vous suffit alors de lire les restes de bas en haut pour obtenir votre nombre binaire... Par exemple le nombre **42** s'écrira **101010** en binaire. Voilà un schéma de démonstration de cette méthode :

![Conversion décimale binaire](/media/galleries/954/c412ddaf-1837-45b1-ae0c-bbf8584597ca.jpg.960x960_q85.jpg)
Figure : On garde les restes (en rouge) et on lit le résultat de bas en haut.

## Binaire - Hexadécimal

La conversion de binaire à l'hexadécimal est la plus simple à réaliser. Tout d'abord, commencez à regrouper les bits par blocs de quatre en commençant par la droite. S'il n'y a pas assez de bits à gauche pour faire le dernier groupe de quatre, on rajoute des zéros. Prenons le nombre 42, qui s'écrit en binaire, on l'a vu, **101010**, on obtiendra deux groupes de 4 bits qui seront **0010 1010**. Ensuite, il suffit de calculer bloc par bloc pour obtenir un chiffre hexadécimal en prenant en compte la valeur de chaque bit. Le premier bit, de poids faible (tout à droite), vaudra par exemple A ($1\times8 + 0\times4 + 1\times2 + 0\times1 = 10$ : A en hexadécimal). Ensuite, l'autre bloc vaudra simplement 2 ($0\times8 + 0\times4 + 1\times2 + 0\times1 = 2$). Donc 42 en base décimale vaut 2A en base hexadécimale, ce qui s'écrit aussi $(42)_{10} = (2A)_{16}$ 
Pour passer de hexadécimal à binaire, il suffit de faire le fonctionnement inverse en s'aidant de la base décimale de temps en temps. La démarche à suivre est la suivante :

* Je sépare les chiffres un par un (on obtient 2 et A)
* Je "convertis" leurs valeurs en décimal (ce qui nous fait 2 et 10)
* Je met ces valeurs en binaire (et on a donc 0010 1010)

## Décimal - Hexadécimal

Ce cas est plus délicat à traiter, car il nécessite de bien connaître la table de multiplication par 16. :euh: Comme vous avez bien suivi les explications précédentes, vous comprenez comment faire ici... Mais comme je suis nul en math, je vous conseillerais de faire un passage par la base binaire pour faire les conversions !

## Méthode rapide

Pour cela, je vais dans *Démarrer / Tous les programmes / Accessoires / Calculatrice* (ou en faisant une petite recherche dans le menu Démarrer ou directement depuis l'écran d'accueil de Windows 8). Qui a dit que j'étais fainéant ? :colere2:

![Utilisation de la calculatrice Windows](/media/galleries/954/534fc9b9-a4dc-4f5c-9670-22b830da63a9.png.960x960_q85.png)

[[information]]
| Pour obtenir cet affichage, il vous faudra peut-être utiliser le menu *Affichage* puis sélectionner *Programmeur*.

Sur le côté gauche, il y a des options à cocher pour afficher le nombre entré dans la base que l'on veut. Présentement, je suis en base 10 (décimale - bouton *Déc*). Si je clique sur *Hex* :

![Sélection de Hex](/media/galleries/954/9f340455-62ed-4157-9e25-daa124e89ba3.png.960x960_q85.png)

Je vois que mon nombre **42** a été converti en : **2A**. Et maintenant, si je clique sur *Bin* :

![Sélection de Bin](/media/galleries/954/48c201c5-77ff-4e35-ba76-8c5ea365e17e.png.960x960_q85.png)

Notre nombre a été converti en : **00101010** !