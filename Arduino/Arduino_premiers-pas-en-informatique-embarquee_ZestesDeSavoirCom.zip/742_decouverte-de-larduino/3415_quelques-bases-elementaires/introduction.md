En attendant que vous achetiez votre matériel, je vais vous présenter les bases de l'électronique et de la programmation. Cela vous demandera tout de même une bonne concentration pour essayer de comprendre des concepts pas évidents en soi.

[[information]]
| La première partie de ce chapitre ne fait que reprendre quelques éléments du [cours sur l'électronique](http://fr.openclassrooms.com/sciences/cours/l-electronique-de-zero), que vous pouvez consulter pour de plus amples explications. ;)