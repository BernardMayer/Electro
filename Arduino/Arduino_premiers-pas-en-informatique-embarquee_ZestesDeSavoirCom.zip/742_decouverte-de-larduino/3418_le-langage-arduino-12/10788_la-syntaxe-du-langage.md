La syntaxe d'un langage de programmation est l'ensemble des *règles d'écriture* liées à ce langage. On va donc voir dans ce sous-chapitre les règles qui régissent l'écriture du langage Arduino.

# Le code minimal

Avec Arduino, nous devons utiliser un *code minimal* lorsque l'on crée un programme. Ce code permet de diviser le programme que nous allons créer en deux grosses parties.

```cpp
// fonction d'initialisation de la carte
void setup()
{
    // contenu de l'initialisation
}

// fonction principale, elle se répète (s’exécute) à l'infini
void loop()
{
    // contenu de votre programme
}
```
Code: Le code minimal d'un programme Arduino

Vous avez donc devant vous le code minimal qu'il faut insérer dans votre programme.
Mais que peut-il bien signifier pour quelqu'un qui n'a jamais programmé ?

## La fonction `setup`

Dans ce code se trouvent deux fonctions. Les fonctions sont en fait *des portions de code*.

```cpp
// fonction d'initialisation de la carte
void setup()
{
    // contenu de l'initialisation
    // on écrit le code à l'intérieur
}
```
Code: Zoom sur la fonction setup

Cette fonction **setup()** est appelée *une seule fois* lorsque le programme commence.
C'est pourquoi c'est dans cette fonction que l'on va écrire le code qui n'a besoin d'être exécuté une seule fois.
On appelle cette fonction : **fonction d'initialisation**. On y retrouvera la mise en place des différentes sorties et quelques autres réglages. C'est un peu le check-up de démarrage. Imaginez un pilote d'avion dans sa cabine qui fait l'inventaire :P : *- patte 2 en sortie, état haut ? - OK - timer 3 à 15 millisecondes ? - OK ...*

Une fois que l'on a initialisé le programme il faut ensuite créer son "cœur", autrement dit le programme en lui même.

```cpp
// fonction principale, elle se répète (s’exécute) à l'infini
void loop()
{
    // contenu de votre programme
}
```
Code: Zoom sur la fonction principale

C'est donc dans cette fonction **loop()** où l'on va écrire le contenu du programme. Il faut savoir que cette fonction est appelée en permanence, c'est-à-dire qu'elle est exécutée une fois, puis lorsque son exécution est terminée, on la ré-exécute et encore et encore. On parle de **boucle infinie**.

[[i]]
| A titre informatif, on n'est pas obligé d'écrire quelque chose dans ces deux fonctions. En revanche, il est **obligatoire** de les écrire, même si elles ne contiennent aucun code !

## Les instructions

[[q]]
| Dans ces fonctions, on écrit quoi ?

C'est justement l'objet de ce paragraphe. Dans votre liste pour le diner de ce soir, vous écrivez les tâches importantes qui vous attendent. Ce sont des **instructions**. Les instructions sont des lignes de code qui disent au programme : "fait ceci, fait cela, ..." C'est tout bête mais très puissant car c'est ce qui va orchestrer notre programme.

## Les points virgules

Les points virgules terminent les instructions. Si par exemple je dis dans mon programme : "appelle la fonction *couperDuSaucisson"* *je dois mettre un point virgule après l'appel de cette fonction*.

[[e]]
| Les points virgules ( **;** ) sont synonymes d'erreurs car il arrive très souvent de les oublier à la fin des instructions.
|Par conséquent le code ne marche pas et la recherche de l'erreur peut nous prendre un temps conséquent ! Donc faites bien attention.


## Les accolades

Les accolades sont les "conteneurs" du code du programme. Elles sont propres aux fonctions, aux conditions et aux boucles. Les instructions du programme sont écrites à l'intérieur de ces accolades.

Parfois elles ne sont pas obligatoires dans les *conditions* (nous allons voir plus bas ce que c'est), mais je recommande de les **mettre tout le temps** ! Cela rendra plus lisible votre programme.

## Les commentaires

Pour finir, on va voir ce qu'est un commentaire. J'en ai déjà mis dans les exemples de codes. Ce sont des lignes de codes qui seront ignorées par le programme. Elles ne servent en rien lors de l'exécution du programme.

[[q]]
| Mais alors c'est inutile ? o_O

Non car cela va nous permettre à nous et aux programmeurs qui lirons votre code (s'il y en a) de savoir ce que signifie la ligne de code que vous avez écrite. C'est très important de mettre des commentaires et cela permet aussi de reprendre un programme laissé dans l'oubli plus facilement ! Si par exemple vous connaissez mal une instruction que vous avez écrite dans votre programme, vous mettez une ligne de commentaire pour vous rappeler la prochaine fois que vous lirez votre programme ce que la ligne signifie.

```cpp
// cette ligne est un commentaire sur UNE SEULE ligne
```
Code: Ligne unique de commentaire

```cpp
/*cette ligne est un commentaire, sur PLUSIEURS lignes
qui sera ignoré par le programme, mais pas par celui qui lit le code */
```
Code: Commentaire sur plusieurs lignes

## Les accents

[[a]]
| Il est formellement interdit de mettre des accents en programmation. Sauf dans les commentaires.