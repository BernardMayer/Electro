A présent que vous avez une vision globale sur le fonctionnement de la carte Arduino, nous allons pouvoir apprendre à programmer avant de nous lancer dans la réalisation de programmes très simples pour débuter ! Pour pouvoir programmer notre carte, il nous faut trois choses :

- Un ordinateur
- Une carte Arduino
- Et connaitre le langage Arduino

C’est ce dernier point qu’il nous faut acquérir. Le but même de ce chapitre est de vous apprendre à programmer avec le langage Arduino. Cependant, ce n’est qu’un support de cours que vous pourrez parcourir lorsque vous devrez programmer tout seul votre carte. En effet, c’est en manipulant que l’on apprend, ce qui implique que votre apprentissage en programmation sera plus conséquent dans les prochains chapitres que dans ce cours même.

[[i]]
| Le langage Arduino est très proche du C et du C++.
|Pour ceux dont la connaissance de ces langages est fondée, ne vous sentez pas obligé de lire les deux chapitres sur le langage Arduino. Bien qu'il y ait des points quelques peu importants.