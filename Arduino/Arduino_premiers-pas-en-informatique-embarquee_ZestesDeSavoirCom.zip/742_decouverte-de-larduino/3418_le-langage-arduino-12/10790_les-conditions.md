# Qu'est-ce qu'une condition ?

C'est un choix que l'on fait entre plusieurs propositions. En informatique, les conditions servent à tester des variables.
Par exemple : *Vous faites une recherche sur un site spécialisé pour acheter une nouvelle voiture.
Vous imposez le prix de la voiture qui doit être inférieur à 5000€ (c'est un petit budget ^^ ).
Le programme qui va gérer ça va faire appel à un **test conditionnel**.
Il va éliminer tous les résultats de la recherche dont le prix est supérieur à 5000€.*

# Quelques symboles

Pour tester des variables, il faut connaître quelques symboles.
Je vous ai fait un joli tableau pour que vous vous repériez bien :

->

Symbole | A quoi il sert | Signification
--------|----------------|--------------
== | Ce symbole, composé de deux égales, permet de tester l'égalité entre deux variables | ... est égale à ...
< | Celui-ci teste l'infériorité d'une variable par rapport à une autre | ...est inférieur à...
> | Là c'est la supériorité d'une variable par rapport à une autre | ...est supérieur à...
<= | teste l'infériorité ou l'égalité d'une variable par rapport à une autre | ...est inférieur ou égale à...
>= | teste la supériorité ou l'égalité d'une variable par rapport à une autre | ...est supérieur ou égal à...
!= | teste la différence entre deux variables | ...est différent de...

Table: Les symboles conditionnels

<-

"Et si on s'occupait des conditions ? Ou bien sinon on va tranquillement aller boire un bon café ?"

Cette phrase implique un choix : le premier choix est de s'occuper des conditions. Si l'interlocuteur dit oui, alors il s'occupe des conditions. Mais s'il dit non, alors il va boire un bon café. Il a donc l'obligation d'effectuer une action sur les deux proposées. En informatique, on parle de **condition**. "si la condition est vraie", on fait une action. En revanche "si la condition est fausse", on exécute une autre action.

# If...else

La première condition que nous verrons est la condition if...else. Voyons un peu le fonctionnement.

## if

On veut tester la valeur d'une variable. Prenons le même exemple que tout à l'heure. Je veux tester si la voiture est inférieure à 5000€.

```cpp
int prix_voiture = 4800; // variable : prix de la voiture définit à 4800€
```

D'abord on définit la variable "prix_voiture". Sa valeur est de 4800€. Ensuite, on doit tester cette valeur. Pour tester une condition, on emploie le terme *if* (de l'anglais "si"). Ce terme doit être suivi de parenthèses dans lesquelles se trouveront les variables à tester. Donc entre ces parenthèses, nous devons tester la variable prix_voiture afin de savoir si elle est inférieure à 5000€.

```cpp
if(prix_voiture < 5000)
{
    // la condition est vraie, donc j'achète la voiture
}
```
Code: Le test d'une condition

On peut lire cette ligne de code comme ceci : "**si** la variable *prix_voiture* est inférieure à 5000, on exécute le code qui se trouve entre les accolades.

[[a]]
| Les instructions qui sont *entre* les accolades ne seront exécutées que si la condition testée est *vraie* !

Le "schéma" à suivre pour tester une condition est donc le suivant :

```cpp
if(/* contenu de la condition à tester */)
{
    // instructions à exécuter si la condition est vraie
}
```
Code: Syntaxe d'une condition

## else

On a pour l'instant testé que si la condition est vraie. Maintenant, nous allons voir comment faire pour que d'autres instructions soient exécutées si la condition est fausse. Le terme *else* de l'anglais "sinon" implique notre deuxième choix si la condition est fausse. *Par exemple, si le prix de la voiture est inférieur à 5000€, alors je l'achète. Sinon, je ne l'achète pas.* Pour traduire cette phrase en ligne de code, c'est plus simple qu'avec un if, il n'y a pas de parenthèses à remplir :

```cpp
int prix_voiture = 5500;

if(prix_voiture < 5000)
{
    // la condition est vraie, donc j'achète la voiture
}
else
{
    // la condition est fausse, donc je n'achète pas la voiture
}
```
Code: Si "", alors "", sinon ""

[[i]]
| Le *else* est généralement utilisé pour les conditions dites **de défaut**. C'est lui qui à le pouvoir sur toutes les conditions, c'est-à-dire que si aucune condition n'est vraie, on exécute les instructions qu'il contient.

[[i]]
| Le *else* n'est pas obligatoire, on peut très bien mettre plusieurs *if* à la suite.

Le "schéma" de principe à retenir est le suivant :

```cpp
else  // si toutes les conditions précédentes sont fausses...
{
    // ...on exécute les instructions entre ces accolades
}
```
Code: Syntaxe du else

## else if

[[q]]
| A ce que je vois, on a pas trop le choix : soit la condition est vraie, soit elle est fausse. Il n'y a pas d'autres possibilités ? o_O

Bien sur que l'on peut tester d'autres conditions ! Pour cela, on emploie le terme *else if* qui signifie "sinon si..." *Par exemple, SI le prix de la voiture est inférieur à 5000€ je l'achète; SINON SI elle est égale à 5500€ mais qu'elle a l'option GPS en plus, alors je l'achète ; SINON je ne l'achète pas.* Le sinon si s’emploie comme le *if* :

```cpp
int prix_voiture = 5500;

if(prix_voiture < 5000)
{
    // la condition est vraie, donc j'achète la voiture
}
else if(prix_voiture == 5500)
{
    // la condition est vraie, donc j'achète la voiture
}
else
{
    // la condition est fausse, donc je n'achète pas la voiture
}
```
Code: Utilisation de `else if`

A retenir donc, si la première condition est fausse, on teste la deuxième, si la deuxième est fausse, on teste la troisième, etc. "Schéma" de principe du *else*, idem au *if* :

```cpp
else if(/* test de la condition */)  // si elle est vraie...
{
    // ...on exécute les instructions entre ces accolades
}
```
Code: Syntaxe du `else if`

[[a]]
| Le "else if" ne peut pas être utilisée toute seule, il faut obligatoirement qu'il y ait un "if" avant !

# Les opérateurs logiques

Et si je vous posais un autre problème ? Comment faire pour savoir si la voiture est inférieure à 5000€ ET si elle est grise ? :twisted:

[[q]]
| C'est vrai ça, si je veux que la voiture soit grise en plus d'être inférieure à 5000€, comment je fais ?

Il existe des opérateurs qui vont nous permettre de tester cette condition ! Voyons quels sont ses opérateurs puis testons-les !

->

+-----------+---------------+
| Opérateur | Signification |
+===========+===============+
|    &&     |   ... ET ...  |
+-----------+---------------+
|    ||     |   ... OU ...  |
+-----------+---------------+
|     !     |      NON      |
+-----------+---------------+

Table: les opérateurs logiques

<-

## ET

Reprenons ce que nous avons testé dans le *else if* : *SI la voiture vaut 5500€ ET qu'elle a l'option GPS en plus, ALORS je l'achète.* On va utiliser un *if* et un opérateur logique qui sera le *ET* :

```cpp
int prix_voiture = 5500;
int option_GPS = TRUE;

/* l'opérateur && lie les deux conditions qui doivent être
vraies ensemble pour que la condition soit remplie */
if(prix_voiture == 5500 && option_GPS)
{
    // j'achète la voiture si la condition précédente est vraie
}
```
Code: Conjonction de deux conditions

## OU

On peut reprendre la condition précédente et la première en les assemblant pour rendre le code beaucoup moins long.

[[i]]
| Et oui, les programmeurs sont des flemmards ! :P

Rappelons quelles sont ces conditions :

```cpp
int prix_voiture = 5500;
int option_GPS = TRUE;

if(prix_voiture < 5000)
{
    // la condition est vraie, donc j'achète la voiture
}
else if(prix_voiture == 5500 && option_GPS)
{
    // la condition est vraie, donc j'achète la voiture
}
else
{
    // la condition est fausse, donc je n'achète pas la voiture
}
```
Vous voyez bien que l'instruction dans le *if* et le *else if* est la même. Avec un opérateur logique, qui est le OU, on peut rassembler ces conditions :

```cpp
int prix_voiture = 5500;
int option_GPS = TRUE;

if((prix_voiture < 5000) || (prix_voiture == 5500 && option_GPS))
{
    // la condition est vraie, donc j'achète la voiture
}
else
{
    // la condition est fausse, donc je n'achète pas la voiture
}

```
Code: Utilisation du OU logique

Lisons la condition testée dans le if : "SI le prix de la voiture est inférieur à 5000€ OU SI le prix de la voiture est égal à 5500€ ET la voiture à l'option GPS en plus, ALORS j'achète la voiture".

[[e]]
| Attention aux parenthèses qui sont à bien placer dans les conditions, ici elles n'étaient pas nécessaires, mais elles aident à mieux lire le code. ;)

## NON

[[q]]
| Moi j'aimerais tester "si la condition est fausse j'achète la voiture". Comment faire ?

~~Toi t'as un souci~~ Il existe un dernier opérateur logique qui se prénomme NON. Il permet en effet de tester si la condition est fausse :

```cpp
int prix_voiture = 5500;

if(!(prix_voiture < 5000))
{
    // la condition est vraie, donc j'achète la voiture
}
```
Code: L'opérateur *négation*

Se lit : "SI le prix de la voiture N'EST PAS inférieur à 5000€, alors j'achète la voiture". On s'en sert avec le caractère ! (point d'exclamation), généralement pour tester des variables booléennes. On verra dans les boucles que ça peut grandement simplifier le code.

# Switch

Il existe un dernier test conditionnel que nous n'avons pas encore abordé, c'est le *switch*. Voilà un exemple :

```cpp
int options_voiture = 0;

if(options_voiture == 0)
{
    // il n'y a pas d'options dans la voiture
}
else if(options_voiture == 1)
{
    // la voiture a l'option GPS
}
else if(options_voiture == 2)
{
    // la voiture a l'option climatisation
}
else if(options_voiture == 3)
{
    // la voiture a l'option vitre automatique
}
else if(options_voiture == 4)
{
    // la voiture a l'option barres de toit
}
else if(options_voiture == 5)
{
    // la voiture a l'option  siège éjectable
}
else
{
// retente ta chance ;-)
}
```
Code: Un grand nombre de `else if`

Ce code est indigeste ! C'est infâme ! Grotesque ! Pas beau ! En clair, il faut trouver une solution pour changer cela. Cette solution existe, c'est le *switch*. Le *switch*, comme son nom l'indique, va tester la variable jusqu'à la fin des valeurs qu'on lui aura données. Voici comment cela se présente :

```cpp
int options_voiture = 0;

switch (options_voiture)
{
    case 0:
        // il n'y a pas d'options dans la voiture
        break;
    case 1:
        // la voiture a l'option GPS
        break;
    case 2:
        // la voiture a l'option climatisation
        break;
    case 3:
        // la voiture a l'option vitre automatique
        break;
    case 4:
        // la voiture a l'option barres de toit
        break;
    case 5:
        // la voiture a l'option siège éjectable
        break;
    default:
        // retente ta chance ;-)
        break;
}
```
Code: Utilisation de `switch`

Si on testait ce code, en réalité cela ne fonctionnerait pas car il n'y a pas d'instruction pour afficher à l'écran, mais nous aurions quelque chose du genre :

```bash
il n'y a pas d'options dans la voiture
```

Si option_voiture vaut maintenant 5 :

```bash
la voiture a l'option siège éjectable
```

[[e]]
| L'instruction **break** est **nécessaire**, car si vous ne la mettez pas, l'ordinateur, ou plutôt la carte Arduino, va exécuter toutes les instructions.
|Pour éviter cela, on met cette instruction break, qui vient de l'anglais "casser/arrêter" pour dire à la carte Arduino qu'il faut arrêter de tester les conditions car on a trouvé la valeur correspondante.

# La condition ternaire ou condensée

Cette condition est en fait une simplification d'un test if...else. Il n'y a pas grand-chose à dire dessus, par conséquent un exemple suffira : Ce code :

```cpp
int prix_voiture = 5000;
int achat_voiture = FALSE;

if(prix_voiture == 5000) // si c'est vrai
{
    achat_voiture = TRUE; // on achète la voiture
}
else // sinon
{
    achat_voiture = FALSE; // on n'achète pas la voiture
}
```

Est équivalent à celui-ci :

```cpp
int prix_voiture = 5000;
int achat_voiture = FALSE;

achat_voiture= (prix_voiture == 5000) ? TRUE : FALSE;
```
Code: Utilisation de la condition ternaire

Cette ligne :

```cpp
achat_voiture= (prix_voiture == 5000) ? TRUE : FALSE;
```

Se lit comme ceci : "Est-ce que le prix de la voiture est égal à 5000€ ? SI oui, alors j'achète la voiture SINON je n'achète pas la voiture"

[[i]]
| Bon, vous n'êtes pas obligé d'utiliser cette condition ternaire, c'est ~~vraiment pour les gros flemmards~~ juste pour simplifier le code, mais pas forcément la lecture de ce dernier.