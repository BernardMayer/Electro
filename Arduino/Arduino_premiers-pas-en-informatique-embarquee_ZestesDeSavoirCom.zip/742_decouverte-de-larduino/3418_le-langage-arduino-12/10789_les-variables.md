Nous l'avons vu, dans un microcontrôleur, il y a plusieurs types de mémoire.
Nous nous occuperons seulement de la mémoire "vive" (RAM) et de la mémoire "morte" (EEPROM).
Je vais vous poser une énigme. Imaginons que vous avez connecté un bouton poussoir sur une broche de votre carte Arduino.
Comment allez-vous stocker l'état du bouton (appuyé ou éteint) ?

# Une variable, qu'est ce que c'est ?

Une **variable est un nombre**. Ce nombre est stocké dans un espace de la mémoire vive (RAM) du microcontrôleur.
La manière qui permet de les stocker est semblable à celle utilisée pour ranger des chaussures : dans un casier numéroté.

->

+----+----+----+----+----+----+----+----+----+----+
|  Chaussures rangées dans des cases numérotées   |
+====+====+====+====+====+====+====+====+====+====+
|  1 |  2 |  3 |  4 |  5 |  6 |  7 |  8 |  9 | 10 |
+----+----+----+----+----+----+----+----+----+----+
| 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 |
+----+----+----+----+----+----+----+----+----+----+
| 21 | 22 | 23 | 24 | 25 | 26 | 27 | 28 | 29 | 30 |
+----+----+----+----+----+----+----+----+----+----+
| 31 | 32 | 33 | 34 | 35 | 36 | 37 | 38 | 39 | 40 |
+----+----+----+----+----+----+----+----+----+----+
| 41 | 42 | 43 | 44 | 45 | 46 | 47 | 48 | 49 | 50 |
+----+----+----+----+----+----+----+----+----+----+
| 51 | 52 | 53 | 54 | 55 | 56 | 57 | 58 | 59 | 60 |
+----+----+----+----+----+----+----+----+----+----+

Table: Un tableau est un ensemble de case
<-

[[q]]
| Une variable est un nombre, c'est tout ? o_O

Ce nombre a la particularité de changer de valeur. Étrange n'est-ce pas ? Et bien pas tant que ça, car une variable est en fait le **conteneur** du nombre en question. Et ce conteneur va être stocké dans une case de la mémoire. Si on matérialise cette explication par un schéma, cela donnerait :

-> **nombre => variable => mémoire** <-

+ le symbole "=>" signifiant : "est contenu dans..."

## Le nom d'une variable

Le nom de variable accepte quasiment tous les caractères sauf :

+ `.` (le point)
+ `,` (la virgule)
+ `é`,`à`,`ç`,`è` (les accents)

Bon je vais pas tous les donner, il n'accepte que l'alphabet alphanumérique ([a-z], [A-Z], [0-9]) et _ (underscore). Il ne doit **pas** commencer par un chiffre.

# Définir une variable

Si on donne un nombre à notre programme, il ne sait pas si c'est une variable ou pas. Il faut le lui indiquer. Pour cela, on donne un **type** aux variables. Oui, car il existe plusieurs types de variables ! Par exemple la variable "x" vaut 4 :

```cpp
x = 4;
```
Code: Assignation à une variable

Et bien ce code ne fonctionnerait pas car il ne suffit pas !
En effet, il existe une multitude de nombres : les nombres entiers, les nombres décimaux, ...
C'est pour cela qu'il faut assigner une variable à un type. Voilà les types de variables les plus répandus :

->

Type | Quel nombre il stocke ? | Valeurs maximales du nombre stocké | Nombre sur X bits | Nombre d'octets
-----|-------------------------|------------------------------------|-------------------|----------------
**int** | entier | -32 768 **à** +32 767 | 16 bits | 2 octets
**long** | entier | -2 147 483 648 **à** +2 147 483 647 | 32 bits | 4 octets
**char** | entier | -128 **à** +127 | 8 bits | 1 octets
**float** | décimale | -3.4 x $10^{38}$ **à** +3.4 x $10^{38}$ | 32 bits | 4 octets
**double** | décimale | -3.4 x $10^{38}$ **à** +3.4 x $10^{38}$ | 32 bits | 4 octets

Table: Les types de variables

<-

Par exemple, si notre variable "x" ne prend que des valeurs entières, on utilisera les types **int**, **long**, ou **char**.
Si maintenant la variable "x" ne dépasse pas la valeur 64 ou 87, alors on utilisera le type **char**.

```cpp
char x = 0;
```
Code: Assignation avec un type

[[i]]
| Si en revanche x = 260, alors on utilisera le type supérieur (qui accepte une plus grande quantité de nombre) à **char**, autrement dit **int** ou **long**.

[[q]]
| Mais t'es pas malin, pour éviter les dépassements de valeur ont met tout dans des double ou long !

Oui, mais NON. Un microcontrôleur, ce n'est pas un ordinateur 2GHz multicore, 4Go de RAM !
Ici on parle d'un système qui fonctionne avec un CPU à 16MHz (soit 0,016 GHz) et 2 Ko de SRAM pour la mémoire vive.
Donc deux raisons font qu'il faut choisir ses variables de manière judicieuse :

- La RAM n'est pas extensible, quand y en a plus, il y en a plus !
- Le processeur est de type 8 bits (sur Arduino UNO), donc il est optimisé pour faire des traitements sur des variables de taille 8 bits, un traitement sur une variable 32 bits prendra donc (beaucoup) plus de temps !

Si à présent notre variable "x" ne prend jamais une valeur négative (-20, -78, ...), alors on utilisera un type **non-signé**.
C'est à dire, dans notre cas, un **char** dont la valeur n'est plus de -128 à +127, mais de 0 à 255. Voici le tableau des types non signés, on repère ces types par le mot **unsigned** (de l'anglais : non-signé) qui les précède :

->

Type | Quel nombre il stocke ? | Valeurs maximales du nombre stocké | Nombre sur X bits | Nombre d'octets
-----|-------------------------|------------------------------------|-------------------|----------------
**unsigned** char | entier non négatif | 0 à 255 | 8 bits | 1 octet
**unsigned** int | entier non négatif | 0 à 65 535 | 16 bits | 2 octets
**unsigned** long | entier non négatif | 0 à 4 294 967 295 | 32 bits | 4 octets

Table: Les types non signés

<-

Une des particularités du langage Arduino est qu'il accepte un nombre plus important de types de variables. Je vous les liste dans ce tableau :

->

Type | Quel nombre il stocke ? | Valeurs maximales du nombre stocké | Nombre sur X bits | Nombre d'octets
-----|-------------------------|------------------------------------|-------------------|----------------
**byte** | entier non négatif | 0 à 255 | 8 bits | 1 octet
**word** | entier non négatif | 0 à 65535 | 16 bits | 2 octets
**boolean** | entier non négatif | 0 à 1 | 1 bit | 1 octet

Table: Les types propres à Arduino

<-

[[i]]
| Pour votre information, vous pouvez retrouver ces tableaux sur [cette page](http://arduino.cc/fr/Main/SyntheseTypesDonnees).

# Les variables booléennes

Les variables **booléennes** sont des variables qui ne peuvent prendre *que deux valeurs* : ou VRAI ou FAUX. Elles sont utilisées notamment dans les boucles et les conditions. Nous verrons pourquoi. Une variable booléenne peut être définie de plusieurs manières :

```cpp
// variable est fausse car elle vaut FALSE, du terme anglais "faux"
boolean variable = FALSE;
// variable est vraie car elle vaut TRUE, du terme anglais "vrai"
boolean variable = TRUE;
```
Code: Les variables booléennes

Quand une variable vaut "0", on peut considérer cette variable comme une variable booléenne, elle est donc fausse. En revanche, lorsqu'elle vaut "1" ou n'importe quelle valeurs différente de zéro, on peut aussi la considérer comme une variable booléenne, elle est donc vraie. Voilà un exemple :

```cpp
// variable est fausse car elle vaut 0
int variable = 0;
// variable est vraie car elle vaut 1
int variable = 1;
// variable est vraie car sa valeur est différente de 0
int variable = 42;
```
Code: Un booléen codé avec des entiers

Le langage Arduino accepte aussi une troisième forme d'écriture (qui lui sert pour utiliser les broches de sorties du microcontrôleur) :

```cpp
// variable est à l'état logique bas (= traduction de "low"), donc 0
int variable = LOW;
// variable est à l'état logique haut (= traduction de "high"), donc 1
int variable = HIGH;
```
Code: l'utilisation des constantes LOW et HIGH

Nous nous servirons de cette troisième écriture pour allumer et éteindre des lumières...

# Les opérations "simples"

On va voir à présent les opérations qui sont possibles avec le langage Arduino (addition, multiplication, ...).

Je vous vois tout de suite dire : "Mais pourquoi on fait ça, on l'a fait en primaire ! :colere2: " Et bien parce que c'est quelque chose d'essentiel, car on pourra ensuite faire des opérations avec des variables.
Vous verrez, vous changerez d'avis après avoir lu la suite ! ;)

## L'addition

Vous savez ce que c'est, pas besoin d'explications. Voyons comment on fait cette opération avec le langage Arduino. Prenons la même variable que tout à l'heure :

```cpp
// définition de la variable x
int x = 0;

// on change la valeur de x par une opération simple
x = 12 + 3;
// x vaut maintenant 12 + 3 = 15
```
Code: L'addition

Faisons maintenant une addition de variables :

```cpp
// définition de la variable x et assignation à la valeur 38
int x = 38;
int y = 10;
int z = 0;
// faisons une addition
// on a donc z = 38 + 10 = 48
z = x + y;
```
Code: Addition de deux variables

## La soustraction

On peut reprendre les exemples précédents, en faisant une soustraction :

```cpp
 /définition de la variable x
int x = 0;

// on change la valeur de x par une opération simple
x = 12 - 3;
// x vaut maintenant 12 - 3 = 9
```
Code: La soustraction

```cpp
int x = 38;   // définition de la variable x et assignation à la valeur 38
int y = 10;
int z = 0;

z = x - y;    // on a donc z = 38 - 10 = 28
```
Code: Soustraction de deux variables

## La multiplication

```cpp
int x = 0;
int y = 10;
int z = 0;

x = 12 * 3; // x vaut maintenant 12 * 3 = 36

z = x * y; // on a donc z = 36 * 10 = 360

// on peut aussi multiplier (ou une autre opération) un nombre et une variable :

z = z * ( 1 / 10 ); // soit z = 360 * 0.1 = 36
```
Code: la multiplication

## La division

```cpp
float x = 0;
float y = 15;
float z = 0;

x = 12 / 2; // x vaut maintenant 12 / 2 = 6

z = y / x; // on a donc z = 15 / 6 = 2.5
```
Code: La division

Attention cependant, si vous essayer de stocker le résultat d'une division dans une variable de type char, int ou long, le résultat sera stocké sous la forme d'un entier arrondi au nombre inférieur. Par exemple dans le code précédent si on met z dans un int on aura :

```cpp
float x = 0;
float y = 15;
int z = 0;

x = 12 / 2; // x vaut maintenant 12 / 2 = 6

z = y / x; // on a donc z = 15 / 6 = 2 !
```
Code: Arrondi au nombre inférieur

## Le modulo

Après cette brève explication sur les opérations de base, passons à quelque chose de plus sérieux. Le modulo est une opération de base, certes moins connue que les autres. Cette opération permet d'obtenir le reste d'une division.

```cpp
18 % 6 // le reste de l'opération est 0, car il y a 3*6 dans 18 donc 18 - 18 = 0
18 % 5 // le reste de l'opération est 3, car il y a 3*5 dans 18 donc 18 - 15 = 3
```
Code: Le modulo

Le modulo est utilisé grâce au symbole %. C'est tout ce qu'il faut retenir. Autre exemple :

```cpp
int x = 24;
int y = 6;
int z = 0;

z = x % y; // on a donc z = 24 % 6 = 0 (car 6 * 4 = 24)
```
Code: le modulo entre deux variables

[[i]]
| Le modulo ne peut-être fait que sur des nombres entiers

# Quelques opérations bien pratiques

Voyons un peu d'autres opérations qui facilitent parfois l'écriture du code.

## L'incrémentation

Derrière ce nom barbare se cache une simple opération d'addition.

```cpp
var = 0;
var++; // c'est cette ligne de code qui nous intéresse
```
Code: Incrémenter

"var++;" revient à écrire : "var = var + 1;" En fait, on ajoute le chiffre 1 à la valeur de *var*.
Et si on répète le code un certain nombre de fois, par exemple 30, et bien on aura *var* = 30.

## La décrémentation

C'est l'inverse de l'incrémentation. Autrement dit, on enlève le chiffre 1 à la valeur de var.

```cpp
var = 30;
var--; // décrémentation de var
```
Code: La décrémentation

## Les opérations composées

Parfois il devient assez lassant de réécrire les mêmes chose et l'on sait que les programmeurs sont des gros fainéants ! :P Il existe des raccourcis lorsque l'on veut effectuer une opération sur une même variable :

```cpp
int x, y;

x += y; // correspond à x = x + y;
x -= y; // correspond à x = x - y;
x *= y; // correspond à x = x * y;
x /= y; // correspond à x = x / y;
```
Code: des opérations composées

Avec un exemple, cela donnerait :

```cpp
int var = 10;

// opération 1
var = var + 6;
var += 6; // var = 16

// opération 2
var = var - 6;
var -= 6; // var = 4

// opération 3
var = var * 6;
var *= 6; // var = 60

// opération 4
var = var / 5;
var /= 5; // var = 2
```
Code: Opérations composées : détails

# L'opération de bascule (ou "inversion d'état")

Un jour, pour le projet du BAC, je devais (ou plutôt "je voulais") améliorer un code qui servait à programmer un module d'une centrale de gestion domestique. Mon but était d'afficher un choix à l'utilisateur sur un écran.
Pour ce faire, il fallait que je réalise une **bascule programmée** (c'est comme ça que je la nomme maintenant).
Et après maintes recherches et tests, j'ai réussi à trouver ! Et il s'avère que cette "opération", si l'on peut l’appeler ainsi, est très utile dans certains cas. Nous l'utiliserons notamment lorsque l'on voudra faire clignoter une lumière. Sans plus attendre, voilà cette astuce :

```cpp
// on définit une variable x qui ne peut prendre que la valeur 0 ou 1
// (soit vraie ou fausse)
boolean x = 0;

x = 1 - x;  // c'est la toute l'astuce du programme !
```
Code: La bascule

Analysons cette instruction. A chaque exécution du programme (oui, j'ai omis de vous le dire, il se répète jusqu'à l'infini), la variable x va changer de valeur :

- 1^er^ temps : x = 1 - x soit x = 1 - 0 donc x = 1
+ 2^e^ temps : x = 1 - x or x vaut maintenant 1 donc x = 1 - 1 soit x = 0
+ 3^e^ temps : x vaut 0 donc x = 1 - 0 soit x = 1

Ce code se répète donc et à chaque répétition, la variable x change de valeur et passe de 0 à 1, de 1 à 0, de 0 à 1, etc. Il agit bien comme une bascule qui change la valeur d'une variable booléenne. En mode console cela donnerait quelque chose du genre (n'essayez pas cela ne marchera pas, c'est un exemple) :

```bash
x = 0
x = 1
x = 0
x = 1
x = 0
...
```
Code: Le résultat de la bascule

Mais il existe d'autres moyens d'arriver au même résultat. Par exemple, en utilisant l'opérateur '!' qui signifie "not" ("non"). Ainsi, avec le code suivant on aura le même fonctionnement :

```cpp
x = !x;
```
Code: La bascule avec l'opérateur `!`

Puisqu'à chaque passage x devient "pas x" donc si x vaut 1 son contraire sera 0 et s'il vaut 0, il deviendra 1.