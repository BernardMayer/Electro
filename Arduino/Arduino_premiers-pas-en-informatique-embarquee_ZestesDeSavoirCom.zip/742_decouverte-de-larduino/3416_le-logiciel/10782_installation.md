Il n’y a pas besoin d’installer le logiciel Arduino sur votre ordinateur puisque ce dernier est une version portable. Regardons ensemble les étapes pour préparer votre ordinateur à l’utilisation de la carte Arduino.

# Téléchargement
Pour télécharger le logiciel, il faut se rendre sur [la page de téléchargement du site arduino.cc](http://arduino.cc/en/Main/Software) . Vous avez deux catégories :


+ Download : Dans cette catégorie, vous pouvez télécharger la dernière version du logiciel. Les plateformes Windows, Linux et Mac sont supportées par le logiciel. **C'est donc ici que vous allez télécharger le logiciel**.
+ Previous IDE Versions : Dans cette catégorie-là, vous avez toutes les versions du logiciel, sous les plateformes précédemment citées, depuis le début de sa création.

## Sous Windows
Pour moi ce sera sous Windows. Je clique sur le lien **Windows** et le fichier apparaît et doit être enregistre ou bon vous semble.

Une fois que le téléchargement est terminé, vous n'avez plus qu'à décompresser le fichier avec un utilitaire de décompression (7-zip, WinRar, ...). À l'intérieur du dossier se trouvent quelques fichiers et l'exécutable du logiciel :

![Exécutable du logiciel Arduino](/media/galleries/954/837638ab-4640-4a46-b5ff-5efd8193bc58.gif.960x960_q85.png)

## Mac os

Cliquez sur le lien Mac OS. Un fichier **.dmg** apparait. Enregistrez-le.

![Téléchargement sous Mac OS](/media/galleries/954/1185be88-cc72-4ad3-a55f-a47264eaeff3.png.960x960_q85.jpg)

Double-cliquez sur le fichier *.dmg* :

![Contenu du téléchargement](/media/galleries/954/e10776b3-09b9-4a2d-94c5-28f34fdd1419.png.960x960_q85.jpg)

On y trouve l'application Arduino (**.app**), mais aussi le driver à installer (**.mpkg**). Procédez à l’installation du driver puis installez l'application en la glissant dans le raccourci du dossier "Applications" qui est normalement présent sur votre ordinateur.

## Sous Linux

Rien de plus simple, en allant dans la logithèque, recherchez le logiciel "Arduino". Sinon vous pouvez aussi passer par la ligne de commande:

```bash
$ sudo apt-get install arduino
```

Plusieurs dépendances seront installées en même temps.

[[information]]
|Je rajoute [un lien](http://www.arduino.cc/playground/Learning/Linux)  qui vous mènera vers la page officielle.