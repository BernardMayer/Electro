Attaquons-nous plus sérieusement à l'utilisation du logiciel. La barre des menus est entourée en rouge et numérotée par le chiffre 1.

# Le menu *File*

C’est principalement ce menu que l’on va utiliser le plus. Il dispose d’un certain nombre de choses qui vont nous être très utiles. Il a été traduit en français progressivement, nous allons donc voir les quelques options qui sortent de l'ordinaire :

![Le menu Fichier](/media/galleries/954/026d3e88-8282-48b9-8355-062de4081471.png.960x960_q85.jpg)

* *Carnet de croquis* : Ce menu regroupe les fichiers que vous avez pu faire jusqu'à maintenant (et s'ils sont enregistrés dans le dossier par défaut du logiciel).
* *Exemples* (exemples) : Ceci est important, toute une liste se déroule pour afficher les noms d'exemples de programmes existants ; avec ça, vous pourrez vous aider/inspirer pour créer vos propres programmes ou tester de nouveaux composants.
* *Téléverser* : Permet d'envoyer le programme sur la carte Arduino. Nous y reviendrons ;) .
* *Téléverser avec un programmateur* : Idem que ci-dessus, mais avec l'utilisation d'un programmateur (vous n'en n'aurez que très rarement besoin).
* *Préférences* : Vous pourrez régler ici quelques paramètres du logiciel.
Le reste des menus n'est pas intéressant pour l'instant, on y reviendra plus tard, avant de commencer à programmer.

# Les boutons

Voyons à présent à quoi servent les boutons, encadrés en rouge et numérotés par le chiffre 2.

![La barre d'outils](/media/galleries/954/545cc8d8-167e-404f-bede-b28a39edc0e1.png.960x960_q85.png)

* Bouton 1 : Ce bouton permet de vérifier le programme, il actionne un module qui cherche les erreurs dans votre programme
* Bouton 2 : Charge (téléverse) le programme dans la carte Arduino.
* Bouton 3 : Crée un nouveau fichier.
* Bouton 4 : Ouvre un fichier.
* Bouton 5 : Enregistre le fichier.
* Bouton 6 : Ouvre le moniteur série (on verra plus tard ce que c'est ;) ).