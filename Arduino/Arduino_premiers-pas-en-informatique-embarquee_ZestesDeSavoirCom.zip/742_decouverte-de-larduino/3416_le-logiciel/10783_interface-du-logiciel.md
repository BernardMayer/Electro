# Lancement du logiciel
Lançons le logiciel en double-cliquant sur l'icône avec le symbole "infinie" en vert. C'est l’exécutable du logiciel. Après un léger temps de réflexion, une image s'affiche :

![Le splash screen Arduino](/media/galleries/954/be747fab-f62f-4c48-944e-6b25a59170c0.png.960x960_q85.jpg)

Cette fois, après quelques secondes, le logiciel s'ouvre. Une fenêtre se présente à nous :

![L'interface de l'IDE Arduino](/media/galleries/954/7befa027-9571-404d-9ad0-847d2f932b82.png.960x960_q85.png)

Ce qui saute aux yeux en premier, c'est la clarté de présentation du logiciel. On voit tout de suite son interface intuitive. Voyons comment se compose cette interface.

# Présentation du logiciel

J'ai découpé, grâce à mon ami paint.net, l'image précédente en plusieurs parties :

![L'interface de l'IDE Arduino en détail](/media/galleries/954/1f812c18-8421-47f9-934a-7981d80475cc.png.960x960_q85.png)

## Correspondance

* Le cadre numéro 1 : ce sont les options de configuration du logiciel
* Le cadre numéro 2 : il contient les boutons qui vont nous servir lorsque l'on va programmer nos cartes
* Le cadre numéro 3 : ce bloc va contenir le programme que nous allons créer
* Le cadre numéro 4 : celui-ci est important, car il va nous aider à corriger les fautes dans notre programme. C'est le **débogueur**.