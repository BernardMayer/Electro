Certains capteurs ne renvoient pas l'information sous forme "physique" dans le sens où ils ne renvoient pas quelque chose de mesurable directement, comme un temps ou une tension. Non, ces derniers préfèrent envoyer l'information encapsulée bien au chaud dans une trame d'un protocole de communication.

Le gros intérêt de cette méthode est très probablement la résistance au "bruit". Je ne parle bien sûr pas des cris des enfants du voisin ou les klaxons dans la rue mais bien de bruit électronique. Ce dernier est partout et peut avoir des conséquences ennuyeuses sur vos mesures. Transmettre l'information par un protocole de communication est donc un moyen fiable de garantir que la donnée arrivera de manière intègre jusqu'au destinataire. De plus, on peut facilement coupler cette transmission avec un protocole de vérification simple ou compliqué (comme la vérification de parité ou un calcul de CRC).

[[a]]
| Cette partie ne va pas vous enseigner comment utiliser chacun des moyens de communication que nous allons voir. En effet, il s'agit plutôt d'une introduction/ouverture sur l'existence de ces derniers. Ils seront traités de manière indépendante dans des chapitres dédiés comme le fût [la voie série](https://zestedesavoir.com/tutoriels/686/arduino-premiers-pas-en-informatique-embarquee/744_la-communication-avec-arduino/).

# Quelques protocoles de communication

## Voie série / UART

Ce protocole vous devez déjà le connaître par cœur puisque nous l'utilisons presque dans tous les chapitres ! Il s'agit en effet de la voie série via `Serial`. Rien de réellement compliqué donc tellement vous êtes habitués à le voir !
Ceci est une liaison point-à-point, donc seuls deux composants (l'Arduino et le capteur) peuvent être reliés entre eux directement. Elle est généralement bi-directionnelle, ce qui signifie que les deux composants reliés peuvent émettre en même temps.

## I2C

Le protocole I²C (*Inter-Integrated Circuit*) ou TWI (*Two Wire Interface*) permet d'établir une liaison de type "maître/esclave". L'Arduino sera maître et le capteur l'esclave (l'Arduino peut aussi être un esclave dans certains cas). Ainsi, l'Arduino émettra les ordres pour faire les demandes de données et le capteur, lorsqu'il recevra cet ordre, la renverra.

Ce protocole utilise 3 fils. Un pour la masse et ainsi avoir un référentiel commun, un servant à émettre un signal d'horloge (SCL) et un dernier portant les données synchronisées avec l'horloge (SDA).

Chez Arduino, il existe une librairie pour utiliser l'I2C, elle s'appelle `Wire`.

On peut placer plusieurs esclaves à la suite. Un code d'adresse est alors utilisé pour décider à quel composant le maître fait une requête.

## SPI

Le SPI (Serial Peripheral Interface) est une sorte de combo entre la voie série et l'I2C. Elle prend le meilleur des deux mondes.

Comme en voie série, la liaison est bi-directionnelle et point-à-point[^spi]. Cela signifie que Arduino et le capteur sont reliés directement entre eux et ne peuvent que parler entre eux. Cela signifie aussi que les deux peuvent s'envoyer des données simultanément.

Comme en I2C, la liaison est de type maître/esclave. L'un fait une demande à l'autre, le maître transmet l'horloge à l'esclave pour transmettre les données.

Cette transmission utilise 4 fils. Une masse pour le référentiel commun, un fil d'horloge (SCLK), un fil nommé MOSI (*Master Output, Slave Input*, données partant de l'Arduino et allant vers le capteur) et MISO (*Master Input, Slave Output*, données partant du capteur et allant vers l'Arduino).

Chez Arduino, il existe une librairie pour utiliser le SPI, elle s'appelle ... `SPI`.

[^spi]: Afin d'améliorer cette voie série, il existe une autre broche nommée SS (Slave Select) permettant de choisir à quel composant le maître parle. Ainsi la liaison n'est plus limitée à un esclave seulement.

## Protocole propriétaire

Ici pas de solution miracle, il faudra manger de la documentation technique (très formateur !). En effet, si le constructeur décide d'implémenter un protocole à sa sauce alors ce sera à vous de vous plier et de coder pour réussir à l'implémenter et l'utiliser.