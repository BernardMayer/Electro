Voyons maintenant un autre type de sortie très similaire à celui vu ci-dessus, la fréquence. Les capteurs de ce type vont donc vous délivrer une fréquence variable en fonction de la valeur mesurée. Je ne vais pas vous mentir, je n'ai pas d'exemple en tête !
Cependant, il est facile d'imaginer comment les utiliser en prenant en compte ce que l'on vient de voir pour le capteur renvoyant une PWM.

En effet, considérons un capteur nous envoyant un signal de type "créneau" à une fréquence *f*. Un créneau possède en théorie une durée d'état haut égale à la durée de l'état bas. Si on fait donc une mesure de cette durée d'état haut via `pulseIn()` vue précédemment, on peut aisément déduire la période (T) du signal (qui sera égale à deux fois la valeur lue) et ainsi la fréquence puisque $f = 1/T$ .

De manière programmatoire, on obtiendra donc le code suivant :

```cpp
const char capteur = 2; // broche sur laquelle est branchée le capteur

void setup()
{
   pinMode(capteur, INPUT);

   Serial.begin(9600);
}

void loop()
{
   unsigned long duree = pulseIn(capteur, HIGH); // ou LOW, ce serait pareil !
   duree = duree*2; // pour avoir la période complète

   // hop! on calcule la fréquence !
   float frequence = 1.0/duree;
   // passe la fréquence en Hz (car la période était mesurée en µs)
   frequence = frequence*1000000;
   Serial.print("Frequence = ");
   Serial.println(frequence);

   delay(250);
}
```
Code: Mesurer une fréquence

# Exemple / Exercice

Afin de mettre tout cela en pratique, je vous propose un petit exercice pour mettre en œuvre ce dernier point. Peu de matériel est à prévoir.

## Principe

Pour cet exercice, je vous propose d'émuler le comportement d'un capteur générant une fréquence variable.

Nous allons utiliser un potentiomètre qui va nous servir de "variateur". Ensuite nous allons utiliser une fonction propre à Arduino pour générer une fréquence particulière  qui sera l'image multipliée par 10 de la valeur mesurée du potentiomètre. Enfin, nous allons "reboucler" la sortie "fréquence" sur une entrée quelconque sur laquelle nous mesurerons cette fréquence.

C'est clair ? J'espère !

### La fonction tone()

Pour faire cette exercice vous connaissez déjà tout à une chose près : Comment générer une fréquence. Pour cela, je vous propose de partir à la découverte de la fonction `tone()`. Cette dernière génère une fréquence sur une broche, n'importe laquelle. Elle prend en paramètre la broche sur laquelle le signal doit être émis ainsi que la fréquence à émettre. Par exemple, pour faire une fréquence de 100Hz sur la broche 3 on fera simplement : `tone(3, 100);`.

Un troisième argument peut-être utilisé. Ce dernier sert à indiquer la durée pendant laquelle le signal doit être émis. Si on omet cet argument, la fréquence sera toujours générée jusqu'à l'appel de la fonction antagoniste `noTone()` à laquelle on passe en paramètre la broche sur laquelle le signal doit être arrêté.

[[a]]
| L'utilisation de la fonction tone interfère avec le module PWM des broches 3 et 11. Gardez-le en mémoire ;) . Cette fonction ne peut pas non plus descendre en dessous de 31Hz.

Vous avez toutes les informations, maintenant à vous de jouer !

## Correction

Voici ma correction commentée. Comme il n'y a rien de réellement compliqué, je ne vais pas faire des lignes d'explications et vous laisser simplement avec le code et ses commentaires :diable: !

```cpp
const char potar = 0; // potentiomètre sur la broche A0;
const char emetteur = 8; // fréquence émise sur la broche 8
const char recepteur = 2; // fréquence mesurée sur la broche 2

void setup()
{
   pinMode(emetteur, OUTPUT);
   pinMode(recepteur, INPUT);

   Serial.begin(9600);
}

void loop()
{
   // fait la lecture analogique (intervalle [0;1023] )
   unsigned int mesure = 100;

   // applique la mesure comme fréquence (intervalle [0;10230] )
   tone(emetteur, mesure*10);

   // mesure la demi-période
   unsigned long periode = pulseIn(recepteur, HIGH);
   // pour avoir une période complète on multiplie par 2
   periode = periode*2;
   // transforme en fréquence
   float frequence = 1.0/periode;
   // passe la fréquence en Hz (car la période était mesurée en µs)
   frequence = frequence*1000000;

   Serial.print("Mesure : ");
   Serial.println(mesure, DEC);
   Serial.print("Periode : ");
   Serial.println(periode, DEC);
   Serial.print("Frequence : ");
   Serial.println(frequence);

   delay(250);
}
```
Code: Générateur et mesure de fréquence, correction