# Principe

Vous vous souvenez de la PWM ? Nous l'avons utilisée dans le chapitre sur [les sorties analogiques](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/745/les-grandeurs-analogiques/3432/et-les-sorties-analogiques-enfin-presque/). Dans ce type de signal, l'information est présente dans la durée de l'état haut par rapport à l'état bas. Ici, notre capteur va donc de la même façon coder l'information via une durée d'état (mais elle ne sera pas forcément relative à son état antagoniste). Il est donc nécessaire de connaitre les caractéristiques du capteur pour pouvoir interpréter le signal correctement.

En effet, si on prend le signal sans rien savoir du capteur, comment déterminer ce que 20ms d'état haut signifie par exemple ?
Pour cela, ce type de composant doit toujours être utilisé avec sa documentation technique, afin de déterminer des paramètres comme ses bornes inférieure et supérieure de mesure. Mais c'est aussi vrai pour les autres (si vous tombez sur une résistance variable sans rien en connaître, vous devrez vous farcir une belle séance d'étalonnage pour l'identifier !).

# Utilisation

Prenons un cas simple. Imaginons que nous avons un capteur de température qui nous renvoie l'information suivante : *"La température en °C Celsius est proportionnelle à la durée d'état haut. La plage de mesure va de 0°C à 75°C pour une durée d'état haut de 0ms à 20ms"*.

Nous avons donc une relation proportionnelle entre une température et une durée. Nous pouvons alors déduire une règle mathématique pour faire la conversion degrésdurée.

En effet, on a les équivalences suivantes :

+ $0^{\circ}C \Leftrightarrow 0ms \Leftrightarrow 0\%$
+ $75^{\circ}C \Leftrightarrow 20ms \Leftrightarrow 100\%$

Une simple règle de trois nous donne : $x = \frac{75}{20} = 3.75^{\circ}C/ms$ ce qui signifie que pour chaque milliseconde, on a 3.75°C .

Voyons maintenant comment l'utiliser...

## Dans la pratique avec Arduino

Bon, c'est pas mal on a le côté théorique de la chose, mais ça ne nous dit toujours pas comment on va l'exploiter avec notre Arduino. En effet, générer une PWM on sait faire, mais mesurer une durée d'état haut ça on ne sait pas !
Et bien rassurez-vous, comme d'habitude c'est assez simple. En effet, il existe une fonction dans le framework Arduino qui sert exactement à cela, mesurer une durée d'état haut ou bas.

Cette fonction s'appelle [`pulseIn()`](http://arduino.cc/en/Reference/pulseIn). Elle prend simplement en paramètres la broche sur laquelle vous voulez faire la mesure et l'état que vous voulez mesurer (HIGH ou LOW). En option, un troisième paramètre permettra de spécifier un "timeout", un temps maximal à attendre avant de décider que la mesure n'est pas possible. Si le timeout est de 2 secondes et que l'état à mesurer n'a pas commencé 2 secondes après l'appel de la fonction, alors cette dernière retournera 0. Dernier détail, l'intervalle de mesure de la fonction est de 10µs à 3 minutes et renvoie un `unsigned long` représentant la durée de l'état en **microsecondes**.

Voilà, vous savez tout pour utiliser cette fonction ! Il ne faut pas oublier cependant que la broche sur laquelle nous allons faire la mesure doit être placée en INPUT lors du setup() ;) .

Reprenons maintenant l'exemple commencé ci-dessus.

Pour mesurer la température, nous allons mesurer l'état haut en sachant que celui-ci sera proportionnel à la température. Un code simple serait donc :

```cpp
const char capteur = 2; // en admettant que le capteur de température soit sur la broche 2

void setup()
{
   pinMode(capteur, INPUT);
   Serial.begin(9600); // pour afficher la température
}

void loop()
{
   unsigned long duree = pulseIn(capteur, HIGH, 25000);
   // dans notre exemple la valeur est dans l'intervalle [0, 20000]
   float temperature = duree*0.00375; // 3.75 °C par ms donc 0.00375 °C par µs

   /* Dans notre cas, on n'utilise pas "map()" car la fonction fait des arrondis,
   ce qui risquerait de nous faire perdre de l'informations */

   Serial.print("Duree lue : ");
   Serial.println(duree, DEC);
   Serial.print("Temperature : ");
   Serial.println(temperature);

   delay(200); // pour ne pas spammer la voie série
}
```
Code: Mise en pratique de `pulseIn`

## Simulation de l'exemple

Si comme moi vous n'avez pas de capteur retournant une PWM, voici un petit montage tout simple permettant de tester ce concept.

Pour cela, nous allons utiliser une PWM de l'Arduino ! En effet, on sait depuis le chapitre [Sorties analogiques](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/745/les-grandeurs-analogiques/3432/et-les-sorties-analogiques-enfin-presque/) faire varier un rapport cyclique dans une PWM, on va donc l'appliquer ici pour tester `pulseIn()`.

Pour cela, reliez une broche PWM à la broche qui vous sert de capteur puis essayez de réaliser ce que l'on vient de voir.

[[i]]
| La fréquence de la PWM via Arduino est d'environ 490Hz, ce qui signifie que la durée d'état haut pourra varier entre 0ms et 2,04ms

```cpp
const char capteur = 2; // broche capteur
const char emetteur = 3; // broche PWM

void setup()
{
   pinMode(capteur, INPUT);
   pinMode(emetteur, OUTPUT);

   Serial.begin(9600);
}

void loop()
{
   analogWrite(emetteur, 127); // test avec une valeur moyenne : environ 1ms
   unsigned long duree = pulseIn(capteur, HIGH);

   Serial.print("Duree : ");
   Serial.println(duree, DEC); // vérifie qu'on a bien la durée attendue

   delay(250);
}
```
Code: Simulation d'un capteur PWM et exploitation de `pulseIn`

# Étude de cas : le capteur de distance SRF05

[[i]]
| Un tutoriel plus complet sur ce capteur peut être trouvé ici : <https://zestedesavoir.com/tutoriels/539/realiser-un-telemetre-a-ultrasons/>

Prenons un exemple, le télémètre ultrason SRF05 dont la doc. technique a été retranscrite [ici](http://www.robot-electronics.co.uk/htm/srf05tech.htm).

Ce composant est l'exemple classique du capteur renvoyant un créneau codant l'information. En effet, ce dernier mesure ce que l'on appelle un **temps de vol**. Explications !
Le SRF05 est un télémètre ultra-son. Pour mesurer une distance, il compte le temps que met une onde pour faire un aller-retour. Un chronomètre est déclenché lors du départ de l'onde et est arrêté lorsque l'on détecte le retour de l'onde (une fois que celle-ci a "rebondi" sur un obstacle). Puisque l'on connait la vitesse de propagation (V) de l'onde dans l'air, on peut déterminer la distance (d) nous séparant de l'objet. On a donc la formule : $v = \frac{d}{t}$ soit $d = t \times v$ .

[[a]]
| Le temps mesuré correspond à l'aller ET au retour de l'onde, on a donc deux fois la distance. Il ne faudra pas oublier de diviser le résultat par deux pour obtenir la distance réelle qui nous sépare de l'objet.

Comme expliqué dans la documentation, pour utiliser le sonar il suffit de générer un état haut pendant 10 µs puis ensuite mesurer l'état haut généré par le sonar.

Ce dernier représente le temps que met l'onde à faire son aller-retour. Si l'onde met plus de 30ms à faire son voyage, elle est alors considérée comme perdue et la ligne repasse à LOW.

Et voilà, vous avez maintenant toutes les informations pour faire un petit programme d'essai pour utiliser ce sonar.

Ah, une dernière information... La vitesse d'une onde sonore dans l'air à 15°C est de 340 mètres par seconde. Ça pourrait être utile !

```cpp
#define VITESSE 340 // vitesse du son 340 m/s

const int declencheur = 2; // la broche servant à déclencher la mesure
const int capteur = 3; // la broche qui va lire la mesure

void setup()
{
   pinMode(declencheur, OUTPUT);
   pinMode(capteur, INPUT);

   digitalWrite(declencheur, LOW);
   Serial.begin(9600);
}

void loop()
{
   digitalWrite(declencheur, HIGH);
   delayMicroseconds(10); // on attend 10 µs
   digitalWrite(declencheur, LOW);

   // puis on récupère la mesure
   unsigned long duree = pulseIn(capteur, HIGH);

   if(duree > 30000)
   {
      // si la durée est supérieure à 30ms, l'onde est perdue
      Serial.println("Onde perdue, mesure echouee !");
   }
   else
   {
      // l'onde est revenue ! on peut faire le calcul
      // on divise par 2 pour n'avoir qu'un trajet (plutôt que l'aller-retour)
      duree = duree/2;
      float temps = duree/1000000.0; // on met en secondes
      float distance = temps*VITESSE; // on multiplie par la vitesse, d=t*v

      Serial.print("Duree = ");
      Serial.println(temps); // affiche le temps de vol d'un trajet en secondes
      Serial.print("Distance = ");
      Serial.println(distance); // affiche la distance mesurée
   }

   delay(250);
}
```
Code: Utilisation d'un capteur à ultrasons