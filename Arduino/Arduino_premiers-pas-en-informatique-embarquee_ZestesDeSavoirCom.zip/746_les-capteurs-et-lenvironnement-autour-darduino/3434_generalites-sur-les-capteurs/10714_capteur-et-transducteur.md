Un capteur est un dispositif capable de transformer une grandeur physique (telle que la température, la pression, la lumière, etc.) en une autre grandeur physique manipulable. On peut d'ailleurs prendre des exemples : un microphone est un capteur qui permet de transformer une onde sonore en un signal électrique ; un autre capteur tel qu'une photorésistance permet de transformer un signal lumineux en résistance variable selon son intensité.

![Schéma d'un capteur](/media/galleries/954/7027c5a9-6bd6-4d76-8015-bc0f1f8e3fbf.png.960x960_q85.jpg)

Pour nous, utiliser un thermomètre à mercure risque d’être difficile avec Arduino, car ce capteur ne délivre pas d’information électrique ou de résistance qui varie. Il s’agit seulement d’un niveau de liquide. Tandis qu’utiliser un microphone ou une photorésistance sera beaucoup plus facile. On distingue deux types de capteurs.

# ~~Capteurs~~ Transducteurs passifs

![Une photorésistance](http://zestedesavoir.com/media/galleries/954/05ca9c36-cb04-4e72-95c6-06711a7b74d5.jpg.960x960_q85.jpg)
Figure: Une photorésistance - (CC-0)

Ces capteurs ont pour objet de "transformer" ou plus exactement : *donner une image* de la grandeur physique qu'ils mesurent par une **résistance électrique variable** (en fait il s'agit d'une impédance, mais restons simples).
Par exemple, le potentiomètre donne une résistance qui varie selon la position de son axe. Pour ce qui est de leur utilisation, il faudra nécessairement les utiliser avec un montage pour pouvoir les utiliser avec Arduino.
Nous aurons l'occasion de voir tout cela en détail plus loin.
Ainsi, il ne s'agit pas réellement de capteur, mais de **transducteurs** car nous sommes obligés de devoir utiliser un montage additionnel pour assurer une conversion de la grandeur mesurée en un signal électrique exploitable.

[[information]]
| Ce sont principalement des transducteurs que nous allons mettre en œuvre dans le cours.
|Puisqu'ils ont l'avantage de pouvoir fonctionner seul et donc cela vous permettra de vous exercer au niveau électronique ! :diable:

# Capteurs actifs

![Un thermocouple](http://zestedesavoir.com/media/galleries/954/65f6d0d7-84d8-4ce6-8be2-f9096e4c3586.jpg.960x960_q85.jpg)
Figure: Un thermocouple  - (CC-0)

Cette autre catégorie de capteur est un peu spéciale et ne recense que très peu de capteurs en son sein.
Il s'agit de capteur dont la grandeur physique elle-même mesurée va directement établir une relation électrique de sortie.
C'est-à-dire qu'en sortie de ce type de capteur, il y aura une grandeur électrique, sans adjonction de tension à ses bornes. On peut dire que la présence de la tension (ou différence de potentiel, plus exactement) est générée par la grandeur physique. Nous n'entrerons pas dans le détail de ces capteurs et resterons dans ce qui est abordable à votre niveau.

# Les autres capteurs

En fait, il n'en existe pas réellement d'autres...

![infrarouge](/media/galleries/954/faf0de7a-0ea0-409c-8028-d43513664750.jpg.960x960_q85.jpg)
Figure: Détecteur infrarouge - (CC-BY-SA, [robotplatform.com](http://commons.wikimedia.org/wiki/File:Infrared_Transceiver_Circuit.jpg))

Ces "autres capteurs", dont je parle, sont les capteurs ou détecteurs tout prêts que l'on peut acheter dans le commerce, entre autres les détecteurs de mouvements ou capteur de distance.
Ils ne font pas partie des deux catégories précédemment citées, puisqu'ils possèdent toute une électronique d'adaptation qui va s'occuper d'adapter la grandeur physique mesurée par le capteur et agir en fonction.
Par exemple allumer une ampoule lorsqu'il détecte un mouvement.

Sachez cependant qu'il en existe beaucoup d'autres ! Ce sont donc bien des capteurs qui utilisent un ou des transducteurs.
On pourra en fabriquer également, nous serons même obligés afin d'utiliser les transducteurs que je vais vous faire découvrir.

[[attention]]
| Retenez donc bien la différence entre transducteur et capteur : un transducteur permet de donner une image de la grandeur physique mesurée par une autre grandeur physique, mais il doit être additionné à un montage pour être utilisé ; un capteur est nécessairement constitué d'un transducteur et d'un montage qui adapte la grandeur physique donnée par le transducteur en une information facilement manipulable.