Un capteur, on l’a vu, est donc constitué d’un transducteur et d’une électronique d’adaptation.
Le transducteur va d’abord mesurer la grandeur physique à mesurer, par exemple la luminosité.
Il va donner une image de cette grandeur grâce à une autre grandeur, dans ce cas une résistance électrique variable.
Et l’électronique d’adaptation va se charger, par exemple, de “transformer” cette grandeur en une tension électrique image de la grandeur mesurée.
Attention cependant, cela ne veut pas dire que la sortie sera **toujours** une tension variable.
Ainsi, on pourrait par exemple plutôt avoir un courant variable (et tension fixe), ou carrément un message via une liaison de communication (voir série par exemple).
Un capteur plus simple par exemple pourrait simplement nous délivrer un niveau logique pour donner une information telle que “obstacle présent/absent”.

![Un capteur c'est quoi ?](/media/galleries/954/18e87b4a-d8b8-4aa2-8a6f-88e5eb1b8921.png.960x960_q85.jpg)

A gauche se trouve la grandeur physique mesurable. En sortie du transducteur c'est une autre grandeur physique, manipulable cette fois.
Et en sortie de l'électronique d'adaptation, c'est l'information qui peut être sous forme de signal électrique ou d'une simple image de la grandeur physique mesurée par une autre grandeur physique telle qu'une tension électrique ou un courant.

# Mesure, le rôle du transducteur

Gardons notre exemple avec un capteur, pardon, transducteur qui mesure la luminosité.
Le transducteur qui opère avec cette grandeur est une *photorésistance* ou *LDR* (Light Depending Resistor).
C’est une résistance photo-sensible, ou si vous préférez qui réagit à la lumière.
La relation établie par la [photorésistance](http://fr.wikipedia.org/wiki/Photor%C3%A9sistance) entre la luminosité et sa résistance de sortie permet d’avoir une image de l’intensité lumineuse par une résistance électrique qui varie selon cette intensité.
Voici son symbole électrique et une petite photo d’identité :

![Une photorésistance](http://zestedesavoir.com/media/galleries/954/05ca9c36-cb04-4e72-95c6-06711a7b74d5.jpg.960x960_q85.jpg)
Figure: Une photorésistance - (CC-0)

![Symbole de la photorésistance](/media/galleries/954/3195cbde-5972-4afd-8e0c-4dc5c412df5c.png.960x960_q85.png)

![Représentation schématique](/media/galleries/954/ae8df3cf-3a58-49d4-b1d8-3f424ce220b8.png.960x960_q85.jpg)

On a donc, en sortie du transducteur, une relation du type y en fonction de x : $y = f(x)$.

Il s'agit simplement du **rapport** entre la grandeur physique d'entrée du capteur et sa grandeur physique de sortie.
Ici, le rapport entre la luminosité et la résistance électrique de sortie.
Dans les docs techniques, vous trouverez toujours ce rapport exprimé sous forme graphique (on appelle ça une **courbe caractéristique**). Ici, nous avons donc la résistance en fonction de la lumière :

![Caractéristique d'une photorésistance](/media/galleries/954/2685b307-76a5-4166-8f9d-31b4e8473ded.png.960x960_q85.jpg)

# L'intérêt d'adapter

Adapter pour quoi faire ? Eh bien je pense déjà avoir répondu à cette question, mais reprenons les explications avec l'exemple ci-dessus.
La photorésistance va fournir une résistance électrique qui fluctue selon la luminosité de façon quasi-proportionnelle (en fait ce n'est pas réellement le cas, mais faisons comme si :euh: ).
Eh bien, que va-t-on faire d'une telle grandeur ?
Est-ce que nous pouvons l'utiliser avec notre carte Arduino ? Directement ce n'est pas possible.
Nous sommes obligé de l'adapter en une **tension qui varie** de façon proportionnelle à cette résistance, puisque nous ne sommes pas capable de mesurer une résistance directement.
Ensuite nous pourrons simplement utiliser la fonction `analogRead()` pour lire la valeur mesurée.
Néanmoins, il faudra certainement faire des calculs dans le programme pour donner une réelle image de la luminosité.
Et ensuite, éventuellement, afficher cette grandeur ou la transmettre par la liaison série (ou l'utiliser de la manière qui vous fait plaisir :P ! ).
De nouveau, voici la relation établissant le rapport entre les deux grandeurs physiques d'entré et de sortie d'un transducteur :

-> $y = f(x)$ <-

A partir de cette relation, on va pouvoir gérer l'électronique d'adaptation pour faire en sorte d'établir une nouvelle relation qui soit également une image de la mesure réalisée par le capteur.
C'est à dire que l'on va créer une image proportionnelle de la grandeur physique délivrée en sortie du capteur par une nouvelle grandeur physique qui sera, cette fois-ci, bien mieux exploitable.
En l'occurrence une tension dans notre cas.
La nouvelle relation sera du style y prime (noté $y'$ )en fonction de y :

-> $y' = g(y)$ <-

Ce qui revient à dire que $y' $est la relation de sortie du capteur en fonction de la grandeur de mesure d'entré. Soit :

-> $y' = g(y) \longleftrightarrow y' = g(f(x))$ <-

Concrètement, nous retrouvons ces formules dans chaque partie du capteur :

![Représentation schématique](/media/galleries/954/b3093793-6ae1-448f-9bd2-7c763ebb44fe.png.960x960_q85.jpg)

# L'électronique d'adaptation

Elle sera propre à chaque capteur. Cependant, je l'ai énoncé au début de ce chapitre, nous utiliserons principalement des transducteurs qui ont en sortie une résistance électrique variable.
L'électronique d'adaptation sera donc quasiment la même pour tous. La seule chose qui changera certainement, c'est le programme.
Oui car la carte Arduino fait partie intégrante du capteur puisque c'est avec elle que nous allons "fabriquer" nos capteurs.
Le programme sera donc différent pour chaque capteur, d'autant plus qu'ils n'ont pas tous les mêmes relations de sortie... vous l'aurez compris, on aura de quoi s'amuser ! :P

Pour conclure sur l'intérieur du capteur, rentrons dans la partie électronique d'adaptation. La carte Arduino faisant partie de cette électronique, on va avoir un schéma tel que celui-ci :

![Schéma d'électronique d'adaptation](/media/galleries/954/8431b2ec-5209-445d-bd24-51eadebbafbe.png.960x960_q85.jpg)

A l'entrée de l'électronique d'adaptation se trouve la grandeur de sortie du transducteur ; à la sortie de l'électronique d'adaptation se trouve la grandeur de sortie du capteur.
On peut après faire ce que l'on veut de la mesure prise par le capteur. Toujours avec la carte Arduino, dans une autre fonction du programme, on pourra alors transformer la valeur mesurée pour la transmettre via la liaison série ou simplement l'afficher sur un écran LCD, voir l'utiliser dans une fonction qui détermine si la mesure dépasse un seuil limite afin de fermer les volets quand il fait nuit...