Pour terminer cette introduction générale sur les capteurs, nous allons aborder les caractéristiques essentielles à connaitre.

# Les critères à ne pas négliger

## La plage de mesure

La **plage de mesure**, ou *gamme de mesure*, est la première chose à regarder dans le choix d'un capteur ou d'un transducteur.
C'est elle qui définit si vous allez pouvoir mesurer la grandeur physique sur une grande plage ou non.
Par exemple pouvoir mesurer une température de -50°C à +200°C. Tout dépendra de ce que vous voudrez mesurer.

### La précision

La précision est le deuxième critère de choix le plus important. En effet, si votre capteur de température a une précision de 1°C, vous aurez du mal à l'utiliser dans un projet qui demande une précision de mesure de températures de 0.1°C !
En règle générale, la précision est plus grande lorsque la plage de mesure est faible et inversement elle devient moins grande lorsque la plage de mesure augmente.

Il est en effet assez difficile de fabriquer des capteurs qui ont une plage de mesure très grande par exemple un voltmètre qui mesurerait jusqu'à 1000V avec une précision de 0.001V !
Et puis, c'est rarement utile d'avoir ces deux paramètres à leur valeur la plus élevée (grande plage de mesure et grande précision).

Dans un cas le plus général, à prix égal un capteur qui mesure une plus grande plage aura surement une précision plus faible qu'un capteur mesurant une plage plus réduite.

### Sa tension d'alimentation

Il est en effet important de savoir à quelle tension il fonctionne, pour ne pas avoir de mauvaise surprises lorsque l'on veut l'utiliser !

# D'autres caractéristiques à connaitre

## La résolution

Certains capteurs proposent une sortie via une communication (série, I²C, SPI...).
Du coup, la sortie est dite "numérique" (puisqu'on récupère une information logique plutôt qu'analogique). Un facteur à prendre en compte est la résolution proposée.
Certains capteurs seront donc sur 8 bits (la valeur de sortie sera codé sur 256 niveaux), d'autres 10 bits, 16 bits, 32 bits...
Il est évident que plus la résolution est élevée et plus la précision offerte est grande.

## La reproductibilité

Ce facteur sert à déterminer la fiabilité d'une mesure. Si par exemple vous souhaitez mesurer une température à 0.1°C près, et que le capteur que vous utilisez oscille entre 10.3° et 10.8°C lorsque vous faites une série de mesures consécutives dans un intervalle de temps court, vous n'êtes pas précis.

La reproductibilité est donc le critère servant à exprimer la fiabilité d'une mesure au travers de répétitions consécutives, et le cas échéant exprime l'écart-type et la dispersion de ces dernières.
Si la dispersion est élevée, il peut-être utile de faire plusieurs mesures en un court-temps pour ensuite faire une moyenne de ces dernières.

## Le temps de réponse

Comme son nom l'indique, cela détermine la vitesse à laquelle le capteur réagit par rapport au changement de l'environnement.
Par exemple, les changements de température sont des phénomènes souvent lents à mesurer. Si vous passez le capteur d'un milieu très chaud à un milieu très froid, le capteur va mettre du temps (quelques secondes) pour proposer une information fiable.
A contrario, certains capteurs réagissent très vite et ont donc un temps de réponse très faible.

## La bande passante

Cette caractéristique est plus difficile à comprendre et est lié au temps de réponse.
Elle correspond à la capacité du capteur à répondre aux sollicitations de son environnement. Si sa bande passante est élevée, il peut mesurer aussi bien des phénomènes lents que des phénomènes rapides.
Si au contraire elle est faible, sa capacité à mesurer des phénomènes lents **ou** rapides sera réduite sur une certaine plage de fréquences.

## La gamme de température d'utilisation

Ce titre est assez explicite. En effet, lorsque l'on mesure certains phénomènes physiques, le capteur doit avoir une certaine réponse. Cependant, il arrive que le phénomène soit conditionné par la température.
Le capteur doit donc être utilisé dans certaines conditions pour avoir une réponse correcte (et ne pas être détérioré).

[[information]]
| Lorsque vous utilisez un capteur pour la première fois, il est souvent utile de pratiquer un **étalonnage**.
|Cette opération consiste à prendre quelques mesures pour vérifier/corriger la justesse de sa caractéristique par rapport à la datasheet ou aux conditions ambiantes. 

Nous verrons tout au long des chapitres certaines caractéristiques. Après ce sera à vous de choisir vos capteurs en fonction des caractéristiques dont vous aurez besoin.