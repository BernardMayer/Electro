Faisons une petite pause dans notre découverte des capteurs pour parler d'un problème qui peut arriver à tout le monde... Comment faites-vous si vous possédez un capteur mais ne possédez pas sa caractéristique exacte ? Comment feriez-vous pour faire correspondre une valeur analogique lue avec une donnée physique réelle ?

Par exemple, si je vous donne un composant en vous disant "Hey, te voilà un capteur de température, je sais qu'il s'alimente en 5V sur telle et telle broches, je sais que le signal de sortie est une tension en fonction de la température mais je suis incapable de te dire quelle est la caractéristique (la courbe tension en fonction de la température)".

Nous allons maintenant voir comment résoudre ce problème en voyant une méthode pour étalonner son capteur. Nous allons ainsi nous même déterminer la courbe caractéristique du capteur et déterminer son coefficient liant la température et la tension. À la fin, je vous donnerais la vraie courbe constructeur et nous pourrons comparer nos résultats pratiques avec ceux de référence :) .

## Le capteur utilisé

Pour étudier la méthode que je vous propose ici, nous allons utiliser un capteur de température assez répandu qui se nomme "LM35". Il existe dans différents boîtiers que voici :

![Boîtier du LM35](/media/galleries/954/5c44f9ac-cea7-4aaf-9f7f-60175b2b6213.png.960x960_q85.jpg)

Vous aurez deviné le branchement, il est assez simple. Il suffit de relier +VS au 5V et GND à la masse. Le signal sera ensuite lu sur la broche Vout.

# La méthode

La méthode pour caractériser le capteur est assez simple. À l'aide d'une multitude de mesures et d'un appareil témoin, nous allons pouvoir créer un tableau qui nous servira à calculer la courbe (à l'aide d'un logiciel comme Excel par exemple). Pour cela, en plus de votre capteur vous aurez besoin d'un appareil de mesure "témoin" qui vous servira de référence. Par exemple le bon vieux thermomètre qui traîne accroché à votre fenêtre fera parfaitement l'affaire :D .

## Prise de mesures

Vous êtes prêts, alors allons-y, commençons à travailler. Reliez le capteur à l'Arduino et l'Arduino à l'ordinateur, de la manière la plus simple possible, comme ceci par exemple :

![LM35](/media/galleries/954/8629c7c1-636a-470e-afff-eb9768a96281.png.960x960_q85.png)

Ensuite, nous devons récupérer les données envoyées par le capteur de manière régulière (ou rajoutez un bouton et faite des envois lors de l'appui ;) ). Pour cela, voici un petit programme sans difficulté qui vous enverra les valeurs brutes ou converties en volts toutes les demi-secondes.

```cpp
const int capteur = 0; // capteur branché sur la pin analogique 0
float tension = 0.0;
int valeur = 0;

void setup()
{
    Serial.begin(9600);
}

void loop()
{
    valeur = analogRead(capteur);
    tension = (valeur*5.0)/1024;

    Serial.print("Tension : ");
    Serial.print(tension);
    Serial.println(" V");
    Serial.print("Valeur : ");
    Serial.println(valeur);
    Serial.println("---------------------");

    delay(500);
}
```
Code: Mesure des valeurs

Maintenant que tout est prêt, il nous faut un banc de test. Pour cela, préparez une casserole avec de l'eau contenant plein de glaçons (l'eau doit être la plus froide possible). Faites une première mesure avec votre capteur plongé dedans (attention, les broches doivent être isolées électriquement ou alors mettez l'ensemble dans un petit sac plastique pour éviter que l'eau n'aille faire un court-circuit). Faites en même temps une mesure de la température réelle observée à l'aide du thermomètre. Une fois cela fait, relevez ces mesures dans un tableau qui possédera les colonnes suivantes :

- Température réelle (en °C)
- Tension selon Arduino (en V)
- Valeur brute selon Arduino

Quand la première mesure est faite, commencez à faire réchauffer l'eau (en la plaçant sur une plaque de cuisson par exemple). Continuez à faire des mesures à intervalle régulier (tous les 5 degrés voire moins par exemple). Plus vous faites de mesure, plus l'élaboration de la courbe finale sera précise. Voici à titre d'exemple le tableau que j'ai obtenu :

->

Température (°C)     |   Tension (V)   |   Valeur CAN
------|-----|-----
2 |   0,015 |   3
5 |   0,054 |   11
10  |   0,107 |   22
16  | 0,156 |   32
21 |   0,210 |   43
24  |   0,234 |   48
29  | 0,293 |   60
35 |   0,352 |   72
38  |   0,386 |   79
43  | 0,430 |   88
46 |   0,459 |   94
50  |   0,503 |   103

Table: Relevé de température

<-

## Réalisation de la caractéristique

Lorsque vous avez fini de prendre toutes vos valeurs, vous allez pouvoir passer à l'étape suivante qui est :

Calculer la caractéristique de votre courbe !! Sortez vos cahiers, votre calculatrice et en avant ! ... Non je blague (encore que ça ferait un super TP), on va continuer à utiliser notre logiciel tableur pour faire le travail pour nous ! On va donc commencer par regarder un peu l'allure de la courbe.

Je vais en faire deux, une symbolisant les valeurs brutes de la conversion du CAN (entre 0 et 1023) en rouge et l'autre qui sera l'image de la tension en fonction de la température en bleu. Nous pourrons alors déterminer deux caractéristiques, selon ce qui vous arrange le plus.

![Valeurs CAN en fonction de la température](/media/galleries/954/0cf79df4-f683-431c-b269-75e42279a0fb.png.960x960_q85.jpg)

![Tension en fonction de la température](/media/galleries/954/60710cf0-fe3f-4b69-b4dd-b1d03df5c57e.png.960x960_q85.jpg)

Une fois cela fait, il ne reste plus qu'à demander gentiment au logiciel de graphique de nous donner la **courbe de tendance** réalisée par ces points. Sous Excel, il suffit de cliquer sur un des points du graphique et choisir ensuite l'option "Ajouter une courbe de tendance...".

Vous aurez alors le choix entre différents types de courbe (linéaire, exponentielle...). Ici, on voit que les points sont alignés, il s'agit donc d'une équation de courbe linéaire, de type $y=ax+b$. Cochez la case "Afficher l'équation sur le graphique" pour pouvoir voir et exploiter cette dernière ensuite.

![Options de la courbe de tendance](/media/galleries/954/f92bea2e-d344-4977-9b0d-ac8a5ad66c22.png.960x960_q85.png)

Voici alors ce que l'on obtient lorsque l'on rajoute notre équation :

![Ajout de la courbe de tendance](/media/galleries/954/0187b0ca-a546-4e3e-b014-16f7ba351c12.png.960x960_q85.jpg)

![Ajout de la courbe de tendance](/media/galleries/954/ed10f42b-23d3-4802-945b-49c9ea4aff28.png.960x960_q85.jpg)

Grâce à l’équation, nous pouvons déterminer la relation liant la température et la tension (ou les valeurs du CAN). Ici nous obtenons :

- $y = 0.01x - 0.0003$ (pour la tension)
- $y = 2.056x - 0.0707$ (pour les valeurs du CAN)

Le coefficient constant (-0.003 ou -0.0707) peut ici être ignoré. En effet, il est faible (on dit **négligeable**) comparé aux valeurs étudiées. Dans les équations, $x$ représente la température et $y$ représente la tension ou les valeurs du CAN. On lit donc l'équation de la manière suivante : Tension en Volt égale 0,01 fois la température en degrés Celsius. Ce qui signifie que dorénavant, en ayant une mesure du CAN ou une mesure de tension, on est capable de déterminer la température en degrés Celsius :) Super non ? Par exemple, si nous avons une tension de 300mV, avec la formule trouvée précédemment on déterminera que l'on a $0.3 = 0.01 \times Temperature$, ce qui équivaut à $Temperature = 0.3/0.01 = 30 ^oC$ . On peut aisément le confirmer via le graphique ;)

Maintenant j'ai trois nouvelles, deux bonnes et une mauvaise... La bonne c'est que vous êtes capable de déterminer la caractéristique d'un capteur. La deuxième bonne nouvelle, c'est que l'équation que l'on a trouvé est correcte... ... parce qu'elle est marquée dans [la documentation technique](http://www.ti.com/lit/ds/symlink/lm35.pdf) qui est super facile à trouver :D (ça c'était la mauvaise nouvelle, on a travaillé pour rien !! ) Mais comme c'est pas toujours le cas, c'est toujours bien de savoir comment faire ;)

## Adaptation dans le code

Puisque nous savons mesurer les valeurs de notre capteur et que nous avons une équation caractéristique, nous pouvons faire le lien en temps réel dans notre application pour faire une utilisation de la grandeur *physique* de notre mesure. Par exemple, s'il fait 50°C nous allumons le ventilateur. En effet, souvenez-vous, avant nous n'avions qu'une valeur entre 0 et 1023 qui ne signifiait physiquement pas grand chose. Maintenant nous sommes en mesure (oh oh oh :D ) de faire la conversion. Il faudra pour commencer récupérer la valeur du signal. Prenons l'exemple de la lecture d'une tension analogique du capteur précédent :

```cpp
int valeur = analogRead(monCapteur); // lit la valeur
```

Nous avons ensuite deux choix, soit nous le transformons en tension puis ensuite en valeur physique grâce à la caractéristique du graphique bleu ci-dessus, soit nous transformons directement en valeur physique avec la caractéristique rouge. Comme je suis fainéant, je vais chercher à économiser une instruction en prenant la dernière solution. Pour rappel, la formule obtenue était : $y = 2.056x - 0.0707$. Nous avions aussi dit que le facteur constant était négligeable, on a donc de manière simplifiée $y = 2.056x$ soit "la température est égale à la valeur lue divisé par 2.056 ($x = \frac{y}{2.056}$). Nous n'avons plus qu'à faire la conversion dans notre programme !

```cpp
float temperature = valeur/2.056;
```
Code: La formule de conversion

Et voilà ! Si l'on voulait écrire un programme plus complet, on aurait :

```cpp
int monCapteur = 0; // Capteur sur la broche A0;
int valeur = 0;
float temperature = 0.0;

void setup()
{
    Serial.begin(9600);
}

void loop()
{
    valeur = analogRead(monCapteur);
    temperature = valeur/2.056;

    Serial.println(temperature);

    delay(500);
}
```
Code: Lire la température avec un capteur étalonné

[[information]]
| Et si jamais notre coefficient constant n'est pas négligeable ?

Eh bien prenons un exemple ! Admettons qu'on obtienne la caractéristique suivante : $y = 10x + 22$. On pourrait lire ça comme "ma valeur lue par le CAN est égale à 10 fois la valeur physique plus 22". Si on manipule l'équation pour avoir $x$ en fonction de $y$, on aurait :

-> $y = 10x + 22$

$y-22 = 10x$

$x = \frac{y-22}{10}$ <-

Dans le code, cela nous donnerait :

```cpp
void loop()
{
    valeur = analogRead(monCapteur);
    temperature = (valeur-22)/10;

    Serial.println(temperature);

    delay(500);
}
```
Code: Cas d'une constante non négligeable