# La photo-résistance

Nous y voilà, on va enfin voir le transducteur dont j'arrête pas de vous parler depuis tout à l'heure : la photo-résistance ! Je vois que vous commenciez à être impatients. ^^

## Petit aperçu

La photo-résistance est un composant électronique qui est de type transducteur. Il est donc capable de donner une image de la grandeur physique mesurée, la lumière ou précisément la luminosité, grâce à une autre grandeur physique, la résistance.

![Une photorésistance](http://zestedesavoir.com/media/galleries/954/05ca9c36-cb04-4e72-95c6-06711a7b74d5.jpg.960x960_q85.jpg)
Figure: Une photorésistance - (CC-0)

On trouve généralement ce composant en utilisation domotique, pour... devinez quoi ?! ... faire monter ou descendre les volets électriques d'une habitation ! :P

Mais on peut également le retrouver en robotique, par exemple pour créer un robot suiveur de ligne noire. Enfin on le trouve aussi dans beaucoup d'autres applications, vous saurez trouver vous-mêmes où est-ce que vous l'utiliserez, je vous fais confiance de ce point de vue là. ;)

## Propriété

La photo-résistance suit une relation toute simple entre sa résistance et la luminosité :

$$R = f(E)$$

- $R$ la résistance en Ohm ($\Omega$)
- $E$ l'intensité lumineuse en [lux](http://fr.wikipedia.org/wiki/Lux_(unit%C3%A9)) (lx)

Plus l'intensité lumineuse est élevée, plus la résistance diminue. À l'inverse, plus il fait sombre, plus la résistance augmente.

Malheureusement, les photo-résistances ne sont pas des transducteurs très précis. Ils ont notamment des problèmes de linéarité, un temps de réponse qui peut être élevé et une grande tolérance au niveau de la résistance. Nous les utiliserons donc pour des applications qui ne demandent que peu de rigueur. Ce qui ira bien pour ce qu'on veut en faire.

![Symbole de la photorésistance](/media/galleries/954/3195cbde-5972-4afd-8e0c-4dc5c412df5c.png.960x960_q85.png)

Une [photorésistance](http://fr.wikipedia.org/wiki/Photor%C3%A9sistance) est une résistance qui possède une valeur de base en Ohm. C'est à dire qu'elle est calibrée pour avoir une valeur, par exemple 47 kOhm, à un certain seuil de luminosité. À ce seuil on peut donc mesurer cette valeur, suivant la tolérance qu'affiche la photo-résistance. Si la luminosité augmente, la résistance de base n'est plus vraie et chute. En revanche, dans le noir, la résistance augmente bien au delà de la résistance de base.

[[question]]
| Génial !! J'en veux, j'en veux ! Comment on l'utilise ? :D

La photorésistance est principalement utilisée dans un montage en pont diviseur de tension. Vous le connaissez ce montage, c'est exactement le même principe de fonctionnement que le potentiomètre.
Sauf que ce ne sera pas vous qui allez modifier le curseur mais la photorésistance qui, selon la luminosité, va donner une valeur ohmique différente. Ce qui aura pour effet d'avoir une influence sur la tension en sortie du pont diviseur.

## Rappel sur le pont diviseur de tension

Je vous rappelle le montage d'un pont diviseur de tension :

![Pont diviseur de tension](/media/galleries/954/32b46189-ca5e-4752-9889-878943e53324.gif.960x960_q85.png)

La formule associée est la suivante :

$$V_s = V_e \frac{R_2}{R_1 + R_2}$$

[[attention]]
| Cette formule s'applique **uniquement** dans le cas où la sortie Vs ne délivre pas de courant (cas des entrées numériques ou analogiques d'un microcontrôleur par exemple).
|Dans le cas où il y a justement un courant qui sort de ce pont, cela modifie la valeur de la tension de sortie. C'est comme si vous rajoutiez une résistance en parallèle de la sortie.
|Cela a donc pour effet de donner un résistance R2 équivalente plus faible et donc de changer la tension (en appliquant la formule).

Reprenons le tableau présentant quelques exemples :

->

Schéma équivalent     |   Position du curseur     |   Tension sur la broche C
------|-----|-----
![Curseur à la moitié](/media/galleries/954/6163d271-cb79-4627-94ba-132bccf75810.png.960x960_q85.jpg) |   Curseur à **la moitié** |  $V_{signal} = (1-\frac{50}{100})\times 5 = 2.5 V$
![Curseur à 25% du départ](/media/galleries/954/4ec586e8-3092-4782-a6e5-fc6fa2867fec.png.960x960_q85.jpg) |   Curseur à **25% du départ** |  $V_{signal} = (1-\frac{25}{100})\times 5 = 3.75 V$
![Curseur à 75% du départ](/media/galleries/954/2dda4725-868a-49d1-9ba8-d19bbc758971.png.960x960_q85.jpg) |   Curseur à **75% du départ** |  $V_{signal} = (1-\frac{75}{100})\times 5 = 1.25 V$ 

Table: Illustrations de la position du curseur et sa tension résultante

<-

Vous allez donc maintenant comprendre pourquoi je vais vous donner deux montages pour une utilisation différente de la photorésistance...

## Utilisation n°1

Ce premier montage, va être le premier capteur que vous allez créer ! Facile, puisque je vous fais tout le travail. :P Le principe de ce montage réside sur l'utilisation que l'on va faire de la photo-résistance.

Comme je vous le disais à l'instant, on va l'utiliser dans un pont diviseur de tension. Exactement comme lorsque l'on utilise un potentiomètre. Sauf que dans ce cas, c'est l'intensité lumineuse qui va faire varier la tension en sortie. Voyez plutôt :

![Branchement n°1](/media/galleries/954/76d95895-ca45-4692-9d52-1833f99b71e4.png.960x960_q85.jpg)

![Montage n°1](/media/galleries/954/34d39975-225c-4b9f-b781-4d8dfc211c95.png.960x960_q85.jpg)

On calibre le pont diviseur de tension de manière à ce qu'il soit "équitable" et divise la tension d'alimentation par 2 en sa sortie. Ainsi, lorsque la luminosité fluctuera, on pourra mesurer ces variations avec la carte Arduino.
Avec ce montage, **plus l'intensité lumineuse est élevée, plus la tension en sortie du pont sera élevée** à son tour. Et inversement, plus il fais sombre, moins la tension est élevée.

## Utilisation n°2

Tandis que là, c'est l'effet inverse qui va se produire : **plus il y aura de lumière, moins il y aura de tension en sortie du pont**. Et plus il fera sombre, plus la tension sera élevée.

![Branchement n°2](/media/galleries/954/a7b14da6-045f-4b4d-857f-09e03199f45a.png.960x960_q85.jpg)

![Montage n°2](/media/galleries/954/1de0c617-19ad-4a78-a599-67c5e73e7c88.png.960x960_q85.jpg)

Rien de bien sorcier. Il suffit de bien comprendre l'intérêt du pont diviseur de tension.

# Un peu de programmation

Et si vous aviez un réveil, qui ne vous donne pas l'heure ? Fort utile, n'est-ce pas ! :D Non, sérieusement, il va vous réveiller dès que le jour se lève... ce qui fait que vous dormirez plus longtemps en hiver. C'est vos profs qui vont pas être contents ! ^^ Vous n'aurez qu'à dire que c'est de ma faute. :lol:

Bon allez, un peu de tenue quand même, je ne voudrais pas être la cause de votre échec scolaire. Cette fois, vraiment sérieusement, nous allons faire un tout petit programme qui va simplement détecter la présence ou l'absence de lumière. Lorsque la tension en sortie du pont diviseur de tension créée avec la photorésistance et la résistance fixe chute, c'est que la luminosité augmente. À vous de choisir le schéma correspondant suivant les deux présentés précédemment. Pour commencer, on va initialiser les variables et tout le tralala qui va avec.

```cpp
const char led = 2;            // Une LED pour indiquer s'il fait jour
const char capteur = 0; // broche A0 sur laquelle va être connecté le pont diviseur de tension

float tension = 0;             // variable qui va enregistrer la tension lue en sortie du capteur
float seuilObscurite = 1.5;    // valeur en V, seuil qui détermine le niveau auquel l'obscurité est présente

void setup()
{
    // définition des broches utilisées
    pinMode(led, OUTPUT);

    Serial.begin(9600); // la voie série pour monitorer
}
```
Code: Mise en place du capteur

Qu'allons-nous retrouver dans la fonction `loop()` ? Eh bien avant tout il va falloir lire la valeur présente en entrée de la broche analogique A0. Puis, on va calculer la tension correspondante à la valeur lue. Enfin, on va la comparer au seuil préalablement défini qui indique le niveau pour lequel l'absence de lumière fait loi.

```cpp
void loop()
{
    // conversion de cette valeur en tension
    tension = (analogRead(capteur) * 5.0) / 1024;

    if(tension >= seuilObscurite)
    {
        digitalWrite(led, LOW); // On allume la LED
    }
    else
    {
        digitalWrite(led, HIGH); // On éteint la LED
    }
    // envoie de la valeur de la tension lue
    // vers l'ordinateur via la liaison série
    Serial.print("Tension = ");
    Serial.print(tension);
    Serial.println(" V");

    // délai pour ne prendre des mesures que toutes les demi-secondes
    delay(500);
}
```
Code: Détecter la nuit

# Un programme plus évolué

Après tant de difficulté ( :euh: ), voici un nouveau programme qui vous sera peut-être plus intéressant à faire. En fait ça le deviendra dès que je vous aurais dit l'application qui en est prévue...

## Préparation

Cette fois, je vais vous demander d'avoir deux photorésistances identiques. Le principe est simple on va faire une comparaison entre les deux valeurs retournées par les deux capteurs (deux fois le montage précédent).

![Branchement papillon de lumière](/media/galleries/954/75982c0e-3994-4411-8f94-cb648e7224ef.png.960x960_q85.jpg)

![Montage papillon de lumière](/media/galleries/954/b3385386-8227-4d24-86a1-470596cddae2.png.960x960_q85.jpg)

Si la valeur à droite est plus forte, on allumera une LED en broche 2. Sinon, on allume en broche 3. Si la différence est faible, on allume les deux. Dans tous les cas, il n'y a pas de cas intermédiaire. C'est soit à gauche, soit à droite (selon la disposition des photorésistances).

Ce principe pourrait être appliqué à un petit robot mobile avec un comportement de papillon de nuit. Il cherche la source de lumière la plus intense à proximité.

## Le programme

Il parle de lui même, pas besoin d'en dire plus.

```cpp
// déclaration des broches utilisées
const char ledDroite = 2;
const char ledGauche = 3;
const char capteurDroit = 0;
const char capteurGauche = 1;

/* deux variables par capteur qui une stockera la valeur lue sur la broche analogique
et l'autre stockera le résultat de la conversion de la précédente valeur en tension */
float lectureDroite = 0;
float lectureGauche = 0;
float tensionDroite = 0;
float tensionGauche = 0;

void setup()
{
    pinMode(ledDroite, OUTPUT);
    pinMode(ledGauche, OUTPUT);
    Serial.begin(9600);
}

void loop()
{
    // lecture de la valeur en sortie du capteur capteurDroit puis gauche
    lectureDroite = analogRead(capteurDroit);
    lectureGauche = analogRead(capteurGauche);
    // conversion  en tension de la valeur lue
    tensionDroite = (lectureDroite * 5.0) / 1024;
    tensionGauche = (lectureGauche * 5.0) / 1024;

    // si la tension lue en sortie du capteur 1 est plus grande
    // que celle en sortie du capteur 2
    if(tensionDroite > tensionGauche)
    {
        digitalWrite(ledDroite, LOW); // allumée
        digitalWrite(ledGauche, HIGH); // éteinte
    }
    else
    {
        digitalWrite(ledDroite, HIGH); // éteinte
        digitalWrite(ledGauche, LOW); // allumée
    }
    // envoi des données lues vers l'ordinateur
    Serial.print("Tension Droite = ");
    Serial.print(tensionDroite);
    Serial.println(" V");
    Serial.print("Tension Gauche = ");
    Serial.print(tensionGauche);
    Serial.println(" V");

    delay(100); // délai pour ne prendre une mesure que toutes les 100ms
}
```
Code: Le petit robot mobile.

J'en parlais donc brièvement, ce petit programme peut servir de cerveau à un petit robot mobile qui cherchera alors la source de lumière la plus intense à ses "yeux". Vous n'aurez plus qu'à remplacer les LED par une commande de moteur (que l'on verra dans la prochaine partie sur les moteurs) et alimenter le tout sur batterie pour voir votre robot circuler entre vos pattes. ^^ Bien entendu ce programme pourrait largement être amélioré !

# Un autre petit robot mobile

On peut renverser la situation pour faire en sorte que le robot suive une ligne noire tracée au sol. C'est un robot suiveur de ligne. Le principe est de "coller" les deux "yeux" du robot au sol.

L'état initial va être d'avoir un œil de chaque côté de la ligne noire. Le robot avance tant qu'il voit du blanc (car la ligne noire est sur une surface claire, blanche en général). Dès qu'il va voir du noir (lorsque la luminosité aura diminué), il va alors arrêter de faire tourner le moteur opposé à l’œil qui a vu la ligne noire. Ainsi, le robot va modifier sa trajectoire et va continuer en suivant la ligne.

À partir de cela, je vous laisse réfléchir à tout ce que vous pouvez faire. Non pas de programme donné tout frais, je viens de définir un cahier des charges, somme toute, assez simple. Vous n'avez donc plus qu'à le suivre pour arriver à vos fins.