On va donc commencer par voir quelques capteurs dont la sortie est un état logique qui indique un état : **Ouvert** ou **Fermé**. Ces capteurs sont appelés des capteur Tout Ou Rien, capteurs **logiques** ou encore capteurs à **rupture de tension**.

# Deux états

![Schéma d'un capteur normalement ouvert](/media/galleries/954/ffe96f98-635e-4a87-8dc9-3d37afd8cae4.png.960x960_q85.jpg)

![Schéma d'un capteur normalement fermé](/media/galleries/954/d0bf249c-a105-448c-8d38-ed654a47c68a.png.960x960_q85.jpg)

Lorsque le capteur est dit ouvert (ou *open* en anglais), le courant ne passe pas entre ses bornes.

S'il s'agit de la **position de repos**, c'est à dire lorsque le capteur ne capte pas la grandeur qu'il doit capter, on dit alors que le capteur a un contact de type **Normalement Ouvert** (ou *Normally Open* en anglais). Tandis que si le capteur est dit fermé (ou *close* en anglais), le courant peut passer entre ses bornes. S'il s'agit cette fois de sa position de repos, alors on dit qu'il possède un contact **Normalement Fermé** (ou *Normally Closed*).

[[information]]
| J'ai schématisé les contacts par des interrupteurs reliés à deux bornes (les carrés à droite) du capteur.
|C'est le principe d'un capteur TOR (Tout Ou Rien), mais ce n'est pas forcément des interrupteurs qu'il y a dedans, on va le voir bientôt.

# Le capteur ILS ou Interrupteur à Lames Souples

## Le principe du TOR

Une question qui vous est peut-être passée par la tête : mais comment ce capteur peut mesurer une grandeur physique avec seulement deux états en sortie ? C'est assez facile à comprendre.

Imaginons, dans le cadre d'un de vos projets personnels, que vous ayez l'intention de faire descendre les volets électriques lorsqu'il fait nuit. Vous allez alors avoir recours à un capteur de luminosité qui vous donnera une image, par une autre grandeur physique, de l'intensité lumineuse mesurée.
Hors, vous ne voulez pas que ce capteur vous dise s'il fait un peu jour ou un peu nuit, ou entre les deux... Non, il vous faut une réponse qui soit OUI ou NON il fait nuit.
Vous aurez donc besoin d'un capteur TOR. Alors, il en existe qui sont capables de donner une réponse TOR, mais lorsque l'on utilisera un transducteur, on devra gérer ça nous même avec Arduino et un peu d'électronique.

## Champ magnétique

Ne prenez pas peur, je vais simplement vous présenter le capteur ILS qui utilise le champ magnétique pour fonctionner. ;)
En effet, ce capteur, est un capteur TOR qui détecte la présence de champ magnétique. Il est composé de deux lames métalliques souples et sensibles au champ magnétique.

Lorsqu'un champ magnétique est proche du capteur, par exemple un aimant, eh bien les deux lames se mettent en contact et laissent alors passer le courant électrique. D'une façon beaucoup plus simple, c'est relativement semblable à un interrupteur mais qui est actionné par un champ magnétique. Photo d'un interrupteur ILS et image, extraites du site [Wikipédia](http://fr.wikipedia.org/wiki/Interrupteur_%C3%A0_lames_souples):

![Interrupteur à lames souples (reed), montrant les contacts](http://zestedesavoir.com/media/galleries/954/a989cc45-13cb-470d-912c-75809d734261.jpg.960x960_q85.jpg)
Figure: Interrupteur à lames souples (reed) - (CC-BY-SA, [Timothée Cognard](http://commons.wikimedia.org/wiki/File:Interrupteur_reed.jpg))

![Action de l'aimant sur l'interrupteur](/media/galleries/954/06e0229c-efa9-4f49-9828-8052214f1d3f.gif)
Figure: Action de l'aimant sur l'interrupteur - (CC-0)

Dès que l'on approche un aimant, à partir d'un certain seuil de champ magnétique, le capteur agit. Il devient alors un contact fermé et reprend sa position de repos, contact NO, dès que l'on retire le champ magnétique. Ce type de capteur est très utilisé en sécurité dans les alarmes de maison. On les trouve essentiellement au niveau des portes et fenêtres pour détecter leur ouverture.

## Câblage

Le câblage de ce capteur peut être procédé de différentes manières. On peut en effet l'utiliser de façon à ce que le courant ne passe pas lorsque rien ne se passe, ou bien qu'il ne passe pas lorsqu'il est actionné.

![Représentation schématique](/media/galleries/954/6598f563-7f3e-4774-a234-4b6871ec6db7.png.960x960_q85.jpg)

![Représentation schématique](/media/galleries/954/3aaf4c1a-197c-4be2-b747-89403508e22a.png.960x960_q85.jpg)

1. Dans le premier cas, la sortie vaut HIGH quand l'ILS est au repos et LOW lorsqu'il est actionné par un champ magnétique.
2. Sur la deuxième image, le câblage est différent et fait en sorte que la sortie soit à LOW lorsque le contact ILS est au repos et passe à HIGH dès qu'il est actionné par un champ magnétique.

Un petit programme tout simple qui permet de voir si l'ILS est actionné ou non, selon le schéma utilisé :

```cpp
const char entree_ils = 2; // utilisation de la broche numérique numéro 2 comme entrée pour le capteur ILS

const char led_indication = 13; // utilisation de la LED de la carte pour indiquer si l'ILS est activé ou non

unsigned char configuration_ils = 0; // ou 1, dépend du câblage de l'ILS selon les schémas précédents
/*
0 pour le premier schéma (gauche)
1 pour le deuxième schéma (droite)
*/

void setup()
{
    // définition des broches utilisées
    pinMode(entree_ils, INPUT);
    pinMode(led_indication, OUTPUT);
}

void loop()
{
    if(configuration_ils) // si c'est le deuxième schéma
    {
        // la LED est éteinte lorsque l'ILS est au repos
        digitalWrite(led_indication, digitalRead(entree_ils));
    }
    else // si c'est le premier schéma
    {
        // la LED est allumée lorsque l'ILS est au repos
        digitalWrite(led_indication, !digitalRead(entree_ils));
    }
}
```
Code: Test des ILS

# Capteur logique prêt à l'emploi

Bon, là ça va être très très court, puisque vous savez déjà faire ! Les capteurs tout prêts que l'on peut acheter dans le commerce et qui fournissent un état de sortie logique (LOW ou HIGH) sont utilisables tels quels.

Il suffit de connecter la sortie du capteur sur une entrée numérique de la carte Arduino et de lire dans le programme l'état sur cette broche. Vous saurez donc en un rien de temps ce que le capteur indique. On peut citer pour exemple les capteurs de mouvements.

[[information]]
| Le programme précédent, utilisé avec l'ILS, est aussi utilisable avec un capteur logique quelconque. Après, à vous de voir ce que vous voudrez faire avec vos capteurs.