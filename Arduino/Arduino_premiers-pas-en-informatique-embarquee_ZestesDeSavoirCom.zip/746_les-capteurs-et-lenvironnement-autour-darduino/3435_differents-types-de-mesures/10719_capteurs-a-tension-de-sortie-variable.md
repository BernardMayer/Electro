Passons à un capteur un petit peu plus amusant et plus étonnant, dont les applications sont très variées !

# L'élément piézoélectrique

Sous ce nom peu commun se cache un phénomène physique très intéressant. L'élément piézoélectrique, que l'on retrouve dans divers objets du quotidien (montres, certains briquets, raquettes de tennis, ...) présente en effet toute une panoplie de caractéristiques utilisées dans des dizaines voire centaines de domaines. Nous allons voir tout ça en détail. Nous, ce qui va nous intéresser pour le moment, c'est sa propriété à capter des sons.

![Éléments piézoélectriques de montre](/media/galleries/954/fbdbb6e8-c597-4877-aeb8-ec6b029c6b46.png.960x960_q85.jpg)
Figure: Éléments piézoélectriques de montre - (CC-BY-SA, [FDominec](http://commons.wikimedia.org/wiki/File:Electronic_component_piezo.jpg))

![Allumeur de briquet](/media/galleries/954/08a12399-73a8-4753-b49e-1e708a104577.png.960x960_q85.jpg)
Figure: Allumeur de briquet - (CC-0)

## Constitution

Avant de parler de son fonctionnement, voyons un peu sa constitution.

Prenons les éléments piézoélectriques de la première image, à gauche. On observe qu'ils se trouvent sous une forme de pastille composée de plusieurs couches. Généralement c'est une pastille de céramique qui est montée sur une pastille métallique. La fabrication de ces éléments étant très complexe, nous en resterons à ce niveau d'approche.

## Propriété

J'ai trouvé amusant de voir sur internet que l'on parlait de sa propriété principale comme étant analogue à celle d'une éponge. Je ne vous épargnerais donc pas cet exemple. ^^

Dès qu'on met une éponge en contact avec de l'eau, elle l'absorbe. Tandis que lorsqu'on la presse, elle se vide de l'eau qu'elle a absorbée. Le rapport avec l'élément piézoélectrique ? Eh bien il agit un peu de la même manière.

Un élément piézoélectrique, lui, subit un phénomène semblable : dès qu'on lui admet une contrainte mécanique, il génère une tension électrique. En revanche, dès qu'on lui administre une tension électrique, il génère alors une contrainte mécanique, restituée par exemple sous forme sonore.

![Génération d'une tension électrique par un élément piézoélectrique sous l'action d'une contrainte mécanique](/media/galleries/954/dcc727b4-38ad-4661-a4bd-fc68647024df.gif)
Figure: Génération d'une tension électrique par un élément piézoélectrique sous l'action d'une contrainte mécanique - (CC-BY-SA, [Tizeff](http://commons.wikimedia.org/wiki/File:SchemaPiezo.gif))

Un exemple d'utilisation dont vous ne vous doutez certainement pas, c'est l'utilisation de cette propriété dans certaines raquettes de tennis. L'élément piézoélectrique se trouve dans le manche de la raquette. Lorsqu'une balle frappe la raquette, elle génère une contrainte mécanique sur l'élément piézoélectrique qui en retour génère une tension électrique. Cette tension est récupérée et injectée à nouveau dans l'élément piézoélectrique qui génère alors une contrainte mécanique opposée à celle générée par la balle. Vous me suivez ? L'intérêt ? Réduire les vibrations causées par le choc et ainsi améliorer la stabilité de la raquette (et de la frappe) tout en réduisant le "stress" provoqué sur le poignet du joueur. Dingue non ?

## Utilisation

L'utilisation que nous allons faire de cet élément va nous permettre de capter un choc. Cela peut être un "toc" sur une porte, une déformation de surface, voire même une onde sonore un peu puissante. Ce capteur délivre directement une tension proportionnelle à la contrainte mécanique qu'on lui applique. Il s'agit donc d'un capteur actif. Nous pouvons donc l'utiliser sans rien en le connectant directement avec Arduino.

# Montage

Vous allez procéder au montage suivant en respectant le schéma de câblage :

![Branchement du piezo](/media/galleries/954/8084fc80-45cc-4c03-9953-2dfb42e08e0c.png.960x960_q85.jpg)

![Montage du piezo](/media/galleries/954/7f359e9e-168a-4b62-a13d-035d986f6491.png.960x960_q85.jpg)

La résistance de $1M\Omega$ en parallèle de l'élément piézoélectrique permet d'éviter les courants trop forts qui peuvent être générés par l'élément piézoélectrique.

Il est accompagné par une diode un peu particulière que l'on appelle une diode zener. Cette dernière sert à éviter les surtensions. Si jamais la tension générée par le piezo dépasse son seuil (4.7V en l'occurence), elle deviendra passante et le courant ira donc vers la masse plutôt que dans le microcontrôleur (évitant ainsi de griller l'entrée analogique). Cette dernière n'est pas indispensable mais fortement conseillée.

# Programme

Le programme que nous allons associer à ce montage, et qui va être contenu dans la carte Arduino, va exploiter la tension générée par l'élément piézoélectrique, lorsqu'on lui administrera une contrainte mécanique, pour allumer ou éteindre une LED présente en broche 2 de la carte Arduino. On pourra s'en servir pour détecter un événement sonore tel que le toc sur une porte.

La condition pour que l'élément piézoélectrique capte correctement le toc d'une porte est qu'il doit être positionné sur la porte de façon à ce que sa surface soit bien plaquée contre elle. Aussi nous utiliserons la liaison série pour indiquer la tension produite par l'élément piézoélectrique.

C'est un petit plus, par forcément utile mais qui vous donnera une idée de la force qu'il faut pour générer une tension particulière. Vous en trouverez certainement une application utile. ;) Allez, un peu de programmation !

## Fonction setup()

Au début du programme nous déclarons quelques variables que nous utiliserons par la suite. Aussi nous amorçons l'utilisation de la liaison série et des broches utilisées de la carte Arduino.

```cpp
const char led = 2;         // utilisation de la LED en broche 2 de la carte
const char piezo = 0;       // l'élément piézoélectrique est connecté en broche analogique 0
const int seuil_detection = 100;
/* on peut définir le seuil de détection qui va simplement
permettre de confirmer que c'est bien un évènement sonore suffisant et non parasite */
```
Code: Initialisation des paramètres

Petite parenthèse par rapport au seuil. Ici il est configuré de façon à être comparé à la lecture directe de la valeur en broche analogique (comprise entre 0 et 1023). Mais on peut aussi le définir pour qu'il soit comparé au calcul de la tension en sortie du capteur (par exemple le mettre à 1, pour 1V).

```cpp
float lecture_capteur = 0;  // variable qui va contenir la valeur lue en broche analogique 0
float tension = 0;          // variable qui va contenir le résultat du calcul de la tension
int etat_led = LOW;         // variable utilisée pour allumer ou éteindre la LED à chaque "Toc"

void setup()
{
    pinMode(led, OUTPUT);      // déclaration de la broche 2 en sortie
    Serial.begin(9600);        // utilisation de la liaison série
}
```
Code: Initialisation du micro contrôleur pour piloter la LED

## Fonction principale

Étant donné que le code est plutôt court et simple, nous le laisserons dans la seule fonction loop() plutôt que de le découper en plusieurs petites fonctions. Cependant libre à vous de l'agencer autrement selon vos besoins.

```cpp
void loop()
{
    // lecture de la valeur en sortie du capteur
    lecture_capteur = analogRead(piezo);
    // conversion de cette valeur en tension
    tension = (lecture_capteur * 5.0) / 1024;

    if (lecture_capteur >= seuil_detection)
    {
        // on modifie l'état de la LED pour le passer à son état opposé
        etat_led = !etat_led;
        // application du nouvel état en broche 2
        digitalWrite(led, etat_led);

        // envoi vers l'ordinateur, via la liaison série,
        // des données correspondant au Toc et à la tension
        Serial.println("Toc !");
        Serial.print("Tension = ");
        Serial.print(tension);
        Serial.println(" V");
    }
}
```
Code: Envoie des données captées.

[[information]]
| Ici pas de délai à la fin de la boucle. En effet, si vous mettez un délai (qui est bloquant) vous risqueriez de rater des "toc" puisque cet événement est bref et imprévisible. Si jamais vous tapiez sur votre élément piézoélectrique au moment où le programme est dans la fonction ```delay()```, vous ne pourriez pas l'intercepter.

## Seuil de tension

Comme je le disais, il est aussi possible et non pas idiot de changer le seuil pour qu'il soit comparé en tant que tension et non valeur "abstraite" comprise entre 0 et 1023. Cela relève de la simplicité extrême, voyez plutôt :

```cpp
// utilisation de la LED en broche 2 de la carte
const char led = 2;
// l'élément piézoélectrique est connecté en broche analogique 0
const char piezo = 0;
// seuil de détection en tension et non plus en nombre entre 0 et 1023
const float seuil_detection = 1.36;

// variable qui va contenir la valeur lue en broche analogique 0
float lecture_capteur = 0;
// variable qui va contenir le résultat du calcul de la tension
float tension = 0;
// variable utilisée pour allumer ou éteindre la LED à chaque "Toc"
int etat_led = LOW;

void setup()
{
    pinMode(led, OUTPUT); // déclaration de la broche 2 en sortie
    Serial.begin(9600);   // utilisation de la liaison série
}

void loop()
{
    // lecture de la valeur en sortie du capteur
    lecture_capteur = analogRead(piezo);
    // convestion de cette valeur en tension
    tension = (lecture_capteur * 5.0) / 1024;

    if (tension >= seuil_detection)  // comparaison de deux tensions
    {
        // on modifie l'état de la LED pour le passer à son état opposé
        etat_led = !etat_led;
        // application du nouvel état en broche 2
        digitalWrite(led, etat_led);

        // envoi vers l'ordinateur, via la liaison série,
        // des données correspondant au Toc et à la tension
        Serial.println("Toc !");
        Serial.print("Tension = ");
        Serial.print(tension);
        Serial.println(" V");
    }
}
```
Code: Conversion en Volt

Je n'ai modifié que le type de la variable ```seuil_detection```.

# La réversibilité de l'élément piézoélectrique

Tout à l'heure je vous disais que l'élément piézoélectrique était capable de transformer une contrainte mécanique en une tension électrique. Je vous ai également parlé du "phénomène éponge" en vous disant que l'on pouvait aussi bien absorber que restituer non pas de l'eau comme l'éponge mais une contrainte mécanique à partir d'une tension électrique. On va donc s'amuser à créer du son avec l'élément piézoélectrique ! :P

## Faire vibrer l'élément piézoélectrique !

[[attention]]
| Attention tout de même, bien que vous l'aurez très certainement compris, il n'est plus question d'utiliser l'élément piézoélectrique en entrée comme un capteur, mais bien en sortie comme un actionneur.

Tout d'abord, il vous faudra brancher l'élément piézoélectrique. Pour cela, mettez son fil noir à la masse et son fil rouge à une broche numérique, n'importe laquelle. Pas besoin de résistance cette fois-ci. Et voilà les branchements sont faits ! Il ne reste plus qu'à générer un signal pour faire vibrer l'élément piézoélectrique. Selon la fréquence du signal, la vibration générée par l'élément piézoélectrique sera plus ou moins grave ou aiguë. Essayons simplement avec ce petit programme de rien du tout (je ne vous donne que la fonction loop(), vous savez déjà tout faire ;) ) :

```cpp
void loop()
{
    digitalWrite(piezo, HIGH);
    delay(5);
    digitalWrite(piezo, LOW);
    delay(5);
}
```
Code: Signal 100 Hz

Ce code va générer un signal carré d'une période de 10ms, soit une fréquence de 100Hz. C'est un son plutôt grave. Vous pouvez aisément changer la valeur contenue dans les délais pour écouter les différents sons que vous allez produire. Essayez de générer un signal avec la PWM et soyez attentif au résultat en changeant la valeur de la PWM avec un potentiomètre par exemple.

## Une fonction encore toute prête

Maintenant, si vous souhaitez générer ce signal et en même temps faire d'autres traitements, cela va devenir plus compliqué, car le temps sera plus difficile à maîtriser (et les délais ne sont pas toujours les bienvenus :P ).
Pour contrer cela, nous allons confier la génération du signal à une fonction d'Arduino qui s'appelle [```tone()```](http://arduino.cc/en/Reference/Tone).

Cette fonction prend en argument la broche sur laquelle vous voulez appliquer le signal ainsi que la fréquence dudit signal à réaliser. Si par exemple je veux émettre un signal de 440Hz (qui correspond au "la" des téléphones) je ferais : ```tone(piezo, 440);```. Le son va alors devenir permanent, c'est pourquoi, si vous voulez l'arrêter, il vous suffit d'appeler la fonction [```noTone()```](http://arduino.cc/en/Reference/NoTone) qui va alors arrêter la génération du son sur la broche spécifiée en argument.

[[information]]
| La fonction ```tone()``` peut prendre un troisième argument qui spécifie en millisecondes la durée pendant laquelle vous désirez jouer le son, vous évitant ainsi d'appeler ```noTone()``` ensuite.

Pour les plus motivés d'entre vous, vous pouvez essayer de jouer une petite mélodie avec l'élément piézoélectrique. :) *Ah les joies nostalgiques de l'époque des sonneries monophoniques*. :lol: