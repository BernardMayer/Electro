## Aller plus loin

Ce tutoriel vous a plus ? Vous en voulez encore ? Voici quelques autres tutoriels qui pourrait surement vous intéresser...

[[information]]
| + [Ajouter des sorties numériques à l'Arduino, le 74HC595](https://zestedesavoir.com/tutoriels/613/ajouter-des-sorties-numeriques-a-larduino-le-74hc595/) : pour augmenter le nombre de sorties numériques possibles avec le 74HC595, un convertisseur série -> parallèle ;
| + [Alimenter une Arduino sans USB](https://zestedesavoir.com/tutoriels/612/alimenter-une-arduino-sans-usb/) puis conquérir le monde ;
| + [Gestion de la mémoire sur Arduino](https://zestedesavoir.com/tutoriels/638/gestion-de-la-memoire-sur-arduino/) : maîtrisez les différentes mémoires d'Arduino avec ce mini-tutoriel ;
| + [Réaliser un télémètre à ultrasons](https://zestedesavoir.com/tutoriels/539/realiser-un-telemetre-a-ultrasons/) : mettez vos connaissances en pratique en réalisant cet outil de mesure ;
| + [La Fabrication Numérique](https://zestedesavoir.com/tutoriels/off/820/la-fabrication-numerique/) : passer d’une idée à un prototype en utilisant les nouveaux outils de la Fabrication Numérique (big-tuto format MOOC sur ZdS)

Et quelques articles sur mon blog pas encore paru sur ZdS :

[[information]]
| + [Utiliser un module bluetooth HC-05](http://eskimon.fr/2498-arduino-annexes-g-utiliser-module-bluetooth-hc-05)
| + [Utiliser Sublime Text comme IDE pour Arduino](http://eskimon.fr/2224-arduino-mini-tuto-utiliser-sublime-text-ide)
| + [Découvrir les ports et les registres sur Arduino](http://eskimon.fr/1628-arduino-mini-tuto-les-ports)

## Remerciements

Un gros merci à plusieurs membres de Zeste de Savoir pour le coup de main à l'import de ce tutoriel, sa relecture et l'aide à sa mise en page. Un travail et un soin magnifique ont été apportés pour tenter de vous fournir un tuto le plus propre possible.

Plein de mercis en particulier à :

+ [Arius](https://zestedesavoir.com/membres/voir/Arius/) ;
+ [artragis](https://zestedesavoir.com/membres/voir/artragis/) ;
+ [Flori@n.B](https://zestedesavoir.com/membres/voir/Flori@n.B/) ;
+ [ShigeruM](https://zestedesavoir.com/membres/voir/ShigeruM/) ;
+ [simbilou](https://zestedesavoir.com/membres/voir/simbilou/)

Et pour leur travail sur la publication et l'export PDF, merci à :

+ [gustavi](https://zestedesavoir.com/membres/voir/gustavi/) ;
+ [pierre_24](https://zestedesavoir.com/membres/voir/pierre_24/) ;
+ [SpaceFox](https://zestedesavoir.com/membres/voir/SpaceFox/) ;
+ Et tout ceux ayant apporté leur pierre à l’édifice de près ou de loin ! Ça a vraiment été un travail de longue haleine. :D