[[a]]
| Toute la documentation officielle du shield Ethernet peut être trouvée ici : [http://arduino.cc/en/Main/ArduinoEthernetShield](http://arduino.cc/en/Main/ArduinoEthernetShield)

Maintenant que nous y voyons plus clair dans ce qu'est un réseau, voyons un peu les caractéristiques du matériel que nous allons utiliser pour relier notre carte Arduino.

Il faut tout d'abord savoir que l'Arduino seule n'est PAS DU TOUT faite pour utiliser une liaison réseau comme l'Ethernet. Nous venons de le découvrir, il y a de nombreuses couches à respecter, protocoles à utiliser et paquets à réaliser. Le pauvre petit microcontrôleur de l'Arduino en serait bien incapable dans de bons délais, ce qui rendrait l'utilisation de la carte impossible.

C'est pourquoi l'Arduino va être épaulée par un shield qui se nomme très justement "shield Ethernet". Il est relativement simple à trouver et coûte moins d'une trentaine d'euros, comme sur le site de Farnell. Ce shield permettra alors de décharger l'Arduino de tout le traitement des couches réseau pour ne donner que les informations utiles à cette dernière.
Commençons l'autopsie...

# Le cœur du traitement : Le Wiznet 510

Tout le traitement ou presque va être géré par la puce que vous pouvez voir sur le dessus de la carte. Ce circuit intégré possède la référence Wiznet 5100. C'est un composant qui est dédié au traitement par Ethernet. Une fois configuré, il se chargera de faire toute la communication. C'est-à-dire que vous n'aurez qu'à envoyer vos données au shield (via SPI, nous y reviendrons) et le shield se chargera de les encapsuler dans des trames et de les transmettre à l'adresse que vous souhaitez. De la même façon, si des données sont reçues il se chargera de les récupérer et les transmettre à l'Arduino pour que votre programme puisse les exploiter.

Ce composant possède une mémoire *buffer* de 16 KB. C'est-à-dire que dans le cas d'un échange de données (téléchargement d'une page web par exemple) les données seront stockées ici le temps que l'Arduino les lise et les traite.

Le shield possède aussi plusieurs leds reliées au Wiznet dont voici le nom et le rôle :

+ PWR: indique que la carte est alimentée ;
+ LINK: indique que la carte est connectée à un réseau. Cette led clignote lors de l’émission/réception de données ;
+ FULLD: cette led est allumée dans le cas d'une connexion full-duplex (émission et réception simultanées) ;
+ 100M: allumée si le réseau peut aller à 100 Mb/s (vitesse max. du composant), éteinte dans le cas d'un réseau à 10 Mb/s ;
+ RX: clignote lors de la réception de données ;
+ TX: clignote lors de l'envoi de données ;
+ COLL: clignote si des collisions de données sont détectées.

# De la communication à droite à gauche...

Le shield Ethernet, on s'en doute, communique principalement par ... Ethernet ! Mais ce n'est pas tout. Il lui faut aussi échanger avec l'Arduino pour pouvoir recevoir une configuration, savoir quelle page aller chercher ou encore transmettre des informations reçues. Pour toutes ces opérations, la transmission se fera par une liaison que nous ne connaissons pas encore : **SPI** (*Serial Protocol Interface*).

Cette transmission, nous allons découvrir comment l'utiliser via la librairie Ethernet dans cette partie. Nous n'allons cependant pas rentrer dans les détails puisque ce n'est pas le but de cette partie.

## Carte SD

Sur le shield vous avez sûrement vu l'emplacement pour la carte SD. Cette dernière servira à stocker/charger des pages ou des données quelconques. Cette carte se sert elle aussi de la connexion SPI que je viens d’évoquer. On devra donc utiliser une broche comme "Slave Select" (sélection de cible) pour déclarer au système à quel composant on s'adresse, soit l’Ethernet, soit la SD.

![Le shield Ethernet Arduino](http://zestedesavoir.com/media/galleries/954/db1830a2-7a63-43f5-9861-3e6f83ec5d9d.jpg.960x960_q85.jpg)
Figure: Le shield Ethernet Arduino - (CC-BY, [arduino.cc](http://arduino.cc/en/uploads/Main/ArduinoEthernetShield_R3_Front_450px.jpg))