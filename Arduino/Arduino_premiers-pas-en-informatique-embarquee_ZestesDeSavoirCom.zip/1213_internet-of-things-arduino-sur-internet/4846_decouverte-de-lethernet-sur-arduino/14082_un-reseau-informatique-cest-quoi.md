Internet, qu'est-ce que c'est au juste ? On en entend parler tout le temps et vous vous en servez probablement tous les jours, mais seriez-vous capable de le définir pour autant ? Essayons d'y voir plus clair...

Internet est un réseau de réseaux. C'est un support de transfert d'informations dans un sens le plus large possible. Afin d'organiser ces échanges, on utilise des **protocoles** spécifiques pour chaque type de transfert. Ces protocoles sont ainsi adaptés à une tache en particulier. Le plus connu est certainement *http*, soit *HyperText Transfert Protocol* qui sert à naviguer sur des pages en se promenant via des liens. Ceux d’entre vous qui font du développement web connaissent aussi sûrement le *ftp*, *File Transfert Protocol* (Protocole d’échanges de fichiers) qui permet de faire du transfert de fichiers uniquement.

Si l'on descend dans des considérations plus techniques, on peut s’intéresser au support de l'information, comment cette dernière voyage-t-elle. On découvrira alors les différents vecteurs de communication comme le WiFi ou l'Ethernet.

Chaque partie du réseau, que ce soit le medium de transfert de l'information ou le protocole final utilisé, peut être retrouvée dans ce que l'on appelle le modèle OSI (Open Systems Interconnection). Ce modèle possède 7 couches servant à définir le rôle de chacun des composants importants du réseau :

![Les couches OSI](http://zestedesavoir.com/media/galleries/954/7efc3245-7703-4888-adc8-87acf97661b1.png.960x960_q85.png)
Figure: Les couches OSI - (source [Wikipédia](http://fr.wikipedia.org/wiki/Mod%C3%A8le_OSI))

L'Ethernet, que nous allons voir dans ce cours agit sur les couches 1 et 2, physique et liaison de données puisqu'il transforme et transporte les données dans un "format" électronique qui lui est spécifique.