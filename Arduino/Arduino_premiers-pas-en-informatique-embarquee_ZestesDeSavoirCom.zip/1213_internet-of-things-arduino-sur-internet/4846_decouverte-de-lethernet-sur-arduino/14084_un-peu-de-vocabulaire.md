# Architecture Serveur/Client

Dans le monde magique d'internet, des ordinateurs se parlent entre eux. Cependant, on retrouve deux rôles particuliers : les clients et les serveurs. Bien que souvent exclusif, il peut cependant arriver qu'une machine serve aux deux. Mais voyons plus en détail ces rôles.

## Le Serveur

Le travail du serveur est de ... servir une information. Cette dernière peut être une page web ou un service quelconque. Par exemple, quand vous allez sur un site web, c'est un "serveur HTTP" (serveur web) qui sera chargé de vous répondre en vous renvoyant la bonne page. Autre exemple, dans votre établissement (scolaire ou professionnel), si une imprimante est branchée sur le réseau alors c'est un serveur d'impression qui sera utilisé pour convertir votre demande "imprime-moi la page 42 du pdf Arduino d'Eskimon" en une tâche dans le monde réel.

Vous vous en doutez sûrement, des serveurs il en existe pour plein de choses différentes ! Web, e-mail, impression... Quand nous utiliserons notre Arduino pour *offrir/servir* une donnée, on dira alors qu'elle est en fonctionnement de "serveur". On aura donc un "Serveur Arduino" en quelque sorte (qui pourra être un simple serveur web par exemple).

## Le Client

Si vous avez compris les paragraphes précédents, alors vous avez sûrement deviné le rôle du client. Comme dans la vie réelle, le client est celui qui va demander une information ou un service. Dans la vie de tous les jours, vous utilisez sûrement au quotidien un navigateur internet. Eh bien ce dernier est un client pour un serveur web. Il fera alors des demandes au serveur, ce dernier les renverra et le client les interprétera.

Il existe autant de types de clients qu'il y a de types de serveurs. À chaque service, sa tâche !

# Des adresses pour tout !

Dans ce tutoriel, nous allons rencontrer deux types d'**adresses**, l'IP et la MAC. Voyons de quoi il s'agit.

## IP

L'adresse IP, Internet Protocol, représente l'adresse à l’échelle du réseau, qu'il soit global ou local. Dans le monde physique, vous possédez une adresse pour recevoir du courrier. Dans le monde de l'internet, c'est pareil. Quand des paquets de données sont échangés entre serveur et client, ces derniers possèdent une adresse pour savoir où les délivrer.

À l’échelle globale, votre connexion possède une adresse IP dite *publique*. C'est cette dernière qui sert à échanger avec le monde extérieur. En revanche, quand vous êtes connecté à votre box internet ou un routeur quelconque, vous possédez alors une adresse IP *locale*. Cette dernière est très souvent de la forme 192.168.0.xxx. C'est votre box/routeur qui servira d'aiguillage entre les paquets qui sont destinés à votre ordinateur ou votre Arduino (ou n'importe quel autre équipement sur le même réseau).

## MAC

L'adresse MAC, Media Access Control, représente une adresse physique, matérielle, de votre matériel. Elle est propre à votre ordinateur/carte réseau. Elle est normalement unique à n'importe quel matériel réseau. Mais elle est aussi falsifiable, donc l’unicité ne peut être garantie globalement.

# D'autres notions utiles

## Ports

Comme on le voyait un peu plus tôt, différentes applications serveur peuvent fonctionner sur une même machine. MAIS, ils sont tous cachés derrière la même adresse IP. Comment donc séparer les paquets qui vont au serveur web de ceux qui vont au serveur e-mail par exemple ? Une solution pourrait être d'ajouter une information dans le paquet pour préciser l'application de destination. Et bien c'est presque ça. En effet, chaque paquet se verra attribuer un *port* de destination qui est celui sur lequel l'application fonctionne.

Pour imager, essayez d'imaginer la liaison Internet comme une autoroute avec de très nombreuses voies. Les paquets sont les voitures circulant sur cette autoroute. Chaque port sera alors une voie dédiée. Ainsi, le serveur web serait la voie de droite, le serveur mail celle du milieu et le serveur Arduino la voie de gauche. Et comme ça tout le monde arrive à bon port, le serveur au bout de la voie a juste à s'occuper de ses paquets et non pas ceux des autres applications !