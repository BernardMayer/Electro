L'utilisation de l'Arduino en mode serveur est sûrement plus courante que celle en client. Cette partie devrait donc particulièrement vous intéresser.
Deux grands rôles peuvent être accomplis :

+ L'envoi de données *à la demande* (l'utilisateur vient demander les données quand il les veut) ;
+ La réception d'ordre pour effectuer des actions.

Ces deux rôles ne sont pas exclusifs, ils peuvent tout à fait cohabiter. Mais dans un premier temps, reparlons un peu de ce qu'est un serveur.

Nous l'avons vu dans le premier chapitre, un serveur est chargé de réceptionner du trafic, l’interpréter puis agir en conséquence. Pour cela, il possède un **port** particulier qui lui est dédié. Chaque octet arrivant sur ce port lui est donc destiné. On dit que le serveur **écoute** sur un **port**.

C'est donc à partir de cela que nous allons pouvoir mettre en place notre serveur !

Comme pour le client, il va falloir commencer par les options du shield (MAC, IP...) afin que ce dernier puisse se connecter à votre box/routeur.
On retrouve donc un setup similaire au chapitre précédent :

```cpp
// Ces deux bibliothèques sont indispensables pour le shield
#include <SPI.h>
#include <Ethernet.h>

// L'adresse MAC du shield
byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0xA5, 0x7E };
// L'adresse IP que prendra le shield
IPAddress ip(192,168,0,143);

void setup()
{
  // On démarre la voie série pour déboguer
  Serial.begin(9600);

  char erreur = 0;
  // On démarre le shield Ethernet SANS adresse IP (donc donnée via DHCP)
  erreur = Ethernet.begin(mac);

  if (erreur == 0) {
    Serial.println("Parametrage avec ip fixe...");
    // si une erreur a eu lieu cela signifie que l'attribution DHCP
    // ne fonctionne pas. On initialise donc en forçant une IP
    Ethernet.begin(mac, ip);
  }
  Serial.println("Init...");
  // Donne une seconde au shield pour s'initialiser
  delay(1000);
  Serial.print("Pret !");
}
```

Bien. Au chapitre précédent cependant nous avions des variables concernant le *client*. Ici, de manière similaire nous aurons donc des variables concernant le **serveur**.
La première et unique nouvelle chose sera donc une variable de type `EthernetServer` qui prendra un paramètre : le port d'écoute. J'ai choisi 4200 de manière un peu aléatoire, car je sais qu'il n'est pas utilisé sur mon réseau. Une liste des ports les plus souvent utilisés peut être [trouvée sur Wikipédia](http://fr.wikipedia.org/wiki/Liste_de_ports_logiciels).

```cpp
// Initialise notre serveur
// Ce dernier écoutera sur le port 4200
EthernetServer serveur(4200);
```

Puis, à la fin de notre setup, il faudra démarrer le serveur avec la commande suivante :

```cpp
serveur.begin();
```

En résumé, on aura donc le code suivant pour l'initialisation :

```cpp
// Ces deux bibliothèques sont indispensables pour le shield
#include <SPI.h>
#include <Ethernet.h>

// L'adresse MAC du shield
byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0xA5, 0x7E };
// L'adresse IP que prendra le shield
IPAddress ip(192,168,0,143);

// Initialise notre serveur
// Ce dernier écoutera sur le port 4200
EthernetServer serveur(4200);

void setup()
{
  // On démarre la voie série pour déboguer
  Serial.begin(9600);

  char erreur = 0;
  // On démarre le shield Ethernet SANS adresse IP (donc donnée via DHCP)
  erreur = Ethernet.begin(mac);

  if (erreur == 0) {
    Serial.println("Parametrage avec ip fixe...");
    // si une erreur a eu lieu cela signifie que l'attribution DHCP
    // ne fonctionne pas. On initialise donc en forçant une IP
    Ethernet.begin(mac, ip);
  }
  Serial.println("Init...");
  // Donne une seconde au shield pour s'initialiser
  delay(1000);
  // On lance le serveur
  serveur.begin();
  Serial.print("Pret !");
}
```

Et voilà, votre serveur Arduino est en train de surveiller ce qui se passe sur le réseau !