Nous savons maintenant envoyer des données vers notre shield, mais il pourrait être sympa de pouvoir en interpréter et ainsi interagir avec le shield. Voyons voir comment, mais avant tout un petit avertissement :

[[i]]
| On ne va pas se mentir, faire cela demande un peu de bidouille car il faut être à l'aise avec la manipulation de chaîne de caractères. Ce type de code est difficilement généralisable ce qui signifie qu'il faut bien souvent développer pour son cas précis. Ce qui sera exposé ici sera donc un "exemple d'application pour faire comprendre".

Notre objectif va être simple, on doit être capable de recevoir et interpréter les choses suivantes :

+ Un premier paramètre sera "b" signifiant "broches". Il indiquera l’état des broches 3, 4, 5. Si une broche est dans la liste, alors elle est à 1, sinon 0
+ Un second paramètre sera "p" et indiquera le rapport cyclique (entier entre 0 et 255) d'une pwm sur la broche 6. 
+ Enfin, dans tous les cas on renvoie un json possédant les informations suivantes :
    + L'uptime de l'Arduino (millis)
    + L’état des broches 3, 4 et 5
    + La valeur de la PWM de la broche 6
    + La lecture analogique de la broche A0

Démarrons par la fin et avec les choses simples, une fonction pour renvoyer le json.

En cadeau voici le schéma !

![Ethernet, montage](http://zestedesavoir.com/media/galleries/954/51c8dc03-05fe-4bbb-92c7-553c72622917.png.960x960_q85.png)

![Ethernet, schéma](http://zestedesavoir.com/media/galleries/954/835c89ea-ec41-40f0-b272-eab0363d7900.png.960x960_q85.png)

# Répondre à la requête

On l'a vu plus tôt, répondre à une requête n'est pas très compliqué et construire un json non plus. Je vais donc simplement vous poster le code de la fonction `repondre()` avec des commentaires en espérant que cela suffise. Rien de nouveau par rapport aux choses vues ci-dessus.

```cpp
void repondre(EthernetClient client) {
  // La fonction prend un client en argument

  Serial.println("\nRepondre"); // debug
  // On fait notre en-tête
  // Tout d'abord le code de réponse 200 = réussite
  client.println("HTTP/1.1 200 OK");
  // Puis le type mime du contenu renvoyé, du json
  client.println("Content-Type: application/json");
  // Autorise le cross origin
  client.println("Access-Control-Allow-Origin: *");
  // Et c'est tout !
  // On envoi une ligne vide pour signaler la fin du header
  client.println();

  // Puis on commence notre JSON par une accolade ouvrante
  client.println("{");
  // On envoie la première clé : "uptime"
  client.print("\t\"uptime\": ");
  // Puis la valeur de l'uptime
  client.print(millis());
  //Une petite virgule pour séparer les deux clés
  client.println(",");
  // Et on envoie la seconde nommée "analog 0"
  client.print("\t\"A0\": ");
  client.print(analogRead(A0));
  client.println(",");
  // Puis la valeur de la PWM sur la broche 6
  client.print("\t\"pwm\": ");
  client.print(pwm, DEC);
  client.println(",");
  // Dernières valeurs, les broches (elles-mêmes dans un tableau)
  client.println("\t\"broches\": {");
  // La broche 3
  client.print("\t\t\"3\": ");
  client.print(digitalRead(3));
  client.println(",");
  // La broche 4
  client.print("\t\t\"4\": ");
  client.print(digitalRead(4));
  client.println(",");
  // La broche 5
  client.print("\t\t\"5\": ");
  client.println(digitalRead(5));
  client.println("\t}");
  // Et enfin on termine notre JSON par une accolade fermante
  client.println("}");
}
```

# Lire la requête

Lorsque l'on reçoit une requête, il faut la traiter. Avez-vous essayé de faire un `Serial.print()` des caractères reçus lors des demandes ? Vous pouvez remarquer que la première ligne est toujours "GET /... HTTP/1.1". Avec `GET` qui est "l'action", `/...` l'url demandée et `HTTP/1.1` le protocole utilisé, on a tout ce qu'il faut pour (ré)agir ! Par exemple, si on reçoit la requête `GET /?b=3,4&p=42 HTTP/1.1`, on aura "juste" à traiter la demande pour extraire le numéro des broches à allumer (3 et 4 mais pas 5) et la valeur du rapport cyclique à appliquer pour la PWM (42).
Voyons comment faire.

## Préparation

Tout d'abord, on va réserver un tableau de caractères pour le traitement des données. Dans notre cas, 100 caractères devraient largement faire l'affaire. On va aussi déclarer quelques variables pour stocker l'état des broches à changer.

```cpp
char *url = (char *)malloc(100); // L'url reçue à stocker
//char url[100]; // équivalent à la ligne du dessus mais qui ne semble pas vouloir fonctionner
char index = 0; // index indiquant où l'on est rendu dans la chaine
boolean etats[3] = {LOW, LOW, LOW}; // L'état des 3 sorties
unsigned char pwm = 0; // La valeur de la pwm
```

Une fois cela fait, nous allons devoir passer à la récupération de la première chaîne envoyée par le client.

## Récuperer l'URL

C'est parti, faisons notre loop ! On va commencer comme avant, en allant lire la présence d'un client.

```cpp
void loop() {
  // Regarde si un client est connecté et attend une réponse
  EthernetClient client = serveur.available();
  if (client) {
    url = ""; // on remet à zéro notre chaîne tampon
    index = 0;
    // traitement
  }
}
```

Si un client est présent, on va regarder s'il a des données à nous donner tant qu'il est connecté (car s'il ne se déconnecte pas, pas la peine de perdre du temps avec lui !).

```cpp
void loop() {
  // Regarde si un client est connecté et attend une réponse
  EthernetClient client = serveur.available();
  if (client) { // Un client est là ?
    url = ""; // on remet à zéro notre chaîne tampon
    index = 0;
    while(client.connected()) { // Tant que le client est connecté
      if(client.available()) { // A-t-il des choses à dire ?
        // traitement des infos du client
      }
    }
  }
}
```


Maintenant que l'on sait que le client est là et nous parle, on va l’écouter en lisant les caractères reçus.

```cpp
void loop() {
  // Regarde si un client est connecté et attend une réponse
  EthernetClient client = serveur.available();
  if (client) { // Un client est là ?
    url = ""; // on remet à zéro notre chaîne tampon
    index = 0;
    while(client.connected()) { // Tant que le client est connecté
      if(client.available()) { // A-t-il des choses à dire ?
        // traitement des infos du client
        char carlu = client.read(); //on lit ce qu'il raconte
        if(carlu != '\n') { // On est en fin de chaîne ?
          // non ! alors on stocke le caractère
          url[index] = carlu;
          index++;
        } else {
          // on a fini de lire ce qui nous intéresse
          // on marque la fin de l'url (caractère de fin de chaîne)
          url[index] = '';
          // + TRAITEMENT
          // on quitte le while
          break;
        }
      }
    }
    // Donne le temps au client de prendre les données
    delay(10);
    // Ferme la connexion avec le client
    client.stop();
  }
}
```

## Interpréter l'URL

Maintenant que nous avons la chaîne du client, il faut l'interpréter pour lire les valeurs des paramètres.
Tout d'abord, on commencera par remettre les anciens paramètres à zéro. Ensuite, on va parcourir les caractères à la recherche de marqueur connu : b et p. Ce n'est pas ce qu'il y a de plus simple, mais vous allez voir avec un peu de méthode on y arrive !
Rappel : Nous cherchons à interpréter `GET /?b=3,4&p=42 HTTP/1.1`

PS : le code est "volontairement" un peu plus lourd, car je fais des tests évitant les problèmes si quelqu'un écrit une URL un peu farfelue (sans le "b" ou le "p").

```cpp
boolean interpreter() {
  // On commence par mettre à zéro tous les états
  etats[0] = LOW;
  etats[1] = LOW;
  etats[2] = LOW;
  pwm = 0;

  // Puis maintenant on va chercher les caractères/marqueurs un par un.
  index = 0; // Index pour se promener dans la chaîne (commence à 4 pour enlever "GET "
  while(url[index-1] != 'b' && url[index] != '=') { // On commence par chercher le "b="
    index++; // Passe au caractère suivant
    if(index == 100) {
      // On est rendu trop loin !
      Serial.println("Oups, probleme dans la recherche de 'b='");
      return false;
    }
  }
  // Puis on lit jusqu’à trouver le '&' séparant les broches de pwm
  while(url[index] != '&') { // On cherche le '&'
    if(url[index] >= '3' && url[index] <= '5') {
      // On a trouvé un chiffre identifiant une broche
      char broche = url[index]-'0'; // On ramène ça au format décimal
      etats[broche-3] = HIGH; // Puis on met la broche dans un futur état haut
    }
    index++; // Passe au caractère suivant
    if(index == 100) {
      // On est rendu trop loin !
      Serial.println("Oups, probleme dans la lecture des broches");
      return false;
    }
    // NOTE : Les virgules séparatrices sont ignorées
  }
  // On a les broches, reste plus que la valeur de la PWM
  // On cherche le "p="
  while(url[index-1] != 'p' && url[index] != '=' && index<100) {
    index++; // Passe au caractère suivant
    if(index == 100) {
      // On est rendu trop loin !
      Serial.println("Oups, probleme dans la recherche de 'p='");
      return false;
    }
  }
  // Maintenant, on va fouiller jusqu'a trouver un espace
  while(url[index] != ' ') { // On cherche le ' ' final
    if(url[index] >= '0' && url[index] <= '9') {
      // On a trouve un chiffre !
      char val = url[index]-'0'; // On ramene ca au format decimal
      pwm = (pwm*10) + val; // On stocke dans la pwm
    }
    index++; // Passe au caractère suivant
    if(index == 100) {
      // On est rendu trop loin !
      Serial.println("Oups, probleme dans la lecture de la pwm");
      return false;
    }
    // NOTE : Les virgules séparatrices sont ignorées
  }
  // Rendu ici, on a trouvé toutes les informations utiles !
  return true;
}
```

## Agir sur les broches

Lorsque toutes les valeurs sont reçues et interprétées, il ne reste plus qu'à les appliquer à nos broches. Vu ce que l'on vient de faire, c'est de loin le plus facile !

```cpp
void action() {
  // On met à jour nos broches
  digitalWrite(3, etats[0]);
  digitalWrite(4, etats[1]);
  digitalWrite(5, etats[2]);
  // Et la PWM
  analogWrite(6, pwm);
}
```

## On assemble !!

Il ne reste plus qu'à enchaîner toutes nos fonctions pour avoir un code complet !!

```cpp
void loop() {
  // Regarde si un client est connecté et attend une réponse
  EthernetClient client = serveur.available();
  if (client) { // Un client est là ?
    Serial.println("Ping !");
    url = ""; // on remet à zéro notre chaîne tampon
    index = 0;
    while(client.connected()) { // Tant que le client est connecté
      if(client.available()) { // A-t-il des choses à dire ?
        // traitement des infos du client
        char carlu = client.read(); //on lit ce qu'il raconte
        if(carlu != '\n') { // On est en fin de chaîne ?
          // non ! alors on stocke le caractère
          Serial.print(carlu);
          url[index] = carlu;
          index++;
        } else {
          // on a fini de lire ce qui nous intéresse
          // on marque la fin de l'url (caractère de fin de chaîne)
          url[index] = '\0';
          boolean ok = interpreter(); // essaie d'interpréter la chaîne
          if(ok) {
            // tout s'est bien passé = on met à jour les broches
            action();
          }
          // et dans tout les cas on répond au client
          repondre(client);
          // on quitte le while
          break;
        }
      }
    }
    // Donne le temps au client de prendre les données
    delay(10);
    // Ferme la connexion avec le client
    client.stop();
    Serial.println("Pong !");
  }
}
```

# Code complet

[[secret]]
| ```cpp
| // Ces deux bibliothèques sont indispensables pour le shield
| #include <SPI.h>
| #include <Ethernet.h>
| 
| // L'adresse MAC du shield
| byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0xA5, 0x7E };
| // L'adresse IP que prendra le shield
| IPAddress ip(192,168,0,143);
| 
| // Initialise notre serveur
| // Ce dernier écoutera sur le port 4200
| EthernetServer serveur(4200);
| 
| char *url = (char *)malloc(100); // L'url recu à stocker
| //char url[100];
| char index = 0; // index indiquant où l'on est rendu dans la chaîne
| boolean etats[3] = {LOW, LOW, LOW}; // L'état des 3 sorties
| unsigned char pwm = 0; // La valeur de la pwm
| 
| void setup()
| {
|   // On démarre la voie série pour déboguer
|   Serial.begin(9600);
| 
|   // Configure et initialise les broches
|   pinMode(3, OUTPUT); digitalWrite(3, LOW);
|   pinMode(4, OUTPUT); digitalWrite(4, LOW);
|   pinMode(5, OUTPUT); digitalWrite(5, LOW);
|   pinMode(6, OUTPUT); analogWrite(6, 0);
| 
|   char erreur = 0;
|   // On démarre le shield Ethernet SANS adresse ip (donc donnée via DHCP)
|   erreur = Ethernet.begin(mac);
| 
|   if (erreur == 0) {
|     Serial.println("Parametrage avec ip fixe...");
|     // si une erreur a eu lieu cela signifie que l'attribution DHCP
|     // ne fonctionne pas. On initialise donc en forçant une IP
|     Ethernet.begin(mac, ip);
|   }
|   Serial.println("Init...");
|   // Donne une seconde au shield pour s'initialiser
|   delay(1000);
|   // On lance le serveur
|   serveur.begin();
|   Serial.println("Pret !");
| }
| 
| void loop() {
|   // Regarde si un client est connecté et attend une réponse
|   EthernetClient client = serveur.available();
|   if (client) { // Un client est là ?
|     Serial.println("Ping !");
|     url = ""; // on remet à zéro notre chaîne tampon
|     index = 0;
|     while(client.connected()) { // Tant que le client est connecté
|       if(client.available()) { // A-t-il des choses à dire ?
|         // traitement des infos du client
|         char carlu = client.read(); //on lit ce qu'il raconte
|         if(carlu != '\n') { // On est en fin de chaîne ?
|           // non ! alors on stocke le caractère
|           Serial.print(carlu);
|           url[index] = carlu;
|           index++;
|         } else {
|           // on a fini de lire ce qui nous intéresse
|           // on marque la fin de l'url (caractère de fin de chaîne)
|           url[index] = '\0';
|           boolean ok = interpreter(); // essaie d'interpréter la chaîne
|           if(ok) {
|             // tout s'est bien passé = on met à jour les broches
|             action();
|           }
|           // et dans tout les cas on répond au client
|           repondre(client);
|           // on quitte le while
|           break;
|         }
|       }
|     }
|     // Donne le temps au client de prendre les données
|     delay(10);
|     // Ferme la connexion avec le client
|     client.stop();
|     Serial.println("Pong !");
|   }
| }
| 
| void rafraichir() {
|   // Rafraichit l'etat des broches / PWM
|   digitalWrite(3, etats[0]);
|   digitalWrite(4, etats[1]);
|   digitalWrite(5, etats[2]);
|   analogWrite(6, pwm);
| }
| 
| void repondre(EthernetClient client) {
|   // La fonction prend un client en argument
| 
|   Serial.println("\nRepondre"); // debug
|   // On fait notre en-tête
|   // Tout d'abord le code de réponse 200 = réussite
|   client.println("HTTP/1.1 200 OK");
|   // Puis le type mime du contenu renvoyé, du json
|   client.println("Content-Type: application/json");
|   // Autorise le cross origin
|   client.println("Access-Control-Allow-Origin: *");
|   // Et c'est tout !
|   // On envoi une ligne vide pour signaler la fin du header
|   client.println();
| 
|   // Puis on commence notre JSON par une accolade ouvrante
|   client.println("{");
|   // On envoie la première clé : "uptime"
|   client.print("\t\"uptime\": ");
|   // Puis la valeur de l'uptime
|   client.print(millis());
|   //Une petite virgule pour séparer les deux clés
|   client.println(",");
|   // Et on envoie la seconde nommée "analog 0"
|   client.print("\t\"A0\": ");
|   client.print(analogRead(A0));
|   client.println(",");
|   // Puis la valeur de la PWM sur la broche 6
|   client.print("\t\"pwm\": ");
|   client.print(pwm, DEC);
|   client.println(",");
|   // Dernières valeurs, les broches (elles mêmes dans un tableau)
|   client.println("\t\"broches\": {");
|   // La broche 3
|   client.print("\t\t\"3\": ");
|   client.print(digitalRead(3));
|   client.println(",");
|   // La broche 4
|   client.print("\t\t\"4\": ");
|   client.print(digitalRead(4));
|   client.println(",");
|   // La broche 5
|   client.print("\t\t\"5\": ");
|   client.println(digitalRead(5));
|   client.println("\t}");
|   // Et enfin on termine notre JSON par une accolade fermante
|   client.println("}");
| }
| 
| boolean interpreter() {
|   // On commence par mettre à zéro tous les états
|   etats[0] = LOW;
|   etats[1] = LOW;
|   etats[2] = LOW;
|   pwm = 0;
| 
|   // Puis maintenant on va chercher les caractères/marqueurs un par un.
|   index = 0; // Index pour se promener dans la chaîne (commence à 4 pour enlever "GET "
|   while(url[index-1] != 'b' && url[index] != '=') { // On commence par chercher le "b="
|     index++; // Passe au caractère suivant
|     if(index == 100) {
|       // On est rendu trop loin !
|       Serial.println("Oups, probleme dans la recherche de 'b='");
|       return false;
|     }
|   }
|   // Puis on lit jusqu’à trouver le '&' séparant les broches de pwm
|   while(url[index] != '&') { // On cherche le '&'
|     if(url[index] >= '3' && url[index] <= '5') {
|       // On a trouvé un chiffre identifiant une broche
|       char broche = url[index]-'0'; // On ramène ça au format décimal
|       etats[broche-3] = HIGH; // Puis on met la broche dans un futur état haut
|     }
|     index++; // Passe au caractère suivant
|     if(index == 100) {
|       // On est rendu trop loin !
|       Serial.println("Oups, probleme dans la lecture des broches");
|       return false;
|     }
|     // NOTE : Les virgules séparatrices sont ignorées
|   }
|   // On a les broches, reste plus que la valeur de la PWM
|   // On cherche le "p="
|   while(url[index-1] != 'p' && url[index] != '=' && index<100) {
|     index++; // Passe au caractère suivant
|     if(index == 100) {
|       // On est rendu trop loin !
|       Serial.println("Oups, probleme dans la recherche de 'p='");
|       return false;
|     }
|   }
|   // Maintenant, on va fouiller jusqu'a trouver un espace
|   while(url[index] != ' ') { // On cherche le ' ' final
|     if(url[index] >= '0' && url[index] <= '9') {
|       // On a trouve un chiffre !
|       char val = url[index]-'0'; // On ramene ca au format decimal
|       pwm = (pwm*10) + val; // On stocke dans la pwm
|     }
|     index++; // Passe au caractère suivant
|     if(index == 100) {
|       // On est rendu trop loin !
|       Serial.println("Oups, probleme dans la lecture de la pwm");
|       return false;
|     }
|     // NOTE : Les virgules séparatrices sont ignorées
|   }
|   // Rendu ici, on a trouvé toutes les informations utiles !
|   return true;
| }
| 
| void action() {
|   // On met à jour nos broches
|   digitalWrite(3, etats[0]);
|   digitalWrite(4, etats[1]);
|   digitalWrite(5, etats[2]);
|   // Et la PWM
|   analogWrite(6, pwm);
| }
| ```