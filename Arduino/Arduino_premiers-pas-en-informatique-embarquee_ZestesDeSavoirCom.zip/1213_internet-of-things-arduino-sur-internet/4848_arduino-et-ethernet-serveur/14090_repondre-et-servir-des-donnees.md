Maintenant que le serveur est prêt et attend qu'on lui parle, on va pouvoir coder la partie "communication avec le demandeur".
La première étape va être de vérifier si un client attend une réponse de la part de notre serveur. On va donc retrouver notre objet EthernetClient vu au chapitre précédent et une fonction du serveur que l'on aurait presque pu deviner : `available()`

```cpp
// Regarde si un client est connecté et attend une réponse
EthernetClient client = serveur.available();
```
Ensuite les choix sont simples. Soit un client (donc une application externe) est connecté avec l'Arduino et veut interagir, soit il n'y a personne et donc on ne fait... rien (ou autre chose). Pour cela, on va simplement regarder si client vaut autre chose que zéro. Si c'est le cas, alors on traite les données.

```cpp
if (client) {
  // Quelqu'un est connecté !
}
```

Maintenant, on va faire au plus simple. On va considérer que l'on renvoie toujours les mêmes informations : la valeur de l'entrée analogique 0 et la variable millis(), quelle que soit la requête du client. On va alors se retrouver dans le cas similaire au chapitre précédent ou il faudra simplement construire une requête pour renvoyer des données.
Comme j'aime les choses simples, j'ai décidé de ne pas renvoyer une page web (trop verbeux), mais juste du texte au [format JSON](http://fr.wikipedia.org/wiki/JavaScript_Object_Notation) qui est simple à lire et à fabriquer.

[[i]]
| Le HTML demande **BEAUCOUP** trop de contenu texte à envoyer pour afficher une information utile. Soyons clairs, un système embarqué comme Arduino n'est **pas fait pour afficher des pages web**, il faut pouvoir renvoyer des informations de manière **simple et concise**.

Il faudra comme pour le client commencer par renvoyer un header. Le nôtre sera simple et possèdera seulement deux informations : le protocole utilisé avec le code de retour (encore http 1.1 et 200 pour dire que tout s'est bien passé) ainsi que le type mime du contenu renvoyé (en l’occurrence "application/json"). Si vous renvoyez de l'html, ce serait "text/html" par exemple.

```cpp
// Tout d'abord le code de réponse 200 = réussite
client.println("HTTP/1.1 200 OK");
// Puis le type mime du contenu renvoyé, du json
client.println("Content-Type: application/json");
// Et c'est tout !
// On envoie une ligne vide pour signaler la fin du header
client.println();
```

Une fois le header envoyé, on construit et envoie notre réponse json. C'est assez simple, il suffit de bien former le texte en envoyant les données dans le bon ordre avec les bons marqueurs.

```cpp
// Puis on commence notre JSON par une accolade ouvrante
client.println("{");
// On envoi la première clé : "uptime"
client.print("\t\"uptime (ms)\": ");
// Puis la valeur de l'uptime
client.print(millis());
//Une petite virgule pour séparer les deux clés
client.println(",");
// Et on envoie la seconde nommée "analog 0"
client.print("\t\"analog 0\": ");
client.println(analogRead(A0));
// Et enfin on termine notre JSON par une accolade fermante
client.println("}");
```

On a presque fini !

Une fois la réponse envoyée, on va faire une toute petite pause pour laisser le temps aux données de partir et enfin on fera le canal de communication avec le client.

```cpp
// Donne le temps au client de prendre les données
delay(10);
// Ferme la connexion avec le client
client.stop();
```

Et voilà !

Il est maintenant temps de tester. Branchez votre Arduino, connectez-la au réseau et allez sur la page ip:port que vous avez paramétrée avec votre navigateur (en l’occurrence http://192.168.0.143:4200/ pour moi). Si tout se passe bien, aux valeurs près vous obtiendrez quelque chose de similaire à ceci :

```javascript
{
    "uptime (ms)": 18155,
    "analog 0": 386
}
```

Génial, non ?

Voici le code complet pour faire tout cela :

```cpp
// Ces deux bibliothèques sont indispensables pour le shield
#include <SPI.h>
#include <Ethernet.h>

// L'adresse MAC du shield
byte mac[] = { 0x90, 0xA2, 0xDA, 0x0E, 0xA5, 0x7E };
// L'adresse IP que prendra le shield
IPAddress ip(192,168,0,143);

// Initialise notre serveur
// Ce dernier écoutera sur le port 4200
EthernetServer serveur(4200);

void setup()
{
  // On démarre la voie série pour déboguer
  Serial.begin(9600);

  char erreur = 0;
  // On démarre le shield Ethernet SANS adresse IP (donc donnée via DHCP)
  erreur = Ethernet.begin(mac);

  if (erreur == 0) {
    Serial.println("Parametrage avec ip fixe...");
    // si une erreur a eu lieu cela signifie que l'attribution DHCP
    // ne fonctionne pas. On initialise donc en forçant une IP
    Ethernet.begin(mac, ip);
  }
  Serial.println("Init...");
  // Donne une seconde au shield pour s'initialiser
  delay(1000);
  // On lance le serveur
  serveur.begin();
  Serial.print("Pret !");
}

void loop()
{
  // Regarde si un client est connecté et attend une réponse
  EthernetClient client = serveur.available();
  if (client) {
    // Quelqu'un est connecté !
    Serial.print("On envoi !");
    // On fait notre en-tête
    // Tout d'abord le code de réponse 200 = réussite
    client.println("HTTP/1.1 200 OK");
    // Puis le type mime du contenu renvoyé, du json
    client.println("Content-Type: application/json");
    // Et c'est tout !
    // On envoie une ligne vide pour signaler la fin du header
    client.println();

    // Puis on commence notre JSON par une accolade ouvrante
    client.println("{");
    // On envoie la première clé : "uptime"
    client.print("\t\"uptime (ms)\": ");
    // Puis la valeur de l'uptime
    client.print(millis());
    //Une petite virgule pour séparer les deux clés
    client.println(",");
    // Et on envoie la seconde nommée "analog 0"
    client.print("\t\"analog 0\": ");
    client.println(analogRead(A0));
    // Et enfin on termine notre JSON par une accolade fermante
    client.println("}");
    // Donne le temps au client de prendre les données
    delay(10);
    // Ferme la connexion avec le client
    client.stop();
  }
}
```

[[i]]
| S'il faut encore vous convaincre, sachez que cet exemple affiche environ 50 caractères, donc 50 octets (plus le header) à envoyer. La même chose en HTML proprement formaté aurait demandé au grand minimum le double.