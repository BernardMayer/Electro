Magie de l'internet, votre Arduino fait maintenant partie de la grande sphère de l'IoT, le phénomène très à la mode de l'Internet of Things. Qu'allez-vous bien pouvoir envoyer comme informations dorénavant ?

->

!(https://www.youtube.com/watch?v=9j_j5Q-MZ_0)

<-