Pour terminer ce tutoriel, je vous propose de réaliser une petite interface de pilotage de l'Arduino via internet. Pour cela, on va garder le programme que nous avions dans l'Arduino pour le paragraphe concernant les requêtes avancées, et nous nous contenterons de simplement faire de l'HTML et du JavaScript. Le HTML servira à faire l'interface et le JavaScript fera les interactions via des requêtes ajax.

Avant toute chose, je vous ai menti ! Il faut en fait rajouter une petite ligne dans notre code de la fonction `repondre()` faite plus tôt. En effet, pour des raisons de sécurité les requêtes ajax ne peuvent pas aller d'un domaine à un autre (donc de "n'importe où sur le web" à "votre Arduino"). Il faut donc rajouter une ligne dans le header renvoyé pour signaler que l'on autorise le "cross-domain".
Rajoutez donc cette ligne juste après le "content-type" :

```cpp
// Autorise le cross origin
client.println("Access-Control-Allow-Origin: *");
```

Maintenant que cela est fait, nous allons créer une structure HTML toute simple pour avoir nos boutons.

```html
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <title>Interface de pilotage Arduino</title>
  </head> 
  <body>
    <div class="main">
      <p>
        Adresse publique du shield : <br />
        http://<input type="text" id="ip" value="123.123.123.123" size="15"/>
        : <input type="text" id="port" value="4200" size="5"/>
      </p>
      <hr />
      <p>
        <input type="checkbox" id="broche3" name="broche3" />
        <label for="broche3">Activer Broche 3.</label>
        Etat : <input type="radio" id="etat3" disabled />
      </p>
      <p>
        <input type="checkbox" id="broche4" name="broche4" />
        <label for="broche4">Activer Broche 4.</label>
        Etat : <input type="radio" id="etat4" disabled />
      </p>
      <p>
        <input type="checkbox" id="broche5" name="broche5" />
        <label for="broche5">Activer Broche 5.</label>
        Etat : <input type="radio" id="etat5" disabled />
      </p>
      <p>
        PWM : 0<input type="range" min="0" max="255" id="pwm" />255
      </p>
      <p>
        A0 : <meter min="0" max="1023" id="a0" />
      </p>
      <button id="envoyer">Executer !</button>
      <p>
        Millis : <span id="millis">0</span> ms
      </p>
    </div>
  </body>
</html>
```

![Interface HTML](http://zestedesavoir.com/media/galleries/954/0bda9b78-50d0-408b-8ac8-a638c0215967.png.960x960_q85.jpg)

Ensuite, un peu de JavaScript nous permettra les interactions. L'ensemble est grosso modo divisé en deux fonctions importantes. `setup()` qui sera exécuté lorsque la page est prête puis `executer()` qui sera appelée à chaque fois que vous cliquez sur le bouton. Cette dernière fera alors une requête à votre Arduino et attendra la réponse json. La fonction `afficher()` utilisera alors les informations pour changer les composants html.

Comme vous pouvez le constater, toute la partie affichage est gérée de manière quasi complètement indépendante de l'Arduino. Cela va nous permettre de transmettre un minimum de données et garder une souplesse maximale sur l'affichage. Si demain vous décidez de changer l'interface voire carrément de faire une application dans un autre langage, vous n'aurez pas besoin de toucher à votre Arduino car les données sont envoyées dans un format générique.

```javascript
var broches = []; // Tableau de broches
var etats = []; // Tableau d'etat des broches
var pwm;
var a0;
var millis;
var adresse = "http://82.143.160.118:4200/"; // L'url+port de votre shield

document.addEventListener('DOMContentLoaded', setup, false);

function setup() {
    // fonction qui va lier les variables à leur conteneur HTML
    broches[3] = document.getElementById("broche3");
    broches[4] = document.getElementById("broche4");
    broches[5] = document.getElementById("broche5");
    etats[3] = document.getElementById("etat3");
    etats[4] = document.getElementById("etat4");
    etats[5] = document.getElementById("etat5");
    pwm = document.getElementById("pwm");
    a0 = document.getElementById("a0");
    millis = document.getElementById("millis");
    
    // La fonction concernant le bouton
    var bouton = document.getElementById("envoyer");
    bouton.addEventListener('click', executer, false);
}

function executer() {
    // Fonction qui va créer l'url avec les paramètres puis
    // envoyer la requête
    var requete = new XMLHttpRequest(); // créer un objet de requête
    var url = adresse;
    url += "?b=";
    for(i=3; i <= 5; i++) { // Pour les broches 3 à 5 de notre tableau
        if(broches[i].checked) // si la case est cochée
            url += i + ",";
    }
    // enlève la dernière virgule si elle existe
    if(url[url.length-1] === ',')
        url = url.substring(0, url.length-1);
    // Puis on ajoute la pwm
    url += "&p=" + pwm.value;
    console.log(url) // Pour debugguer l'url formée    
    requete.open("GET", url, true); // On construit la requête
    requete.send(null); // On envoie !
    requete.onreadystatechange = function() { // on attend le retour
        if (requete.readyState == 4) { // Revenu !
            if (requete.status == 200) {// Retour s'est bien passé !
                // fonction d'affichage (ci-dessous)
                afficher(requete.responseText);
            } else { // Retour s'est mal passé :(
                alert(requete.status, requete.statusText);
            }
        }
    };
}

function afficher(json) {
    // Affiche l'état des broches/pwm/millis revenu en json
    donnees = JSON.parse(json);
    console.log(donnees);
    
    for(i=3; i <= 5; i++) { // Pour les broches 3 à 5 de notre tableau
        etats[i].checked = donnees["broches"][i];
    }
    pwm.value = parseInt(donnees["pwm"]);
    a0.value = parseInt(donnees["A0"]);
    millis.textContent = donnees["uptime"];
}
```

En cadeau de fin, une version utilisable en ligne de cette interface :

->

http://jsfiddle.net/f6c2kc11/7/

<-

Pour l'utiliser, il suffit simplement de modifier l'url de base avec votre IP publique et le port utilisé par l'Arduino.