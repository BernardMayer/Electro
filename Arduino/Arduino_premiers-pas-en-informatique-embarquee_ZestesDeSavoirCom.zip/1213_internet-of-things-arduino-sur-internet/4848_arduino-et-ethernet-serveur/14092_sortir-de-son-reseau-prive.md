À ce stade, nous arrivons à récupérer des informations et donner des ordres à notre Arduino. Cependant, on est bloqué dans notre réseau local. En effet, si vous essayez d'y accéder depuis un autre ordinateur à l'autre bout du monde, il est fort probable que cela ne marche pas...

Pour pallier cela, il va falloir faire un peu d'administration réseau. Je vais couvrir la démarche ici mais ne rentrerai pas trop dans les détails, car ce n'est pas non plus le but de ce tutoriel. Je partirai aussi du principe que vous êtes à votre domicile et utilisez une box ou un routeur que vous pouvez administrer.

L’opération que nous allons faire ici s'appelle une redirection NAT (Network address translation). Mais tout d'abord, essayons de comprendre le problème.

# Le souci

Le problème dans l’état actuel c'est que votre box laisse passer le trafic vers l’extérieur, accepte les réponses, mais ne tolère pas trop qu'on accède directement à son adresse sur n'importe quel port. En effet, après tout c'est logique. Imaginez que vous avez plusieurs équipements connectés a votre routeur/box. Si vous essayez d'y accéder depuis l’extérieur, comment cette dernière saura à quel matériel vous souhaitez accéder ?

Dans votre réseau local, chaque appareil à sa propre adresse IP qui le représente **localement**. Cette adresse est très souvent de la forme 192.168.0.xyz. Vous pourriez avoir par exemple votre téléphone en 192.168.0.142, votre ordinateur en 192.168.0.158 et votre Arduino en 192.168.0.199. Votre box (qui gère ce réseau local) possède quant à elle une IP **publique**. C'est cette IP qui la représente aux yeux du monde. Admettons, pour l'exemple, que cette adresse soit 42.128.12.13 (trouvez la vôtre avec un service comme my-ip.com). Si vous cherchez à accéder à l'adresse publique avec le port 4200 en espérant atteindre votre Arduino vous serez déçus. En effet, vous allez bien atteindre votre box, mais cette dernière n'aura aucune idée de quel équipement doit être interrogé ! Est-ce votre ordinateur ? Votre smartphone ? Votre Arduino ?

Il va donc falloir lui expliquer...

# La solution

[[a]]
| Chaque constructeur de box/routeur possède sa propre interface. Je vais essayer d’être le plus générique possible pour que les explications parlent au plus grand nombre, mais ne m'en voulez pas si toutes les dénominations ne sont pas exactement comme chez vous !

Et cette explication s'appelle une redirection **NAT**, ou redirection de port. En faisant cela, vous expliquerez à votre box que "tout le trafic qui arrive sur ce port particulier doit être envoyé sur cet équipement local" (et vous pouvez même rerouter le trafic pour le changer de port si vous voulez).

Mettons cela en place. Pour cela, commencez par aller dans l'interface d'administration de votre box (souvent c'est à l'adresse 192.168.0.1). Vous devez être dans le réseau local de la box pour le faire ! Ensuite, il vous faudra trouver la partie parlant de "NAT" ou de "redirection de port".
Une fois dans cette dernière, il va falloir demander à ce que tout ce qui rentre dans le port 4200 (ou la plage 4200-4200) soit redirigé vers l’équipement "Arduino" (Wiznet) ou son adresse IP locale si vous la connaissez et que vous l'avez déjà imposée au routeur comme fixe.

Vous aurez alors quelque chose comme ça :

![Réglages NAT](http://zestedesavoir.com/media/galleries/954/c8357df5-5a3f-41a6-92fc-47d358ce4d29.png.960x960_q85.jpg)

Sauvegardez et éventuellement redémarrez votre box (normalement ce n'est pas nécessaire, mais sur du vieux matériel ça peut arriver...). Maintenant, démarrez votre Arduino avec un des programmes ci-dessus et essayez d’accéder à votre adresse publique et le port 4200 avec un navigateur internet. Normalement, l'Arduino devrait répondre comme si vous l’interrogiez avec son adresse locale !