Commençons doucement à découvrir ce shield en utilisant notre Arduino comme **client**.
Dans ce chapitre, nous allons découvrir comment faire en sorte que notre Arduino aille interroger un site internet pour obtenir une information de sa part.

[[information]]
| Ici nous allons interroger un site internet, mais cela aurait très bien pu être un autre service, sur un autre port (vous allez comprendre)

Afin de bien comprendre, je vous propose tout d'abord quelques explications sur le protocole HTTP et comment se passe un échange de données (requête + réponse).

Ensuite, nous verrons comment mettre en œuvre le shield et faire en sorte qu'il puisse accéder au monde extérieur.

Enfin, nous mettrons tout en œuvre pour faire une simple requête sur un moteur de recherche.

Pour terminer, je vous propose un petit exercice qui permettra de voir un cas d'utilisation : le "monitoring" d'un serveur.