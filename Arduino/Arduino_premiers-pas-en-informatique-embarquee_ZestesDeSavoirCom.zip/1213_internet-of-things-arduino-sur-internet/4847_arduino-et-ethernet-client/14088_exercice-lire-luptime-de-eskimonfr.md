Pour finir ce chapitre je vous propose un petit exercice, allez lire l'uptime (temps écoulé depuis la mise en route du système) de mon blog, eskimon.fr.

# Consigne

Pour cela, je vous ai concocté une petite page juste pour vous qui renvoie uniquement cette information, sans tout le bazar HTTP qui va avec une page classique. Vous obtiendrez ainsi simplement le header de la requête et la valeur brute de l'uptime.

La page à interroger pour votre requête est : `http://eskimon.fr/public/arduino.php`

Essayer de modifier votre code pour afficher cette information ;)