Faisons un petit retour étendu sur la notion de client et surtout découvrons plus en détail en quoi consiste exactement une requête HTTP.

# Un client, ça fait quoi ?

Le rôle du client est finalement assez simple. Son but sera d'aller chercher des informations pour les afficher à un utilisateur ou effectuer une action particulière. D'une manière générale, le client sera celui qui traite l'information que le serveur envoie.

Prenons l'exemple du navigateur web. C'est un *client*. Lorsque vous l'utilisez, vous allez générer des *requêtes* vers des serveurs et ces derniers vont ensuite renvoyer un tas d'informations (la page web). Le navigateur va alors les traiter pour vous les afficher sous une forme agréable et prévue par le développeur web.

Finalement, c'est simple d’être client, ça consiste juste à demander des choses et attendre qu'elles arrivent :) !

Les termes "client" et "serveur" (et même "requête") sont d'ailleurs très bien choisis car ils illustrent très bien les mêmes rôles que leur équivalent "dans la vraie vie".

# Une requête HTTP, c'est quoi ?

Des requêtes HTTP il en existe de plusieurs types. Les plus classiques sont sûrement les GET et les POST, mais on retrouve aussi les PUT, DELETE, HEAD... Pour faire simple, nous allons uniquement nous intéresser à la première car c'est celle qui est utilisée la plupart du temps !

## Émission

Dans la spécification du protocole HTTP, on apprend que GET nous permet de demander une ressource en lecture seule. On aura simplement besoin de spécifier une page cible et ensuite le serveur HTTP de cette page nous renverra la ressource ou un code d'erreur en cas de problème. On peut passer des arguments/options à la fin de l'adresse que l'on interroge pour demander des choses plus particulières au serveur.

Par exemple, si vous êtes sur la page d'accueil de Google et que vous faites une recherche sur "Arduino", votre navigateur fera la requête suivante : `GET /search?q=arduino HTTP/1.0`. Il interroge donc la page principale "/" (racine) et envoie l'argument "search?q=arduino". Le reste définit le protocole utilisé.

## Réception

Une fois la requête faite, le serveur interrogé va vous renvoyer une réponse. Cette réponse peut être découpée en deux choses : l'en-tête (header) et le contenu. On pourrait comparer cela à un envoi de colis. L’en-tête possèderait les informations sur le colis (destinataires, etc.) et le contenu est ce qui est à l’intérieur du colis.

Typiquement, dans une réponse minimaliste, on lira les informations suivantes :

+ Le code de réponse de la requête (200 si tout s'est bien passé) ;
+ Le type MIME du contenu renvoyé (`text/html` dans le cas d'une page web) ;
+ Une ligne blanche/vide ;
+ Le contenu.

Les deux premières lignes font partie du header, puis après viendra le contenu.

Si l'on veut chercher des informations, en général on le fera dans le contenu.