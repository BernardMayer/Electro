# Contexte

Imaginez-vous au bord de la plage. Le ciel est bleu, la mer aussi... Ahhh le rêve. Puis, tout un coup le drapeau rouge se lève ! "Requiiiinn" crie un nageur... L’application que je vous propose de développer ici correspond à ce genre de situation. Vous êtes au QG de la zPlage, le nouvel endroit branché pour les vacances. Votre mission si vous l'acceptez est d'afficher en temps réel un indicateur de qualité de la plage et de ses flots. Pour cela, vous devez informer les zTouristes par l'affichage d'un code de 3 couleurs. Des zSurveillants sont là pour vous prévenir que tout est rentré dans l'ordre si un incident survient.

# Objectif

Comme expliqué ci-dessus, l'affichage de qualité se fera au travers de 3 couleurs qui seront représentées par des LEDs :

* **Rouge** : Danger, ne pas se baigner
* **Orange** : Baignade risquée pour les novices
* **Vert** : Tout baigne !

La zPlage est équipée de deux boutons. L'un servira à déclencher un SOS (si quelqu'un voit un nageur en difficulté par exemple). La lumière passe alors au rouge clignotant jusqu'à ce qu'un sauveteur ait appuyé sur l'autre bouton signalant "**Problème réglé, tout revient à la situation précédente**". Enfin, dernier point mais pas des moindres, le QG (vous) reçoit des informations météorologiques et provenant des marins au large. Ces messages sont retransmis sous forme de textos (symbolisés par la voie série) aux sauveteurs sur la plage pour qu'ils changent les couleurs en temps réel. Voici les mots-clés et leurs impacts :

* **Rouge** : meduse, tempete, requin : Des animaux dangereux ou la météo rendent la zPlage dangereuse. Baignade interdite
* **Orange** : vague : La natation est réservée aux bons nageurs
* **Vert** : surveillant, calme : Tout baigne, les zSauveteurs sont là et la mer est cool

# Conseil

Voici quelques conseils pour mener à bien votre objectif.

## Réalisation

Une fois n'est pas coutume, **nommez bien vos variables** ! Vous verrez que dès qu'une application prend du volume il est agréable de ne pas avoir à chercher qui sert à quoi. - N'hésitez pas à **décomposer votre code en fonction**. Par exemple les fonctions `changerDeCouleur()` peuvent-être les bienvenues. :euh:

## Précision sur les chaines de caractères

Lorsque l'on écrit une phrase, on a l'habitude de la finir par un point. En informatique c'est pareil mais à l'échelle du mot ! Je m'explique. Une chaîne de caractères (un mot) est, comme l'indique son nom, une suite de caractères. Généralement on la déclare de la façon suivante :

```cpp
char mot[20] = "coucou"
```

Lorsque vous faites ça, vous ne le voyez pas, l'ordinateur rajoute juste après le dernier caractère (ici 'u') un caractère invisible qui s'écrit **`\0`** (antislash-zéro). Ce caractère signifie "fin de la chaîne". En mémoire, on a donc :

->

|  case  |  car. |
|--------|-------|
| mot[0] | `'c'` |
| mot[1] | `'o'` |
| mot[2] | `'u'` |
| mot[3] | `'c'` |
| mot[4] | `'o'` |
| mot[5] | `'u'` |
| mot[6] | `'\0'`|

Table: Correspondance des lettres vers le tableau

<-

[[information]]
| Ce caractère est **très important** pour la suite car je vais vous donner un petit coup de pouce pour le traitement des mots reçus.

Une bibliothèque, nommée "string" (chaîne en anglais) et présente nativement dans votre logiciel Arduino, permet de traiter des chaînes de caractères. Vous pourrez ainsi plus facilement comparer deux chaînes avec la fonction `strcmp(chaine1, chaine2)`. Cette fonction vous renverra 0 si les deux chaînes sont identiques. Vous pouvez par exemple l'utiliser de la manière suivante :

```cpp
// utilisation de la fonction strcmp(chaine1, chaine2) pour comparer des mots
int resultat = strcmp(motRecu, "requin");

if(resultat == 0)
    Serial.print("Les chaines sont identiques");
else
    Serial.print("Les chaines sont différentes");
```
Code: Utilisation de `strcmp`

Le truc, c'est que cette fonction compare *caractère par caractère* les chaînes, or celle de droite : "requin" possède ce fameux `'\0'` après le `'n'`. Pour que le résultat soit identique, il faut donc que les deux chaînes soient parfaitement identiques ! Donc, avant d'envoyer la chaîne tapée sur la voie série, il faut lui rajouter ce fameux `'\0'`.

[[information]]
| Je comprends que ce point soit délicat à comprendre, je ne vous taperais donc pas sur les doigts si vous avez des difficultés lors de la comparaison des chaînes et que vous allez vous balader sur la solution... Mais essayez tout de même, c'est tellement plus sympa de réussir en réfléchissant et en essayant ! :)

# Résultat

Prenez votre temps, faites-moi quelque chose de beau et amusez-vous bien ! Je vous laisse aussi choisir comment et où brancher les composants sur votre carte Arduino. :ninja: Voici une photo d'illustration du montage ainsi qu'une vidéo du montage en action.

![Photo du TP : Baignade Intedite](/media/galleries/954/0bd1622e-35e7-47e1-9348-74638ae474eb.jpg.960x960_q85.jpg)

->!(https://www.youtube.com/watch?v=KncBc25Skxo)<-

[[information]]
| Bon Courage !