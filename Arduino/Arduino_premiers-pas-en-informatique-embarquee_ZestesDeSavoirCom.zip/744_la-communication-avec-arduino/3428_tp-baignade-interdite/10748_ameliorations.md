Je peux vous proposer quelques idées d'améliorations que je n'ai pas mises en oeuvre, mais qui me sont passées par la tête au moment où j'écrivais ces lignes :

## Améliorations logicielles

Avec la nouvelle version d'Arduino, la version 1.0,; il existe une fonction `SerialEvent()` qui est exécutée dès qu'il y a un évènement sur la voie série du micro-contrôleur. Je vous laisse le soin de chercher à comprendre comment elle fonctionne et s'utilise, sur [cette page](http://arduino.cc/en/Reference/SerialEvent).

## Améliorations matérielles

* On peut par exemple automatiser le changement d'un drapeau en utilisant un système mécanique avec un ou plusieurs moteurs électriques. Ce serait dans le cas d'utilisation réelle de ce montage, c'est-à-dire sur une plage...
* Une liaison filaire entre un PC et une carte Arduino, ce n'est pas toujours la joie. Et puis bon, ce n'est pas toujours facile d'avoir un PC sous la main pour commander ce genre de montage. Alors pourquoi ne pas rendre la connexion sans-fil en utilisant par exemple des modules XBee ? Ces petits modules permettent une connexion sans-fil utilisant la voie série pour communiquer. Ainsi, d'un côté vous avez la télécommande (à base d'Arduino et d'un module XBee) de l'autre vous avez le récepteur, toujours avec un module XBee et une Arduino, puis le montage de ce TP avec l'amélioration précédente.

Sérieusement si ce montage venait à être réalité avec les améliorations que je vous ai données, prévenez-moi par MP et faites en une vidéo pour que l'on puisse l'ajouter en lien ici même ! ^^