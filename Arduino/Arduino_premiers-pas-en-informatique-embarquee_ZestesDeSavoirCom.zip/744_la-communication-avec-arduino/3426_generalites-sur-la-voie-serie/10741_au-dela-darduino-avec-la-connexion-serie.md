Voici une petite annexe qui va vous présenter un peu l'utilisation du vrai port série. Je ne vous oblige pas à la lire, elle n'est pas indispensable et peu seulement servir si vous avez un jour besoin de communiquer avec un dispositif qui exploite cette voie série.

# Le connecteur série (ou sortie DB9)

## Le brochage au complet !

[[question]]
| Oui, je veux savoir pourquoi il possède tant de broches puisque tu nous as dit que la voie série n'utilisait que 3 fils.

Eh bien, toutes ces broches ont une fonction bien précise. Je vais vous les décrire, ensuite on verra plus en détail ce que l'on peut faire avec :

1. **DCD** : Détection d'un signal sur la ligne. Utilisée uniquement pour la connexion de l'ordinateur à un modem ; détecte la porteuse
2. **RXD** : Broche de réception des données
3. **TXD** : Broche de transmission des données
4. **DTR** : Le support qui veut recevoir des données se déclare prêt à "écouter" l'autre
5. **GND** : Le référentiel électrique commun ; la masse
6. **DSR** : Le support voulant transmettre déclare avoir des choses à dire
7. **RTS** : Le support voulant transmettre des données indique qu'il voudrait communiquer
8. **CTS** : Invitation à émettre. Le support de réception attend des données
9. **RI** : Très peu utilisé, indiquait la sonnerie dans le cas des modems RS232

Vous voyez déjà un aperçu de ce que vous pouvez faire avec toutes ces broches. Mais parlons-en plus amplement.

# Désolé, je suis occupé...

Dans certains cas, et il n'est pas rare, les dispositifs communicant entre eux par l'intermédiaire de la voie série ne traitent pas les données à la même vitesse. Tout comme lorsque l'on communique avec quelqu'un, il arrive parfois qu'il n'arrive plus à suivre ce que l'on dit car il en prend des notes. Il s'annonce alors indisponible à recevoir plus d'informations. Dès qu'il est à nouveau prêt, il nous le fait savoir. Il y a un moyen, mis en place grâce à certaines broches du connecteur pour effectuer ce genre d'opération que l'on appelle le **contrôle de flux**. Il y a deux manières d'utiliser un contrôle de flux, nous allons les voir tout de suite.

## Contrôle de flux logiciel

Commençons par le contrôle de flux logiciel, plus simple à utiliser que le contrôle de flux matériel. En effet, il ne nécessite que trois fils : la masse, le Rx et le TX. Eh oui, ni plus ni moins, tout se passe logiciellement. Le fonctionnement très simple de ce contrôle de flux utilise des caractères de la table ASCII, le caractère 17 et 19, respectivement nommés **XON** et **XOFF**. Ceci se passe entre un équipement E, qui est l'émetteur, et un équipement R, qui est récepteur. Le récepteur reçoit des informations, il les traite et stockent celles qui continuent d'arriver en attendant de les traiter. Mais lorsqu'il ne peut plus stocker d'informations, le récepteur envoie le caractère XOFF pour indiquer à l'émetteur qu'il sature et qu'il n'est plus en mesure de recevoir d'autres informations. Lorsqu'il est à nouveau apte à traiter les informations, il envoie le caractère XON pour dire à l'émetteur qu'il est à nouveau prêt à écouter ce que l'émetteur à a lui dire.

## Contrôle de flux matériel

On n'utilisera pas le contrôle de flux matériel avec Arduino car la carte n'en est pas équipée, mais il est bon pour vous que vous sachiez ce que c'est. Je ne parlerai en revanche que du contrôle matériel à 5 fils. Il en existe un autre qui utilise 9 fils. Le principe est le même que pour le contrôle logiciel. Cependant, on utilise certaines broches du connecteur DB9 dont je parlais plus haut. Ces broches sont **RTS** et **CTS**.

![Connexion avec contrôle de flux](/media/galleries/954/8cfb949d-075e-4138-95b5-2602b0a14132.png.960x960_q85.jpg)

Voilà le branchement adéquat pour utilise ce contrôle de flux matériel à 5 fils. Une transmission s'effectue de la manière suivante :

* Le dispositif 1, que je nommerais maintenant *l'émetteur*, met un état logique 0 sur sa broche RTS1. Il demande donc au dispositif 2, *le récepteur*, pour émettre des données.
* Si le récepteur est prêt à recevoir des données, alors il met un niveau logique 0 sur sa broche RTS2.
* Les deux dispositifs sont prêts, l'émetteur peut donc envoyer les données qu'il a à transmettre.
* Une fois les données envoyées, l'émetteur passe à 1 l'état logique présent sur sa broche RTS1.
* Le récepteur voit ce changement d'état et sait donc que c'est la fin de la communication des données, il passe alors l'état logique de sa broche RTS2 à 1.

Ce contrôle n'est pas très compliqué et est utilisé lorsque le contrôle de flux logiciel ne l'est pas.

# Avec ou sans horloge ?

Pour terminer, faisons une petite ouverture sur d'autres liaisons séries célèbres...

## L'USB

On la côtoie tout les jours sans s'en soucier et pourtant elle nous entoure : C'est la liaison USB ! Comme son nom l'indique, Universal Serial Bus, il s'agit bien d'une voie série. Cette dernière existe en trois versions. La dernière, la 3.1, vient juste de sortir. Une des particularités de cette voie série est qu'elle se propose de livrer l’alimentation de l'équipement avec lequel elle communique. Par exemple votre ordinateur peut alimenter votre disque dur portable et en même temps lui demander des fichiers. Dans le cas de l'USB, la communication se fait de manière "maître-esclave". C'est l'hôte (l'ordinateur) qui demande des informations à l'esclave (le disque dur). Tant qu'il n'a pas été interrogé, ce dernier n'est pas censé parler. Afin de s'y retrouver, chaque périphérique se voit attribuer une adresse. La transmission électrique se fait grâce à un procédé "différentiel" entre deux fils, D+ et D-, afin de limiter les parasites.

## L'I2C

L'I²C est un autre protocole de communication qui fut tout d'abord propriétaire (inventé par Philips) et né de la nécessité d'interfacer de plus en plus de microcontrôleurs. En effet, à ce moment là une voie série "classique" ne suffisait plus car elle ne pouvait relier que deux à deux les microcontrôleurs. La particularité de cette liaison est qu'elle transporte son propre signal d'horloge. Ainsi, la vitesse n'a pas besoin d'être connu d'avance. Les données sont transportées en même temps que l'horloge grâce à deux fils : SDA (Data) et SCL (Clock). Comme pour l'USB, la communication se fait sur un système de maître/esclave.

*[DCD]: Carrier Detect
*[RXD]: Receive Data
*[TXD]: Transmit Data
*[DTR]: Data Terminal Ready
*[GDN]: Provient de l'anglais GROUND
*[DST]: Date Set Read
*[RTS]: Request To Send
*[CTS]: Clear To Send
*[RI]: Ring Indicator