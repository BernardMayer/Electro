[[question]]
| Et on connecte quoi à où pour utiliser la voie série avec la carte Arduino et le PC ? C'est le même câblage ? Et on connecte où sur le PC ?

Là, on va avoir le choix...

# Émulation du port série

Le premier objectif et le seul que nous mettrons en place dans le cours, va être de connecter et d'utiliser la voie série avec l'ordinateur. Pour cela, rien de plus simple, il n'y a que le câble USB à brancher entre la carte Arduino et le PC. En fait, la voie série va être **émulée** à travers l'USB. C'est une forme virtuelle de cette liaison. Elle n'existe pas réellement, mais elle fonctionne comme si c'était bien une vraie voie série. Tout ça va être géré par un petit composant présent sur votre carte Arduino et le gestionnaire de port USB et périphérique de votre ordinateur.

![Le composant entouré en rouge gère l'émulation de la voie série](/media/galleries/954/26bec92b-3c71-47db-beb1-01019dd5bb32.png.960x960_q85.jpg)

C'est la solution la plus simple et celle que nous allons utiliser pour vos débuts.

# Arduino et un autre microcontrôleur

On a un peu abordé ce sujet, au début de la présentation sur la voie série. Mais, on va voir un peu plus de choses. Le but de connecter deux microcontrôleur ensemble est de pouvoir les faire communiquer entre eux pour qu'ils puissent s'échanger des données.

## La tension des microcontrôleurs

->

|     | Tension |
|-----|---------|
| NL0 | 0V      |
| NL1 | +5V     |

<-

Contrairement à ce qu'impose la norme RS-232, les microcontrôleur ne peuvent pas utiliser des tensions négatives. Du coup, ils utilisent les seuls et uniques tensions qu'ils peuvent utiliser, à savoir le 0V et le +5V. Il y a donc quelques petits changement au niveau de la transmission série.

Un niveau logique 0 correspond à une tension de 0V et un niveau logique 1 correspond à une tension de +5V (cf. tableau ci-contre). Fort heureusement, comme les microcontrôleurs utilisent quasiment tous cette norme, il n'y a aucun problème à connecter deux microcontrôleurs entre-eux. Cette norme s'appelle alors UART pour **U**niversal **A**synchronous **R**eceiver **T**ransmitter plutôt que RS232. Hormis les tensions électriques et le connecteur, c'est la même chose !

## Croisement de données

Il va simplement falloir faire attention à bien croiser les fils. On connecte le Tx (broche de transmission) d'un microcontrôleur au Rx (broche de réception) de l'autre microcontrôleur. Et inversement, le Tx de l'autre au Rx du premier. Et bien sûr, la masse à la masse pour faire une référence commune. Exactement comme le premier schéma que je vous ai montré :

![Deux Arduino reliées entre elles](/media/galleries/954/15e08601-6c85-49e6-964d-8c232b8b6cb1.png.960x960_q85.png)

Tx $\rightarrow$ Rx, fil vert || Rx $\rightarrow$ Tx, fil orange Masse $\rightarrow$ Masse, fil noir

La couleur des fils importe peu, évidemment ! :P

# Arduino au PC

## Le connecteur série (ou sortie DB9)

Alors là, les enfants, je vous parle d'un temps que les moins de vingt ans ne peuvent pas connaittttrrreuhhh... Bon on reprend ! Comme énoncé, je vous parle de quelque chose qui n'existe presque plus. Ou du moins, vous ne trouverez certainement plus cette "chose" sur la connectique de votre ordinateur. En effet, je vais vous parler du connecteur DB9 (ou DE9). Il y a quelques années, l'USB n'était pas si véloce et surtout pas tant répandu. Beaucoup de matériels (surtout d'un point de vue industriel) utilisaient la voie série (et le font encore).

À l'époque, les équipements se branchaient sur ce qu'on appelle une prise DB9 (9 car 9 broches). Sachez simplement que ce nom est attribué à un connecteur qui permet de relier divers matériels informatiques entre eux.

![Connecteur DB9 Mâle](/media/galleries/954/fcff503b-1d74-4eff-934b-dc30e454150e.jpg.960x960_q85.jpg)

![Connecteur DB9 Femelle](/media/galleries/954/4b50d2d6-4dc2-4560-ab73-b25eceee5e21.png.960x960_q85.jpg)
Figure: Connecteur DB9 Femelle - (CC-BY-SA, [Faxe](http://commons.wikimedia.org/wiki/File:RS-232.jpeg))

Photos extraites du site Wikipédia - Connecteur DB9 Mâle à gauche ; Femelle à droite

[[question]]
| A quoi ça sert ?

Si je vous parle de ça dans le chapitre sur la voie série, c'est qu'il doit y avoir un lien, non ? o_O Juste, car la voie série (je parle là de la transmission des données) est véhiculée par ce connecteur dans la norme RS-232. Donc, notre ordinateur dispose d'un connecteur DB9, qui permet de relier, via un câble adapté, sa connexion série à un autre matériel. Avant, donc, lorsqu'il était très répandu, on utilisait beaucoup ce connecteur. D'ailleurs, la première version de la carte Arduino disposait d'un tel connecteur !

![La première version de la carte Arduino, avec un connecteur DB9](/media/galleries/954/9a887209-ee8e-4a4a-8ebc-ebbf3f19dd11.png.960x960_q85.jpg)
Figure: La première version de la carte Arduino, avec un connecteur DB9 - (CC-BY-SA, [arduino.cc](http://arduino.cc/en/Main/Boards))

Aujourd'hui, le connecteur DB9 a déjà bien disparu mais reste présent sur les "vieux" ordinateurs ou sur d'autres appareils utilisant la voie série. C'est pourquoi, le jour où vous aurez besoin de communiquer avec un tel dispositif, il vous faudra faire un peu d'électronique...

## Une petite histoire d'adaptation

Si vous avez donc l'occasion de connecter votre carte Arduino à un quelconque dispositif utilisant la voie série, il va falloir faire attention aux tensions...oui, encore elles ! Je l'ai déjà dis, un microcontrôleur utilise des tensions de 0V et 5V, qu'on appel TTL. Hors, la norme RS-232 impose des tensions positives et négatives comprise en +/-3V et +/-25V. Il va donc falloir adapter ces tensions. Pour cela, il existe un composant très courant et très utilisé dans ce type de cas, qu'est le MAX232.

-> [Datasheet du MAX232](http://www.ti.com/lit/ds/symlink/max232.pdf) <-

Je vous laisse regarder la datasheet et comprendre un peu le fonctionnement. Aussi, je vous met un schéma, extrait du site internet sonelec-musique.com :

![Câblage du MAX232](/media/galleries/954/13a06982-606c-4ac3-b9c3-af93858a1bb2.gif.960x960_q85.jpg)
Figure: Câblage du MAX232 - (Autorisation de reproduction par l'auteur, Rémy, [source](http://sonelec-musique.com/images/max232_001.gif))

Le principe de ce composant, utilisé avec quelques condensateur, est d'adapter les signaux de la voie série d'un microcontrôleur vers des tensions aux standards de la norme RS-232 et inversement. Ainsi, une fois le montage installé, vous n'avez plus à vous soucier de savoir quelle tension il faut, etc...

![Lien entre microcontrôleur et MAX232](/media/galleries/954/a57c74ce-798a-404b-9847-1a97ef1a186d.png.960x960_q85.jpg)

[[erreur]]
| En revanche, n'utilisez jamais ce composant pour relier deux microcontrôleurs entre eux ! Vous risqueriez d'en griller un. Ou alors il faut utiliser deux fois ce composant (un pour TTL $\rightarrow$ RS232 et l'autre pour RS232 $\rightarrow$ TTL >_< ), mais cela deviendrait alors peu utile.

Donc en sortie du MAX232, vous aurez les signaux Rx et Tx au standard RS-232. Elles dépendent de son alimentation et sont en générale centrées autour de +/-12V. Vous pourrez par exemple connecter un connecteur DB9 à la sortie du MAX232 et relier la carte Arduino à un dispositif utilisant lui aussi la voie série et un connecteur DB9. Ou même à un dispositif n'utilisant pas de connecteur DB9 mais un autre (dont il faudra connaitre le brochage) et qui utilise la voie série.

*[TTL]: Transistor-Transistor Logic