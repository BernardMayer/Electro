Des liaisons séries, il en existe un paquet ! Je peux en citer quelques unes : RS-232, Universal Serial Bus (USB), Serial ATA, SPI, ... Et pour dire, vous pouvez très bien inventer votre propre norme de communication pour la voie série que vous décidez de créer. L'inconvénient, bien que cela puisse être également un avantage, il n'y a que vous seul qui puissiez alors utiliser une telle communication.

[[question]]
| Et nous, laquelle allons-nous voir parmi celles-là ? Il y en a des meilleurs que d'autres ? oO

D'abord, nous allons voir la voie série utilisant la norme RS-232. Ensuite, oui, il y en a qui ont des avantages par rapport à d'autres. On peut essentiellement noter le type d'utilisation que l'on veut en faire et la vitesse à laquelle les dispositifs peuvent communiquer avec.

## Applications de la norme

La **norme RS-232** s'applique sur trois champs d'une communication de type série. Elle définit le signal électrique, le protocole utilisé et tout ce qui est lié à la mécanique (la connectique, le câblage, etc...).

# La mécanique

Pour communiquer via la voie série, deux dispositifs doivent avoir 3 câbles minimum.

* Le premier câble est la **référence électrique**, communément appelée **masse électrique**. Cela permet de prendre les mesures de tension en se fixant un même référentiel. Un peu lorsque vous vous mesurez : vous mesurez 1,7 mètre du sol au sommet de votre tête et non pas 4,4 mètre parce que vous êtes au premier étage et que vous vous basez par rapport au sol du rez-de-chaussé. Dans notre cas, on considérera que le 0V sera notre référentiel électrique commun.
* Les deux autres câbles permettent la transmission des données. L'un sert à l'envoi des données pour un émetteur, mais sert aussi pour la réception des données venant de l'autre émetteur. Idem pour l'autre câble. Il permet l'émission de l'un et la réception de l'autre.

![Deux Arduino reliées entre elles](/media/galleries/954/15e08601-6c85-49e6-964d-8c232b8b6cb1.png.960x960_q85.png)

Deux cartes Arduino reliées par 3 câbles :

* Le **noir** est la masse électrique commune
* Le **vert** est celui utilisé pour l'envoi des données de la première carte (à gauche), mais sert également à la réception des données envoyées pour la deuxième carte (à droite)
* Le **orange** est celui utilisé pour l'envoi des données de la deuxième carte (à droite), mais sert également à la réception des données envoyées pour la première carte (à gauche)

Cela, il s'agit du strict minimum utilisé. La norme n'interdit pas l'utilisation d'autres câbles qui servent à faire du contrôle de flux et de la gestion des erreurs.

# Le signal électrique et le protocole

Avant tout, il faut savoir que pour communiquer, deux dispositifs électronique ou informatique utilisent des données sous forme de **bits**. Ces bits, je le rappel, sont des états logiques (vrai ou faux) qui peuvent être regroupés pour faire des ensembles de bits. Généralement, ces ensembles sont constitués de 8 bits qui forment alors un **octet**.

## Les tensions utilisées

Ces bits sont en fait des niveaux de tension électrique. Et la norme RS-232 définit quelles tensions doivent être utilisées. On peut spécifier les niveaux de tension imposés par la norme dans un tableau, que voici :

->

| | Niveau logique 0 | Niveau logique 1 |
|-|------------------|------------------|
| Tension électrique minimale | +3V | -3V |
| Tension électrique maximale | +25V | -25V |

Table: Niveau électrique de la norme RS-232

<-

Ainsi, toutes les tensions au delà des valeurs imposées, donc entre -3V et +3V, au dessous de -25V et au dessus de +25V, sont hors normes. Pour les tensions trop élevées (aux extrêmes de + et -25V) elles pourraient endommager le matériel. Quand aux tensions comprises entre + et -3V, eh bien elles sont ignorées car c'est dans ces zones là que se trouvent la plupart et même la quasi totalité des parasites. C'est un moyen permettant d'éviter un certain nombre d'erreurs de transmissions.

[[information]]
| Les parasites dont je parle sont simplement des pics de tensions qui peuvent survenir à cause de différentes sources (interrupteur, téléviseur, micro-ondes, ...) et qui risquent alors de modifier des données lors d'une transmission effectuée grâce à la voie série.

Lorsqu'il n'y a pas de communication sur la voie série, il y a ce qu'on appelle un **état de repos**. C'est à dire un niveau logique toujours présent. Il s'agit du niveau logique 1. Soit une tension comprise entre -3V et -25V. Si cet état de repos n'est pas présent, c'est qu'il peut y avoir un problème de câblage.

## Les données

Les données qui transitent par la voie série sont transmises sous une forme binaire. C'est à dire avec des niveaux logiques 0 et 1. Prenons une donnée que nous voudrions envoyer, par exemple la lettre "P" majuscule. Vous ne le saviez peut-être pas mais une lettre du clavier est codé sur un nombre de 8 bits, donc un octet. Réellement c'est en fait sur 7 bits qu'elle est codée, mais en rajoutant un 0 devant le codage, cela conserve sa valeur et permet d'avoir un codage de la lettre sur 8 bits. Ces codes sont définis selon la **table ASCII**.

Ainsi, pour chaque caractère du clavier, on retrouve un codage sur 8 bits. Vous pouvez aller consulter cette table pour comprendre un peu comment elle fonctionne en [suivant ce lien](http://fr.wikipedia.org/wiki/American_Standard_Code_for_Information_Interchange#Table_des_128_caract.C3.A8res_ASCII). En haut à gauche de la table ASCII, on observe la ligne : "Code en base..." et là vous avez : 10, 8, 16, 2. Respectivement, ce sont les bases décimale (10), octale (8), hexadécimale (16) et binaire (2). 

Certaines ne vous sont donc pas inconnues puisque l'on en a vu. Nous, ce qui va nous intéresser, c'est la base binaire. Oui car le binaire est une succession de 0 et de 1, qui sont les états logiques 0 (LOW) et 1 (HIGH). En observant la table, on tombe sur la lettre "P" majuscule et l'on voit sa correspondance en binaire : *01010000*.

[[question]]
| Je crois ne pas bien comprendre pourquoi on envoie une lettre... qui va la recevoir et pour quoi faire ? o_O

Il faut vous imaginer qu'il y a un destinataire. Dans notre cas, il s'agira avant tout de l'ordinateur avec lequel vous programmez votre carte. On va lui envoyer la lettre "P" mais cela pourrait être une autre lettre, une suite de lettres ou autres caractères, voire même des phrases complètes. Pour ne pas aller trop vite, nous resterons avec cette unique lettre. Lorsque l'on enverra la lettre à l'ordinateur, nous utiliserons un petit module intégré dans le logiciel Arduino pour visualiser le message réceptionné. C'est donc nous qui allons voir ce que l'on transmet via la voie série.

## L'ordre et les délimiteurs

On va à présent voir comment est transmit un octet sur la voie série en envoyant notre exemple, la lettre "P". Analogiquement, je vais vous montrer que cette communication par la voie série se présente un peu comme un appel téléphonique :

1. Lorsque l'on passe un coup de fil, bien généralement on commence par dire "Bonjour" ou "Allo". Ce début de message permet de faire l'ouverture de la conversation. En effet, si l'on reçoit un appel et que personne ne répond après avoir décroché, la conversation ne peut avoir lieu. Dans la norme RS-232, on va avoir une ouverture de la communication grâce à un **bit de départ**. C'est lui qui va engager la conversation avec son interlocuteur. Dans la norme RS-232, ce dernier est un état 0.
2. Ensuite, vous allez commencer à parler et donner les informations que vous souhaitez transmettre. Ce sera les **données**. L'élément principal de la conversation (ici notre lettre 'P').
3. Enfin, après avoir renseigné tout ce que vous aviez à dire, vous terminez la conversation par un "Au revoir" ou "Salut !", "A plus !" etc. Cela termine la conversation. Il y aura donc un **bit de fin** ou **bit de stop** qui fera de même sur la voie série. Dans la norme RS-232, c'est un état 1.

![Chronogramme d'un échange sur la voie série](/media/galleries/954/d49d77e5-5187-4d60-b762-d09425e21ed7.png.960x960_q85.jpg)

C'est de cette manière là que la communication série fonctionne. D'ailleurs, savez-vous pourquoi la voie série s'appelle ainsi ? En fait, c'est parce que les données à transmettre sont envoyées une par une. Si l'on veut, elles sont à la queue leu-leu. Exactement comme une conversation entre deux personnes : la personne qui parle ne peut pas dire plusieurs phrases en même temps, ni plusieurs mots ou sons. Chaque élément se suit selon un ordre logique. L'image précédente résume la communication que l'on vient d'avoir, il n'y a plus qu'à la compléter pour envoyer la lettre "P".

[[question]]
| Ha, je vois. Donc il y a le bit de start, notre lettre P et le bit de stop. D'après ce qu'on a dit, cela donnerait, dans l'ordre, ceci : 0 (Start) 01010000 (Données) et 1 (Stop). :D

Eh bien... c'est presque ça. Sauf que les ~~petits malins~~ ingénieurs qui ont inventé ce protocole ont eu la bonne idée de transmettre les données à l'envers... Par conséquent, la bonne réponse était : 0000010101. Avec un chronogramme, on observerait ceci :

![Chronogramme de la transmission de la lettre 'P'](/media/galleries/954/e92850c8-f693-42b0-8a44-23031b6997be.png.960x960_q85.jpg)

## Un peu de vocabulaire

Avant de continuer à voir ce que compose le protocole RS-232, voyons un peu de vocabulaire, mais sans trop en abuser bien sûr ! :P Les données sont envoyées à l'envers, je le disais. Ce qu'il faut savoir c'est que le bit de donnée qui vient après le bit de start s'appelle le **bit de poids faible** ou **LSB** en anglais pour Less Significant Bit. C'est un peu comme un nombre qui a des unités (tout à droite), des dizaines, des centaines, des milliers (à gauche), etc.

Par exemple le nombre *6395* possède 5 unités (à droite), 9 dizaines, 3 centaines et 6 milliers (à gauche). On peut faire référence au bit de poids faible en binaire qui est donc à droite. Plus on s'éloigne et plus on monte vers... le bit de **poids fort** ou **MSB** en anglais pour Most Significant Bit. Et comme les données sont envoyées à l'envers sur la liaisons série, on aura le bit de poids faible juste après le start, donc à gauche et le bit de poids fort à droite.

Avec le nombre précédent, si l'on devait le lire à l'envers cela donnerait : 5936. Bit de poids faible à gauche et à droite le bit de poids fort.

[[erreur]]
| Il est donc essentiel de savoir où est le bit de poids faible pour pouvoir lire les données à l'endroit. Sinon on se retrouve avec une donnée erronée !

Pour regrouper un peu tout ce que l'on a vu sur le protocole de la norme RS-232, voici une image le résumant :

![Protocole de la norme RS-232](/media/galleries/954/806ebada-1a4c-4179-b58b-f09cf0e3b1ae.png.960x960_q85.png)
Figure: Protocole de la norme RS-232 - (CC-SA, [Ktnbn](http://commons.wikimedia.org/wiki/File:Rs232_oscilloscope_trace.svg))

Vous devrez être capable de trouver quel est le caractère envoyé sur cette trame... alors ? :D Indice : c'est une lettre... On lit les niveaux logiques de gauche à droite, soit 11010010 ; puis on les retourne soit 01001011 ; enfin on compare à la table ASCII et on trouve la lettre "K" majuscule. Attention aux tensions négatives qui correspondent à l'état logique 1 et les tensions positives à l'état logique 0.

## La vitesse

La norme RS-232 définit la vitesse à laquelle sont envoyée les données. Elles sont exprimés en bit par seconde (bit/s). Elle préconise des vitesse inférieures à 20 000 bits/s. Sauf qu'en pratique, il est très courant d'utiliser des débits supérieurs pouvant atteindre les 115 200 bits/s. Quand on va utiliser la voie série, on va définir la vitesse à laquelle sont transférées les données.

Cette vitesse dépend de plusieurs contraintes que sont : la longueur du câble utilisé reliant les deux interlocuteurs et la vitesse à laquelle les deux interlocuteurs peuvent se comprendre. Pour vous donner un ordre d'idée, je reprend le tableau fourni sur la page Wikipédia sur la norme RS-232 :

->

| Débit en bit/s | Longueur du câble en mètres (m) |
|----------------|---------------------------------|
| 2 400          | 900                             |
| 4 800          | 300                             |
| 9 600          | 150                             |
| 19 200         | 15                              |

Table: Vitesses théoriques de la norme RS-232

<-

Plus le câble est court, plus le débit pourra être élevé car moins il y a d'affaiblissement des tensions et de risque de parasites. Tandis que si la distance séparant les deux interlocuteurs grandie, la vitesse de communication diminuera de façon effective.

## La gestion des erreurs

Malgré les tensions imposées par la norme, il arrive qu'il y ai d'autres parasites et que des erreurs de transmission surviennent. Pour limiter ce risque, il existe une solution. Elle consiste à ajouter un **bit de parité**. Vous allez voir, c'est hyper simple ! ;)

Juste avant le bit de stop, on va ajouter un bit qui sera pair ou impair. Donc, respectivement, soit un 0 soit un 1. Lorsque l'on utilisera la voie série, si l'on choisi une parité paire, alors le nombre de niveaux logiques 1 dans les données plus le bit de parité doit donner un nombre paire. Donc, dans le cas ou il y a 5 niveaux logiques 1 sans le bit de parité, ce dernier devra prendre un niveau logique 1 pour que le nombre de 1 dans le signal soit paire. Soit 6 au total :

![Chronogramme pair](/media/galleries/954/7597ca26-4e61-4707-9c8c-cf7f9684ff01.png.960x960_q85.jpg)

Dans le cas où l'on choisirait une parité impaire, alors dans le même signal où il y a 5 niveaux logiques 1, eh bien le bit de parité devra prendre la valeur qui garde un nombre impaire de 1 dans le signal. Soit un bit de parité égal à 0 dans notre cas :

![Chronogramme impair](/media/galleries/954/d14dbffb-b92a-45a7-8c7b-8bc94d717b2d.png.960x960_q85.jpg)

Après, c'est le récepteur qui va vérifier si le nombre de niveaux logiques 1 est bien égale à ce que indique le bit de parité. Dans le cas où une erreur de transmissions serait survenu, ce sera au récepteur de traiter le problème et de demander à son interlocuteur de répéter. Au fait, ne vous inquiétez pas, on aura l'occasion de voir tout ça plus tard dans les prochains chapitres. De quoi s'occuper en somme... :diable: