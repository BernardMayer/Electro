Nous avons vu dans la partie précédente où nous faisions nos premiers pas avec Arduino, comment utiliser la carte. Nous avons principalement utilisé des LED pour communiquer à l'utilisateur (donc vous, à priori) certaines informations. Cela pouvait être une LED ou un groupe de LED qui peut indiquer tout et n'importe quoi, ou bien un afficheur 7 segments qui affiche des chiffres ou certains caractères pouvant tout aussi bien indiquer quelque chose. Tout dépend de ce que vous voulez signaler avec les moyens que vous mettez à disposition. On peut très bien imaginer un ensemble de LED ayant chacune un nom, sigle ou autre marqueur pour indiquer, selon l'état d'une ou plusieurs d'entre-elles, un mode de fonctionnement ou bien une erreur ou panne d'un système. Cependant, cette solution reste tout de même précaire et demande à l'utilisateur d'être devant le système de signalisation. Aujourd'hui, avec l'avancée de la technologie et du "tout connecté", il serait fâcheux de ne pouvoir aller plus loin. Je vais donc vous présenter un nouveau moyen de **communication** grâce à la **voie série** (ou "liaison série"), qui va vous permettre de communiquer des informations à l'utilisateur par divers intermédiaires. A la fin de la partie, vous serez capable de transmettre des informations à un ordinateur ou une autre carte Arduino.

# Transmettre des informations

Tel est le principal objectif de la communication. Mais comment transmettre des informations... et puis quelles informations ? Avec votre carte Arduino, vous aurez certainement besoin de transmettre des mesures de températures ou autres grandeurs (tension, luminosité, etc.). Ces informations pourront alimenter une base de donnée, servir dans un calcul, ou à autre chose. Tout dépendra de ce que vous en ferez.

## Émetteur et récepteur

Lorsque l'on communique des informations, il faut nécessairement un **émetteur**, qui va transmettre les informations à communiquer, et un **récepteur**, qui va recevoir les informations pour les traiter.

![Communication entre deux cartes](/media/galleries/954/2168fa25-e7e0-404b-9d83-14b6323e6409.png.960x960_q85.jpg)

Dans le cas présent, deux carte Arduino communiquent. L'une communique à l'autre tandis que l'autre réceptionne le message envoyé par la première.

[[question]]
| Pourtant, il y a deux flèches sur ton dessin. L'autre aussi, qui réceptionne le message, peut envoyer des données ?

Absolument ! Cependant, tout dépend du type de communication.

## La communication en trois cas

Pour parler, on peut par exemple différencier trois types de conversations. A chaque conversation, il n'y a que deux interlocuteurs. On ne peut effectivement pas en faire communiquer plus dans notre cas ! On dit que c'est une communication **point-à-point**.

* Le premier type serait lorsqu'un interlocuteur parle à son compère sans que celui-ci dise quoi que ce soit puisqu'il ne peut pas répondre. Il est muet et se contente d'écouter. C'est une communication à sens unilatérale, ou techniquement appelée communication **simplex**. L'un parle et l'autre écoute.
* Le deuxième type serait une conversation normale où chacun des interlocuteurs est poli et attend que l'autre est finie de parler pour parler à son tour. Il s'agit d'une communication **half-duplex**. Chaque interlocuteur parle **à tour de rôle**.
* Enfin, il y a la conversation du type "débat politique" (ce n'est évidemment pas son vrai nom ^^ ) où chaque interlocuteur parle en même temps que l'autre. Bon, cela dit, ce type de communication marche très bien (pas au sens politique, je parle au niveau technique !) et est très utilisé ! C'est une communication dite **full-duplex**.

A notre échelle, Arduino est capable de faire des communications de type full-duplex, puisqu'elle est capable de comprendre son interlocuteur tout en lui parlant en même temps.

# Le récepteur

Qu'en est-il ? Eh bien il peut s'agir, comme je le sous-entendais plus tôt, d'une autre carte Arduino. Cela étant, n'importe quel autre appareil utilisant la voie série et son **protocole de communication** pourrait communiquer avec. Cela peut être notamment un ordinateur, c'est d'ailleurs le principal interlocuteur que nous mettrons en relation avec Arduino.

[[question]]
| C'est quoi ça, un protocole de communication ?

C'est un ensemble de règles qui régissent la façon dont communiquent deux dispositifs entre eux. Cela définit par exemple le rythme de la conversation (le débit de parole des acteurs si vous préférez), l'ordre des informations envoyées (la grammaire en quelque sorte), le nombre d'informations, etc... On peut analogiquement comparer à une phrase en français, qui place le sujet, le verbe puis le complément. C'est une forme de protocole. Si je mélange tout ça, en plaçant par exemple le sujet, le complément et le verbe, cela donnerait un style parlé de maître Yoda... bon c'est moins facilement compréhensible, mais ça le reste. En revanche, deux dispositifs qui communiquent avec un protocole différent ne se comprendront pas correctement et pourraient même interpréter des actions à effectuer qui seraient à l'opposé de ce qui est demandé. Ce serait en effet dommage que votre interlocuteur "donne le chat à manger" alors que vous lui avez demandé "donne à manger au chat". ^^ Bref, si les dispositifs communiquant n'utilisent pas le bon protocole, cela risque de devenir un véritable capharnaüm !