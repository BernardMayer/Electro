Comme ce langage à l'air d'être en vogue, je me suis un peu penché dessus pour vous fournir une approche de comment utiliser python pour se servir de la voie série. Mon niveau en python étant équivalent à "grand débutant", je vais vous proposer un code simple reprenant les fonctions utiles à savoir le tout sans interface graphique. Nul doute que les pythonistes chevronnés sauront creuser plus loin :)

[[information]]
| Comme pour les exemples dans les autres langages, on utilisera l'exercice "Attention à la casse" dans l'Arduino pour tester notre programme.

Pour communiquer avec la voie série, nous allons utiliser une librairie externe qui s'appelle [pySerial](http://pyserial.sourceforge.net/).

# Installation

## Ubuntu

Pour installer pySerial sur votre une machine Ubuntu c'est très simple, il suffit de lancer une seule commande :

```bash
sudo apt-get install python3-serial
```

Vous pouvez aussi l'installer à partir des sources à l'adresse suivante : https:// pypi.python.org/pypi/pyserial . Ensuite, décompresser l'archive et exécuter la commande : (pour python 2)

```bash
python setup.py install
```

(pour python 3)

```bash
python3 setup.py install
```

## Windows

Si vous utilisez Windows, il vous faudra un logiciel capable de décompresser les archives de types tar.gz (comme 7-zip par exemple). Ensuite vous devrez récupérer les sources à la même adresse que pour Linux : https:// pypi.python.org/pypi/pyserial . Enfin, comme pour Linux encore il vous suffira d’exécuter la commande qui va bien :

```bash
python setup.py install
```

# Utiliser la librairie

Pour utiliser la librairie, il vous faudra tout d'abord l'importer. Pour cela, on utilise la commande import :

```python
import serial
```

mais comme seule une partie du module nous intéresse vraiment (Serial) on peut restreindre :

```python
from serial import Serial
```

(notez l'importance des majuscules/minuscules)

## Ouvrir un port série

Maintenant que le module est bien chargé, nous allons pouvoir commencer à l'utiliser. La première chose importante à faire est de connaître le port série à utiliser. On peut obtenir une liste de ces derniers grâce à la commande :

```bash
python -m serial.tools.list_ports
```

Si comme chez moi cela ne fonctionne pas, vous pouvez utiliser d'autres méthodes.

* Sous Windows : en allant dans le gestionnaire de périphériques pour trouver le port série concerné (COMx)
* Sous Linux : en utilisant la commande `ls /dev`, vous pourrez trouver le nom du port série sous le nom "ttyACMx" par exemple

![Le port USB de l'Arduino](/media/galleries/954/7a96ac16-5090-479e-9a69-3fdb89f89e72.png.960x960_q85.jpg)

Lorsque le port USB est identifié, on peut créer un objet de type Serial. Le constructeur que l'on va utiliser prend deux paramètres, le nom du port série et la vitesse à utiliser (les autres paramètres (parité...) conviennent par défaut).

```python
port = Serial('/dev/ttyACM0', 9600)
```

Une fois cet objet créé, la connexion peut-être ouverte avec la fonction open()

```python
port.open()
```

Pour vérifier que la voie série est bien ouverte, on utilisera la méthode "isOpen()" qui retourne un booléen vrai si la connexion est établie.

## Envoyer des données

Maintenant que la voie série est ouverte, nous allons pouvoir lui envoyer des données à traiter. Pour le bien de l'exercice, il nous faut récupérer un (des) caractère(s) à envoyer et retourner avec la casse inversée. Nous allons donc commencer par récupérer une chaîne de caractère de l'utilisateur :

```python
chaine = input("Que voulez vous transformer ? ")
```

Puis nous allons simplement l'envoyer avec la fonction "write". Cette fonction prend en paramètre un tableau de bytes. Nous allons donc transformer notre chaîne pour convenir à ce format avec la fonction python "bytes()" qui prend en paramètres la chaine de caractères et le format d'encodage.

```python
bytes(chaine, 'UTF-8')
```

Ce tableau peut directement être envoyé dans la fonction write() :

```python
port.write(bytes(chaine, 'UTF-8'))
```

## Recevoir des données

La suite logique des choses voudrait que l'on réussisse à recevoir des données. C'est ce que nous allons voir maintenant. ;) Nous allons tout d'abord vérifier que des données sont arrivées sur la voie série via la méthode inWaiting(). Cette dernière nous renvoie le nombre de caractères dans le buffer de réception de la voie série. S'il est différent de 0, cela signifie qu'il y a des données à lire. S'il y a des caractères, nous allons utiliser la fonction "read()" pour les récupérer. Cette fonction retourne les caractères (byte) un par un dans l'ordre où il sont arrivés. Un exemple de récupération de caractère pourrait-être :

```python
while(port.inWaiting() != 0):
    car = port.read() #on lit un caractère
    print(car) #on l'affiche
```
Code: Lecture des données en python

Vous en savez maintenant presque autant que moi sur la voie série en python :P ! Je suis conscient que c'est assez maigre comparé aux autres langages, mais je ne vais pas non plus apprendre tout les langages du monde :D

# Code exemple complet et commenté

```python
#!/usr/bin/python3
# -*-coding:Utf-8 -*

from serial import Serial
import time

port = Serial('/dev/ttyACM0', 9600)

port.open()

# test que le port est ouvert
if (port.isOpen()):
    # demande de la chaîne à envoyer
    chaine = input("Que voulez vous transformer ? ")
    # on écrit la chaîne en question
    port.write(bytes(chaine, 'UTF-8'))
    # attend que des données soit revenues
    while(port.inWaiting() == 0):
        # on attend 0.5 seconde pour que les données arrive
        time.sleep(0.5)

    # si on arrive là, des données sont arrivées
    while(port.inWaiting() != 0):
        # il y a des données !
        car = port.read() #on lit un caractère
        print(car) #on l'affiche
else:
    print ("Le port n'a pas pu être ouvert !")
```
Code: Code complet d'utilisation de la liaison série en python