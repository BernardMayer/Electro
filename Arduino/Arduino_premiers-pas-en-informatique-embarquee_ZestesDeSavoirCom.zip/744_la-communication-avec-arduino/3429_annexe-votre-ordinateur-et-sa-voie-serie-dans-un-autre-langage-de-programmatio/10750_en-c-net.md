[[attetion]]
| Dans cette partie (comme dans les précédentes) je pars du principe que vous connaissez le langage et avez déjà dessiné des interfaces et créé des actions sur des boutons par exemple. Cette sous-partie n'est pas là pour vous apprendre le C# !

Là encore je vais reprendre la même structure que les précédentes sous-parties.

# Les trucs utiles

## L'interface et les imports

Voici tout de suite l'interface utilisée ! Je vous donnerai juste après le nom que j'utilise pour chacun des composants (et tant qu'à faire je vous donnerai aussi leurs types).

![L'interface en C#](/media/galleries/954/c614856b-8385-43ff-bca1-4a3ce254fc7a.png.960x960_q85.jpg)

Comme cette interface est la même pour tout ce chapitre, nous retrouvons comme d'habitude le bandeau pour gérer la connexion ainsi que les deux boîtes de texte pour l'émission et la réception des données. Voici les types d'objets et leurs noms pour le bandeau de connexion :

|           Composant           |     Nom      |                      Rôle                      |
|-------------------------------|--------------|------------------------------------------------|
| System.Windows.Forms.ComboBox | comboPort    | Permet de choisir le port série                |
| System.Windows.Forms.ComboBox | comboVitesse | Permet de choisir la vitesse de communication  |
| System.Windows.Forms.Button   | btnConnexion | (Dé)Connecte la voie série (bouton "checkable")|
| System.Windows.Forms.TextBox  | boxEmission  | Nous écrirons ici le texte à envoyer           |
| System.Windows.Forms.TextBox  | boxReception | Ici apparaitra le texte à recevoir             |


Avant de commencer les choses marrantes, nous allons d'abord devoir ajouter une librairie : celle des liaisons séries. Elle se nomme simplement `using System.IO.Ports;`. Nous allons en profiter pour rajouter une variable membre de la classe de type SerialPort que j'appellerai "port". Cette variable représentera, vous l'avez deviné, notre port série !

```csharp
SerialPort port
```

Maintenant que tous les outils sont prêts, nous pouvons commencer !

## Lister les liaisons séries

La première étape sera de lister l'ensemble des liaisons séries sur l'ordinateur. Pour cela nous allons nous servir d'une fonction statique de la classe `String`. Chaque case du tableau sera une chaîne de caractère comportant le nom d'une voie série. Une fois que nous avons ce tableau, nous allons l'ajouter sur l'interface, dans la liste déroulante prévue à cet effet pour pouvoir laisser le choix à l'utilisateur au démarrage de l'application. Dans le même élan, on va peupler la liste déroulante des vitesses avec quelques-unes des vitesses les plus courantes. Voici le code de cet ensemble. Personnellement je l'ai ajouté dans la méthode `InitializeComponent()` qui charge les composants.

```csharp
private void Form1_Load(object sender, EventArgs e)
{
    // on commence par lister les voies séries présentes
    String[] ports = SerialPort.GetPortNames(); // fonction statique
    // on ajoute les ports au combo box
    foreach (String s in ports)
        comboPort.Items.Add(s);

    // on ajoute les vitesses au combo des vitesses
    comboVitesse.Items.Add("300");
    comboVitesse.Items.Add("1200");
    comboVitesse.Items.Add("2400");
    comboVitesse.Items.Add("4800");
    comboVitesse.Items.Add("9600");
    comboVitesse.Items.Add("14400");
    comboVitesse.Items.Add("19200");
    comboVitesse.Items.Add("38400");
    comboVitesse.Items.Add("57600");
    comboVitesse.Items.Add("115200");
}
```
Code: Intialisation du combobox des vitesses

Si vous lancez votre programme maintenant avec la carte Arduino connectée, vous devriez avoir le choix des vitesses mais aussi d'au moins un port série. Si ce n'est pas le cas, il faut trouver pourquoi avant de passer à la suite (Vérifiez que la carte est bien connectée par exemple).

## Gérer une connexion

Une fois que la carte est reconnue et que l'on voit bien son port dans la liste déroulante, nous allons pouvoir ouvrir le port pour établir le canal de communication entre Arduino et l'ordinateur. Comme vous vous en doutez surement, la fonction que nous allons écrire est celle du clic sur le bouton. Lorsque nous cliquons sur le bouton de connexion, deux actions peuvent être effectuées selon l'état précédent. Soit nous nous connectons, soit nous nous déconnectons. Les deux cas seront gérés en regardant le texte contenu dans le bouton ("Connecter" ou "Deconnecter"). Dans le cas de la déconnexion, il suffit de fermer le port à l'aide de la méthode `close()`. Dans le cas de la connexion, plusieurs choses sont à faire. Dans l'ordre, nous allons commencer par instancier un nouvel objet de type `BaudRate` et ainsi de suite. Voici le code commenté pour faire tout cela. Il y a cependant un dernier point évoqué rapidement juste après et sur lequel nous reviendrons plus tard.

```csharp
private void btnConnexion_Click(object sender, EventArgs e)
{
    // on gère la connexion/déconnexion
    if (btnConnexion.Text == "Connecter") // alors on connecte
    {
        // crée un nouvel objet voie série
        port = new SerialPort();
        // règle la voie série
        // parse en int le combo des vitesses
        port.BaudRate = int.Parse(comboVitesse.SelectedItem.ToString());
        port.DataBits = 8;
        port.StopBits = StopBits.One;
        port.Parity = Parity.None;
        // récupère le nom sélectionné
        port.PortName = comboPort.SelectedItem.ToString();

        // ajoute un gestionnaire de réception
        // pour la réception de donnée sur la voie série
        port.DataReceived +=
            new SerialDataReceivedEventHandler(DataReceivedHandler);

        port.Open(); // ouvre la voie série

        btnConnexion.Text = "Deconnecter";
    }
    else // sinon on déconnecte
    {
        port.Close(); // ferme la voie série
        btnConnexion.Text = "Connecter";
    }
}
```
Code: Gestion du bouton de connexion

Le point qui peut paraître étrange est la ligne 16, avec la propriété `Handler()` qui devra être appelée lorsque des données arriveront. Je vais vous demander d'être patient, nous en reparlerons plus tard lorsque nous verrons la réception de données. A ce stade du développement, lorsque vous lancez votre application vous devriez pouvoir sélectionner une voie série, une vitesse, et cliquer sur "Connecter" et "Déconnecter" sans aucun bug.

# Émettre et recevoir des données

La voie série est prête à être utilisée ! La connexion est bonne, il ne nous reste plus qu'à envoyer les données et espérer avoir quelque chose en retour. ;)

## Envoyer des données

Pour envoyer des données, une fonction toute prête existe pour les objets `char` qui serait envoyé un par un. Dans notre cas d'utilisation, c'est ce deuxième cas qui nous intéresse. Nous allons donc implémenter la méthode `TextChanged` du composant "boxEmission" afin de détecter chaque caractère entré par l'utilisateur. Ainsi, nous enverrons chaque nouveau caractère sur la voie série, un par un. Le code suivant, commenté, vous montre la voie à suivre.

```csharp
// lors d'un envoi de caractère
private void boxEmission_TextChanged(object sender, EventArgs e)
{
    // met le dernier caractère dans un tableau avec une seule case le contenant
    char[] car = new char[] {boxEmission.Text[boxEmission.TextLength-1]};
    // on s'assure que le port est existant et ouvert
    if(port!=null && port.IsOpen)
        // envoie le tableau de caractère,
        // depuis la position 0, et envoie 1 seul élément
        port.Write(car,0,1);
}
```
Code: Envoi de données

## Recevoir des données

La dernière étape pour pouvoir gérer de manière complète notre voie série est de pouvoir afficher les caractères reçus. Cette étape est un petit peu plus compliquée. Tout d'abord, revenons à l'explication commencée un peu plus tôt. Lorsque nous démarrons la connexion et créons l'objet `boxReception`. Dans l'idéal nous aimerions faire de la façon suivante :

```csharp
// gestionnaire de la réception de caractère
private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
{
    String texte = port.ReadExisting();
    boxReception.Text += texte;
}
```
Code: Réception de données

Cependant, les choses ne sont pas aussi simples cette fois-ci. En effet, pour des raisons de sécurité sur les processus, C# interdit que le texte d'un composant (`boxReception`) soit modifié de manière asynchrone, quand les données arrivent. Pour contourner cela, nous devons créer une méthode "déléguée" à qui on passera notre texte à afficher et qui se chargera d'afficher le texte quand l'interface sera prête. Pour créer cette déléguée, nous allons commencer par rajouter une méthode dite de *callback* pour gérer la mise à jour du texte. La ligne suivante est donc à ajouter dans la classe, comme membre :

```csharp
// une déléguée pour pouvoir mettre à jour le texte de la boite de réception
// de manière "thread-safe"
delegate void SetTextCallback(string text);
```

Le code de la réception devient alors le suivant :
```csharp
// gestionnaire de la réception de caractère
private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
{
    String texte = port.ReadExisting();
    // boxReception.Text += texte;
    SetText(texte);
}

private void SetText(string text)
{
    if (boxReception.InvokeRequired)
    {
        SetTextCallback d = new SetTextCallback(SetText);
        boxReception.Invoke(d, new object[] { text });
    }
    else
    {
        boxReception.Text += text;
    }
}
```
Code: Réception de données avec la déléguée

[[information]]
| Je suis désolé si mes informations sont confuses. Je ne suis malheureusement pas un maitre dans l'art des threads UI de C#. Cependant, un tas de documentation mieux expliqué existe sur internet si vous voulez plus de détails.

Une fois tout cela instancié, vous devriez avoir un terminal voie série tout beau fait par vous même ! Libre à vous maintenant toutes les cartes en main pour créer des applications qui communiqueront avec votre Arduino et feront des échanges d'informations avec.