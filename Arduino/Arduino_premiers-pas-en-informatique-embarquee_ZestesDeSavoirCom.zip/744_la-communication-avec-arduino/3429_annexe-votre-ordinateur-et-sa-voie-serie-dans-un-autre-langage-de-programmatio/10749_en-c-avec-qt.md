[[attention]]
| Avant de commencer cette sous-partie, il est indispensable de connaître la programmation en C++ et savoir utiliser le framework Qt. Si vous ne connaissez pas tout cela, vous pouvez toujours aller vous renseigner avec le [tutoriel C++](http://fr.openclassrooms.com/informatique/cours/apprenez-a-programmer-en-c) !

[[question]]
| Le C++, OK, mais pourquoi Qt ?

J'ai choisi de vous faire travailler avec Qt pour plusieurs raisons d'ordres pratiques.

* Qt est multiplateforme, donc les réfractaires à Linux (ou à Windows) pourront quand même travailler.
* Dans le même ordre d'idée, nous allons utiliser une librairie tierce pour nous occuper de la voie série. Ainsi, aucun problème pour interfacer notre matériel que l'on soit sur un système ou un autre !
* Enfin, j'aime beaucoup Qt et donc je vais vous en faire profiter :)</li>

En fait, sachez que chaque système d'exploitation à sa manière de communiquer avec les périphériques matériels. L'utilisation d'une librairie tierce nous permet donc de faire abstraction de tout cela. Sinon il m'aurait fallu faire un tutoriel par OS, ce qui, on l'imagine facilement, serait une perte de temps (écrire trois fois *environ* les mêmes choses) et vraiment galère à maintenir.

# Installer QextSerialPort

QextSerialPort est une librairie tierce réalisée par un membre de la communauté Qt. Pour utiliser cette librairie, il faut soit la compiler, soit utiliser les sources directement dans votre projet.

## 1ère étape : télécharger les sources

Le début de tout cela commence donc par récupérer les sources de la librairie. Pour cela, rendez-vous sur [la page google code](http://code.google.com/p/qextserialport/) du projet. A partir d'ici vous avez plusieurs choix. Soit vous récupérez les sources en utilisant le gestionnaire de source mercurial (Hg). Il suffit de faire un clone du dépôt avec la commande suivante :

```bash
hg clone https:// code.google.com/p/qextserialport/
```

Sinon, vous pouvez [récupérer les fichiers un par un](http://code.google.com/p/qextserialport/source/browse/#hg/src) (une dizaine). C'est plus contraignant mais ça marche aussi si vous n'avez jamais utilisé de gestionnaire de sources (mais c'est vraiment plus contraignant !)

[[attention]]
| Cette dernière méthode est vraiment **déconseillée**. En effet, vous vous retrouverez avec le strict minimum (fichiers sources sans exemples ou docs).

La manipulation est la même sous Windows ou Linux !

## Compiler la librairie

Maintenant que nous avons tous nos fichiers, nous allons pouvoir compiler la librairie. Pour cela, nous allons laisser Qt travailler à notre place.

* Démarrez QtCreator et ouvrez le fichier .pro de QextSerialPort
* Compilez...
* C'est fini !

Normalement vous avez un nouveau dossier à côté de celui des sources qui contient des exemples, ainsi que les **librairies** QExtSerialPort.

## Installer la librairie : Sous Linux

Une fois que vous avez compilé votre nouvelle librairie, vous allez devoir placer les fichiers aux bons endroits pour les utiliser. Les librairies, qui sont apparues dans le dossier "build" qui vient d'être créé, vont être déplacées vers le dossier /usr/lib. Les fichiers sources qui étaient avec le fichier ".pro" pour la compilation sont à copier dans un sous-dossier "QextSerialPort" dans le répertoire de travail de votre projet courant.

[[attention]]
| A priori il y aurait un bug avec la compilation en mode release (la librairie générée ne fonctionnerait pas correctement). Je vous invite donc à compiler aussi la debug et travailler avec.

## Installer la librairie : Sous Windows

[[erreur]]
| Ce point est en cours de rédaction, merci de patienter avant sa mise en ligne. :)

## Infos à rajouter dans le .pro

Dans votre nouveau projet Qt pour traiter avec la voie série, vous aller rajouter les lignes suivantes à votre .pro :

```text
INCLUDEPATH += QextSerialPort

CONFIG(debug, debug|release):LIBS += -lqextserialportd
else:LIBS += -lqextserialport
```
Code: Ajout au .pro

La ligne "INCLUDEPATH" représente le dossier où vous avez mis les fichiers sources de QextSerialPort. Les deux autres lignes font le lien vers les librairies copiées plus tôt (les .so ou les .dll selon votre OS).

# Les trucs utiles

## L'interface utilisée

Comme expliqué dans l'introduction, nous allons toujours travailler sur le même exercice et juste changer le langage étudié. Voici donc l'interface sur laquelle nous allons travailler, et quels sont les noms et les types d'objets instanciés :

![interface Qt](/media/galleries/954/6641281b-f49d-41f0-b0cf-91d016d1075d.png.960x960_q85.png)

Cette interface possède deux parties importantes : La **gestion de la connexion** (en haut) et **l'échange de résultat** (milieu -> émission, bas -> réception). Dans la partie supérieure, nous allons choisir le port de l’ordinateur sur lequel communiquer ainsi que la vitesse de cette communication. Ensuite, deux boîtes de texte sont présentes. L'une pour écrire du texte à émettre, et l'autre affichant le texte reçu. Voici les noms que j'utiliserai dans mon code :

|    Widget    |     Nom     |                       Rôle                     |
|--------------|-------------|------------------------------------------------|
| QComboBox    | comboPort   | Permet de choisir le port série                |
| QComboBox    | comboVitesse| Permet de choisir la vitesse de communication  |
| QButton      | btnconnexion| (Dé)Connecte la voie série (bouton "checkable")|
| QTextEdit    | boxEmission | Nous écrirons ici le texte à envoyer           |
| QTextEdit    | boxReception| Ici apparaitra le texte à recevoir             |

Table: Liste des widgets utilisé


## Lister les liaisons séries

Avant de créer et d'utiliser l'objet pour gérer la voie série, nous allons en voir quelques-uns pouvant être utiles. Tout d'abord, nous allons apprendre à obtenir la liste des ports série présents sur notre machine. Pour cela, un objet a été créé spécialement, il s'agit de `QextPortInfo`. Voici un exemple de code leur permettant de fonctionner ensemble :

```cpp
// L'objet mentionnant les infos
QextSerialEnumerator enumerateur;
// on met ces infos dans une liste
QList<QextPortInfo> ports = enumerateur.getPorts();
```
Code: Récuperation de la liste des ports séries

Une fois que nous avons récupéré une énumération de tous les ports, nous allons pouvoir les ajouter au combobox qui est censé les afficher (comboPort). Pour cela on va parcourir la liste construite précédemment et ajouter à chaque fois une item dans le menu déroulant :

```cpp
// on parcourt la liste des ports
for(int i=0; i<ports.size(); i++)
   ui->ComboPort->addItem(ports.at(i).physName);
```
Code: Remplissage du combobox des ports séries

[[attention]]
| Les ports sont nommés différemment sous Windows et Linux, ne soyez donc pas surpris avec mes captures d'écrans, elles viennent toutes de Linux.

Une fois que la liste des ports est faite (attention, certains ports ne sont connectés à rien), on va construire la liste des vitesses, pour se laisser le choix le jour où l'on voudra faire une application à une vitesse différente. Cette opération n'est pas très compliquée puisqu'elle consiste simplement à ajouter des items dans la liste déroulante "comboVitesse".

```cpp
ui->comboVitesse->addItem("300");
ui->comboVitesse->addItem("1200");
ui->comboVitesse->addItem("2400");
ui->comboVitesse->addItem("4800");
ui->comboVitesse->addItem("9600");
ui->comboVitesse->addItem("14400");
ui->comboVitesse->addItem("19200");
ui->comboVitesse->addItem("38400");
ui->comboVitesse->addItem("57600");
ui->comboVitesse->addItem("115200");
```
Code: Remplissage du combobox des vitesses

Votre interface est maintenant prête. En la démarrant maintenant vous devriez être en mesure de voir s'afficher les noms des ports séries existant sur l'ordinateur ainsi que les vitesses. Un clic sur le bouton ne fera évidemment rien puisque son comportement n'est pas encore implémenté.

## Gérer une connexion<

Lorsque tous les détails concernant l'interface sont terminés, nous pouvons passer au cœur de l'application : la *communication série*. La première étape pour pouvoir faire une communication est de se connecter (tout comme vous vous connectez sur une borne WiFi avant de communiquer et d'échanger des données avec cette dernière). C'est le rôle de notre bouton de connexion. A partir du système de slot automatique, nous allons créer une fonction qui va recevoir le clic de l'utilisateur. Cette fonction instanciera un objet QextSerialPort pour créer la communication, règlera cet objet et enfin ouvrira le canal. Dans le cas où le bouton était déjà coché (puisqu'il sera "checkable" rappelons-le) nous ferons la déconnexion, puis la destruction de l'objet QextSerialPort créé auparavant. Pour commencer nous allons donc déclarer les objets et méthodes utiles dans le .h de la classe avec laquelle nous travaillons :

```cpp
private:
// l'objet représentant le port
QextSerialPort * port;

// une fonction utile que j'expliquerais après
BaudRateType getBaudRateFromString(QString baudRate);

private slots:
// le slot automatique du bouton de connexion
void on_btnconnexion_clicked();
```

Ensuite, il nous faudra instancier le slot du bouton afin de traduire un comportement. Pour rappel, il devra :

* Créer l'objet "port" de type QextSerialPort
* Le régler avec les bons paramètres
* Ouvrir la voie série

Dans le cas où la voie série est déjà ouverte (le bouton est déjà appuyé) on devra la fermer et détruire l'objet. Voici le code commenté permettant l'ouverture de la voie série (quelques précisions viennent ensuite) :

```cpp
// Slot pour le click sur le bouton de connexion
void Fenetre::on_btnconnexion_clicked() {
    // deux cas de figures à gérer,
    // soit on coche (connecte), soit on décoche (déconnecte)

    // on coche -> connexion
    if(ui->btnconnexion->isChecked()) {
        // on essaie de faire la connexion avec la carte Arduino
        // on commence par créer l'objet port série
        port = new QextSerialPort();
        // on règle le port utilisé (sélectionné dans la liste déroulante)
        port->setPortName(ui->ComboPort->currentText());
        // on règle la vitesse utilisée
        port->setBaudRate(
            getBaudRateFromString(ui->comboVitesse->currentText()));
        // quelques règlages pour que tout marche bien
        port->setParity(PAR_NONE);// parité
        port->setStopBits(STOP_1);// nombre de bits de stop
        port->setDataBits(DATA_8);// nombre de bits de données
        port->setFlowControl(FLOW_OFF);// pas de contrôle de flux
        // on démarre !
        port->open(QextSerialPort::ReadWrite);
        // change le message du bouton
        ui->btnconnexion->setText("Deconnecter");

        // on fait la connexion pour pouvoir obtenir les évènements
        connect(port,SIGNAL(readyRead()), this, SLOT(readData()));
        connect(ui->boxEmission,SIGNAL(textChanged()),this,SLOT(sendData()));
    }
    else {
        // on se déconnecte de la carte Arduino
        port->close();
        // puis on détruit l'objet port série devenu inutile
        delete port;
        ui->btnconnexion->setText("Connecter");
    }
}
```
Code: Gestion du bouton de connexion

Ce code n'est pas très compliqué à comprendre. Cependant quelques points méritent votre attention. Pour commencer, pour régler la vitesse du port série on fait appel à la fonction "setBaudRate". Cette fonction prend un paramètre de type BaudRateType qui fait partie d'une énumération de QextSerialPort. Afin de faire le lien entre le comboBox qui possède des chaines et le type particulier attendu, on crée et utilise la fonction "getBaudRateFromString". A partir d'un simple `BaudRateType`.

```cpp
BaudRateType Fenetre::getBaudRateFromString(QString baudRate) {
    int vitesse = baudRate.toInt();
    switch(vitesse) {
        case(300):return BAUD300;
        case(1200):return BAUD1200;
        case(2400):return BAUD2400;
        case(4800):return BAUD4800;
        case(9600):return BAUD9600;
        case(14400):return BAUD14400;
        case(19200):return BAUD19200;
        case(38400):return BAUD38400;
        case(57600):return BAUD57600;
        case(115200):return BAUD115200;
        default:return BAUD9600;
    }
}
```
Code: Gestion du changement de vitesse

Un autre point important à regarder est l'utilisation de la fonction open() de l'objet QextSerialPort. En effet, il existe plusieurs façons d'ouvrir un port série :

* En lecture seule $\to$ QextSerialPort::ReadOnly
* En écriture seule $\to$ QextSerialPort::WriteOnly
* En lecture/écriture $\to$ QextSerialPort::ReadWrite

Ensuite, on connecte simplement les signaux émis par la voie série et par la boite de texte servant à l'émission (que l'on verra juste après). Enfin, lorsque l'utilisateur re-clic sur le bouton, on passe dans le `NULL`.

[[attention]]
| Ce code présente le principe et n'est pas parfait ! Il faudrait par exemple s'assurer que le port est bien ouvert avant d'envoyer des données (faire un test `if(port->isOpen())` par exemple).

# Émettre et recevoir des données

Maintenant que la connexion est établie, nous allons pouvoir envoyer et recevoir des données. Ce sera le rôle de deux slots qui ont été brièvement évoqués dans la fonction `connect()` du code de connexion précédent.

## Émettre des données

L'émission des données se fera dans le slot "sendData". Ce slot sera appelé à chaque fois qu'il y aura une modification du contenu de la boîte de texte "boxEmission". Pour l'application concernée (l'envoi d'un seul caractère), il nous suffit de chercher le dernier caractère tapé. On récupère donc le dernier caractère du texte contenu dans la boite avant de l'envoyer sur la voie série. L'envoi de texte se fait à partir de la fonction `toAscii()` et on peut donc les utiliser directement. Voici le code qui illustre toutes ces explications (ne pas oublier de mettre les déclarations des slots dans le .h) :

```cpp
void Fenetre::sendData() {
    // On récupère le dernier caractère tapé
    QString caractere = ui->boxEmission->toPlainText().right(1);
    // si le port est instancié (donc ouvert a priori)
    if(port != NULL)
        port->write(caractere.toAscii());
}
```
Code: Envoi de données

## Recevoir des données

Le programme étudié est censé nous répondre en renvoyant le caractère émis mais dans une *casse opposée* (majuscule contre minuscule et vice versa). En temps normal, deux politiques différentes s'appliquent pour savoir si des données sont arrivées. La première est d'aller voir de manière régulière (ou pas) si des caractères sont présents dans le tampon de réception de la voie série. Cette méthode dite de *Polling n'est pas très fréquemment utilisée. La seconde est de déclencher un évènement lorsque des données arrivent sur la voie série. C'est la forme qui est utilisée par défaut par l'objet `readyRead()`) est émis par l'objet et peut donc être connecté à un slot. Pour changer le mode de fonctionnement, il faut utiliser la méthode `QextSerialPort::EventDriven` pour la seconde (par défaut). Comme la connexion entre le signal et le slot est créée dans la fonction de connexion, il ne nous reste qu'à écrire le comportement du slot de réception lorsqu'une donnée arrive. Le travail est simple et se résume en deux étapes :

* Lire le caractère reçu grâce à la fonction `QextSerialPort`
* Le copier dans la boite de texte "réception"

```cpp
void Fenetre::readData() {
    QByteArray array = port->readAll();
    ui->boxReception->insertPlainText(array);
}
```
Code: Réception de données

Et voilà, vous êtes maintenant capable de travailler avec la voie série dans vos programmes Qt en C++. Au risque de me répéter, je suis conscient qu'il y a des lacunes en terme de "sécurité" et d'efficacité. Ce code a pour but de vous montrer les bases de la classe pour que vous puissiez continuer ensuite votre apprentissage. En effet, la programmation C++/Qt n'est pas le sujet de ce tutoriel. :ninja: Nous vous serons donc reconnaissants de ne pas nous harceler de commentaires relatifs au tuto pour nous dire "bwaaaa c'est mal codéééééé". Merci ! :)