Le titre est piégeur, en effet, cela peut être l'Arduino qui envoie des données ou l'ordinateur. Bon, on est pas non plus dénué d'une certaine logique puisque pour envoyé des données à partir de l'ordinateur vers la carte Arduino il suffit d'ouvrir le terminal série et de taper le texte dedans ! :P Donc, on va bien programmer et voir comment faire pour que votre carte Arduino envoie des données à l'ordinateur.

[[question]]
| Et ces données, elles proviennent d'où ?

Eh bien de la carte Arduino... En fait, lorsque l'on utilise la voie série pour transmettre de l'information, c'est qu'on en a de l'information à envoyer, sinon cela ne sert à rien. Ces informations proviennent généralement de capteurs connectés à la carte ou de son programme (par exemple la valeur d'une variable). La carte Arduino traite les informations provenant de ces capteurs, s'il faut elle adapte ces informations, puis elle les transmet. On aura l'occasion de faire ça dans la partie dédiée aux capteurs, comme afficher la température sur son écran, l'heure, le passage d'une personne, etc.

# Appréhender l'objet Serial

Dans un premier temps, nous allons utiliser l'objet Serial pour tester quelques envois de données. Puis nous nous attèlerons à un petit exercice que vous ferez seul ou presque, du moins vous aurez eu auparavant assez d'informations pour pouvoir le réaliser (ben oui, sinon c'est plus un exercice !).

## Phrase ? Caractère ?

On va commencer par envoyer un caractère et une phrase. À ce propos, savez-vous quelle est la correspondance entre un caractère et une phrase ? Une phrase est constituée de caractères les uns à la suite des autres. En programmation, on parle plutôt de **chaine caractères** pour désigner une phrase.

* Un caractère seul s'écrit entre guillemets simples : 'A', 'a', '2', '!', ...
* Une phrase est une suite de caractère et s'écrit entre guillemets doubles : "Salut tout le monde", "J'ai 42 ans", "Vive Clem' !"

[[information]]
| Pour vous garantir un succès dans le monde de l'informatique, essayez d'y penser et de respecter cette convention, écrire 'A' ce n'est pas pareil qu'écrire "A" !

## `println()`

La fonction que l'on va utiliser pour débuter, s'agit de `println()`. Ces deux fonctions sont quasiment identiques, mais à quoi servent-elles ?

* `print()` : cette fonction permet d'envoyer des données sur la voie série. On peut par exemple envoyer un caractère, une chaine de caractère ou d'autres données dont je ne vous ai pas encore parlé.
* `println()` : c'est la même fonction que la précédente, elle permet simplement un retour à la ligne à la fin du message envoyé.

Pour utiliser ces fonctions, rien de plus simple :

```cpp
Serial.print("Salut ca zeste ?!");
```

Bien sûr, au préalable, vous devrez avoir "déclaré/créé" votre objet Serial et définis une valeur de vitesse de communication :

```cpp
void setup()
{
    // création de l'objet Serial
    // (=établissement d'une nouvelle communication série)
    Serial.begin(9600);
    // envoie de la chaine "Salut ca zeste ?!" sur la voie série
    Serial.print("Salut ca zeste ?!");
}
```
Code: Envoi d'un message simple via la liaison série

Cet objet, parlons-en. Pour vous aider à représenter de façon plus concise ce qu'est l'objet Serial, je vous propose cette petite illustration de mon cru :

![L'objet Serial](/media/galleries/954/4dad771f-d51c-445e-9ed0-11ec7fcfd271.png.960x960_q85.jpg)

Comme je vous le présente, l'objet Serial est muni d'un panel de fonctions qui lui sont propres. Cet objet est capable de réaliser ces fonctions selon ce que le programme lui ordonne de faire. Donc, par exemple, quand j'écris : `print()` en lui passant pour paramètre la chaine de caractère : "Salut ca zeste ?!". On peut compléter le code précédent comme ceci :

```cpp
void setup()
{
    Serial.begin(9600);

    // l'objet exécute une première fonction
    Serial.print("Salut ca zeste ?!");
    // puis une deuxième fonction, différente cette fois-ci
    Serial.println("Vive Clem' !");
    // et exécute à nouveau la même
    Serial.println("Cette phrase passe en dessous des deux precedentes");
}
```

Sur le terminal série, on verra ceci :

```bash
Salut ca zeste ?! Vive Clem' !
Cette phrase passe en dessous des deux precedentes
```

# La fonction `print()` en détail

Après cette courte prise en main de l'objet Serial, je vous propose de découvrir plus en profondeur les surprises que nous réserve la fonction `print()`.

[[information]]
| Petite précision, je vais utiliser de préférence `print()`.

Résumons un peu ce que nous venons d'apprendre : on sait maintenant envoyer des caractères sur la voie série et des phrases. C'est déjà bien, mais ce n'est qu'un très bref aperçu de ce que l'on peut faire avec cette fonction.

## Envoyer des nombres

Avec la fonction `print()`, il est aussi possible d'envoyer des chiffres ou des nombres car ce sont des caractères :

```cpp
void setup()
{
    Serial.begin(9600);

    Serial.println(9);            // chiffre
    Serial.println(42);           // nombre
    Serial.println(32768);        // nombre
    Serial.print(3.1415926535);   // nombre décimale
}
```

```bash
9
42
32768
3.14
```

[[question]]
| Tiens, le nombre pi n'est pas affiché complètement ! C'est quoi le bug ? o_O

Rassurez-vous, ce n'est ni un bug, ni un oubli inopiné de ma part. ^^ En fait, pour les nombres décimaux, la fonction `print()` affiche par défaut seulement deux chiffres après la virgule. C'est la valeur par défaut et heureusement elle est modifiable. Il suffit de rajouter le nombre de décimales que l'on veut afficher :

```cpp
void setup()
{
    Serial.begin(9600);

    Serial.println(3.1415926535, 0);
    Serial.println(3.1415926535, 2); // valeur par défaut
    Serial.println(3.1415926535, 4);
    Serial.println(3.1415926535, 10);
}
```

```cpp
3
3.14
3.1415
3.1415926535
```

## Envoyer la valeur d'une variable

Là encore, on utilise toujours la même fonction (qu'est-ce qu'elle polyvalente !). Ici aucune surprise. Au lieu de mettre un caractère ou un nombre, il suffit de passer la variable en paramètre pour qu'elle soit ensuite affichée à l'écran :

```cpp
int variable = 512;
char lettre = 'a';

void setup()
{
    Serial.begin(9600);

    Serial.println(variable);
    Serial.print(lettre);
}
```

```bash
512
a
```

Trop facile n'est-ce pas ?

## Envoyer d'autres données

Ce n'est pas fini, on va terminer notre petit tour avec les types de variables que l'on peut transmettre grâce à cette fonction `print()` sur la voie série. Prenons l'exemple d'un nombre choisi judicieusement : 65.

[[question]]
| Pourquoi ce nombre en particulier ? Et pourquoi pas 12 ou 900 ?

Eh bien, c'est relatif à la **table ASCII** que nous allons utiliser dans un instant.

[[information]]
| Tout d'abord, petit cours de prononciation, ASCII se prononce comme si on disait "A ski", on a donc : "la table à ski" en prononciation phonétique.

La table ASCII, de l'américain "**A**merican **S**tandard **C**ode for **I**nformation **I**nterchange", soit en bon français : "Code américain normalisé pour l'échange d'information" est, selon Wikipédia :

> "la norme de codage de caractères en informatique la plus connue, la plus ancienne et la plus largement compatible"
Source:Wikipédia

En somme, c'est un tableau de valeurs codées sur 8bits qui à chaque valeur associent un caractère. Ces caractères sont les lettres de l'alphabet en minuscule et majuscule, les chiffres, des caractères spéciaux et des symboles bizarres. Dans cette table, il y a plusieurs colonnes avec la valeur décimale, la valeur hexadécimale, la valeur binaire et la valeur octale parfois. Nous n'aurons pas besoin de tout ça, mais pour votre culture voici une table ASCII étendu (0 à 255).

![Table ASCII étendu](http://zestedesavoir.com/media/galleries/954/bf46888c-372d-4e10-8637-aac905290822.png.960x960_q85.jpg)
Figure: Table ASCII étendu - (CC-BY-SA, [Yuriy Arabskyy](http://commons.wikimedia.org/wiki/File:Ascii-codes-table.png))

Revenons à notre exemple, le nombre 65. C'est en effet grâce à la table ASCII que l'on sait passer d'un nombre à un caractère, car rappelons-le, dans l'ordinateur tout est traité sous forme de nombre en base 2 (binaire). Donc lorsque l'on code :

```cpp
maVariable = 'A';
// l'ordinateur stocke la valeur 65 dans sa mémoire (cf. table ASCII)
```

Si vous faites ensuite :

```cpp
maVariable = maVariable + 1;
// la valeur stockée passe à 66 (= 65 + 1)

// à l'écran, on verra s'afficher la lettre "B"
```

[[information]]
| Au début, on trouvait une seule table ASCII, qui allait de 0 à 127 (codée sur 7bits) et représentait l'alphabet, les chiffres arabes et quelques signes de ponctuation. Depuis, de nombreuses tables dites "étendues" sont apparues et vont de 0 à 255 caractères (valeurs maximales codables sur un type *char* qui fait 8 bits).

[[question]]
| Et que fait-on avec la fonction print() et cette table ?

Là est tout l'intérêt de la table, on peut envoyer des données, avec la fonction print(), de tous types ! En binaire, en hexadécimal, en octal et en décimal.

```cpp
void setup()
{
    Serial.begin(9600);

    Serial.println(65, BIN); // envoie la valeur 1000001
    Serial.println(65, DEC); // envoie la valeur 65
    Serial.println(65, OCT); // envoie la valeur 101 (ce n'est pas du binaire !)
    Serial.println(65, HEX); // envoie la valeur 41
}
```
Code: Différents moyens d'afficher la même information

Vous pouvez donc manipuler les données que vous envoyez à travers la voie série ! C'est là qu'est l’avantage de cette fonction.

# Exercice : Envoyer l'alphabet

## Objectif

Nous allons maintenant faire un petit exercice, histoire de s’entraîner à envoyer des données. Le but, tout simple, est d'envoyer l'ensemble des lettres de l'alphabet de manière *la plus intelligente* possible, autrement dit, sans écrire 26 fois "print();"... La fonction setup restera la même que celle vue précédemment. Un délai de 250 ms est attendu entre chaque envoi de lettre et un delay de 5 secondes est attendu entre l'envoi de deux alphabets.

[[information]]
| Bon courage !

## Correction

Bon j’espère que tout c'est bien passé et que vous n'avez pas joué au roi du copier/coller en me mettant 26 print...

[[secret]]
| ```cpp
| void loop()
| {
|   char i = 0;
|   char lettre = 'a'; // ou 'A' pour envoyer en majuscule
|
|   // petit message d'accueil
|   Serial.println("------  L'alphabet des Zesteurs  ------");
|
|   // on commence les envois
|   for(i=0; i<26; i++)
|   {
|       Serial.print(lettre); // on envoie la lettre
|       lettre = lettre + 1; // on passe à la lettre suivante
|       delay(250); // on attend 250ms avant de réenvoyer
|    }
|   Serial.println(""); // on fait un retour à la ligne
|
|    delay(5000); // on attend 5 secondes avant de renvoyer l'alphabet
| }
| ```
| Code: Exercice d'écriture de l'alphabet

Si l'exercice vous a paru trop simple, vous pouvez essayer d'envoyer l'alphabet à l'envers, ou l'alphabet minuscule ET majuscule ET les chiffres de 0 à 9... Amusez-vous bien ! ;)