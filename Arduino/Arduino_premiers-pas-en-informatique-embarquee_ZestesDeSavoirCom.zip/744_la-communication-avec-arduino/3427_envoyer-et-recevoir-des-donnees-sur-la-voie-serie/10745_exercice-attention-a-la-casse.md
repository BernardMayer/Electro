# Consigne

Le but de cet exercice est très simple. L'utilisateur saisit un caractère à partir de l'ordinateur et si ce caractère est minuscule, il est renvoyé en majuscule ; s'il est majuscule il est renvoyé en minuscule. Enfin, si le caractère n'est pas une lettre on se contente de le renvoyer normalement, tel qu'il est. Voilà le résultat de mon programme :

->!(https://www.youtube.com/watch?v=9i-gfmQu2Cc)<-

# Correction

Je suppose que grâce au superbe tutoriel qui précède vous avez déjà fini sans problème, n'est-ce pas ? :P

## La fonction `setup()` et les variables utiles

Une fois n'est pas coutume, on va commencer par énumérer les variables utiles et le contenu de la fonction `setup()`. Pour ce qui est des variables globales, on n'en retrouve qu'une seule, "carlu". Cette variable de type `int` sert à stocker le caractère lu sur le buffer de la carte Arduino. Puis on démarre une nouvelle voie série à 9600bauds :

[[secret]]
|```cpp
|int carlu; // stock le caractère lu sur la voie série
|
|void setup()
|{
|    Serial.begin(9600);
|}
|```
|Code: Exercice, le `setup`

## Le programme

Le programme principal n'est pas très difficile non plus. Il va se faire en trois temps.

* Tout d'abord, on boucle jusqu'à recevoir un caractère sur la voie série
* Lorsqu'on a reçu un caractère, on regarde si c'est une lettre
* Si c'est une lettre, on renvoie son acolyte majuscule ; sinon on renvoie simplement le caractère lu

Voici le programme décrivant ce comportement :

[[secret]]
|```cpp
|void loop()
|{
|    // on commence par vérifier si un caractère est disponible dans le buffer
|    if(Serial.available() > 0)
|    {
|        carlu = Serial.read(); // lecture du premier caractère disponible
|
|        // Est-ce que c'est un caractère minuscule ?
|        if(carlu >= 'a' && carlu <= 'z')
|        {
|            carlu = carlu - 'a'; // on garde juste le "numéro de lettre"
|            carlu = carlu + 'A'; // on passe en majuscule
|        }
|        // Est-ce que c'est un caractère MAJUSCULE ?
|        else if(carlu >= 'A' && carlu <= 'Z')
|        {
|            carlu = carlu - 'A'; // on garde juste le "numéro de lettre"
|            carlu = carlu + 'a'; // on passe en minuscule
|        }
|        // ni l'un ni l'autre on renvoie en tant que BYTE
|        // ou alors on renvoie le caractère modifié
|        Serial.write(carlu);
|    }
|}
|```
|Code: Exercice, la `loop`

Je vais maintenant vous expliquer les parties importantes de ce code. Comme vu dans le cours, la ligne 4 va nous servir à attendre un caractère sur la voie série. Tant qu'on ne reçoit rien, on ne fait rien ! Sitôt que l'on reçoit un caractère, on va chercher à savoir si c'est une lettre. Pour cela, on va faire deux tests. L'un est à la ligne 8 et l'autre à la ligne 13. Ils se présentent de la même façon : **SI** le caractère lu à une valeur supérieure ou égale à la lettre `'a'` (ou `'A'`) **ET** inférieure ou égale à la lettre `'z'` (`'Z'`), alors on est en présence d'une lettre. Sinon, c'est autre chose, donc on se contente de passer au renvoi du caractère lu ligne 21. Une fois que l'on a détecté une lettre, on effectue quelques transformations afin de changer sa casse. Voici les explications à travers un exemple :

->

|        Description       | Opération (lettre) | Opération (nombre) | Valeur de carlu |
|--------------------------|--------------------|--------------------|-----------------|
| On récupère la lettre `'e'`| e                  | 101                | `'e'`             |
| On isole son numéro de lettre en lui enlevant la valeur de 'a' | e-a | 101-97 | 4    |
| On ajoute ce nombre à la lettre `'A'` | A + (e-a) | 65 + (101-97) = 69| `'E'`            |
| Il ne suffit plus qu'à retourner cette lettre | E | 69 | `E`                         |

<-

On effectuera sensiblement les mêmes opérations lors du passage de majuscule à minuscule.

[[information]]
| A la ligne 22, j'utilise la fonction `write()` qui envoie le caractère en tant que variable de type *byte*, signifiant que l'on renvoie l'information sous la forme d'un seul octet. Sinon Arduino enverrait le caractère en tant que 'int', ce qui donnerait des problèmes lors de l'affichage.