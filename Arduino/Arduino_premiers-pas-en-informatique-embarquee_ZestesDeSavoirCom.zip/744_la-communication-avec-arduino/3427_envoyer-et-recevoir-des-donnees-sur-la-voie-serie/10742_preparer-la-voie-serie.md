Notre objectif, pour le moment, est de communiquer des informations de la carte Arduino vers l'ordinateur et inversement. Pour ce faire, on va d’abord devoir préparer le terrain.

# Du côté de l'ordinateur

Pour pouvoir utiliser la communication de l'ordinateur, rien de plus simple. En effet, L'environnement de développement Arduino propose de base un outil pour communiquer. Pour cela, il suffit de cliquer sur le bouton ![Icône de la voie série](/media/galleries/954/6cc4ffff-816f-4184-8ea1-82934ff4dc7b.png.960x960_q85.jpg) (pour les versions antérieures à la version 1.0) dans la barre de menu pour démarrer l'outil. Pour la version 1.0, l’icône a changé et de place et de visuel :

![Sélection moniteur série](/media/galleries/954/ed4fadc6-0f42-4736-b9e1-ca2b655003fd.png.960x960_q85.jpg)

Une nouvelle fenêtre s'ouvre : c'est le **terminal série** :

->![Voie série, vitesse](/media/galleries/954/1d1f0ef0-9a91-4d1e-8218-a1bc97a8bdcf.png.960x960_q85.jpg)<-

Dans cette fenêtre, vous allez pouvoir envoyer des messages sur la voie série de votre ordinateur (qui est émulée[^emule] par l'Arduino) ; recevoir les messages que votre Arduino vous envoie ; et régler deux trois paramètres tels que la vitesse de communication avec l'Arduino et l'autoscroll qui fait défiler le texte automatiquement. On verra plus loin à quoi sert le dernier réglage.

# Du côté du programme

## L'objet *Serial*

Pour utiliser la voie série et communiquer avec notre ordinateur (par exemple), nous allons utiliser un *objet* (une sorte de variable mais plus évoluée) qui est intégré nativement dans l'ensemble Arduino : l'objet **Serial**.

[[information]]
| Pour le moment, *considérez qu'un objet est une variable évoluée qui peut exécuter plusieurs fonctions*. On verra (beaucoup) plus loin ce que sont réellement des objets. On apprendra à en créer et à les utiliser lorsque l'on abordera le logiciel [Processing](http://processing.org/).

Cet objet rassemble des informations (vitesse, bits de données, etc.) et des fonctions (envoi, lecture de réception,...) sur ce qu'est une voie série pour Arduino. Ainsi, pas besoin pour le programmeur de recréer tous le protocole (sinon on aurait du écrire nous même TOUT le protocole, tel que "Ecrire un bit haut pendant 1 ms, puis 1 bit bas pendant 1 ms, puis le caractère 'a' en 8 ms...), bref, on gagne un temps fou et on évite les bugs !

## Le setup

Pour commencer, nous allons donc initialiser l'objet Serial. Ce code sera à copier à chaque fois que vous allez créer un programme qui utilise la voie série. Le logiciel Arduino à prévu, dans sa *bibliothèque Serial*, tout un tas de fonctions qui vont nous êtres très utiles, voir même indispensables afin de bien utiliser la voie série. Ces fonctions, je vous les laisse découvrir par vous même si vous le souhaitez, elles se trouvent sur [cette page](http://arduino.cc/en/Reference/Serial). Dans le but de créer une communication entre votre ordinateur et votre carte Arduino, il faut déclarer cette nouvelle communication et définir la vitesse à laquelle ces deux dispositifs vont communiquer. Et oui, si la vitesse est différente, l'Arduino ne comprendra pas ce que veut lui transmettre l'ordinateur et vice versa ! Ce réglage va donc se faire dans la fonction setup, en utilisant la fonction `begin()` de l'objet Serial.

[[information]]
| Lors d'une communication informatique, une vitesse s'exprime en bits par seconde ou **bauds**. Ainsi, pour une vitesse de 9600 bauds on enverra jusqu'à 9600 '0' ou '1' en une seule seconde. Les vitesses les plus courantes sont 9600, 19200 et 115200 bits par seconde.

```cpp
void setup()
{
    // on démarre la liaison
    // en la réglant à une vitesse de 9600 bits par seconde.
    Serial.begin(9600);
}
```
Code: Démarrage de la liaison série


À présent, votre carte Arduino a ouvert une nouvelle communication vers l'ordinateur. Ils vont pouvoir communiquer ensemble.

[^emule]: créée de façon fictive