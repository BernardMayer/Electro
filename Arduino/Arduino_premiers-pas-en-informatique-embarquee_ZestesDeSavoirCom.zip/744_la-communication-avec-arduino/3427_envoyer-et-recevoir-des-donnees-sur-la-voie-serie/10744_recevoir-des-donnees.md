Cette fois, il s'agit de l'Arduino qui reçoit les données que nous, utilisateur, allons transmettre à travers le terminal série. Je vais prendre un exemple courant : une communication téléphonique. En règle générale, on dit "Hallo" pour dire à l'interlocuteur que l'on est prêt à écouter le message. Tant que la personne qui appelle n'a pas cette confirmation, elle ne dit rien (ou dans ce cas elle fait un monologue ^^ ). Pareillement à cette conversion, l'objet Serial dispose d'une fonction pour "écouter" la voie série afin de savoir si oui ou non il y a une communication de données.

# Réception de données

## On m'a parlé ?

Pour vérifier si on a reçu des données, on va régulièrement interroger la carte pour lui demander si des données sont disponibles dans son **buffer de réception**. Un buffer est une zone mémoire permettant de stocker des données sur un cours instant. Dans notre situation, cette mémoire est dédiée à la réception sur la voie série. Il en existe un aussi pour l'envoi de donnée, qui met à la queue leu leu les données à envoyer et les envoie dès que possible. En résumé, un buffer est une sorte de salle d'attente pour les données. Je disais donc, nous allons régulièrement vérifier si des données sont arrivées. Pour cela, on utilise la fonction `available()` (de l'anglais "disponible") de l'objet Serial. Cette fonction renvoie le nombre de caractères dans le buffer de réception de la voie série. Voici un exemple de traitement :

```cpp
void loop()
{
    // lecture du nombre de caractères disponibles dans le buffer
    int donneesALire = Serial.available();
    if(donneesALire > 0) // si le buffer n'est pas vide
    {
        // Il y a des données, on les lit et on fait du traitement
    }
    // on a fini de traiter la réception ou il n'y a rien à lire
}
```
Code: Lecture simple de données sur la voie série

[[information]]
| Cette fonction de l'objet Serial, available(), renvoie la valeur -1 quand il n'y a rien à lire sur le buffer de réception.

## Lire les données reçues

Une fois que l'on sait qu'il y a des données, il faut aller les lire pour éventuellement en faire quelque chose. La lecture se fera tout simplement avec la fonction... read() ! Cette fonction renverra le premier caractère arrivé non traité (comme un supermarché traite la première personne arrivée dans la file d'attente de la caisse avant de passer au suivant). On accède donc *caractère par caractère* aux données reçues. Ce type de fonctionnement est appelé FIFO (First In First Out, premier arrivé, premier traité). Si jamais rien n'est à lire (personne dans la file d'attente), je le disais, la fonction renverra -1 pour le signaler.

```cpp
void loop()
{
    // on lit le premier caractère non traité du buffer
    char choseLue = Serial.read();

    if(choseLue == -1) // si le buffer est vide
    {
        // Rien à lire, rien lu
    }
    else // le buffer n'est pas vide
    {
        // On a lu un caractère
    }
}
```
Code: Lecture simple de données sur la voie série sans `available`

Ce code est une façon simple de se passer de la fonction available().

## Le serialEvent

Si vous voulez éviter de mettre le test de présence de données sur la voie série dans votre code, Arduino a rajouter une fonction qui s'exécute de manière régulière. Cette dernière se lance régulièrement avant chaque redémarrage de la loop. Ainsi, si vous n'avez pas besoin de traiter les données de la voie série à un moment précis, il vous suffit de rajouter cette fonction. Pour l'implémenter c'est très simple, il suffit de mettre du code dans une fonction nommé `serialEvent()` (attention à la casse) qui sera a rajouté en dehors du setup et du loop. Le reste du traitement de texte se fait normalement, avec `Serial.read()` par exemple. Voici un exemple de squelette possible :

```cpp
const int maLed = 11; // on met une LED sur la broche 11

void setup()
{
    pinMode(maLed, OUTPUT); // la LED est une sortie
    digitalWrite(maLed, HIGH); // on éteint la LED
    Serial.begin(9600); // on démarre la voie série
}

void loop()
{
    delay(500); // fait une petite pause
    // on ne fait rien dans la loop
    digitalWrite(maLed, HIGH); // on éteint la LED

}

void serialEvent() // déclaration de la fonction d'interruption sur la voie série
{
    // lit toutes les données (vide le buffer de réception)
    while(Serial.read() != -1);

    // puis on allume la LED
    digitalWrite(maLed, LOW);
}
```
Code: Utilisation de `serialEvent` pour tester la présence de données

# Exemple de code complet

Voici maintenant un exemple de code complet qui va aller lire les caractères présents dans le buffer de réception s'il y en a et les renvoyer tels quels à l’expéditeur (mécanisme d’écho).

```cpp
void setup()
{
    Serial.begin(9600);
}

void loop()
{
    // variable contenant le caractère à lire
    char carlu = 0;
    // variable contenant le nombre de caractère disponibles dans le buffer
    int cardispo = 0;

    cardispo = Serial.available();

    while(cardispo > 0) // tant qu'il y a des caractères à lire
    {
        carlu = Serial.read(); // on lit le caractère
        Serial.print(carlu); // puis on le renvoi à l’expéditeur tel quel
        cardispo = Serial.available(); // on relit le nombre de caractères dispo
    }
    // fin du programme
}
```
Code: Code complet pour faire un *echo* avec la liaison série

Avouez que tout cela n'était pas bien difficile. Je vais donc en profiter pour prendre des vacances et vous laisser faire un exercice qui demande un peu de réflexion. :diable: