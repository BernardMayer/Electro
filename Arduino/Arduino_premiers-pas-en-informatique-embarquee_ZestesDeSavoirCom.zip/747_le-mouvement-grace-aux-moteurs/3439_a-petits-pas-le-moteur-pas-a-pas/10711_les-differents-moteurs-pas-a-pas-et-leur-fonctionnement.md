Les moteurs pas-à-pas... encore un nouveau type de moteur. Une question vous taraude sûrement l'esprit :

[[q]]
| Pourquoi il existe tant de moteurs différents !?

Et bien je vous répondrais par une autre question : pourquoi existe-t'il autant de langages de programmation différents !? La réponse est pourtant simple : car ils ont tous leurs avantages et leurs inconvénients. Par exemple, un servomoteur pourra facilement maintenir la position de son axe, tandis que le moteur à courant continu sera plus facile à faire tourner à différentes vitesses. Eh bien, le but du moteur pas-à-pas (que j'abrégerais moteur pàp) est un peu une réunion de ces deux avantages. Vous pourrez le faire tourner à des vitesses variables et la position parcourue sera aussi facile à déterminer. En contrepartie, ces moteurs ne peuvent pas tourner à des vitesses hallucinantes et sont plus délicats à mettre en œuvre que les moteurs CC par exemple (mais rien d'insurmontable je vous rassure).

En parlant de précision, savez-vous dans quel objet du quotidien on retrouve beaucoup de moteurs pàp ? Dans l'imprimante (éventuellement scanner aussi) qui traîne sur votre bureau ! En effet, l'aspect "précision" du moteur est utilisé dans cette situation sans avoir besoin d'aller vraiment vite. Vous pourrez donc en trouver un pour faire avancer les feuilles et un autre pour déplacer le chariot avec les cartouches d'encre (et encore un autre pour déplacer le capteur du scanner). Donc si vous avez une vieille imprimante destinée à la poubelle, vous savez ce qu'il vous reste à faire ;) ! Les moteurs que vous pourrez trouver posséderont 4, 5 voire 6 fils. Le premier (4 fils) est appelé **moteur bipolaire**, les deux autres sont des moteurs **unipolaires** ou à **réluctance variable**. Tout cela doit-être encore un peu confus. Voyons donc plus clairement comment cela marche !

# Fonctionnement des moteurs

Comme précédemment avancé, ce moteur possède une certaine complexité pour être mis en œuvre. Et ce, plus que les précédents. Vous souvenez-vous du moteur CC (j’espère bien ! :P ). Il était composé d'un ensemble d'aimants sur l’extérieur (le stator) et d'une partie bobinée où le champ magnétique était créée dynamiquement avec un ensemble collecteur/balais qui transmettait l'électricité aux bobines au centre (rotor).

Dans le cas du moteur pàp, c'est sur le rotor (au centre) que l'on retrouve l'aimant permanent, et les bobines sont sur le stator (autour du rotor). Comme pour les moteurs à courant continu, le but du jeu, en quelque sorte, est de "faire tourner un champ magnétique" (à prendre avec des pincettes) pour faire tourner l'aimant fixé au rotor. Il existe cependant différents types de moteurs pàp dont le placement des bobinages diffère les uns des autres et la façon de les alimenter n'est pas non plus identique (d'où une complexité supplémentaire lorsque l'on veut changer le type de moteur pàp à utiliser...). Nous allons maintenant les étudier l'un après l'autre en commençant par celui qui semble avoir le fonctionnement le plus simple à assimiler.

## Moteur pàp bipolaire à aimants permanents

Ce moteur possède quatre fils d'alimentation pour piloter des bobines par paire. Comme un schéma vaut mieux qu'un long discours, voici comment il est constitué :

![Vue schématisée et simplifiée d'un moteur pas-à-pas bipolaire](/media/galleries/954/605f9301-94fb-44e4-b45e-be6a09a3f42d.png.960x960_q85.png)

Vous l'aurez compris, les bobines sont reliées deux à deux en série et sont donc pilotées ensemble. Il n'y a donc finalement que deux enroulements à commander puisque deux bobines montées en série n'en font plus qu'une. Leur placement de part et d'autre de l'aimant permanent du rotor permet de piloter ce dernier. Voyons comment.

+ Lorsqu'il n'y a aucun courant traversant les bobines, le rotor (où l'axe de sortie est lié) est libre de tourner, rien ne cherche à le retenir dans sa course.
+ Maintenant, si nous décidons de faire passer du courant entre les points C et D pour alimenter la bobine de gauche et celle de droite. Un courant va s'établir et deux champs électromagnétiques vont apparaître de part et d'autre du rotor. Que va-t-il alors se passer ? L'aimant du rotor va tourner sur lui-même pour se placer de façon à ce que son pôle Nord soit en face du pôle Sud du champ magnétique créé dans la première bobine et que son pôle Sud soit en face du pôle Nord créé dans la deuxième bobine.
+ Si ensuite on alimente non plus les bobines entre C et D mais plutôt celles entre A et B, le rotor va alors tourner pour s'aligner à nouveau vers les pôles qui l'intéressent (Nord/Sud, Sud/Nord).
+ Et c'est reparti, on va alors alimenter de nouveau les bobines entre D et C, donc avec un courant de signe opposé à la fois où l'on les a alimenter entre C et D (par exemple C était relié au "+" de l'alimentation tout à l'heure et là on le fait passer au "-", idem pour D que l'on fait passer du "-" au "+") et le moteur va encore faire un quart de tour.
+ On peut continuer ainsi de suite pour faire tourner le moteur en faisant attention de ne pas se tromper dans les phases d'alimentation.

À chaque phase on va donc faire tourner le moteur d'un quart de tour :

![Rotation pas-à-pas du moteur](/media/galleries/954/f3b3a2be-a158-4bb7-ad25-c23f6a672474.png.960x960_q85.png)

[[i]]
| Ce quart de rotation s'appelle un **pas**. Et comme il faut plusieurs pas pour faire tourner le moteur sur 360°, on l'a donc appelé ainsi, le moteur *pas-à-pas*.

Dans le cas illustré ci-dessus, on dit que le moteur fait 4 pas par tour. Il existe bien des moteurs qui font ce nombre de pas, mais il en existe qui ont un nombre de pas plus conséquent (24, 48, etc.). Leur constitution mécanique est différente, ce qui leur confère ce pouvoir, bien que le fonctionnement reste identique, puisque l'on cherche toujours à attirer un aimant grâce à des champs magnétiques crées par des bobines parcourues par un courant. Pour avoir plus de pas, on multiplie les aimants au centre. Sur l'image ci-dessous, on peut bien voir les bobines (en cuivre à l’extérieur) et tous les aimants au centre (les petites dents). Il existe aussi deux autres modes de fonctionnement que nous verrons dans la partie suivante : **le pilotage avec couple maximal** et **le pilotage par demi-pas**.

![Vue en coupe d'un moteur pas-à-pas bipolaire](/media/galleries/954/8ec3ce2a-97a0-49bb-9045-1e0c08021547.jpg.960x960_q85.jpg)
Figure: Vue en coupe d'un moteur pas-à-pas bipolaire - (CC-BY-SA, [vincenzov.net](http://commons.wikimedia.org/wiki/File:Struttura_motore_passo-passo.jpg))

![Animation de la rotation d'un moteur pas à pas](http://zestedesavoir.com/media/galleries/954/729ab71c-6fc3-40bb-ba13-191c3c996cb3.gif)
Figure: Animation de la rotation d'un moteur pas à pas - (CC-BY-SA, [Teravolt](http://commons.wikimedia.org/wiki/File:StepperMotor.gif))

Pour rappel, voici la vue d'un moteur à courant continu :
[[s]]
| ![Vue interne d'un moteur CC](/media/galleries/954/8c648145-d9b3-497f-88ed-85477c450b96.png.960x960_q85.jpg)

## Le moteur unipolaire

Le moment est enfin venu de vous révéler la véritable signification des noms du moteur vu précédemment et de celui-ci même... non il ne faut pas lire ça sur un ton tragique. ^^ Le moteur bipolaire est nommé ainsi car il présente la faculté d'être commandé en inversant simplement la polarité de ces bobinages. Quant au moteur unipolaire, pas besoin de faire cette inversion, chaque bobinage est commandé séparément et ne requiert qu'une alimentation présente ou absente selon que l'on veuille ou non créer un champ magnétique en son sein. La commande sera donc plus simple à mettre en place qu'avec le moteur bipolaire. Cependant, le nombre de bobines étant plus important, la quantité de cuivre également et le prix s'en ressent ! En effet, il s'agit bien de 4 bobines bien distinctes, alors que le moteur bipolaire à aimant permanent en possède finalement quatre moitiés de bobines, donc deux bobines complètes.

![Vue en coupe d'un moteur pas-à-pas unipolaire](/media/galleries/954/ff0f59aa-8779-4a4e-a7cc-7284325532f4.png.960x960_q85.png)

On retrouve nos quatre fils A, B, C et D ainsi qu'un fil de masse commun (bon ben imaginez-le puisqu'il n'est pas dessiné comme tel sur le schéma). Soit 5 fils (v'là pas qu'on sait compter maintenant ! ^^ ). Le fonctionnement est rigoureusement identique que le précédent moteur. On cherche à créer un champ magnétique "rotatif" pour faire passer l'aimant alternativement devant chacune des bobines. On va donc alimenter la bobine A, puis la C, puis la B, puis la D selon le schéma ci-dessus. Et voilà, le moteur aura fait tout un tour assez simplement. Il suffit d'avoir quatre transistors (un par enroulement) sans avoir besoin de les disposer en H et de les piloter deux à deux. Ici il suffit de les alimenter un par un, chacun leur tour. Facile, non ? ;)

## Le moteur à réluctance variable

[[q]]
| Gné :o ? c'est quoi ce nom barbare ?

Ce moteur est un peu plus compliqué, mais c'est aussi le dernier que nous verrons et le plus fascinant ! Contrairement aux deux précédents, ce moteur ne possède pas d'aimants permanents, ni même d'aimant tout court ! Non, en son centre on trouve un simple morceau de **fer doux**. Ce dernier à la particularité de très bien conduire les champs magnétiques. Du coup, si un champ magnétique le traverse, il voudra absolument s'aligner dans son sens. C'est cette propriété qui est exploitée. Commençons par voir tout de suite le schéma de ce moteur :

![Vue en coupe d'un moteur pas-à-pas à réluctance variable](/media/galleries/954/fd25b73a-3117-4cc1-8fa3-e96ad0842cfa.png.960x960_q85.png)

Comme vous pouvez le voir, il possède 4 enroulements (formant 4 paires) et le morceau de fer doux au milieu à une forme d'étoile à 6 branches. Et ce n'est pas un hasard ! Le ratio de 6 pour 8 a une raison très précise car cela introduit un léger décalage (15°) entre une branche et une bobine. En effet, si l'on a 8 bobines (4 paires) on a un décalage entre chaque bobine de : $\frac{360^\circ}{8}=45^\circ$ Donc tous les 45° le long du cylindre qu'est le moteur, on trouve un bobinage. En revanche il n'y a que 60° entre chaque extrémité de l'étoile du rotor : $\frac{360^\circ}{6}=60^\circ$ Mais pourquoi exactement ? Eh bien, c'est simple avec un peu d'imagination (et quelques dessins). Si l'on commence par alimenter le premier enroulement, le A, le rotor va s'aligner avec. Maintenant que se passera-t-il si l'on alimente B ? Le rotor, qui était alors positionné avec une de ses branches bien en face de A, va bouger pour s'aligner correctement vers B. Ensuite, si l'on alimente C il va se passer de même, le rotor va encore tourner de 15° pour s'aligner, etc. Si l'on effectue cette opération 24 fois, on fera un tour complet car : $24 \times 15^\circ = 360^\circ$

[[i]]
| Vous remarquerez que dans cet exemple le rotor tourne dans le sens horaire alors que l'alimentation des bobines se fera dans le sens antihoraire.

Ces moteurs ont certains avantages. Parmi ces derniers, il n'y a pas besoin de polariser les bobines (peu importe le sens du champ magnétique, l'entrefer n'étant pas polarisé essaiera de s'aligner sans chipoter). Le fait que l'on utilise un simple entrefer en fer doux le rend aussi moins cher qu'un modèle avec des aimants permanents. Vous savez maintenant tout sur les trois types de moteurs pas-à-pas que l'on peut trouver, place maintenant à la pratique !

[[a]]
| De manière générale, n'essayez pas d'ouvrir vos moteurs pas-à-pas pour regarder comment c'est fait et espérer les remonter après. Le simple démontage à tendance à faire diminuer la qualité des aimants permanents à l'intérieur et donc votre moteur ne sera plus aussi bon après remontage.