Continuons à parler de notre super moteur. Si vous avez suivi ce que j'ai dit plus tôt, j'ai expliqué qu'il y avait des bobines qui généraient un champ magnétique. Lorsqu'elles sont alimentées, ces bobines ont besoin de courant pour pouvoir générer un champ magnétique suffisant. Vous ne serez donc pas surpris si je vous dis qu'il faudra utiliser un composant pour faire passer la puissance dans ces dernières. Et là, comme les choses sont bien faites, nous allons retrouver le pont en H et le L298. :)

[[i]]
| Afin de limiter la redondance d'informations, je vais me contenter de vous expliquer le pilotage du moteur unipolaire et bipolaire. Si vous comprenez correctement ces derniers, vous n'aurez aucun problème avec le moteur restant ;)

[[e]]
| Les schémas qui vont suivre ont pour source d'énergie une pile +9V. Cependant il est déconseillé de les faire avec car la consommation des moteurs est assez importante et la pile risque de se fatiguer très vite. Utilisez plutôt une source d'alimentation prévue à cet effet (une alimentation de laboratoire).

# Le moteur unipolaire

## Connecter un moteur unipolaire

Pour rappel, voici la structure du moteur unipolaire :

![Vue en coupe d'un moteur pas-à-pas unipolaire](/media/galleries/954/e8e65912-4b58-4a54-94ef-d285da528d19.png.960x960_q85.png)

Si vous avez bien lu la partie précédente, vous devez avoir retenu que ce moteur est assez simple à piloter. En effet, il suffit d'alimenter une à une les bobines pour que le moteur tourne. Et c'est tout ! Il nous faut juste utiliser le bon composant pour alimenter les bobines et en avant ! A priori, le bon composant serait un bon transistor qui pourrait supporter 50V et 500mA pour débuter. À cela il faudrait ensuite rajouter une diode de roue libre pour ne pas l’abîmer lors des phases de roue libre (tout cela multiplié par 4 puisqu'on a 4 bobines). Plutôt que de s’embêter à câbler tout ça, je vous propose l'intervention d'un nouveau composant : le ULN2003A. Ce dernier regroupe les transistors pour faire passer la puissance et aussi la diode. Il est très simple à câbler puisqu'il faut simplement amener l'alimentation et les broches de commandes. Chacune de ces dernières possède respectivement une sortie où la tension sera celle de l'alimentation. Voici une illustration de ce câblage :

![Câblage simple du moteur unipolaire - Schéma](/media/galleries/954/d8ecbfb8-de09-4dfb-9192-8651d5a00c55.png.960x960_q85.jpg)

![Câblage simple du moteur unipolaire - Montage](/media/galleries/954/59b23291-a16f-4cf0-966d-bf912a2a64a1.png.960x960_q85.jpg)

## Utiliser un moteur unipolaire

Je l'ai maintenant dit et répété plusieurs fois, pour ce moteur il suffit de piloter chaque bobine une à une, chacune leur tour. Je vais donc vous résumer tout cela de manière plus schématique et on sera bon pour ce moteur. :D A la fin, si vous avez bien compris vous devriez être capable de le faire tourner tout doucement en plaçant alternativement les fils In1 à 4 (abrégé In1..4) au 5V ou à la masse.

![Séquence du moteur unipolaire](/media/galleries/954/1366405d-3579-4443-8503-6ed61e51bf80.png.960x960_q85.jpg)

[[i]]
| Les différentes illustrations de séquences peuvent êtres trouvées sous licence CC-BY-SA [sur wikipedia](http://fr.wikipedia.org/wiki/Moteur_pas_%C3%A0_pas) (M4RC0)

->

Etape | In 1 | In 2 | In 3 | In 4
------|------|------|------|------
Pas n°1 | HIGH | LOW | LOW | LOW
Pas n°2 | LOW | HIGH | LOW | LOW
Pas n°3 | LOW | LOW | HIGH | LOW
Pas n°4 | LOW | LOW | LOW | HIGH

Table: Séquence du moteur unipolaire

<-

![Chronogramme du moteur unipolaire](/media/galleries/954/3a59d16f-e6f9-4d58-baba-c5ef811e6140.png.960x960_q85.jpg)

Si vous placez les fils de commande à la masse ou au 5V convenablement, votre moteur devrait tourner :) Vous n'avez plus qu'à créer le programme qui va bien pour piloter tout ce bazar... ben vous vous attendiez à quoi ? Une solution peut-être ? Non. :diable: Bon bon, d'accord... vous vous souvenez de vos premiers pas avec le chenillard ? Tout est dit. ;) (et si vous ne voulez pas vous fatiguer, attendez la suite du tuto :D )

# Le moteur bipolaire

## Le câbler, la théorie

Nous avons vu dans le chapitre précédent que le moteur bipolaire a besoin, à un moment, d'une inversion de courant si l'on veut pouvoir utiliser les bobines à bon escient. Vous vous souvenez probablement que nous avons vu précédemment un composant capable de faire cela : le pont en H. L'idée va donc être de câbler correctement les bobines pour pouvoir faire passer le courant dans un sens, ou dans l'autre. Je vous rappelle la structure du pont en H :

![Le pont en H - vue simplifiée](/media/galleries/954/6a4d5998-633c-4e1e-9c4a-ee4155edac55.png.960x960_q85.png)

Problème, un pont en H ne peut piloter qu'une "paire de bobines" (celle qui sont dans le même axe et relié entre elles), or nous en avons deux à piloter. Heureusement, le L298 est un composant très bien pensé et ne possède non pas un mais bien deux ponts en H ! Du coup, nous pourrons en utiliser un par couple de bobines. :) Plutôt sympa non ?

## La pratique avec le L298

Dans le chapitre précédent, nous avons justement vu un composant qui possède deux ponts en H : le L298. Le reste du travail semble presque trop simple ! Pour la partie "sortie/puissance", vous devrez relier les sorties Out1 (broche 2) et Out2 (broche 3) à la première bobine et ensuite Out3 et Out4 (13 et 14) à la seconde. N'oubliez pas les diodes de roue libre (8 au total et qui supporte la puissance) ! Enfin, il ne reste qu'à connecter les entrées In1..4 à 4 entrée/sortie numérique (pas besoin de PWM). Pour l'instant, pas besoin de les relier à l'Arduino, contentez-vous de les mettre à la masse, nous allons faire un test ensemble. Comme nous voulons activer les deux ponts, mettez les deux entrées "enable" au +5V. Nous verrons dans la prochaine partie comment l'utiliser avec Arduino ;) . Voici un petit schéma récapitulatif :

![Câblage simple - Schéma](/media/galleries/954/2470b115-93ae-4480-859e-c8ce4fbb472f.png.960x960_q85.png)

Le schéma de montage avec quelques condensateurs de filtrage qui viennent aider l'alimentation en cas de forte demande de courant et des condensateurs qui filtre les parasites engendrés par les bobines du moteur.

![Câblage simple - Montage](/media/galleries/954/d95f7f2e-b79b-46b9-bba3-92cae69ad6e2.png.960x960_q85.png)

# Piloter le moteur bipolaire

Une fois que le moteur est branché, nous allons pouvoir le faire tourner. Comme son nom l'indique, il s'appelle pas à pas et donc nous allons le faire pivoter étape par étape et non de manière continue comme le moteur à courant continu. Cependant, en répétant les étapes de rotation rapidement et successivement, le moteur donnera l'impression de tourner sans s’arrêter entre chaque étape. Il existe trois méthodes distinctes pour piloter les moteurs bipolaires. Nous allons maintenant les voir une par une. Dans les cas qui vont suivre, on va considérer un moteur de 4 pas par tour (ce qui est ridiculement faible). Voici ce à quoi il va ressembler (comment sont placées ses bobines) :

![Vue schématisé d'un moteur pas-à-pas](/media/galleries/954/32ef91e0-2e85-49ed-a878-bffacac0ce09.png.960x960_q85.png)

## Rotation par pas complet

Ce mode de fonctionnement est le plus simple, c'est pourquoi nous allons commencer par lui. Grâce à ce dernier, vous allez pouvoir faire des rotations "pas par pas". Pour cela, nous allons alternativement alimenter les bobines de droites et de gauche et inverser le sens du courant pour pouvoir faire une rotation complète du champ magnétique. Voici l'illustration Wikipédia très bien faite à ce sujet :

![Séquence à pas complet](/media/galleries/954/4fa90138-e5dd-459d-a502-4bd0751ba61e.png.960x960_q85.jpg)

[[i]]
| En rouge la bobine alimentée ainsi que le sens du courant symbolisé par une flèche et en noir la bobine qui n'est pas alimentée.

En considérant que la bobine A est connectée aux entrées IN1 et IN2 et que la bobine B est connectée aux commandes IN3 et IN4, on peut donc écrire la séquence de commande suivante :

->

Etape | In 1 | In 2 | In 3 | In 4
------|------|------|------|------
Pas n°1 | HIGH | LOW | - | -
Pas n°2 | - | - | HIGH | LOW
Pas n°3 | LOW | HIGH | - | -
Pas n°4 | - | - | LOW | HIGH

Table: Séquence à pas complet

<-

(un état '-' signifie "non nécessaire", placez-le à 0V pour que la bobine soit bien inactive).


On peut traduire cette activité par le chronogramme suivant :

![Chronogramme du pilotage à pas entier](/media/galleries/954/dd6c7a57-7550-480c-95d2-907084bbe3c7.png.960x960_q85.jpg)

Comme vous pouvez le voir à travers ces différents moyens d'explication, c'est somme toute assez simple. On va chercher à déplacer l'aimant central en le faisant tourner petit à petit. Pour cela on cherchera à l'attirer dans différentes positions.

## Rotation à couple maximal

Un autre mode de fonctionnement est celui dit à **couple maximal**. Cette méthode de pilotage utilise toutes les bobines à la fois pour pouvoir immobiliser au maximum l'aimant central. En effet, en utilisant plus de champs magnétiques on obtient une force supplémentaire. Par contre, on consomme évidemment d'avantage de courant. Pour comprendre ce fonctionnement, voyons les différentes étapes par un dessin puis par un chronogramme. Vous verrez, ce n'est pas très compliqué, le fonctionnement est très similaire, seules les activations de bobines changent un peu :

![Séquence à couple maximal](/media/galleries/954/a2c38969-cdec-4ffd-8de4-3200f9572740.png.960x960_q85.jpg)

[[i]]
| Avez-vous remarqué quelque chose de particulier ? Dans cette utilisation, l'aimant ne fait plus face aux bobines mais se place *entre* les deux. Par contre, il effectue toujours des pas entiers, ces derniers ont juste un décalage constant par rapport à avant.

Voici le tableau correspondant au pilotage des bobines :

->

Etape | In 1 | In 2 | In 3 | In 4
------|------|------|------|------
Pas n°1 | HIGH | LOW | HIGH | LOW
Pas n°2 | HIGH | LOW | LOW | HIGH
Pas n°3 | LOW | HIGH | LOW | HIGH
Pas n°4 | LOW | HIGH | HIGH | LOW

Table: Séquence à couple maximal

<-

(un état '-' signifie "non nécessaire", placez-le à 0V pour que la bobine soit bien inactive).

![Chronogramme pour un couple max.](/media/galleries/954/66ad8d65-8fa0-4363-9bd6-8b96b15a2071.png.960x960_q85.jpg)

## Rotation par demi-pas

Enfin, le dernier mode de fonctionnement est celui dit à **demi-pas**. Ce mode mélange les deux précédents puisqu'on va alterner les étapes du mode à pas complet et les étapes du mode à couple maximal. En effet, comme nous avons pu le voir dans les explications précédentes, les deux modes placent l'aimant central de manière différente. L'un est "en face des bobines" alors qu'avec l'autre est plutôt "entre les bobines". 

Ainsi, en se mettant alternativement "en face" puis "entre" les bobines on va effectuer deux fois plus de pas que précédemment puisqu'on intercalera des étapes supplémentaires. Attention, lorsque je dis "deux fois plus de pas" je veux surtout dire que l'on aura des étapes intermédiaires qui augmentent la précision du déplacement. Ce mode de pilotage est un peu plus compliqué que les précédents puisqu'il est "plus long" (8 étapes au lieu de 4) mais rien d'insurmontable vous allez voir !

![Séquence à demi-pas](/media/galleries/954/1e65bea6-b6ba-47bc-ae73-58812126660c.png.960x960_q85.jpg)

->

Etape | In 1 | In 2 | In 3 | In 4
------|------|------|------|------
Pas n°1 | HIGH | LOW | - | -
Pas n°1 ½ | HIGH | LOW | HIGH | LOW
Pas n°2 | - | - | HIGH | LOW
Pas n°2 ½ | LOW | HIGH | HIGH | LOW
Pas n°3 | LOW | HIGH | - | -
Pas n°3 ½ | LOW | HIGH | LOW | HIGH
Pas n°4 | - | - | LOW | HIGH
Pas n°4 ½ | HIGH | LOW | LOW | HIGH

Table: Séquence à demi-pas

<-

(un état '-' signifie "non nécessaire", placez-le à 0V pour que la bobine soit bien inactive).

![Chronogramme du pilotage à demi-pas](/media/galleries/954/0bb60cfc-b1f6-4616-9caf-a649915bdfcd.png.960x960_q85.jpg)

Maintenant que vous connaissez les différents modes de fonctionnement, vous pouvez essayer de faire tourner le moteur en branchant les entrées IN1..4 à la masse ou au 5V. Si vous le faites dans le bon ordre, votre moteur devrait tourner tout doucement, en allant d'une étape vers l'autre. :) 

[[a]]
| Si vous avez une charge qui demande trop de couple (par exemple un poids à faire monter), il peut arrive que le moteur "saute" un/des pas. Cette donnée est à prendre en compte si vous vous servez du nombre de pas effectué logiciellement comme moyen de calcul de distance.