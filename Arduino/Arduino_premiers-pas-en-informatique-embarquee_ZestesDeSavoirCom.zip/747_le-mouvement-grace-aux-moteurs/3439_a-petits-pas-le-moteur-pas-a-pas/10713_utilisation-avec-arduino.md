# Câbler les moteurs

Avec les chapitres précédents, vous avez vu comment on devait utiliser les moteurs avec les composants gérant la puissance. Cependant, nous n'avons pas vu à quoi relier les broches de commande... Et c'est très simple ! En effet, tous les signaux sont tout ou rien et n'ont même pas besoin d'être des PWM ! Ce qui veut dire que les 4 broches de pilotage ont juste besoin d'être reliées à 4 broches numériques de la carte Arduino (2, 3, 4, 5 par exemple). Voyons ce que cela donne en schéma (qui sont exactement les mêmes que ceux de la partie précédente, mais avec une carte Arduino en plus :D )

## Le moteur unipolaire

![Câblage du moteur unipolaire - Schéma](/media/galleries/954/ecca72e7-bc0d-47fc-9a98-84d225fc5d8e.png.960x960_q85.jpg)

![Câblage du moteur unipolaire - Montage](/media/galleries/954/940db675-3dfc-4ffd-ac75-3dcae81d1b67.png.960x960_q85.jpg)

## Le moteur bipolaire

![Câblage du moteur bipolaire - Schéma](/media/galleries/954/c2d29ced-68cc-4433-a771-cdebced314c2.png.960x960_q85.png)

![Câblage du moteur bipolaire - Montage](/media/galleries/954/bc58e6e8-c4d6-4b1d-81ce-71ba9bddd906.png.960x960_q85.png)

Jusque là rien de vraiment compliqué, on passe à la suite !

# Piloter les moteurs avec Arduino

## Le principe

L'idée est toute simple, il suffit de générer la bonne séquence pour piloter les moteurs à la bonne vitesse, vous vous en doutez surement. La principale difficulté réside dans la génération des signaux dans le bon ordre afin que le moteur se déplace correctement. Bien entendu, c'est plus facile à dire qu'à faire. En effet, pour que le mouvement soit fluide, il faut que les changements dans la séquence soient faits de manière régulière et pour cela il faut une gestion du temps correcte. Ça peut sembler simple au premier abord, mais quand il s'agira de mixer le comportement du moteur avec celui du programme principal (qui devra peut-être faire des traitements assez lourds) cela deviendra probablement beaucoup moins trivial. Une bonne méthode consisterait à utiliser un **timer** sur lequel on réglerait la période à avoir qui refléterait ainsi la vitesse à obtenir. Mais avec Arduino vous allez voir que tout devient plus simple...

## L'objet Stepper

Sur Arduino les choses sont bien faites pour rester simples et accessibles, un objet a déjà été créé pour vous aider à piloter un moteur pas à pas. Attention cependant, il ne fonctionne que pour les moteurs unipolaires et bipolaires. Il tire parti du fait que ces deux types de moteur peuvent fonctionner avec une séquence commune. Ainsi, tout est généralisé et utilisable le plus simplement possible ! Ce nouveau composant s'appelle "[Stepper](http://arduino.cc/en/Reference/Stepper)". À sa création, il prend en argument le nombre de pas total que fait le moteur pour faire un tour (information trouvable dans la documentation constructeur ou empiriquement). Cette information sert à déterminer la vitesse de rotation par minute que vous pourrez ensuite régler à loisir pour faire des déplacements lents ou rapides. Il prend aussi en arguments les quatre broches servant à contrôler l'engin. Son constructeur est donc : [`Stepper(steps, pin1, pin2, pin3, pin4)`](http://arduino.cc/en/Reference/StepperConstructor). Pour initialiser le moteur, nous pouvons donc écrire la ligne suivante :

```cpp
// pour un moteur de 200 pas par tour et brancher sur les broches 2, 3, 4, 5
Stepper moteur(200, 2, 3, 4, 5);
```
Code: Initialisation d'un moteur pas à pas

Pour l'utiliser, deux fonctions sont utilisables. La première sert à définir la vitesse de rotation, exprimée en tours par minute (**trs/min**). Pour cela, on utilise la fonction [`step(steps)`](http://arduino.cc/en/Reference/StepperSetSpeed) qui prend en paramètre le nombre de pas à effectuer. Si ce nombre est négatif, le moteur tournera en sens inverse du nombre de pas spécifié. Voici un petit exemple qui va faire faire un aller-retour de 200 pas toutes les 2 secondes à votre moteur :

```cpp
#include <Stepper.h>

// pour un moteur de 200 pas par tour et brancher sur les broches 2, 3, 4, 5
Stepper moteur(200, 2, 3, 4, 5);

void setup()
{
    moteur.setSpeed(30); // 30 tours par minute
    // (rappel : ici le moteur fait 200 pas par tour,
    // on fera donc 6000 pas par minute)
}

void loop()
{
    moteur.step(1000);
    delay(100);
    moteur.step(-1000);
    delay(2000);
}
```
Code: Utilisation simple d'un moteur pas à pas

[[a]]
| La fonction `step(x)` est bloquante. Cela signifie qu'elle agit comme un délai. Tant que le moteur n'a pas fait les x pas demandés, le reste du programme est en attente.

# Aller plus loin

Vous êtes devenus incollables sur les moteurs pas à pas ? Vous en voulez encore plus ? Suffit de demander, voilà du bonus d'informations rien que pour toi cher lecteur !

## 2 fils au lieu de 4 !

On a toujours utilisé 4 fils pour commander les moteurs. C'est bien, mais que diriez-vous de sauver deux broches et de passer à seulement 2 fils au lieu de 4 ? Pas mal comme amélioration non ? Petite anecdote : un jour, un utilisateur des moteurs pàp s'est rendu compte d'un truc, dans une paire de fils pour piloter un moteur (dans la séquence utilisée par Arduino), l'information est toujours antagoniste. Si un fil est à HIGH, sa paire sera à LOW et vice versa. Du coup il suffit d'un peu d'électronique pour pouvoir inverser un des deux signaux et se retrouver ainsi avec seulement deux fils au lieu de 4 sortants d'Arduino. :)

![Moteur bipolaire avec 2 fils](/media/galleries/954/ef720d06-eb16-4286-9e6d-d0c5ae2b1424.png.960x960_q85.jpg)

![Moteur unipolaire avec 2 fils](/media/galleries/954/61347982-9de1-422f-b111-5f1f8751c05b.png.960x960_q85.jpg)

(source des images : [tigoe.net](http://www.tigoe.net/pcomp/code/circuits/motors/stepper-motors/)) Cette solution est plutôt intéressante du fait que les entrées/sorties sont parfois une denrée rare sur Arduino ! ^^

## Le L297

Lorsque vous utilisez votre Arduino, vous ne pouvez utiliser qu'une seule séquence. Par exemple pour un moteur bipolaire vous n'avez pas le choix entre le mode pas entier, demi-pas ou couple max. Une des solutions serait de générer vous-même les séquences. Mais c'est assez fastidieux. Une autre solution est électronique et compensera le développement informatique à faire. Un composant, nommé L297 (de la famille du L298 vous vous en doutez) est justement fait pour générer les séquences de moteur pas à pas. Il possède 4 broches de sorties pour générer la séquence et plusieurs en entrée pour "paramétrer" le fonctionnement voulu. Parmi elles on en retrouve trois principales :

+ CW/CCW : (ClockWise ou Counter ClockWise) qui décidera du sens de rotation du moteur (horaire ou antihoraire).
+ Half/Full : Qui décide si on est en mode pas entier ou demi-pas.
+ Clk : (Clock) qui est l'horloge pour la vitesse. À chaque front descendant, le moteur fera un pas.
Je vous laisse un peu chercher sur le net, vous trouverez de plus amples informations à ce sujet. Avant même de regarder sur le net, en fait, regardez plutôt sa datasheet !! ;) Un des avantages de délester le travail des séquences au L297 est que vous n'aurez plus besoin de l'objet Stepper et de sa fonction step() bloquante. Il faudra cependant toujours utiliser un composant de puissance pour laisser passer les forts courants nécessaires au moteur (comme le L298 par exemple).