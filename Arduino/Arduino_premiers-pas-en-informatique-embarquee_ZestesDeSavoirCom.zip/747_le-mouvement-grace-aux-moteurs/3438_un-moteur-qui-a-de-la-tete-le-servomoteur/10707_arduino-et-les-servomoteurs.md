Bon, eh bien à présent, voyons un peu comment utiliser ces moteurs dont je vous vente les intérêts depuis tout à l'heure. Vous allez le voir, et ça ne vous surprendra même plus, la facilité d'utilisation est encore améliorée grâce à une bibliothèque intégrée à l'environnement Arduino. Ils nous mâchent vraiment tout le travail ces développeurs ! ^^

# Câblage

Nous l'avons vu plus haut, la connectique d'un servomoteur se résume à trois fils : deux pour l'alimentation positive et la masse et le dernier pour le signal de commande. Rappelons qu'un servomoteur accepte généralement une plage d'alimentation comprise entre 4.5V et 6V (à 6V il aura plus de couple et sera un peu plus rapide qu'à 4.5V). Si vous n'avez besoin d'utiliser qu'un ou deux servomoteurs, vous pouvez les brancher sur la sortie 5V de la carte Arduino. Si vous voulez en utiliser plus, il serait bon d'envisager une alimentation externe car le régulateur de l'Arduino n'est pas fait pour délivrer trop de courant, vous risqueriez de le cramer. Dans ce cas, n'oubliez pas de relier la masse de l'alimentation externe et celle de l'Arduino afin de garder un référentiel électrique commun. Le câble permettant le transit du signal de commande du servo peut-être branché sur n'importe quelle broche de l'Arduino. Sachez cependant que lorsque nous utiliserons ces derniers, les sorties 9 et 10 ne pourront plus fournir un signal PWM (elles pourront cependant être utilisées comme de simples entrées/sorties numériques). C’est une des contraintes de la bibliothèque que nous allons utiliser.

[[i]]
| Ces dernières contraintes s'appliquent différemment sur les cartes MEGA. [Cette page](http://arduino.cc/en/Reference/Servo) vous dira tout !

Voici maintenant un petit exemple de montage d'un servo sur l'Arduino :

![Montage simple d'un servomoteur avec l'Arduino](/media/galleries/954/3a13e2bf-5dd7-4d4f-b5a4-30514bd09be0.png.960x960_q85.png)

# La librairie *Servo*

Pour utiliser le servo avec Arduino, il va nous falloir générer le signal PPM vu précédemment. C'est-à-dire créer un signal d'une fréquence de 50Hz et modifier l'état haut d'une durée comprise entre 1 et 2ms. Contraignant n'est-ce pas ? Surtout si l'on a plusieurs servos et tout un programme à gérer derrière... C'est pourquoi l'équipe d'Arduino a été sympa en implémentant une classe très bien nommée : Servo. Tout comme l'objet Serial vous permettait de faire abstraction du protocole de la voie série, l'objet Servo va vous permettre d'utiliser les servomoteurs. Et comme elle est développée par une équipe de personnes compétentes, on peut leur faire totalement confiance pour qu'elle soit optimisée et sans bugs ! ;) Voyons maintenant comme s'en servir !

## Préparer le terrain

Tout d'abord, il nous faut inclure la librairie dans notre sketch. Pour cela, vous pouvez au choix écrire vous même au début du code `#include <Servo.h>` ou alors cliquer sur *library* dans la barre de menu puis sur "Servo" pour que s'écrive automatiquement et sans faute la ligne précédente. Ensuite, il vous faudra créer un objet de type Servo pour chaque servomoteur que vous allez utiliser. Nous allons ici n'en créer qu'un seul que j’appellerai "monServo" de la manière suivante : `Servo monServo;`. Nous devons lui indiquer la broche sur laquelle est connecté le fil de commande du servo en utilisant la fonction `attach()` de l'objet Servo créé. Cette fonction prend 3 arguments :

+ Le numéro de la broche sur laquelle est relié le fil de signal
+ La valeur basse (angle à 0°) de la durée de l'état haut du signal de PPM en microsecondes (optionnel, défaut à 544 µs)
+ La valeur haute (angle à 90°, 180°, 360°, etc.) de la durée de l'état haut du signal de PPM en microsecondes (optionnel, défaut à 2400 µs)

Par exemple, si mon servo possède comme caractéristique des durées de 1ms pour 0° et 2ms pour 180° et que je l'ai branché sur la broche 2, j'obtiendrais le code suivant :

```cpp
#include <Servo.h>

Servo monServo;

void setup()
{
    monServo.attach(2, 1000, 2000);
}
```
Code: Initialisation d'un servo moteur

## Utiliser le servo

Une fois ces quelques étapes terminées, notre servo est fin prêt à être mis en route. Nous allons donc lui donner une consigne d'angle à laquelle il doit s'exécuter. Pour cela, nous allons utiliser la fonction prévue à cet effet : `write()`. Tiens, c'est la même que lorsque l'on utilisait la liaison série ! Eh oui. ;) Comme son nom l'indique, elle va *écrire* quelque chose au servo. Ce quelque chose est l'angle qu'il doit donner à son axe. Cette fonction prend pour argument un nombre, de type `int`, qui donne la valeur en degré de l'angle à suivre. Si par exemple je veux placer le bras du servo à mi-chemin entre 0 et 180°, j'écrirais :

```cpp
monServo.write(90);
```

Pour terminer, voilà le code complet qui vous permettra de mettre l'angle du bras de votre servomoteur à 90° :

```cpp
#include <Servo.h>

Servo monServo;

void setup()
{
    monServo.attach(2, 1000, 2000);
    monServo.write(90);
}

void loop()
{
}
```
Code: Initialisation et déplacement d'un servo

J’ai mis l’ordre de l’angle dans la fonction setup() mais j’aurais tout autant pu la mettre dans la loop(). En effet, lorsque vous utilisez write(), la valeur est enregistrée par Arduino et est ensuite envoyée 50 fois par seconde (rappelez-vous du 50Hz du signal ;) ) au servo moteur afin qu’il garde toujours la position demandée.