Un servomoteur... Étrange comme nom, n'est-ce pas ? Cela dit, il semblerait qu'il le porte bien puisque ces moteurs, un peu particuliers je le disais, emportent avec eux une électronique de commande (faisant office de "cerveau"). Le nom vient en fait du latin *servus* qui signifie esclave. Mais avant de nous atteler à l'exploration interne de ce cher ami, façon de parler, nous allons avant tout voir à quoi il sert.

# Vue générale

## Le servo, un drôle de moteur

Commençons en image, avec la photographie d'un servomoteur :

![Un servomoteur](/media/galleries/954/0c77be1e-dba2-4fe1-8e83-487e4cf604be.jpg.960x960_q85.jpg)

C'est, en règle générale, à quoi ils ressemblent, variant selon leur taille.

[[q]]
| Pfiouuu, c'est quoi ce moteur, ça n'y ressemble même pas ! :o

J'vous l'avais dit que c'était des moteurs particuliers ! En détail, voyons à quoi ils servent. De manière semblable aux moteurs à courant continu, les servomoteurs disposent d'un axe de rotation. Sur la photo, il se trouve au centre de la roue blanche. Cet axe de rotation est en revanche entravé par un système de bridage. Cela ne veut pas dire qu'il ne tourne pas, mais cela signifie qu'il ne peut pas tourner au-delà d'une certaine limite. Par exemple, certains servomoteurs ne peuvent même pas faire tourner leur axe de rotation en leur faisant faire un tour complet ! D'autres en sont capables, mais pas plus d'un tour. Enfin, un cas à part que nous ne ferons qu'évoquer, ceux qui tournent sans avoir de limite (autant de tours qu'ils le veulent). Et là, c'est le moment où je vous dis : "*détrompez-vous !*" en répondant à la question critique que vous avez en tête : "*Un moteur qui ne peut même pas faire un tour avec son axe de rotation, ça ne sert à rien ? o_O* " En effet, s'il ne peut pas faire avancer votre robot, il peut cependant le guider. Prenons l'exemple d'une petite voiture de modélisme à quatre roues. Les roues arrière servent à faire avancer la voiture, elles sont mises en rotation par un moteur à courant continu, tandis que les roues avant, qui servent à la direction de la voiture pour ne pas qu'elle se prenne les murs, sont pilotées par un servomoteur. Comment ? Eh bien nous allons vous l'expliquer.

## L'exemple de la voiture radiocommandée

Regardons l'image que je vous ai préparée pour comprendre à quoi sert un servomoteur :

![*Vue de dessus* Représentation schématique du système de guidage des roues d'une](/media/galleries/954/571dcfce-0e46-48bc-b297-174781e77d3d.png.960x960_q85.jpg)

Chaque roue est positionnée sur un axe de rotation (partie bleue) lui-même monté sur un pivot sur le châssis de la voiture (en vert). La baguette (rouge) permet de garder le parallélisme entre les roues. Si l'une pivote vers la gauche, l'autre en fait de même (ben ouais, sinon la voiture devrait se couper en deux pour aller dans les deux directions opposées :lol: ). Cette baguette est fixée, par un pivot encore, au bras de sortie du servomoteur. Ce bras est à son tour fixé à l'axe de rotation du servomoteur. Ainsi, lorsque le servomoteur fait tourner son axe, il entraine le bras qui entraine la baguette et fait pivoter les roues pour permettre à la voiture de prendre une direction dans son élan (tourner à gauche, à droite, ou aller tout droit). Il n'y a rien de bien compliqué. Ce qu'il faut retenir est que le servomoteur va entrainer la baguette pour orienter les roues dans un sens ou dans l'autre. Elles auront donc un angle d'orientation par rapport au châssis de la voiture. Voyez plutôt :

![Animation de la direction](/media/galleries/954/d442d4d2-07a6-42a5-bda6-cee9a30298c8.gif)

Alors, vous allez me dire : "*mais pourquoi on ne met pas un moteur à courant continu avec un bras sur son axe, ce serait plus simple, non ?*" Eh bien non, car cela ne conviendrait pas. Je vous explique pourquoi. Nous l'avons vu, un moteur à courant continu tourne sans s'arrêter, sauf si on lui coupe l'alimentation. Le problème c'est que, dans notre cas, si on laisse le moteur tourner, il pourrait faire pivoter les roues plus loin que leur angle maximal et casser le système de guidage car il ne saura pas quand il faut s'arrêter (à savoir, quand les roues sont arrivées à leur angle maximal).
Bon, on pourrait très bien faire un système qui coupe l'alimentation quand les roues arrivent sur leur butée. En plus, les moteurs à courant continu sont de bien piètres athlètes, il leur faudrait nécessairement un réducteur pour arriver à avoir une vitesse faible et un couple plus élevé. Mais pourquoi s'embêter avec ça plutôt que d'utiliser quelque chose de déjà tout prêt ? C'est le servomoteur qui va faire tout ça ! Pour être précis, le servomoteur est commandé de telle sorte qu'au lieu de donner une vitesse de rotation de son axe, il donne une position angulaire de l'arbre relié à son axe. Donc, on lui demande de faire tourner son axe de 10° vers la gauche et il s’exécute !

# Composition d'un servomoteur

Les servomoteurs ont donc l'avantage d'être *asservis* en **position angulaire**. Cela signifie, je vous l'expliquais, que l'axe de sortie du servomoteur respectera une consigne d'orientation que vous lui envoyez en son entrée. En plus, tenez-vous bien, si par malheur les roues venaient à changer d'orientation en passant sur un caillou par exemple, l'électronique interne du servomoteur essaiera tant bien que mal de conserver cette position ! Et quelle que soit la force que l'on exerce sur le bras du servomoteur, il essayera de toujours garder le même angle (dans les limites du raisonnable évidemment). En quelque sorte vous ne pilotez pas directement le moteur, mais plutôt **vous imposez le résultat que vous voulez avoir en sortie**.

## Apparence

On en trouve de toutes les tailles et de toutes les puissances. La plupart du temps la sortie peut se positionner entre 0 et 180°. Cela dit, il en existe également dont la sortie peut se débattre sur seulement 90° et d'autres, ayant un plus grand débattement, sur 360°. Ceux qui ont la possibilité de faire plusieurs tours sont souvent appelés **servo-treuils**. Enfin, les derniers, qui peuvent faire tourner leur axe sans jamais se buter, sont appelés **servomoteurs à rotation continue**. Les servomoteurs sont très fréquemment employés dans les applications de modélisme pour piloter le safran d'un bateau, le gouvernail d'un avion ou bien même les roues d'une voiture téléguidée dont on a parlé jusqu'à présent. Maintenant que les présentations sont faites, mettons-le à nu ! Il est composé de plusieurs éléments visibles ... :

+ Les fils, qui sont au nombre de trois (nous y reviendrons)
+ L'axe de rotation sur lequel est monté un accessoire en plastique ou en métal
+ Le boitier qui le protège

... mais aussi de plusieurs éléments que l'on ne voit pas :

+ un moteur à courant continu
+ des engrenages pour former un réducteur (en plastique ou en métal)
+ un capteur de position de l'angle d'orientation de l'axe (un potentiomètre bien souvent)
+ une carte électronique pour le contrôle de la position de l'axe et le pilotage du moteur à courant continu

Voilà une image 3D (extraite du [site internet suivant](http://ericaeromodelisme974.unblog.fr/2011/06/04/le-servomoteur/)) de vue de l'extérieur et de l'intérieur d'un servomoteur :

![Vue interne d'un servomoteur (sans l'électronique de commande)](/media/galleries/954/34fb4be4-3143-4263-aca3-b061462d9844.jpg.960x960_q85.jpg)

([Source de l'image](http://ericaeromodelisme974.unblog.fr/2011/06/04/le-servomoteur/))

## Connectique

Le servomoteur a besoin de trois fils de connexion pour fonctionner. Deux fils servent à son alimentation, le dernier étant celui qui reçoit le signal de commande :

+ rouge : pour l'alimentation positive (4.5V à 6V en général)
+ noir ou marron : pour la masse (0V)
+ orange, jaune, blanc, ... : entrée du signal de commande

Nous verrons tout à l'heure ce que nous devons entrer sur le dernier fil.

## La mécanique

Comme on le voit dans l'image précédente, le servomoteur possède plusieurs pignons (engrenages) en sortie du petit moteur CC. Cet ensemble est ce qui constitue le **réducteur**. Ce réducteur fait deux choses : d'une part il réduit la vitesse de rotation en sortie de l'axe du servomoteur (et non du moteur CC), d'autre part il permet d'augmenter le couple en sortie du servomoteur (là encore non en sortie du moteur CC). Alors, à quoi ça sert de réduire la vitesse et d'augmenter le couple ? Eh bien les moteurs CC se débrouillent très bien pour tourner très vite, mais lorsqu'ils font une si petite taille ils sont bien moins bons pour fournir du couple. On va donc utiliser ce réducteur qui va réduire la vitesse, car nous n'avons pas besoin d'avoir une vitesse trop élevée, et augmenter le couple pour ainsi pouvoir déplacer une charge plus lourde. Ceci est prouvé par la formule que je vous ai donnée dans le chapitre précédent : $R = \frac{\omega_{entree}}{\omega_{sortie}} = \frac{C_{sortie}}{C_{entree}}$ .

Le rapport de réduction (R) du réducteur définit le couple et la vitesse de sortie (en sortie du réducteur) selon la vitesse et le couple d'entrée (en sortie du moteur CC). Ces données sont souvent transparentes lorsque l'on achète un servomoteur. Dans la quasi-totalité des cas, nous n'avons que la vitesse angulaire (en degré par seconde °/s ), le couple de sortie du servomoteur et le débattement maximal (s'il s'agit d'un servomoteur ayant un débattement de 0 à 90°, 180, 360 ou autre). Et c'est largement suffisant étant donné que c'est que ce qui nous intéresse dans le choix d'un servomoteur. Il y a cependant une unité qui pourra peut-être vous donner quelques doutes ou une certaine incompréhension. Cette caractéristique est celle du couple du servomoteur et a pour unité le $kg.cm$ (kilogramme-centimètre). Nous allons tout de suite rappeler ce que cela signifie. Avant tout, rappelons la formule suivante : $C = F \times r$ qui donne la relation entre le couple $C$ du servomoteur (en kilogramme mètre), $F$ la force exercée sur le bras du servomoteur (en kilos) et $r$ la distance (en m) à laquelle s'exerce cette force par rapport à l'axe de rotation du servomoteur. Disséquons dans notre langage la signification de cette formule : le couple (C) exercé sur un axe est égal à la force (F) appliquée au bout du levier accroché à ce même axe.

À force identique, plus le levier est long et plus le couple exercé sur cet axe est important. En d'autres termes, si votre servomoteur dispose d'un bras d'un mètre de long (oui c'est très long) eh bien il aura beaucoup plus de difficultés à soulever une charge de, disons 10g, que son homologue qui supporte la même charge avec un bras nettement raccourci à 10 centimètres. Prenons l'exemple d'un servomoteur assez commun, le [Futaba s3003](http://www.gpdealera.com/cgi-bin/wgainf100p.pgm?I=FUTM0031). Sa documentation nous indique que lorsqu'il est alimenté sous 4.8V (on reviendra dessus plus tard), il peut fournir un couple (*torque* en anglais) de $3,2 kg.cm$ . C'est à dire, qu'au bout de son bras, s'il fait 1 centimètre, il pourra soulever une charge de 3,2kg. Simple, n'est-ce pas ? ;) Si le bras fait 10 centimètres, vous aurez compris que l'on perd 10 fois la capacité à soulever une masse, on se retrouve alors avec un poids de 320g au maximum (sans compter le poids du bras lui-même, certes négligeable ici, mais parfois non).

![Principe du couple mécanique](/media/galleries/954/cf0af115-8f68-410d-9286-0c77e6763815.png.960x960_q85.jpg)

Voilà une image qui permet d'illustrer un peu ce que je vous raconte depuis tout à l'heure (ça commençait à être ennuyeux, non ?). Bref. Ici, chaque poids représenté est celui maximum que peut soulever le servomoteur selon la distance à laquelle il est situé. Et ne vous avisez pas de les mettre tous car votre pauvre servo serait bien dans l'incapacité de les soulever en même temps. Et oui, malgré le fait qu'il n'y ait que 320g au bout du bras, le servo voit comme s'il y avait un poids de 3,2kg ! Dans cette situation on aurait trois fois 3,2kg, ce qui ferait un poids total de 9,6kg ! Impossible pour le servo de ne bouger ne serait-ce que d'un millimètre (vous risqueriez fort de le détruire d’ailleurs).

[[q]]
| Bon, d'accord, je comprends, mais et le zéro il y est pas sur ton dessin. Comment je sais quel poids je peux mettre sur l'axe du moteur ? o_O

Eh bien tout dépend du diamètre de cet axe. Voilà une question pertinente ! Alors, oui, répondons à la question. Mais avant, vous devriez avoir une idée de la réponse que je vais vous donner. Non ? Ben si, voyons ! Plus on éloigne le poids le l'axe et plus celui-ci diminue, et cela fonctionne dans l'autre sens : plus on le rapproche, plus sa valeur maximale augmente. En théorie, si on se met à 0cm, on pourrait mettre un poids infini. Admettons, plus rigoureusement, que l'on mette le poids à 1mm de l'axe (soit un axe de diamètre 2mm). Le poids que le servo pourrait soulever serait de... 10 fois plus ! Soit 32kg !! En conclusion, on peut admettre la formule suivante qui définit le poids maximal à mettre à la distance voulue :

$$ P_{max} = \frac C {d} $$

Avec :

+ $P_{max}$ : poids maximal de charge en kilogramme (kg)
+ $C$ : couple du servomoteur, en kilogramme centimètre (kg.cm)
+ $d$ : distance à laquelle le poids est placé en centimètre (cm)

Et si on se concentrait sur le pourquoi du servomoteur, car son objectif principal est avant tout de donner une position angulaire à son bras. Allez, voyons ça tout de suite !

## L'électronique d'asservissement

"*Qu'est-ce que l'asservissement ?*", vous demandez-vous sans doute en ce moment. Malgré la signification peu intuitive que ce terme porte, il se cache derrière quelque chose de simple à comprendre, mais parfois très compliqué à mettre en œuvre. Heureusement, ce n'est pas le cas pour le servomoteur. Toutefois, nous n'entrerons pas dans le détail et nous nous contenterons de présenter le fonctionnement. L'asservissement n'est ni plus ni moins qu'un moyen de gérer une consigne de régulation selon une commande d'entrée. Euuuh, vous me suivez ? :euh:

Prenons l'exemple du servomoteur : on l'alimente et on lui envoie un signal de commande qui permet de définir à quel angle va se positionner le bras du servomoteur. Ce dernier va s'exécuter. Essayez de forcer sur le bras du servomoteur... vous avez vu ? Quelle que soit la force que vous exercez (dans les limites du raisonnable), le servo va faire en sorte de toujours garder la position de son bras à l'angle voulu. Même si le poids est largement supérieur à ce qu'il peut supporter, il va essayer de remettre le bras dans la position à laquelle il se trouvait (à éviter cependant).

Ainsi, si vous changez l'angle du bras en forçant dessus, lorsque vous relâcherez le bras, il va immédiatement reprendre sa position initiale (celle définie grâce au signal de commande). Pour pouvoir réaliser le maintien de la position du bras de manière correcte, le servo utilise une **électronique de commande**. On peut la nommer **électronique d'asservissement**, car c'est elle qui va gérer la position du bras du servomoteur. Cette électronique est constituée d'une zone de comparaison qui compare (étonnamment ^^ ) la position du bras du servo au signal de commande. Le deuxième élément qui constitue cette électronique, c'est le capteur de position du bras. Ce capteur n'est autre qu'un potentiomètre couplé à l'axe du moteur. La mesure de la tension au point milieu de ce potentiomètre permet d'obtenir une tension image de l'angle d'orientation du bras.

Cette position est ensuite comparée, je le disais, à la consigne (le signal de commande) qui est transmise au servomoteur. Après une rapide comparaison entre la consigne et valeur réelle de position du bras, le servomoteur (du moins son électronique de commande) va appliquer une correction si le bras n'est pas orienté à l'angle imposé par la consigne.

![Synoptique de fonctionnement de l'asservissement du servomoteur](/media/galleries/954/c450a716-c5f7-48f3-924b-6da27eeaf820.png.960x960_q85.jpg)

Afin de garder la position de son bras stable, il est donc important de savoir quelle est la charge maximale applicable sur le bras du servomoteur. En somme, bien vérifier que le poids de la charge que vous comptez mettre sur votre servomoteur ne dépasse pas celui maximal qu'il peut supporter. Avant de passer à la suite, je vous propose de regarder cette superbe vidéo que j'ai trouvée par hasard sur [ce site web](http://trissiti.blogspot.fr/2012/04/servomoteur-pour-robot.html). Vous allez pouvoir comprendre au mieux le fonctionnement de la mécanique du servomoteur :

->!(https://www.youtube.com/watch?v=ZZhuD78BLDk)<-

->(Crédit vidéo : Bartek Sliwinski)<-

[[q]]
| Mais au fait, comment est transmise la consigne de commande de position du bras ? On lui dit par la liaison série ?

C'est ce que nous allons voir tout de suite dans la partie suivante. En avant !