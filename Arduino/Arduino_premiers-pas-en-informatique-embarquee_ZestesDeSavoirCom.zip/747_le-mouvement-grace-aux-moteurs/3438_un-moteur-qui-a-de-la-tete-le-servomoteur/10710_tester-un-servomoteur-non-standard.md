[[q]]
| C'est déjà la fin ? o_O

Eh oui, je n'ai plus grand-chose à vous dire, car ce n'est pas très compliqué puisqu'il suffit d'utiliser un outil déjà tout prêt qui est la bibliothèque *Servo*. Je vais cependant vous montrer deux autres fonctions bien utiles.

## `writeMicroSeconds()`

En premier, la fonction `writeMicroSeconds()`. Cette fonction permet de définir un temps à l'état HAUT du signal PPM autre que celui compris entre 1 et 2 ms. Elle est très pratique pour tester un servo dont vous ne connaissez pas les caractéristiques (servo 0 à 90° ou autre). De plus, il arrive que certains constructeurs ne se soucient pas trop des standards [1ms-2ms] et dépassent un peu ces valeurs. De par ce fait, si vous utilisez un servo avec les valeurs originales vous n'obtiendrez pas le comportement escompté. En utilisant cette fonction, vous pourrez ainsi tester le servo petit à petit en envoyant différentes valeurs une à une (par la voie série par exemple).

[[i]]
| Une valeur incorrecte se repère assez facilement. Si vous voyez votre servo "trembler" aux alentours des 0° ou 180° ou bien encore s'il fait des allers-retours étranges sans que vous n’ayez changé la consigne alors c'est que la valeur utilisée est probablement fausse.

## `read()`

Une deuxième fonction pouvant être utile est la fonction `read()`. Tout l'intérêt de cette fonction est perdu si elle est utilisée pour le code que l'on a vu dans l'exercice précédent. En revanche, elle a très bien sa place dans un système où le servomoteur est géré automatiquement par le programme de la carte Arduino et où l'utilisateur ne peut y accéder.

# Programme de test

En préparant ce chapitre, j'ai pu commencer à jouer avec un servomoteur issu de mes fonds de tiroirs. N'ayant bien entendu aucune documentation sur place ou sur internet, j'ai commencé à jouer avec en assumant qu'il utiliserait des valeurs "standards", donc entre 1000 et 2000µs pour l'état haut de la PPM. J'ai ainsi pu constater que mon servo fonctionnait, mais on était loin de parcourir les 180° attendus. J'ai donc fait un petit code utilisant une des fonctions précédentes pour tester le moteur en mode "pas à pas" et ainsi trouver les vrais timings de ces bornes. Pour cela, j'ai utilisé la liaison série. Elle m'a servi pour envoyer une commande simple ('a' pour augmenter la consigne, 'd' pour la diminuer). Ainsi, en recherchant à tâtons et en observant le comportement du moteur, j'ai pu déterminer qu'il était borné entre 560 et 2130 µs. Pas super proche des 1 et 2ms attendues ! :P Comme je suis sympa ( :euh: ), je vous donne le code que j'ai réalisé pour le tester. Les symptômes à observer sont : aucune réaction du servo (pour ma part en dessous de 560 il ne se passe plus rien) ou au contraire, du mouvement sans changement de la consigne (de mon côté, si l'on augmente au-dessus de 2130 le servo va continuer à tourner sans s’arrêter).

```cpp
#include <Servo.h> // On oublie pas d'ajouter la bibliothèque !

int temps = 1500; // censée être à mi-chemin entre 1000 et 2000, un bon point de départ

Servo monServo;

void setup()
{
    Serial.begin(115200);
    Serial.println("Hello World");

    monServo.attach(2);
    // on démarre à une valeur censé être la moitié de
    // l'excursion totale de l'angle réalisé par le servomoteur
    monServo.writeMicroseconds(temps);
}

void loop()
{
    // des données sur la liaison série ? (lorsque l'on appuie sur 'a' ou 'd')
    if(Serial.available())
    {
        char commande = Serial.read(); // on lit

        // on modifie la consigne si c'est un caractère qui nous intéresse
        if(commande == 'a')
            temps += 10;  // ajout de 10µs au temps HAUT
        else if(commande == 'd')
            temps -= 10;  // retrait de 10µs au temps HAUT

        // on modifie la consigne du servo
        monServo.writeMicroseconds(temps);

        // et on fait un retour sur la console pour savoir où on est rendu
        Serial.println(temps, DEC);
    }
}
```
Code: Programme de test d'un servomoteur

Ce programme est très simple d'utilisation et vous pouvez d'ailleurs le modifier comme bon vous semble pour qu'il corresponde à ce que vous voulez faire avec. Il suffit en fait de brancher la carte Arduino à un ordinateur et ouvrir un terminal série (par exemple le moniteur intégré dans l'environnement Arduino). Ensuite, appuyez sur 'a' ou 'd' pour faire augmenter ou diminuer le temps de l'état HAUT du signal PPM. Vous pourrez ainsi avoir un retour des temps extrêmes qu'utilise votre servomoteur.