Bon allez, il est temps de faire un peu d'entrainement ! Je vous laisse découvrir le sujet...

## Consigne

Nous allons utiliser trois éléments dans cet exercice :

+ un servomoteur (évidemment)
+ un potentiomètre (valeur de votre choix)
+ la liaison série

## Objectif

Le servo doit "suivre" le potentiomètre. C'est-à-dire que lorsque vous faites tourner l'axe du potentiomètre, le bras du servomoteur doit tourner à son tour et dans le même sens. Pour ce qui est de l'utilisation de la liaison série, je veux simplement que l'on ait un retour de la valeur donnée par le potentiomètre pour faire une supervision. Je ne vous en dis pas plus, vous savez déjà tout faire. Bon courage et à plus tard ! ;)

->!(https://www.youtube.com/watch?v=LQtl9KkunVE)<-

# Correction

J’espère que vous avez réussi ! Tout d’abord le schéma, même si je sais que vous avez été capable de faire les branchements par vous-même. C’est toujours bon de l'avoir sous les yeux. ;)

![Arduino branché avec un servomoteur et un potentiomètre](/media/galleries/954/3d5b2b64-74cc-4832-8ec9-f7ee17a2366f.png.960x960_q85.png)

Pour ma part, j'ai branché le servo sur la broche numérique 2 et le potentiomètre sur la broche analogique 0. J'ai donc le code suivant pour préparer l'ensemble :

```cpp
#include <Servo.h> // On n'oublie pas d'ajouter la bibliothèque !

// notre potentiomètre
const int potar = 0;

// création d'un nouveau servomoteur
Servo monServo;

void setup()
{
    // on déclare l'entrée du servo connectée sur la broche 2
    monServo.attach(2);
    // on n'oublie pas de démarrer la liaison série ;-)
    Serial.begin(9600);
}
```

Voilà qui est fait pour les préparatifs, il n'y a plus qu'à travailler un tout petit peu pour faire la logique du code. Commençons par la lecture analogique que nous allons renvoyer sur le servo ensuite. Le potentiomètre délivre une tension variable de 0 à 5V selon sa position. La carte Arduino, elle, lit une valeur comprise entre 0 et 1023. Ce nombre est stocké au format `int`. Il faut ensuite que l'on donne à la fonction qui permet d'envoyer la consigne au servo une valeur comprise entre 0 et 180°. On va donc utiliser une fonction dédiée à cela. Cette fonction permet de faire le rapport entre deux gammes de valeurs ayant chacune des extremums différents. Il s'agit de la fonction [`map()`](http://arduino.cc/en/Reference/Map) (nous en avions parlé dans le chapitre sur les lectures analogiques) :

```cpp
map(value, fromLow, fromHigh, toLow, toHigh)
```

Avec pour correspondance :

+ **value** : valeur à convertir pour la changer de gamme
+ **fromLow** : valeur minimale de la gamme à convertir
+ **fromHigh** : valeur maximale de la gamme à convertir
+ **toLow** : valeur minimale de la gamme vers laquelle est convertie la valeur initiale
+ **toHigh** : valeur maximale de la gamme vers laquelle est convertie la valeur initiale

Nous utiliserons cette fonction de la manière suivante :

```cpp
map(valeur_potentiometre, 0, 1023, 0, 180) ;
```

[[q]]
| On aurait pu faire un simple produit en croix, non ?

Tout à fait. Mais les programmeurs sont de véritables fainéants et aiment utiliser des outils déjà prêts. :P Cela dit, ils les ont créés. Et pour créer de nouveaux outils, il est plus facile de prendre des outils déjà existants. Mais si vous voulez, on peut recréer la fonction map() par nous-mêmes :

```cpp
int conversion(int mesure)
{
    return mesure*180/1023;
}
```

## Fonction `loop()`

Dans la fonction `loop()` on a donc la récupération et l'envoi de la consigne au servomoteur :

```cpp
void loop()
{
    // on lit la valeur du potentiomètre
    int val = analogRead(potar);
    // mise à l'échelle de la valeur lue vers la plage [0;180]
    int angle = map(val, 0, 1023, 0, 180);
    // on met à jour l'angle sur le servo
    monServo.write(angle);
}
```
Code: Rotation du servo en fonction du potentiomètre

Avez-vous remarqué que ces trois lignes de code auraient pu être réduites en une seule ? :P Comme ceci :

```cpp
monServo.write(map(analogRead(potar), 0, 1023, 0, 180));
```

Ou bien la version utilisant le produit en croix :

[[s]]
| ```cpp
| void loop()
| {
|     // on lit la valeur du potentiomètre
|     int val = analogRead(potar);
|     // on converti la valeur lue en angle compris dans l’interval [0;180]
|     int angle = val / 5.7;
|     // 5,7 provient de la division de 1023/180
|     // pour la mise à l'échelle de la valeur lue
|
|     // on met à jour l'angle sur le servo
|     monServo.write(angle);
| }
| ```
|
| Et à nouveau une condensation de ces trois lignes en une :
|
| ```cpp
| monServo.write(analogRead(potar)/5.7);
| ```

[[a]]
| Mais comme il nous faut renvoyer la valeur convertie vers l'ordinateur, il est mieux de stocker cette valeur dans une variable. Autrement dit, préférez garder le code à trois lignes.

## Et la liaison série

Pour renvoyer la valeur, rien de bien sorcier :

```cpp
Serial.println(angle);
```

## Code final

Au final, on se retrouve avec un code tel que celui-ci :

[[s]]
| ```cpp
| #include <Servo.h> // On n'oublie pas d'ajouter la bibliothèque !
|
| const int potar = 0; // notre potentiomètre
| Servo monServo;
|
| void setup()
| {
|     // on déclare le servo sur la broche 2 (éventuellement régler les bornes)
|     monServo.attach(2);
|     // on n'oublie pas de démarrer la voie série
|     Serial.begin(9600);
| }
|
| void loop()
| {
|     // on lit la valeur du potentiomètre
|     int val = analogRead(potar);
|     // on convertit la valeur lue en angle compris dans l’intervalle [0;180]
|     int angle = val / 5.7;
|     // on met à jour l'angle sur le servo
|     monServo.write(angle);
|     // on renvoie l'angle par la voie série pour superviser
|     Serial.println(angle);
|     // un petit temps de pause
|     delay(100);
| }
| ```
| Code: Code final de l'exercice de rotation d'un servo en fonction d'un potentiomètre

Je vous laisse mixer avec les différents codes que l'on vous a donnés pour que vous fassiez celui qui vous convient le mieux (avec la fonction map(), ou bien celui qui est tout condensé, etc.). Dorénavant, vous allez pouvoir vous amuser avec les servomoteurs ! ;)