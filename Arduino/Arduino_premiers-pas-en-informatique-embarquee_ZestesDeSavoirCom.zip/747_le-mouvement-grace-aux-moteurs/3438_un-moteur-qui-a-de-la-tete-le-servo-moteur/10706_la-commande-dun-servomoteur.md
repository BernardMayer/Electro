Ce qu'il est intéressant de découvrir à présent, c'est de savoir comment piloter un moteur de ce type. Et oui car cela n'a pas beaucoup de ressemblances avec le moteur à courant continu. Il ne va pas être question de pont en H ou autres bizarreries de ce type, non, vous allez voir, ça va être très simple.

[[i]]
| Sachez toutefois qu'il existe deux types de servomoteur : ceux qui possèdent une électronique de commande de type analogique, qui sont les plus courants et les moins chers et ceux qui sont asservis par une électronique de commande numérique, très fiables et très performants, mais bien plus onéreux que leur homologues analogiques. Vous comprendrez pourquoi notre choix s'oriente sur le premier type. :P De plus, leur contrôle est bien plus simple que les servomoteurs à régulation numérique qui utilisent parfois des protocoles bien particuliers.

# Le signal de commande

La consigne envoyée au servomoteur n'est autre qu'un signal électronique de type PWM. Il dispose cependant de deux caractéristiques indispensables pour que le servo puisse comprendre ce qu'on lui demande. À savoir : une fréquence fixe de valeur 50Hz (comme celle du réseau électrique EDF) et d'une durée d'état HAUT elle aussi fixée à certaines limites. Nous allons étudier l'affaire.

[[i]]
| Certains sites de modélisme font état d'un nom pour ce signal : une PPM pour *Pulse Position Modulation*. J'utiliserais également ce terme de temps en temps, n'en soyez pas surpris !

## La fréquence fixe

Le signal que nous allons devoir générer doit avoir une fréquence de 50 Hz. Autrement dit, le temps séparant deux fronts montants est de 20 ms. Je rappelle la formule qui donne la relation entre la fréquence (F) et le temps de la période du signal (T) : $F = \frac 1 T$

![Signal de fréquence 50 Hz](/media/galleries/954/96748950-6aff-434e-bdf1-88ffc63dba62.png.960x960_q85.png)

Malheureusement ,la fonction analogWrite() de Arduino ne possède pas une fréquence de 50Hz, mais dix fois plus élevée, de 500Hz environ. On ne pourra donc pas utiliser cette fonction.

[[q]]
| Haaaaaaaaaa ! Mais comment on va faire !!! :'(

Ola, vous affolez pas ! Il existe une alternative, ne vous pressez pas, on va voir ça dans un moment. ^^

## La durée de l'état HAUT

Pourquoi est-ce si important ? Qu'avons nous à savoir sur la durée de l'état HAUT du signal PWM ? À quoi cela sert-il, finalement ? Eh bien ces questions trouvent leurs réponses dans ce qui va suivre, alors tendez bien l'oreille et ne perdez pas une miette de ce que je vais vous expliquer. ~(Eh ! Entre nous, c'est pas mal cette petite intro, non ? Elle captive votre attention tout en faisant durer le suspense. Perso j'aime bien, pas vous ? Bon, je continue. ^^ )~ Cette durée, chers petits zéros, est ce qui compose l'essentiel du signal. Car c'est selon elle que le servomoteur va savoir comment positionner son bras à un angle précis. Vous connaissez comment fonctionne un signal PWM, qui sert également à piloter la vitesse d'un moteur à courant continu. Eh bien, pour le servomoteur, c'est quelque peu semblable. En fait, un signal ayant une durée d'état HAUT très faible donnera un angle à 0°, le même signal avec une durée d'état HAUT plus grande donnera un angle au maximum de ce que peut admettre le servomoteur. Mais, soyons rigoureux ! Précisément, je vous parlais de valeurs limites pour cet état HAUT et ce n'est pas pour rien, car ce dernier est limité entre une valeur de $1ms$ au minimum et au maximum de $2ms$ (ce sont bien des millisecondes puisque l'on parle de durée en temps) pour les servos standards. Comme un schéma vaut mieux qu'un long discours :

![Position en fonction de la pulsation](/media/galleries/954/7591c7c0-8407-4560-99f3-50a15f711865.png.960x960_q85.jpg)

Vous aurez deviné, à travers cette illustration, que la durée de l'état HAUT fixe la position du bras du servomoteur à un angle déterminé.

[[q]]
| Et comment je fais si je veux que mon servomoteur face un angle de 45° ? Ça marche pas ? o_O

Si, bien sûr. En fait, il va falloir faire jouer le temps de l'état HAUT. Pour un angle de 45°, il va être compris entre 1ms et 1,5ms. À 1,25ms précisément. Après, c'est un rapport qui utilise une relation très simple, le calcul ne vous posera donc aucun problème. Tous les angles compris dans la limite de débattement du bras du servomoteur sont possibles et configurables grâce à ce fameux état HAUT.

[[q]]
| Et si mon servomoteur n'a pas l'angle 0° pour origine, mais 90°, comment on fait ?

C'est pareil ! Disons que 90° est l'origine, donc on peut dire qu'il est à l'angle 0°, ce qui lui donne un débattement de -90° à +90° :

![Position en fonction de la pulsation avec décalage](/media/galleries/954/05d9283e-a86b-462a-b788-21d7daf90cfc.png.960x960_q85.jpg)

Et dans le cas où le servo peut faire un tour complet (donc 360°), c'est aussi la même chose. En fait c'est toujours pareil, quelque soit le débattement du moteur. En revanche, c'est légèrement différent pour les servomoteurs à rotation continue. Le signal ayant un état HAUT de 1ms donnera l'ordre "vitesse maximale dans un sens", la même ayant 2ms sera l'ordre pour "vitesse maximale dans l'autre sens" et 1.5ms sera la consigne pour "moteur arrêté". Entre chaque temps (par exemple entre 1ms et 1,5ms) le moteur tournera à une vitesse proportionnelle à la durée de l'état HAUT. On peut donc commander la vitesse de rotation du servo.