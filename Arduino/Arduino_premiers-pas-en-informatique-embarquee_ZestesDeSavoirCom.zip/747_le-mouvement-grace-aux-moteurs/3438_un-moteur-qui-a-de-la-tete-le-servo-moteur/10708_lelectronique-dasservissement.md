Je le disais donc, on va voir un peu comment se profile le fonctionnement de l'électronique interne des servomoteurs analogiques. Je précise bien *analogiques* car je rappelle qu'il y a aussi des servomoteurs numériques, beaucoup plus complexes au niveau de l'électronique.

# Principe de fonctionnement

Commençons par un simple synoptique de fonctionnement. Référez-vous à la vidéo et aux explications que je vous ai données jusqu'à présent pour comprendre ce synoptique :

![Principe de fonctionnement de l'électronique de commande d'un servomoteur](/media/galleries/954/1e41cddb-0e5d-41da-a443-98ba825daa46.png.960x960_q85.jpg)

Rapidement : la consigne donnée par l'utilisateur (dans notre cas il va s'agir du signal envoyé par la carte Arduino), est comparée par rapport à la position réelle de l'axe du moteur. Ainsi, s'il y a une différence d'angle entre la consigne et l'angle mesuré par le capteur (le potentiomètre qui est fixé sur l'axe du servomoteur) eh bien le comparateur va commander le moteur et le faire tourner jusqu'à ce que cette différence s'annule.

[[a]]
| Avant d'aller plus loin, il faut savoir que les servomoteurs analogiques du commerce emploient en fait, dans leur électronique de commande, un microcontrôleur. Je ne vais donc pas vous expliquer comment ceux-là fonctionnent, mais je vais prendre le montage le plus basique qui soit. D'ailleurs, à l'issue de mes explications, vous serez capable de mettre en œuvre le montage que je vais donner et créer votre propre servomoteur avec un moteur CC anodin. ;)

# Électronique à consigne manuelle

On va commencer par un montage dont la simplicité est extrême mais dont vous ne connaissez pas encore le fonctionnement d'un composant essentiel : le **comparateur**. Allez, c'est parti pour un bon petit cours d'électronique pure ! :roll: Alors, déjà, pourquoi "manuelle" ? Simplement parce que la consigne envoyée à l'électronique de commande est une tension continue et qu'elle sera réglable par un potentiomètre. En gros vous aurez simplement à faire tourner l'axe d'un potentiomètre pour régler l'angle du bras du servomoteur.

## Synoptique de l'électronique interne

Commençons par un synoptique qui établit le fonctionnement de l'électronique de contrôle :

![Fonctionnement de l'électronique de contrôle](/media/galleries/954/ce7aaf9e-001d-4417-bb2f-9d50f78969ed.png.960x960_q85.jpg)

Il y a donc en entrée les deux paramètres : la consigne et l'angle réel de l'axe du moteur; Et en sortie, la tension qui va commander le moteur. On l'a vu, un moteur à courant continu doit être commandé par une tension continue, si cette tension est positive, le moteur tournera dans un sens, si elle est négative, le moteur tournera dans l'autre sens. C'est pourquoi le comparateur délivrera une tension positive ou négative selon la correction d'angle à effectuer.

## Schéma de principe

À présent voici le schéma de principe qui a pour fonctionnement celui expliqué par le synoptique précédent :

![Schéma de principe](/media/galleries/954/4927e49f-4c42-491d-9862-108e8cee8910.png.960x960_q85.jpg)

De gauche à droite on a : les alimentations qui fournissent la tension positive et négative ; les potentiomètres P1 et P2 ; le comparateur (oui c'est ce gros triangle avec un plus et un moins) : enfin le moteur à courant continu.

## Fonctionnement du comparateur

Un comparateur est un composant électronique de la famille des circuits intégrés car, il contient en vérité d'autres composants, essentiellement des semi-conducteurs (diodes, transistors) et des résistances. **Ce composant a toujours besoin d'une alimentation externe pour fonctionner, c'est à dire qu'on ne peut lui mettre des signaux à son entrée que s'il est alimenté.** Autrement il pourrait être endommagé (c'est pas souvent le cas, mais mieux vaut être prudent). Vous le constatez par vous-même, le comparateur est un composant qui possède deux entrées et une sortie. Et, de la manière la plus simple qui soit, en fait il n'y a rien de plus simple qui puisse exister, son fonctionnement réside sur le principe suivant :

+ Si la tension (je me base par rapport au schéma) $V1$ qui arrive sur l'entrée $E1$ du comparateur est supérieure à la tension $V2$ qui entre sur l'entrée $E2$ du comparateur, alors la tension en sortie $S$ du comparateur est égale à $+Vcc$ (l'alimentation du comparateur).
+ Tandis que dans le cas opposé où la tension $V2$ va être supérieure à $V1$ , la sortie $S$ du comparateur aura une tension égale à $-Vcc$ .

En transposant mes dires sous une forme mathématique, cela donnerait ceci :

+ Si $V1 \gt V2$ , alors $Vs = +Vcc$
+ Si $V1 \gt V2$ , alors $Vs = -Vcc$

Comment s'en rappeler ? Eh bien grâce aux petits symboles "+" et "-" présents dans le triangle représentant le comparateur. La sortie du comparateur prendra +Vcc si la tension sur l'entré "+" du comparateur est supérieure à celle sur l'entrée "-" et inversement. Voyez, j'vous z'avais dis que c'était ultra simple. ;) Il y a encore quelque chose à savoir : Il est impossible que les tensions V1 et V2 soient égales ! Oui, car le comparateur ne peut pas fournir une tension positive ET une tension négative en sa sortie, c'est pourquoi, même si vous reliez E1 et E2 avec un fil, la tension en sortie du comparateur sera toujours OU +Vcc OU -Vcc.

# Électronique à consigne PWM

## Synoptique de principe

Prenons l'exemple d'un servomoteur qui utilise une PWM, oui j'ai bien dit... euh écrit **PWM**. Je prends cet exemple fictif car comme je le disais il y a quelques instants, c'est bien souvent un microcontrôleur qui gère l'asservissement du servomoteur. Et puis, avec l'exemple que je vais vous donner, vous pourrez vous-même créer un servomoteur. ;) En fait, on ne peut pas utiliser directement ce signal PWM avec le schéma précédent. Il va falloir que l'on fasse une extraction de la composante continue de ce signal pour obtenir une consigne dont la tension varie et non la durée de l'état HAUT du signal. Et ceci, nous l'avons déjà vu dans [un chapitre dédié à la PWM](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/745/les-grandeurs-analogiques/3432/et-les-sorties-analogiques-enfin-presque/#2-la-pwm-de-larduino) justement. Le synoptique ne change guère, il y a simplement ajout de ce montage intermédiaire qui va extraire cette tension continue du signal :

![Principe d'extraction de la tension continue du signal](/media/galleries/954/6255d872-9ea9-4270-8017-5570d66a4a69.png.960x960_q85.jpg)

Le schéma électrique ne change pas non plus de beaucoup, on retire le potentiomètre qui permettait de régler la consigne manuellement en le remplaçant par le montage qui fait l'extraction de la composante continue:

![Montage d'extraction de la tension continue du signal](/media/galleries/954/58e9098f-b7a6-4e4b-9cf0-bdd6ff66f861.png.960x960_q85.jpg)

À la place du potentiomètre de commande manuelle on retrouve un couple résistance/condensateur avec $R$ et $C$ , qui permet d'extraire la tension continue du signal $V_{PWM}$ qui est donc un signal de type PWM dont le rapport cyclique varie de 0 à 100%. Et là, tenez-vous bien, on en arrive au point où je voulais vous amener ! :D Que remarquez-vous ? Rien ? Alors je vous le dis : que se passe-t-il si on arrête d'envoyer le signal $V_{PWM}$ ? Le moteur garde son bras au même angle ? Ou bien il reprend sa position initiale ? Réponse : il reprend sa position initiale. Eh oui, car la tension continue $V1$ n'existe plus puisqu'elle est créée à partir du signal $V_{PWM}$ . Quand il y avait le potentiomètre, la tension $V1$ gardait la même valeur tant que vous ne tourniez pas l'axe du potentiomètre, hors là, si on enlève le signal $V_{PWM}$ , eh bien la tension $V1$ perd sa valeur et retombe à 0V. Par conséquent, le moteur redonne à son bras sa position initiale.

[[q]]
| Et si je veux que mon servomoteur continue de garder l'angle de la consigne qui lui a été transmise sans que je continue à lui envoyer cette consigne, est-ce possible ?

Oui, c'est tout à fait possible. En fait, cela va peut-être paraître un peu "barbare", mais c'est la seule solution envisageable avec les servomoteurs analogiques : il suffit de le positionner à l'angle voulu et de couper son alimentation. L'angle du bras du servomoteur sera alors conservé. **Mais attention, cet angle ne sera conservé que s'il n'y a pas de contrainte mécanique exercée sur le bras du servo !** C'est à dire qu'il n'y ai pas un poids accroché à l'axe du moteur, ou alors il faut qu'il soit bien inférieur à la force de maintien de la position du bras du servo lorsque celui-ci n'est plus alimenté.

[[q]]
| Et pour l'électronique à consigne PPM alors ? o_O

Pour ce type d'électronique de commande (présent dans tous les servos du commerce), je vous l'ai dit : il y a utilisation d'un microcontrôleur. Donc tout se fait par un programme qui scrute la position réelle du bras du moteur par rapport à la consigne PPM qu'il reçoit. Je n'ai donc rien d'intéressant à vous raconter. :-°