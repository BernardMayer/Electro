[[information]]
|Les montages de cette partie sont importants à connaître. Vous n'êtes pas obligé de les mettre en œuvre, mais si vous le voulez (et en avez les moyens), vous le pouvez. Je dis ça car la partie suivante vous montrera l'existence de shields dédiés aux moteurs à courant continu, vous évitant ainsi quelques maux de têtes pour la réalisation des schémas de cette page. ^^

# Faire varier la vitesse : la PWM

Maintenant que nous avons les bases fondamentales pour faire tourner notre moteur sans tout faire griller ( :roll: ), nous allons pouvoir acquérir d'autres connaissances. À commencer par quelque chose de facile : le réglage de la vitesse de rotation du moteur. Comme nous l'expliquions dans le premier morceau de ce chapitre, un moteur à courant continu possède une relation directe entre sa tension d'alimentation et sa vitesse de rotation. En effet, plus la tension à ses bornes est élevée et plus son axe tournera rapidement (dans la limite de ses caractéristiques évidemment). Cependant le microcontrôleur d'Arduino n'est capable de produire que des tensions de 0 ou 5V. En revanche, il peut "simuler" des tensions variables comprises entre 0 et 5V. Encore un petit rappel de cours nécessaire sur la PWM que nous avons déjà [rencontrée ici](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/745/les-grandeurs-analogiques/3432/et-les-sorties-analogiques-enfin-presque/)  pour vous rafraichir la mémoire. Nous sommes en mesure de produire à l'aide de notre microcontrôleur un signal carré dont le rapport cyclique est variable. Et grâce à cela, nous obtenons une tension moyenne (comprise entre 0 et 5V) en sortie de la carte Arduino. Il faut juste bien penser à utiliser les sorties adéquates, à savoir : 3, 5, 6, 9, 10 ou 11 (sur une duemilanove/UNO). Je résume : en utilisant la PWM, on va générer une tension par impulsions plus ou moins grandes. Ce signal va commander le transistor qui va à son tour commander le moteur. Le moteur va donc être alimenté par intermittences à cause des impulsions de la PWM. Ce qui aura pour effet de modifier la vitesse de rotation du moteur.

[[question]]
|Mais, si le moteur est coupé par intermittences, il va être en rotation, puis va s'arrêter, puis va recommencer, etc. Ce sera pas beau et ça ne tournera pas moins vite. Je comprends pas trop ton histoire. o_O

Non, puisque le moteur garde une inertie de rotation et comme la PWM est un signal qui va trop vite pour que le moteur ait le temps de s'arrêter puis de redémarrer, on va ne voir qu'un moteur qui tourne à une vitesse réduite. Finalement, nous allons donc pouvoir modifier la vitesse de rotation de notre moteur en modifiant le rapport cyclique de la PWM. Plus il est faible (un état BAS plus long qu'un état HAUT), plus le moteur ira doucement. Inversement, plus le rapport cyclique sera élevé (état HAUT plus long que l'état BAS), plus le moteur ira vite. Tout cela couplé à un transistor pour faire passer de la puissance (et utiliser la tension d'utilisation adaptée au moteur) et nous pouvons faire tourner le moteur à la vitesse que nous voulons. Génial non ? Pour l'instant je ne vous ferai pas de démo (vous pouvez facilement imaginer le résultat), mais cela arrivera très prochainement lors de l'utilisation de l'Arduino dans la prochaine sous-partie. Le montage va être le même que tout à l'heure avec le "nouveau" transistor et sa résistance de base :

![Schéma du montage complet du moteur CC](/media/galleries/954/e7ba621c-7ff6-4166-9dde-ab2ed3723390.png.960x960_q85.jpg)


![Montage complet du moteur CC](/media/galleries/954/8b268b47-06bd-496b-8603-a16c8833f257.png.960x960_q85.jpg)


Maintenant que le moteur tourne à une vitesse réglable, il pourra être intéressant de le faire tourner aussi dans l'autre sens (si jamais on veut faire une marche arrière, par exemple, sur votre robot), voire même d'être capable de freiner le moteur. C'est ce que nous allons tout de suite étudier dans le morceau suivant en parlant d'un composant très fréquent dans le monde de la robotique : le **pont en H**.

# Tourner dans les **deux** sens : le pont en H

Faire tourner un moteur c'est bien. Tourner à la bonne vitesse c'est mieux. Aller dans les deux sens c'est l'idéal. C'est donc ce que nous allons maintenant chercher à faire !

## Découverte du pont en H

Tout d'abord une question très simple : pourquoi le moteur tourne dans un seul sens ? Réponse évidente : parce que le courant ne va que dans un seul sens ! Pour pouvoir aller vers l'avant ET vers l'arrière il nous faut donc un dispositif qui serait capable de faire passer le courant dans le moteur dans un sens ou dans l'autre. Vous pouvez faire l'expérience en reprenant le premier montage de ce chapitre où il n'y avait que le moteur connecté sur une pile de 9V. Essayez d'inverser les deux bornes du moteur (ça ne risque rien ;) ) pour observer ce qu'il se passe : le moteur change de sens de rotation. C'est dû au champ magnétique créé par les bobines internes du moteur qui est alors opposé. Reprenons notre dispositif de base avec un transistor (que nous symboliserons ici par un interrupteur). Si ce dernier est activé le moteur tourne, sinon le moteur est arrêté. Jusque là rien de nouveau. Rajoutons un deuxième transistor "de l'autre côté" du moteur. Rien ne va changer, mais il va falloir commander les deux transistors pour faire tourner le moteur. Ce n'est pas bon. Essayons avec quatre transistors, soyons fou !

![Le pont en H](/media/galleries/954/8064797c-1d5e-449b-8a44-dec74dccc24e.png.960x960_q85.png)


Eh bien, cela change tout ! Car à présent nous allons piloter le moteur dans les deux sens de rotation. Pour comprendre le fonctionnement de ce pont en H (appelé ainsi par sa forme), imaginons que je ferme les transistors 1 et 4 en laissant ouverts le 2 et le 3. Le courant passe de la gauche vers la droite.

![Fonctionnement dans le sens horaire](/media/galleries/954/11e2f730-9491-4a56-b71a-e10da3bcb2a2.png.960x960_q85.png)


Si en revanche je fais le contraire (2 et 3 fermés et 1 et 4 ouverts), le courant ira dans l'autre sens ! C'est génial non ?

![Fonctionnement dans le sens anti-horaire](/media/galleries/954/39ee92d1-9212-4cd3-9d4d-7b134ab51cb5.png.960x960_q85.png)


Et ce n'est pas tout !

## Allons plus loin avec le pont en H

Comme vous l'aurez sûrement remarqué, les transistors fonctionnent deux par deux. En effet, si on en ferme juste un seul et laisse ouvert les trois autres le courant n'a nulle part où aller et rien ne se passe, le moteur est en roue libre. Maintenant, que se passe-t-il lorsqu'on décide de fermer 1 & 2 en laissant 3 et 4 ouverts ? Cette action va créer ce que l'on appelle un **frein magnétique**. Je vous ai expliqué plus tôt comment cela fonctionnait lorsque l'on mettait une diode de roue libre aux bornes du moteur. Le moteur se retrouve alors court-circuité. En tournant à cause de son inertie, le courant généré va revenir dans le moteur et va le freiner. Attention cependant, c'est différent d'un phénomène de roue libre où le moteur est libre de tourner.

![Freinage avec 1 & 2](/media/galleries/954/9fca6594-bfef-45aa-b57d-8c63d8ff154c.png.960x960_q85.png)


![Freinage avec 3 & 4](/media/galleries/954/3baeca89-6e06-4c1a-8129-984f41964e40.png.960x960_q85.png)


[[attention]]
| Ne fermez **jamais** 1 & 3 et/ou 2 & 4 ensembles, cela ferait un court-circuit de l'alimentation et vos transistors risqueraient de griller immédiatement si l'alimentation est capable de fournir un courant plus fort que ce qu'ils ne peuvent admettre.


# Les protections nécessaires


## Les diodes de roue libre

Comme nous l'avons vu plus haut, pour protéger un transistor des parasites ou lors du freinage électronique du moteur, nous plaçons une diode. Dans le cas présent, cette diode devra être en parallèle aux bornes du transistor (regardez le schéma qui suit). Ici nous avons quatre transistors, nous utiliserons donc quatre diodes que nous placerons sur chaque transistor. Ainsi, le courant trouvera toujours un moyen de passer sans risquer de forcer le passage dans les transistors en les grillant. Comme vu précédemment, des diodes de type Shottky sont recommandées pour leurs caractéristiques de tension de seuil faible et commutation rapide.

![Pont en H avec ses diodes de protection](/media/galleries/954/8e6fdc4f-1b1c-4497-93bc-a34e8cc92045.png.960x960_q85.png)



## Un peu de découplage

Lorsque nous utilisons le moteur avec une PWM, nous générons une fréquence parasite. De plus, le moteur qui tourne génère lui même des parasites. Pour ces deux raisons, il est souvent utile d'ajouter des **condensateurs de filtrage** aux bornes du moteur. Comme sur le montage suivant, on peut en placer un en parallèle des deux broches du moteur, et deux autres plus petits entre une broche et la carcasse du moteur.

![Un peu de découplage](/media/galleries/954/0fc61175-04cc-4f9f-9725-3222fe9a1711.jpg.960x960_q85.jpg)

![Un peu de découplage, schéma](/media/galleries/954/7648321e-69e8-45d4-b6b2-5d18ae581dda.jpg.960x960_q85.jpg)


Ensuite, lorsque le moteur démarre il fera un appel de courant. Pour éviter d'avoir à faire transiter ce courant depuis la source de tension principale (une batterie par exemple), il est de bon usage de mettre un gros condensateur polarisé aux bornes de l'alimentation de puissance du pont en H. Ainsi, au moment du départ l'énergie sera en partie fournie par ce condensateur plutôt qu'en totalité par la batterie (ce qui évitera un échauffement abusif des conducteurs mais aussi une éventuelle baisse de la tension due à l'appel de courant).

# Des solutions intégrées : L293, L298...

Afin d'éviter de vous torturer avec les branchements des transistors et leur logique de contrôle, des composants "clés en main" ont été développés et produits. Nous allons maintenant étudier deux d’entre eux que nous retrouvons dans quasiment tous les shields moteurs Arduino : le L293(D) et son grand frère, plus costaud, le L298.

## Le L293(D)

Tout d'abord, voici un lien vers [la datasheet du composant](http://www.datasheetcatalog.org/datasheet/texasinstruments/l293d.pdf) . Les premières données nous apprennent que ce composant est un "quadruple demi-pont en H". Autrement formulé, c'est un double pont en H (car oui, 4 fois un demi ça fait 2 !). Ce composant est fait pour fonctionner avec des tensions de 4.5V à 36V et sera capable de délivrer 600 mA par canaux (dans notre cas cela fera 1,2A par moteur puisque nous utiliserons les demi-ponts par paire pour tourner dans les deux sens). Un courant de pic peut être toléré allant jusqu'à 1,2A par canaux (donc 2,4A dans notre cas). Enfin, ce composant existe en deux versions, le L293 et le L293D. La seule différence (non négligeable) entre les deux est que le L293D intègre déjà les diodes en parallèle des transistors. Un souci de moins à se préoccuper ! En revanche, cela implique donc des concessions sur les caractéristiques (le courant max passe à 1A par canaux et 2A pic pour la version sans les diodes). Le branchement de ce composant est assez simple (page 2 de la datasheet), mais nous allons le voir ensemble maintenant. Ce composant a 16 broches et fonctionne selon un système de symétrie assez simple.

![Le L293](/media/galleries/954/a07ef8bb-39f4-4973-9bbe-dba6d05719e4.png.960x960_q85.png)


De chaque côté les broches du milieu (4, 5, 12 et 13) servent à relier la masse mais aussi à dissiper la chaleur. On trouve les entrées d'activation des ponts (*enable*) sur les broches 1 et 9. Un état HAUT sur ces broches et les ponts seront activés, les transistors pourront s'ouvrir ou se fermer, alors qu'un état BAS désactive les ponts, les transistors restent ouverts. Ensuite, on trouve les broches pour piloter les transistors. Comme un bon tableau vaut mieux qu'un long discours, voici les cas possibles et leurs actions :

->

Input 1 (broche 2 et 10) | Input 2 (broche 7 et 15) | Effet
-------------------------|--------------------------|---------
0                        |1                         | Tourne dans le sens horaire
1                        |0                         | Tourne dans le sens anti-horaire
0                        |0                         | Frein
1                        |1                         | Frein

Table: Commande et impact sur le moteur

<-

Ainsi, en utilisant une PWM sur la broche d'activation des ponts on sera en mesure de faire varier la vitesse. Il ne nous reste plus qu'à brancher le moteur sur les sorties respectives (2 et 7 ou 11 et 14 selon le pont utilisé) pour le voir tourner. :) Et voilà ! Vous savez à peu près tout ce qu'il faut savoir (pour l'instant :P ) sur ce composant.

[[question]]
|Attends attends attends, pourquoi il y a deux broches Vcc qui ont des noms différents, c'est louche ça !

Ah oui, c'est vrai et c'est important ! Le composant possède deux sources d'alimentation. Une pour la partie "logique" (contrôle correct des transistors), VCC1 ; et l'autre pour la partie puissance (utile pour alimenter les moteurs à la bonne tension), VCC2. Bien que ces deux entrées respectent les mêmes tensions (4.5V à 36V), nous ne sommes pas obligés de mettre des tensions identiques. Par exemple, la tension pour la logique pourrait venir du +5V de la carte Arduino tandis que la partie puissance pourrait être fournie par une pile 9V par exemple (n'oubliez pas de bien relier les masses entre elles pour avoir un référentiel commun).

[[e]]
| N'utilisez **JAMAIS** le +5V de la carte Arduino comme alimentation de puissance (pour la logique c'est OK). Son régulateur ne peut fournir que 250mA ce qui est faible. Si vous l'utilisez pour alimenter des moteurs vous risquez de le griller !

Comme je suis sympa ( ^^ ) je vous donne un exemple de branchement du composant avec un moteur et une carte Arduino (j'ai pris le modèle L293D pour ne pas m’embêter à devoir mettre les diodes de protection sur le schéma :roll: ) :

![Schéma d'utilisation du L293D](/media/galleries/954/54f9eb8c-fd3b-494a-b943-052ca5195840.png.960x960_q85.jpg)


![Montage du L293D](/media/galleries/954/58785af8-96bd-4a7d-9571-55e4e8cc5dc5.png.960x960_q85.png)


**Vous noterez la présence du gros condensateur polarisé (100 µF / 25V ou plus selon l'alimentation) pour découpler l'alimentation de puissance du L293D**. Comme je n'utilise qu'un seul pont, j'ai relié à la masse les entrées de celui qui est inutilisé afin de ne pas avoir des entrées qui "grésillent" et fassent consommer le montage pour rien. Enfin, vous remarquez que j'utilise trois broches de l'Arduino, deux pour le sens (2 et 4) et une PWM pour la vitesse (3).

## Le L298

Étudions maintenant le grand frère du L293 : [le L298](http://www.st.com/st-web-ui/static/active/en/resource/technical/document/datasheet/CD00000240.pdf) . Si je parle de grand frère ce n'est pas innocent. En effet, son fonctionnement est très similaire à celui du L293, mais il est capable de débiter des courants jusqu'à 2A nominal par pont et jusqu'à 3A pendant un bref instant. Il propose aussi une fonction pouvant être intéressante qui est la mesure du courant passant au travers du pont (pour vérifier si votre moteur est "rendu en butée"[^butee] par exemple). Que dire de plus ? On retrouve deux broches d'alimentation, une pour la logique et l'autre pour la puissance. Celle pour la logique peut aller de 4.5 à 7V (là encore on pourra utiliser celle de l'Arduino). L'entré puissance, en revanche, admet une tension comprise entre 5 et 46V. Pour un fonctionnement optimal, la documentation nous recommande de placer des condensateurs de 100nF sur chaque ligne d'alimentation. Et comme pour le L293, on pourra aussi placer un gros condensateur polarisé de 100µF (tension à choisir selon l'alimentation) sur la ligne d'alimentation de puissance. Comme le fonctionnement est le même que celui du L293, je vais juste vous proposer une liste des broches utiles (oui je suis fainéant !).

![le L298](/media/galleries/954/a78a60c2-1123-452c-9535-d9c3c7c62d63.png.960x960_q85.png)


Pour le premier pont :

* Les sorties sont situées sur les broches 2 et 3.
* Les entrées pour le sens de rotation sont la 5 et 7 et la PWM (*enable*) ira sur la broche 6.

Pour le second pont :

* Les sorties sont situées sur les broches 13 et 14.
* Les entrées pour le sens de rotation sont la 10 et 12 et la PWM (*enable*) ira sur la broche 11.

Pour les deux ponts :

* La masse, qui est au milieu sur la broche 8.
* L'alimentation de la logique de commande (le 5V) sur la broche suivante, la 9.
* Et l'alimentation de la partie puissance sur la broche 4.

Je ne mentionne pas les broches 1 et 15 qui sont celles servant à mesurer le courant traversant les ponts. Je doute que vous vous en serviez dans un premier temps et si vous arrivez jusque là je n'ai aucun doute que vous arriverez à les mettre en oeuvre (indice : il faudra utiliser une résistance ;) )

[[information]]
|Le L298 n'existe pas avec les diodes de roue libre intégrées. Prenez donc garde à bien les rajouter dans votre montage sous peine de voir votre composant griller.

Comme précédemment, voici un schéma d'illustration (l'image représentant le L298 n'est pas exacte, mais le boitier multiwatt n'existe pas encore dans Fritzing donc j'ai dû feinter) :

![Schéma du L298 avec un moteur et ses diodes](/media/galleries/954/59c5ae12-68cc-496b-b873-4513582cde0c.png.960x960_q85.jpg)

![Montage du L298 avec un moteur et ses diodes](/media/galleries/954/b4cc32b2-092f-4317-a432-33835dbd6667.png.960x960_q85.png)

[^butee]: s'il rencontre un obstacle qui freine sa course