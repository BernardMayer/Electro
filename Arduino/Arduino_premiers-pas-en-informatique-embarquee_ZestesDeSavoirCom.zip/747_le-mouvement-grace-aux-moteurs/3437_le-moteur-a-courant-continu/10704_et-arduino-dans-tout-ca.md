# Bref rappel sur les PWM

Si vous avez bien lu la partie précédente, vous avez dû apprendre que pour pouvoir modifier la vitesse de rotation du moteur il faut utiliser un signal PWM. Mais vous souvenez-vous comment on s'en sert avec Arduino ? Allez, zou, petite piqûre de rappel ! Commençons par redire où sont situées les broches utilisables avec la PWM. Elles sont au nombre de 6 et ont les numéros 3, 5, 6, 9, 10 et 11. Pour les utiliser, vous devrez les configurer en sortie dans le setup() de votre programme :

```cpp
const int brochePWM = 3;

void setup()
{
    // configuration en sortie de la broche 3
    pinMode(brochePWM, OUTPUT);
}
```


Ensuite, vous pourrez agir sur le *rapport cyclique* du signal PWM (le ratio entre temps à l'état HAUT et temps à l'état BAS) en utilisant la fonction `analogWrite(broche, ratio)`. L'argument *broche* désigne... la broche à utiliser et l'argument *ratio* indique la portion de temps à l'état haut du signal.

```cpp
/* le signal PWM est généré sur la broche 3 de la carte Arduino
   avec un rapport cyclique de 50%
   (état HAUT égal en temps à celui de l'état BAS */

analogWrite(brochePWM, 127);
```
Code: La fonction `analogWrite`

Le rapport cyclique est défini par un nombre allant de 0 à 255. Cela signifie qu'à 0, le signal de sortie sera nul et à 255, le signal de sortie sera à l'état HAUT. Toutes les valeurs comprises entre ces deux extrêmes donneront un rapport cyclique plus ou moins grand. Dans notre cas, le moteur tourne plus ou moins vite selon si le rapport cyclique est grand ou petit. Pour savoir quel rapport cyclique correspond avec quelle valeur, il faut faire une règle de trois :

->

Valeur argument | Rapport cyclique (%)
----------------|----------------------
0               | 0
127             | 50
255             | 100

Table: Quelques exemples de rapport cyclique

<-

Le calcul donnant la valeur pour chaque portion est défini par cette relation :

$$argument = \frac{x \times 100}{255}$$


Le résultat de ce calcul donne la valeur de l'argument pour le rapport cyclique recherché. x est la valeur du rapport cyclique que vous souhaitez donner au signal.

# Utiliser un shield moteur

Comme nous l'avons vu précédemment, réaliser un pont en H demande quelques efforts (surtout si vous désirez tout faire vous mêmes :D ). Afin de rendre ces derniers plus accessibles aux personnes ayant moins de moyens techniques (tout le monde ne dispose pas du matériel pour réaliser ses propres cartes électroniques !), l'équipe Arduino a développé et mis en productions un shield (une carte d'extension) pour pouvoir utiliser facilement des moteurs. Cette extension possède ainsi tout ce qu'il faut pour mettre en œuvre rapidement un ou des moteurs. La seule contrepartie est que les broches à utiliser sont imposées. Cependant, il existe une multitude de shields moteurs *non officiels* pouvant faire les mêmes choses ou presque. L'avantage de ces derniers est indéniablement leur prix souvent moins cher. En revanche, il n'est pas toujours facile de trouver leur documentation et le format de la carte ne se soucie pas forcément du "standard" Arduino (et n'est donc pas forcément adaptable en "s'ajoutant par dessus" comme un shield officiel le ferait). Je vais donc maintenant vous présenter le shield officiel, son fonctionnement et son utilisation, puis ensuite un shield non-officiel (acheté pas cher sur le net) que je possède et avec lequel je ferai mes photos/vidéos. Vous devriez alors avoir assez de connaissances pour utiliser n'importe quel shield non-officiel que vous pourrez trouver. Les deux shields présentés ont un point commun : ils utilisent tous les deux le L298 comme composant pour les ponts en H.

## Le shield officiel d'Arduino

Tout d'abord, voici l'adresse de description de ce shield : [le shield moteur](http://arduino.cc/en/Main/ArduinoMotorShieldR3) . Comme vous avez bien lu la partie précédente à propos du L298, vous connaissez déjà la majeure partie des choses à savoir. Parmi elles, vous savez que le L298 nécessite trois broches de "pilotage" (par pont intégré) et envoie la puissance sur deux broches (par moteur). Éventuellement nous disposons aussi des deux "sondes de courant" mais nous y reviendrons plus tard. Voici un petit synoptique de résumé que je vous ai concocté pour l'occasion : :)

![Le shield moteur officiel en image](/media/galleries/954/844a6e07-4f9d-4b51-9240-09d399a0a7ee.png.960x960_q85.jpg)

Voici comment il fonctionne et les quelques précautions d'utilisation.

* L'alimentation de puissance sur les borniers à visser à gauche est reliée à l'Arduino et peut donc lui servir de source d'alimentation. Si vous voulez dédier cette alimentation à la carte moteur, il faut donner un coup de cutter sur le strap marqué Vin en dessous de la carte
* Les entrées/sorties du shield sont reliées à l'Arduino de la manière suivante :

->

Fonction    | Broches mot. A | Broches mot. B
------------|----------------|----------------
Direction   |12              | 13
PWM         | 3              | 11
Frein       | 9              | 8
Mesure de courant | A0       | A1

Table: Entrées/sorties du shield

<-

La mesure de courant se fait sur les broches A0 et A1. Si vous avez besoin de ces broches pour d'autre applications, vous pouvez là encore désactiver la fonction en coupant le strap en dessous de la carte. Sinon, la mesure se fera simplement avec la fonction porte logique OU Exclusif, on peut déactiver la fonction de "frein" tout en gardant celle du sens. Grâce à cela, on peut se limiter à seulement deux broches pour commander chaque moteur : celle du sens et celle de la vitesse. Voici comment ils ont fait : Tout d'abord, regardons la table de vérité du OU EXCLUSIF. Cette dernière s’interprète comme suit : "La sortie est à 1 si une des deux entrées **uniquement** est à 1". Sous forme de tableau on obtient ça:

->

Entrée A | Entrée B | Sortie
---------|----------|--------
0 | 0 | **0**
1 | 0 | **1**
0 | 1 | **1**
1 | 1 | **0**

Table: Le OU Exclusif (XOR)

<-

Maintenant rappelez-vous, les conditions de freinage étaient justement représentées lorsque les deux entrées du pont étaient au même niveau. En couplant intelligemment le résultat de cette porte logique et les entrées de pilotage, on peut décider oui ou non d'avoir la fonction de frein. Afin de mieux comprendre, je vous invite à consulter cet extrait du schéma technique du shield :

![Astuce de pilotage du moteur](/media/galleries/954/25065c9f-7aa4-4125-8df2-ffdea66be959.png.960x960_q85.png)


Grâce à ce montage, vous pouvez choisir ou non d'avoir un mode de frein sur vos moteurs. Si vous préférez avoir deux broches disponibles et ne pas avoir de frein (juste une roue libre lorsque la PWM est à 0), alors il vous suffira une fois de plus de couper les straps en dessous de la carte.

[[information]]
|N'ayez pas peur d'avoir des regrets ! Si vous coupez un strap, vous pourrez toujours le remettre en ajoutant un petit point de soudure pour relier les deux pastilles prévues à cet effet. ;) Le mieux aurait été d'avoir la possibilité de mettre des cavaliers que l'on enlève à la main, mais bon, c'est comme ça.

Vous savez maintenant tout à propos de ce shield. Je vais maintenant vous en présenter un non-officiel et ensuite nous passerons à un petit montage/code d'exemple pour finir ce chapitre.

## Mon shield non-officiel

Maintenant que vous connaissez le fonctionnement global du shield officiel, vous allez pouvoir utiliser sans problème la plupart des shields moteurs. Afin de ne pas faire de publicité pour un site ou un autre, je vais vous présenter mon shield qui vaut aussi bien qu'un autre (mais pas forcément mieux). Il n'y a aucun parti pris, j'ai acheté ce dernier afin de profiter de tarif intéressant lors d'une commande avec d'autres composants. Si j'avais été uniquement à la recherche d'un shield moteur, j'en aurais peut-être pris un autre qui sait ! Bref, assez de ma vie, passons à l'étude du module ! Afin de bien commencer les choses, je vais d'abord vous montrer une photo d'identité de ce dernier. Ensuite je vous expliquerai où sont les broches qui nous intéressent et ferai un parallèle avec le shield officiel. Les deux étant basés sur un L298 l'explication sera assez rapide car je n'ai pas envie de me répéter. Je ferai néanmoins un petit aparté sur les différences (avantages et inconvénients) entre les deux.

![Le shield moteur étudié](/media/galleries/954/a57ead60-4fae-4c41-946b-6863c6154779.jpg.960x960_q85.jpg)


Voici une petite liste des points importants :

* À gauche en **jaune** : les entrées de commande. **EnA**, **In1**, **In2** pour le moteur A ; **EnB**, **In3**, **In4** pour le moteur B. On trouve aussi une broche de masse et une sortie 5V sur laquelle je reviendrai.
* En bas en **vert** différents *jumpers* (des cavaliers si vous préférez ;) ) pour activer des résistances de pull-down (force une entrée/sortie à l'état bas) et câbler la mesure de courant de sortie des ponts
* À droite en **bleu**, les bornes pour brancher les moteurs A et B (respectivement en haut et en bas) et au milieu le bornier pour amener l'alimentation de puissance (et une entrée ou sortie) de 5V

Au milieu on retrouve le L298 avec de chaque côté (en haut et en bas) les diodes de roue libre pour chaque moteur. Une petite précision s'impose par rapport à ce shield. La carte embarque un régulateur 5V (le petit bloc noir en haut à gauche marqué 78M05). Ce dernier peut être utilisé ou non (Activez-le avec le jumper vert juste à coté). Si vous le laissez activé, c'est lui qui fournira l'alimentation pour la logique du L298. Si vous le désactivez, vous devrez fournir vous-même le 5V pour la logique. Dans tous les cas, il vous faut relier les masses puissances et logiques entre Arduino et le shield afin d'avoir un référentiel commun. Si vous l'activez, alors vous obtiendrez une sortie de 5V sur le bornier bleu à droite (utile pour alimenter l'Arduino par exemple). Si vous le désactivez, alors vous devrez fournir le 5V (et donc le bornier bleu devra être utilisé comme une entrée). Ce shield n'est en fait qu'une simple carte électronique disposant du L298 et facilitant l’accès à ses broches. Le fonctionnement se fait exactement comme nous l'avons vu dans le chapitre précédent, lorsque je vous présentais le L293 et L298 pour la première fois. Pas de facétie avec des portes logiques pour gagner des broches. Ici, tout est brut de décoffrage, on commande directement le pont en H. Il vous faudra donc trois broches par moteur, deux pour gérer la direction et le frein et une (PWM) pour la vitesse.

# Petit programme de test

Nous allons maintenant pouvoir passer aux choses sérieuses : l'utilisation du moteur avec l'Arduino !

## L'électronique

Pour cela, nous allons commencer par câbler le shield. En ayant la partie précédente concernant le vôtre sous les yeux, vous devriez pouvoir vous en sortir sans trop de difficulté. (Désolé, pas de schéma ce coup-ci car le logiciel que j'utilise ne possède pas encore le shield moteur dans sa base de données, faites donc preuve d'imagination. ;) ) Personnellement, je n'utiliserai qu'un seul moteur (car dans l'immédiat j'en ai qu'un sous la main :P ). Je vais donc le brancher sur les bornes bleues "Moteur A". Ensuite, je vais relier les différentes broches de commande à mon Arduino. La broche EnA sera reliée à une sortie de PWM (dans mon cas la broche 3) et les broches In1 et In2 seront reliées à n'importe quelles broches numériques (2 et 4 pour moi). Il ne nous reste plus qu'à nous occuper de l'alimentation. Tout d'abord, je mets un fil entre la masse du shield et celle de l'Arduino (pour avoir un référentiel commun). Comme ma carte possède son propre régulateur de tension 5V, pas besoin de l'amener depuis Arduino. Enfin, je relie les deux fils pour la puissance. Dans mon cas ce sera une alimentation 12V (400 mA max, wouhou) qui vient d'un adaptateur allume-cigare (censé fournir du 5V) que j'ai démonté pour obtenir une source de 12V. Je vous propose aussi de rajouter un potentiomètre sur une entrée analogique. De cette façon nous allons pouvoir faire varier la vitesse sans recharger le programme ;) . Et voilà, point de vue électronique tout est prêt. Voilà ce que ça donne chez moi (un beau bazar :D , mais j'ai oublié le potentiomètre) :

![Le montage avec le shield et Arduino](/media/galleries/954/d04aeb1b-b8e7-4d42-bc62-0f21f894c2c8.jpg.960x960_q85.jpg)



## L'informatique

Maintenant, nous allons devoir nous occuper du code et comme toujours, nous commençons par lister les variables concernant les broches utilisées :

```cpp
// la PWM pour la vitesse
const int enable = 3;
// les broches de signal pour le sens de rotation
const int in1 = 2;
const int in2 = 4;

// une entrée analogique (A0) pour régler la vitesse manuellement
const int potar = 0;
```


Ces différentes broches seront bien entendu des broches de sortie (sauf l'analogique), donc nous les déclarons comme telles dans le `setup()` :

```cpp
void setup()
{
    pinMode(enable, OUTPUT);
    pinMode(in1, OUTPUT);
    pinMode(in2, OUTPUT);
    // j'utilise la liaison série pour verifier
    // la vitesse définie par le potentiomètre
    Serial.begin(115200);

    // on démarre moteur en avant et en roue libre
    analogWrite(enable, 0);
    digitalWrite(in1, LOW);
    digitalWrite(in2, HIGH);
}
```
Code: Un setup pour l'utilisation d'un moteur à courant continu

Et voila, si vous exécutez le code maintenant votre moteur sera... arrêté ! Eh oui, j'ai volontairement mis une vitesse nulle à la fin du setup() pour éviter que le moteur ne s'emballe au démarrage du programme. Mais si vous changez cette dernière (mettez 50 pour voir) vous verrez votre moteur se mettre à tourner. Nous allons donc rajouter un peu d'interactivité, pour que vous puissiez vous-même augmenter/diminuer la vitesse en fonction de la valeur lue sur le potentiomètre :

```cpp
void loop()
{
    // on lit la valeur du potentiomètre
    int vitesse = analogRead(potar);

    // division de la valeur lue par 4
    vitesse /= 4;

    // envoie la nouvelle vitesse sur le moteur
    analogWrite(enable, vitesse);

    // on affiche la vitesse sur le moniteur série
    Serial.println(vitesse);

    delay(50);
}
```
Code: Utilisation basique d'un moteur à courant continu


[[question]]
|Mais pourquoi tu divises la vitesse par 4 à la ligne 5 ? Je veux aller à fond moi !

C'est très simple. La lecture analogique nous renvoie une valeur entre 0 et 1023 (soit 1024 valeur possibles). Or la fonction analogWrite ne peut aller qu'entre 0 et 255 (total de 256 valeurs). Je divise donc par 4 pour rester dans le bon intervalle ! Car : $4 \times 256 = 1024$.

# Programme plus élaboré

Maintenant, je vous fais cadeau d'un code vous permettant d'aller dans les deux sens et à vitesse variable. Mais, je vous conseille d'essayer de le faire par vous-même avant de regarder ce qu'il y a dans la balise secret. Le potentiomètre est utilisé comme régulateur de vitesse, mais on va virtuellement décaler l'origine. Autrement dit, entre 0 et 511 nous irons dans un sens, et entre 512 et 1023 nous irons dans l'autre sens. Nous ferons aussi en sorte que la vitesse soit de plus en plus élevée lorsque l'on "s'éloigne" du 0 virtuel (de la valeur 512 donc). Je vous donne le code tel quel (avec des commentaires bien sûr). Libre à vous de le traiter comme un exercice. À sa suite, une petite vidéo du résultat.


[[secret]]
|```cpp
|const int enable = 3; // la PWM
|const int in1 = 2;    // les broches de signal
|const int in2 = 4;
|const int potar = 0;  // la broche pour régler la vitesse
|
|void setup()
|{
|    pinMode(enable, OUTPUT);
|    pinMode(in1, OUTPUT);
|    pinMode(in2, OUTPUT);
|    Serial.begin(115200);
|
|    // on démarre moteur en avant et en roue libre
|    analogWrite(enable, 0);
|    digitalWrite(in1, LOW);
|    digitalWrite(in2, HIGH);
|}
|
|void loop()
|{
|    int vitesse = analogRead(potar);
|
|    // dans le sens positif
|    if(vitesse > 512)
|    {
|        // on décale l'origine de 512
|        vitesse -= 512;
|        // le moteur va dans un sens
|        digitalWrite(in1, LOW);
|        digitalWrite(in2, HIGH);
|        Serial.print("+");
|    }
|    else // dans l'autre sens
|    {
|        // de même on décale pour que la vitesse augmente en s'éloignant de 512
|        vitesse = 512-vitesse;
|        // le moteur va dans l'autre sens
|        digitalWrite(in1, HIGH);
|        digitalWrite(in2, LOW);
|        Serial.print("-");
|    }
|
|    // pour rester dans l'intervalle [0;255] (sinon on est dans [0;512])
|    vitesse /= 2;
|    // envoie la vitesse
|    analogWrite(enable, vitesse);
|
|    // et l'affiche
|    Serial.println(vitesse);
|    delay(50);
|}
|```
|Code: Exercice de rotation du moteur à courant continu

Bravo à ceux qui ont essayé de faire ce programme, même s'ils n'y sont pas arrivé ! Dans ce dernier cas, vous pouvez aller voir sur les forums et poser vos éventuelles questions après avoir vérifié que vous avez bien tout essayé de comprendre. ;) Voilà la vidéo qui montre le fonctionnement du programme :

->!(https://www.youtube.com/watch?v=K1NRLzt_zSI)<-


Désolé pour la qualité de la vidéo, il faut vraiment que je change d'appareil...