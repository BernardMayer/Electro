Bon, et si nous voyions un peu comment cela se passe dans la pratique ? Je vais vous montrer comment alimenter les moteurs électriques à courant continu. Vous allez voir que ce n'est pas aussi simple que ça en a l'air, du moins lorsque l'on veut faire quelque chose de propre. Vous allez comprendre de quoi je parle...

# Connecter un moteur sur une source d'énergie : la pile

Faisons l'expérience la plus simple qui soit : celle de connecter un moteur aux bornes d'une pile de 9V :

![C'est beau, ça tourne.](/media/galleries/954/097b0ae0-07a7-4e4b-818a-ad447c4fc65a.png.960x960_q85.jpg)


[[question]]
|C'est tout ? o_O

Ben oui, quoi de plus ? Le moteur est connecté, son axe tourne, la pile débite du courant... Ha ! Voilà ce qui nous intéresse dans l'immédiat : la pile débite du courant. Oui et pas des moindres car les moteurs électriques sont bien généralement de véritables gloutons énergétiques. Si vous avez la chance de posséder un ampèremètre, vous pouvez mesurer le courant de consommation de votre moteur. En général, pour un petit moteur de lecteur CD on avoisine la centaine de milliampères. Pour un moteur un peu plus gros, tel qu'un moteur de modélisme, on trouve plusieurs centaines de milliampères de consommation. Pour des moteurs encore plus gros, on peut se retrouver avec des valeurs dépassant largement l'ampère voire la dizaine d'ampères. Revenons à notre moteur. Lui ne consomme pas plus de 100mA à vide. Mais pour une simple pile c'est beaucoup. Et je vous garantis qu'elle ne tiendra pas longtemps comme ça ! De plus, la vitesse n'est pas réglable, le moteur tourne toujours à son maximum (si c'est un moteur fait pour tourner à 9V). Enfin, pour allumer ou arrêter le moteur, vous êtes obligé de le connecter ou le déconnecter de la pile. En somme, utiliser un moteur dans cette configuration, par exemple pour faire avancer votre petit robot mobile, n'est pas la solution la plus adaptée.

# Avec la carte Arduino

Vous vous doutez bien que l'on va utiliser la carte Arduino pour faire ce que je viens d’énoncer, à savoir commander le moteur à l'allumage et à l’extinction et faire varier sa vitesse.

[[attention]]
| **Ne faites surtout pas le montage qui suit, je vous expliquerai pourquoi !**

Admettons que l'on essaie de brancher le moteur sur une sortie de l'Arduino :

![Moteur branché sur une sortie de l'Arduino](/media/galleries/954/60140d45-b9b8-4724-9025-03f897f6f061.png.960x960_q85.png)


Avec le programme adéquat, le moteur va tourner à la vitesse que l'on souhaite, si l'on veut, réglable par potentiomètre et s'arrêter ou démarrer quand on le lui demande. C'est mieux. C'est la carte Arduino qui pilote le moteur. Malheureux ! Vous ne croyez tout de même pas que l'on va se contenter de faire ça ?! Non, oulaaaa. C'est hyper ultra dangereux... pour votre carte Arduino ! Il est en effet impensable de réaliser ce montage car les moteurs à courant continu sont de véritables sources de parasites qui pourraient endommager, au point de vue matériel, votre carte Arduino ! Oubliez donc tout de suite cette idée de connecter directement le moteur sur une sortie de votre Arduino. Les moteurs, quand ils tournent, génèrent tout un tas de parasites qui peuvent être des surtensions très grandes par rapport à leur tension d'alimentation. De plus, le courant qu'ils demandent est bien trop grand par rapport à ce que peut fournir une sortie numérique d'une carte Arduino (environ 40 mA). Ce sont deux bonnes raisons de ne pas faire le montage précédent.

[[question]]
|Mais alors, on fait comment si on peut pas piloter un moteur avec notre carte Arduino ?

Je n'ai pas dis que l'on ne pouvait pas piloter un moteur avec une carte Arduino. J'ai bien précisé *dans cette configuration*. Autrement dit, il faut faire quelque chose de plus pour pouvoir mener à terme cet objectif.

# Une question de puissance : le transistor

Souvenez-vous, nous avons parlé d'un composant qui pourrait convenir dans [ce chapitre](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/743/gestion-des-entrees-sorties/3424/afficheurs-7-segments/#5-utiliser-plusieurs-afficheurs). Il s'agit du **transistor**. Si vous vous souvenez de ce que je vous avais expliqué, vous devriez comprendre pourquoi je vous en parle ici. Car, à priori, on ne veut pas allumer un afficheur 7 segments. ^^ En fait, le transistor (bipolaire) est comme un interrupteur que l'on commande par un courant. Tout comme on avait fait avec les afficheurs 7 segments, on peut allumer, saturer ou bloquer un transistor pour qu'il laisse passer le courant ou non. Nous avions alors commandé chaque transistor pour allumer ou éteindre les afficheurs correspondants. Essayons de faire de même avec notre moteur :

![Avec un transistor](/media/galleries/954/c5ec013b-5a96-4b44-a371-f0c948001ab2.png.960x960_q85.png)

Ici, le transistor est commandé par une sortie de la carte Arduino via la résistance sur la base. Lorsque l'état de la sortie est au niveau 0, **le transistor est bloqué et le courant ne le traverse pas**. Le moteur ne tourne pas. Lorsque la sortie vaut 1, le transistor est commandé et devient saturé, c'est-à-dire qu'il laisse passer le courant et le moteur se met à tourner. Le problème, c'est que tout n'est pas parfait et ce transistor cumule des inconvénients qu'il est bon de citer pour éviter d'avoir de mauvaises surprises :

* parcouru par un grand courant, il chauffe et peut être amené à griller s'il n'est pas refroidi
* il est en plus sensible aux parasites et risque d'être endommagé
* enfin, il n'aime pas les "hautes" tensions

Pour répondre à ces trois contraintes, trois solutions. La première consisterait à mettre un transistor qui accepte un courant assez élevé par rapport à la consommation réelle du moteur, ou bien d'adjoindre un *dissipateur* sur le transistor pour qu'il refroidisse. La deuxième solution concernant les parasites serait de mettre un condensateur de filtrage. On en a déjà parlé avec les [boutons poussoirs](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/743/gestion-des-entrees-sorties/3423/un-simple-bouton/) . Pour le dernier problème, on va voir que l'on a besoin d'une diode.

## Le "bon" transistor

Comme je viens de vous l'expliquer, il nous faut un transistor comme "interface" de puissance. C'est lui qui nous sert d'interrupteur pour laisser passer ou non le courant. Pour l'instant, nous avons beaucoup parlé des transistors "bipolaires". Ils sont sympas, pas chers, mais il y a un problème : ils ne sont pas vraiment faits pour faire de la commutation, mais plutôt pour faire de l'amplification de courant. Le courant qu'il laisse passer est proportionnel au courant traversant sa base. Pour les petits montages comme celui des 7 segments ce n'est pas vraiment un problème, car les courants sont faibles. Mais pour des montages avec un moteur, où les courants sont bien plus élevés, votre transistor bipolaire va commencer à consommer. On retrouvera jusqu'à plusieurs volts de perdus entre son émetteur et son collecteur, autant de volts qui ne profiteront pas à notre moteur.

[[question]]
|Mais alors on fait comment pour pas perdre tout ça ?

Eh bien c'est facile ! On change de transistor ! L'électronique de puissance a donné naissance à d'autres transistors, bien plus optimaux pour les questions de fonctionnement à fort courant et en régime saturé/bloqué. Ce sont les transistors MOSFET (appelés aussi "transistor à effet de champ"). Leur symbole est le suivant :

![Symbole du transistor MOSFET (canal N)](/media/galleries/954/3a7ad5e5-ec90-467c-b319-6d799ff8fd5a.jpg.960x960_q85.jpg)

Il ressemble évidemment à un bipolaire, cela reste un transistor. Par contre il est fait pour faire de l'amplification de tension. Autrement dit, sa broche de commande (que l'on appelle "Gate") doit recevoir une commande, une tension, donc plus besoin de résistance entre Arduino et le transistor. Son fonctionnement est simple : une différence de potentiel sur la gate et il commute (laisse passer le courant entre D (Drain) et S (Source)) sinon il bloque le courant. Facile non ? Un inconvénient cependant : ils coûtent plus chers que leurs homologues bipolaires (de un à plusieurs euros selon le modèle, le courant qu'il peut laisser passer et la tension qu'il peut bloquer). Mais en contrepartie, ils n'auront qu'une faible chute de tension lorsqu'ils laissent passer le courant pour le moteur, et ça ce n'est pas négligeable. Il existe deux types de MOSFET, le *canal N* et le *canal P*. Ils font la même chose, mais le comportement est inversé (quand un est passant l'autre est bloquant et vice versa). Voici un schéma d'exemple de branchement (avec une résistance de pull-down, comme ça si le signal n'est pas défini sur la broche Arduino, le transistor sera par défaut bloqué et donc le moteur ne tournera pas) :

![Schéma simple de branchement](/media/galleries/954/a2998c0f-d4b4-4b63-805e-14b2ca8451df.png.960x960_q85.jpg)



# Protégeons l'ensemble : la diode de roue libre

Une diode, qu'est-ce que c'est ? Nous en avons déjà parlé à vrai dire, il s'agissait des diodes électroluminescentes (LED) mais le principe de fonctionnement reste le même sans la lumière. Une diode, dont voici le symbole :

![Symbole d'une diode](/media/galleries/954/27afd55b-84f8-4aa2-a86d-40487ff6b2e0.png.960x960_q85.jpg)


...est un composant électronique qui ne laisse passer le courant que dans un sens (cf. [ce chapitre](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/743/gestion-des-entrees-sorties/3420/notre-premier-programme/) ). Vos souvenirs sont-ils à nouveau en place ? Alors, on continue ! Reprenons le schéma précédent avec le transistor piloté par l'Arduino et qui commande à son tour le moteur. Saturons le transistor en lui appliquant une tension sur sa base. Le moteur commence à tourner puis parvient à sa vitesse de rotation maximale. Il tourne, il tourne et là... je décide de couper l'alimentation du moteur en bloquant le transistor. Soit. Que va-t-il se passer ?

[[question]]
|Le moteur va continuer de tourner à cause de son inertie !

Très bien. Et que cela va t-il engendrer ? Une tension aux bornes du moteur. En effet, je l'ai dit plus tôt, un moteur est aussi un générateur électrique car il est capable de convertir de l'énergie mécanique en énergie électrique même si son rôle principal est de faire l'inverse. Et cette tension est très dangereuse pour le transistor, d'autant plus qu'elle est très haute et peut atteindre plusieurs centaines de Volts (phénomène physique lié aux bobines internes du moteur qui vont se charger). En fait, le moteur va générer une tension à ses bornes et un courant, mais comme le transistor bloque la route au courant, cette tension ne peut pas rester la même et est obligée d'augmenter pour conserver la relation de la loi d'Ohm. Le moteur arrive à un phénomène de **charge**. Il va, précisément, se charger en tension. Je ne m'étends pas plus sur le sujet, il y a bien d'autres informations plus complètes que vous pourrez trouver sur internet. La question : comment faire pour que le moteur se décharge et n'atteigne pas des tensions de plusieurs centaines de Volts à ses bornes (ce qui forcerait alors le passage au travers du transistor et détruirait ce dernier) ? La réponse : par l'utilisation d'une diode. Vous vous en doutiez, n'est-ce pas ? ;) Il est assez simple de comprendre comment on va utiliser cette diode, je vous donne le schéma. Les explications le suivent :

![Schéma d'utilisation de la diode](/media/galleries/954/b0610998-3027-4136-a8e7-93bbae45b265.png.960x960_q85.jpg)

Reprenons au moment où le moteur tourne. Plus de courant ne circule dans le transistor et la seule raison pour laquelle le moteur continue de tourner est qu'il possède une inertie mécanique. Il génère donc cette fameuse tension qui est orientée vers l'entrée du transistor. Comme le transistor est bloqué, le courant en sortie du moteur va donc aller traverser la diode pour revenir dans le moteur. C'est bien, car la tension induite (celle qui est générée par le moteur) restera proche de la tension d'alimentation du moteur et n'ira pas virevolter au voisinage des centaines de Volts. Mais ça ne s'arrête pas là. Pour ceux qui l'auraient remarqué, la tension induite par le moteur est opposée à celle que fournit l'alimentation de ce dernier. Or, étant donné que maintenant on fait un bouclage de la tension induite sur son entrée (vous me suivez toujours ?), eh bien cela alimente le moteur. Les deux tensions s'opposent et cela a pour effet de ralentir le moteur. La **diode de roue libre**, c'est comme ça qu'on l'appelle, sert donc à deux choses : d'une part elle protège le transistor de la surtension induite par le moteur, d'autre part elle permet au moteur de "s'auto-freiner".

[[question]]
|Et on met quoi comme diode ? o_O

Excellente question, j'allais presque oublier ! La diode que nous mettrons sera une diode *Schottky*. Ne vous laissez pas impressionner par ce nom barbare qui signifie simplement que la diode est capable de basculer (passer de l'état bloquant à passant) de manière très rapide. Dès lors qu'il y a une surtension engendrée par le moteur lorsque l'on le coupe de l'alimentation, la diode va l'absorber aussitôt avant que le transistor ait le temps d'avoir des dommages. On pourra également rajouter aux bornes de la diode un condensateur de déparasitage pour protéger le transistor et la diode contre les parasites. Au final, le schéma ressemble à ça :

![Schéma du montage complet du moteur CC](/media/galleries/954/e7ba621c-7ff6-4166-9dde-ab2ed3723390.png.960x960_q85.jpg)


![Montage complet du moteur CC](/media/galleries/954/8b268b47-06bd-496b-8603-a16c8833f257.png.960x960_q85.jpg)


Sa valeur devra être comprise entre 1nF et 100nF environ. Le but étant de supprimer les petits parasites (pics de tension). Bon, nous allons pouvoir attaquer les choses sérieuses ! :Pirate: