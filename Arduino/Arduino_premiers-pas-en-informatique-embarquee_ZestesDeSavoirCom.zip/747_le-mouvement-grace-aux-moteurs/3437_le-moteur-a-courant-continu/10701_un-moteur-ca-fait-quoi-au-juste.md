Commençons en douceur par l'explication de ce à quoi sert un moteur et son fonctionnement.

[[information]]
|Ce chapitre n'est pas un des plus simples car il va faire apparaître des notions de mécanique qui sont indispensables pour comprendre le mouvement. Il prend en général plusieurs heures de cours pour être bien expliqué. Nous allons donc vous faire ici uniquement une introduction à la mécanique du moteur. Cependant, cette introduction présente des notions très importantes pour bien comprendre la suite, ne la négligez donc pas !

Prenons un moteur électrique des plus basiques qui soient :

![Un moteur classique à courant continu](http://zestedesavoir.com/media/galleries/954/6cba1f13-2356-4eb0-93b2-0bff5438ea61.jpg.960x960_q85.jpg)
Figure: Un moteur classique à courant continu - (CC-BY-SA, [Dcaldero8983](http://commons.wikimedia.org/wiki/File:3V_DC_Motor.jpg))

Vous avez devant vos yeux un moteur électrique tel que l'on peut en trouver dans les engins de modélisme ou dans les voitures téléguidées. Mais sachez qu'il en existe de toute sorte, allant du miniature au gigantesque, adaptés à d'autres types d'applications. Nous nous contenterons ici des moteurs électriques "basiques".

## Transformation de l’énergie électrique en énergie mécanique

Un moteur ça fait quoi ? Ça tourne ! On dit qu'**un moteur est un composant de conversion d'énergie électrique en énergie mécanique**. Les moteurs à courant continu (ce terme deviendra plus clair par la suite) transforment l'énergie électrique en énergie mécanique de rotation, pour être précis. Mais ils peuvent également servir de générateur d'électricité en convertissant une énergie mécanique de rotation en énergie électrique. C'est le cas par exemple de la dynamo sur votre vélo !

[[attention]]
|Ce dernier point n'est pas à négliger, car même si dans la plupart des applications votre moteur servira à générer un mouvement, il sera possible qu'il soit actionné "à l'envers" et génère alors du courant. Il faudra donc protéger votre circuit pour ne pas l’abîmer à cause de cette "injection" d'énergie non désirée. On va revenir dessus plus loin. ;)

# Principe de fonctionnement du moteur à courant continu

## Du vocabulaire

![Éclaté d'un MCC](/media/galleries/954/197f320f-dffe-424a-991e-ec75dfc040c2.png.960x960_q85.jpg)

Tout d'abord, nous allons prendre une bonne habitude. Le moteur à courant continu s'appelle aussi "Machine à Courant Continu", que j'abrégerais en MCC. Le moteur à courant continu est composé de deux parties principales : le **rotor** (partie qui tourne) et le **stator** (partie qui ne tourne pas, statique). En électrotechnique (science traitant l'électricité en tant qu'énergie) le stator s'appelle aussi **inducteur** (qui fait l'action d’induire) et le rotor s'appelle l'**induit** (qui subit l'action d'induction). Sur l'image à droite, vous pouvez observer au milieu - entouré par les aimants bleu et rouge qui constituent le stator - le rotor composé de fils de cuivre enroulés sur un support lui même monté sur un axe. Cet axe, c'est l'**arbre** de sortie du moteur. C'est lui qui va transmettre le mouvement à l'ensemble mécanique (pignons, chaîne, actionneur...) qui lui est associé en aval. Dans le cas d'un robot sur roues par exemple, on va mettre la roue sur cet axe, bien souvent par l'intermédiaire d'un réducteur qui diminue la vitesse de rotation tout en augmentant le couple. On verra tout à l'heure pour éclaircir ces termes qui doivent, pour l'instant, ne pas vous dire grand chose.

## De nouvelles bases sur l'électricité

Vous le savez peut-être, lorsque un courant circule dans un fil **il génère un [champ magnétique](http://fr.wikipedia.org/wiki/Champ_magn%C3%A9tique) **. Plus le courant qui circulera dans le fil sera grand, plus l'intensité du champs magnétique sera élevée. Lorsqu'on enroule du fil électrique sur lui même, on forme une **bobine**. Un des avantages de la bobine est que l'on "cumule" ce champ magnétique. Donc plus on a de tours de fil (des **spires**) et plus le champ magnétique sera élevé pour un courant donné.




![Bobine de cuivre - champ magnétique généré représenté par les lignes bleues](/media/galleries/954/c6f142b2-7ec6-4895-9b87-1b17177a56e2.png.960x960_q85.jpg)


En somme, on retiendra que lorsque l'on crée une bobine de fil électrique, en général du cuivre, on additionne les champs magnétiques créés par chaque spire de la bobine. Ainsi, vous comprendrez aisément que plus la bobine contient de spires et plus le champ magnétique qu'elle induit est important. Je ne vous ai pas trop perdu, ça va pour le moment ? :) Bon, continuons.

## Le magnétisme

Oui, parlons-en. Ce sera bref, rassurez-vous. Je vais faire appel à votre expérience... avec les aimants. Vous avez tous déjà eu l'occasion d'avoir deux aimants dans la main et d'observer la résistance qu'ils émettent lorsque l'on veut les rapprocher l'un de l'autre, ou au contraire lorsqu'ils s'attirent soudainement dès qu'on les met un peu trop près. Ce phénomène est dû au champ magnétique que génèrent les aimants. Voilà un aimant permanent le plus simple soit-il :

![Aimant permanent](/media/galleries/954/b418ecbe-86e3-4e9e-995b-f37026bfeb54.png.960x960_q85.jpg)

Il possède un pôle **N**ord et un pôle **S**ud. Cet aimant génère un **champ magnétique permanent**, c'est à dire que le champ magnétique est toujours présent. C'est quelque chose de totalement invisible mais qui permet de faire des choses intéressantes.

![Champ magnétique généré par un aimant permanent](/media/galleries/954/ca87f9b2-d29e-436a-8d76-84f35b6bf315.png.960x960_q85.jpg)

Notez bien que j'ai ajouté des flèches représentatives du sens de parcours du champ magnétique, c'est important pour la suite. Bon, pour terminer mon explication sur le champ magnétique, je vous propose d'imaginer qu'il s'agisse d'un flux invisible, un peu comme le courant. Pour se rapprocher de l’analogie avec l'eau, on peut imaginer aussi que l'aimant est une fontaine qui propulse de l'eau (champ magnétique) et qui la récupère à l'opposé de là où il l'a éjectée. Tout ça, pour en arriver à vous dire qu'approcher deux aimants avec le même pôle, ils se repoussent mutuellement (les deux fontaines éjectent de l'eau l'une contre l'autre, ce qui a pour effet de les repousser). Et on le comprend bien lorsque l'on regarde le sens du champ magnétique :

![Deux aimants permanents qui se repoussent mutuellement](/media/galleries/954/9b2c605d-bb17-490d-9030-5ce56b06c7a5.png.960x960_q85.jpg)

En revanche, deux aimants orientés dans le même sens se rapprocheront car leur champ magnétique ira dans le sens opposé. La première "fontaine" va aspirer ce que l'autre éjecte, et l'autre va aspirer ce que la première éjecte.

![Résultat de la mise en "série" de deux aimants permanents identiques](/media/galleries/954/b73580ba-d1bc-4db6-901c-074b0aa54341.png.960x960_q85.jpg)

Par conséquent, le champ magnétique global sera plus intense. On peut alors schématiser le résultat sous la forme d'un seul aimant plus puissant.

![Schématisation du résultat précédent](/media/galleries/954/f03191ae-4b6f-49fd-865a-16c26b878cef.png.960x960_q85.jpg)

[[question]]
|Ça nous amène où tout ça ? Je comprends mieux comment fonctionne les aimants, mais pour un moteur électrique, c'est pareil ? :roll:

Eh oui, sans quoi mes explications n'auraient eu aucun sens si je vous avais dit qu'un moteur fonctionnait complètement différemment. :P Décomposons notre explication en deux parties.

## Le stator

Le stator, je l'ai dit au début, est une partie immobile du moteur. Sur l'image, il se trouve sur les côtés contre le châssis. Il forme un aimant avec ses pôles Nord et Sud. Cet ensemble aimant+châssis constitue donc le stator :

![Stator d'une MCC](/media/galleries/954/d259ecf2-53f3-4ff0-b02a-d893e92b2ab8.png.960x960_q85.png)

Il n'y a pas plus de choses à dire, l'essentiel du phénomène de rotation créé par un moteur électrique va se jouer dans le rotor.

## Le rotor et la mise en mouvement

Le rotor, je le rappelle, est situé au centre du stator. Pour faire très simple, je vous donnerai les explications ensuite, le rotor est la pièce maîtresse qui va recevoir un courant continu et va induire un champ magnétique variable pour mettre en rotation l'arbre du rotor. Si l'on veut, oui, il s'auto-met en rotation. :roll:

[[question]]
|Waaho ! Avec du courant continu il arrive à créer un champ magnétique variable ? o_O

Surprenant n'est-ce pas ? Eh bien, pour comprendre ce qu'il se passe, je vous propose de regarder comment est constitué un rotor de MCC (j'abrège) :

![Rotor de MCC](/media/galleries/954/39c334fe-702a-40ed-9606-5f6a915b7160.png.960x960_q85.png)

[[attention]]
|Il s'agit bien d'un schéma de principe, normalement un moteur à courant continu est constitué de trois bobines sur son rotor. Autrement on pourrait obtenir un équilibre qui empêcherait la rotation de l'arbre du moteur, mais surtout le moteur tournerait dans un sens aléatoire. Ce qui n'est pas très adapté quand on veut faire avancer son robot. ^^

Voilà donc le rotor de notre moteur. Bien, passons à la prati...

[[question]]
|Eh oh, attends !! :shock: C'est quoi ces deux bobines, comment on les alimente ? o_O

Ha, j'oubliais presque ! Merci de me l'avoir rappelé. Il y a en effet un élément dont nous n'avons pas encore évoqué l'existence, il s'agit du **collecteur**. Comme son nom le suggère, c'est un élément du moteur qui se situe sur l'arbre de rotation (ou l'axe du moteur si vous préférez) et qui a pour objectif de récupérer le courant afin de l'amener jusqu'aux bobines. On peut faire le schéma complet du moteur avec les bobines et le collecteur :

![Schéma complet du moteur](/media/galleries/954/6845e513-cf6b-4d7b-80af-1f78a9b37c37.png.960x960_q85.png)

[[attention]]
|Dites-vous bien qu'il ne s'agit là que d'un schéma de principe simplifié, car je le disais, les moteurs n'ayant que deux bobines n'existent pas.

Le collecteur est représenté ici sur la partie droite de l'image. Il est situé sur l'arbre du moteur (son axe). Ce collecteur est constitué de deux pastilles métalliques auxquelles sont reliées les extrémités des bobines. Le contact électrique entre la pile qui alimente le moteur et les bobines se fait par le collecteur et par des éléments "spéciaux" que l'on appelle les **charbons**. Ces deux éléments servent à amener le courant dans les bobines en faisant un simple contact électrique de toucher. C'est à dire que les charbons frottent sur les pastilles métalliques lorsque le moteur tourne.

[[question]]
|Et y tourne comment ce moteur, on le saura un jour ? :mad:

Ça vient, patience. ^^ Prenons la configuration du moteur tel qu'il est sur l'image précédente. Faites bien attention au sens des bobines, car si elles sont bobinées dans un sens opposé ou bien si le courant circule dans un sens opposé, le moteur ne tournera pas. J'ai donc pris le soin de mettre un point bleu et rouge, pour indiquer le sens des bobines (vous allez comprendre). Nous y voilà. ;) Sur le schéma précédent, le pôle positif de la pile est relié, via le collecteur, à l'entrée bleue des deux bobines. Leur sortie, en rouge, est donc reliée, toujours via le collecteur, à la borne négative de la pile. Vous admettrez donc, avec ce que l'on a vu plus haut, qu'il y a un courant qui parcourt chaque bobine et que cela génère un champ magnétique. Ce champ est orienté selon le sens du courant qui circule dans la bobine. Dans un premier temps, on va se retrouver avec un champ magnétique tel que celui-ci :

![Champ magnétique](/media/galleries/954/f5c26588-47f2-45dc-afa8-fc68d0f9f710.png.960x960_q85.png)


Ce champ va être opposé aux deux aimants permanents du stator du moteur, cela va donc mettre en mouvement l'axe du rotor. Et ce mouvement est défini par le fait que deux aimants orientés par leurs pôles opposés (face nord de l'un face au nord du deuxième, idem pour le sud) se repoussent. Par conséquent, l'axe du moteur, je le disais, va se mettre à tourner jusqu'à ce que les aimants permanents du stator se retrouvent face à chacun de leur complément créé par le champ magnétique des bobines :

![L'axe du moteur se met à tourner](/media/galleries/954/5bd7fa69-5b18-4375-a3e6-b15f0f111642.png.960x960_q85.png)


ATTENDEEEEZ ! Ce n'est pas fini ! Non, car dans cette configuration, si rien ne se passe, eh bien... rien ne se passera. ^^ Et oui, puisque le moteur est arrivé dans une phase de stabilité. En effet, chaque aimant est face au champ magnétique opposé, donc ils s'attirent mutuellement ce qui a pour effet de régir cette situation d'équilibre. L’élément qui va s'opposer à cet équilibre est le branchement des bobines du rotor. Vous ne l'avez peut-être pas remarqué, mais les bobines ne sont plus connectées comme à la situation précédente. Le point rouge des bobines est maintenant relié au pôle positif de la pile et le point bleu au pôle négatif. Le champ magnétique généré par les bobines change alors d'orientation et l'on se retrouve avec des champs opposés. Le moteur est à nouveau en situation de déséquilibre (car les champs magnétiques se repoussent) et cela entraîne un mouvement de rotation de l'axe du moteur. Vous l'aurez compris, ces situations se répètent indéfiniment car **le moteur n'est jamais dans une configuration équilibrée**. C'est cette situation de déséquilibre qui fait que le moteur tourne.

[[attention]]
| Alors attention, je le répète une dernière fois, un moteur n'ayant que deux bobines comme sur mes schémas ne peut pas fonctionner, car c'est un modèle simplifié qui engendrerait immédiatement une situation équilibrée à la mise sous tension.

Pour vous prouver que ce que je dis est vrai, voilà des photos du rotor d'un moteur à courant continu que j'avais démonté il y a bien, bieen, bieeeeeen longtemps : ^^

![Rotor d'un moteur à courant continu](/media/galleries/954/4c2034a3-df1c-499c-992d-c3fb22ec1d57.png.960x960_q85.jpg)


![Rotor d'un moteur à courant continu, encore](/media/galleries/954/2ca1a52e-e45c-4e01-b3a6-f239dc78ab6a.png.960x960_q85.jpg)


Vous voyez ? Trois bobines et trois pastilles reliées à chacune, sur le collecteur. Bon, je ne vous refais pas les explications, vous êtes capables de comprendre comment cela fonctionne. ;)

# La mécanique liée au moteur

A présent, nous allons détailler quelques notions de mécanique liées aux moteurs.

## Le couple

Le couple est une notion un peu dure à comprendre, mais on va y arriver ! Partons de son unité. L'unité du couple est le Newton-Mètre (Nm), attention j'ai bien dit Newton-Mètre et non pas Newton **~~par~~** mètre ! Cette unité nous informe de deux choses : le couple est à la fois lié à une distance (le mètre) mais aussi à une force (le Newton). Maintenant je rajoute une information : le couple s'exprime par rapport à un axe. On peut en conclure que le couple est **la capacité du moteur à faire tourner quelque chose sur son axe**. Plus le couple est élevé et plus le moteur sera capable de mettre en mouvement quelque chose de lourd. Exemple : Vous avez peut-être déjà essayé de dévisser un écrou sur une roue de voiture. Vous avez probablement remarqué que plus vous avez une clef avec un bras long (un [effet de levier](http://fr.wikipedia.org/wiki/Effet_de_levier)  important) et plus il était facile de faire bouger l'écrou (pour le premier tour, quand il est bien vissé/coincé). Ce phénomène s'explique simplement par le fait que vous avez plus de couple avec un levier long qu'avec un levier court. Et c'est logique ! Si l'on considère que le couple s'exprime en Newton-mètre, le Newton se sera la force de vos muscles (considérée fixe dans notre cas d'étude, sauf si vous vous appelez Hulk) et le mètre sera la longueur du levier. Plus votre levier est grand, plus la distance est élevée, et plus le couple augmente. Ce qui nous permet d'introduire la formule suivante :

$$C = F \times r$$

Avec :

* $C$ : le couple, en Newton-mètre
* $F$ : la force exercée, en Newton
* $r$ : le rayon de l'action (la longueur du levier si vous préférez), en mètre

On pourra également se souvenir que plus la force exercée sur l'axe de rotation d'un moteur est grande, plus il faudra un couple élevé. Et plus le couple du moteur sera élevé, moins votre futur robot aura de difficultés à supporter de lourdes charges. Cela dit, tout n'est pas parfait car plus la charge est lourde, plus la consommation électrique du moteur va augmenter. On va voir la relation qui recoupe ces deux informations.

[[information]]
|Dans le système international, l'expression du couple se fait en N.m (Newton mètre), mais le commun des mortels arrive mieux à interpréter des kilos plutôt que des Newtons, donc les constructeurs prennent des raccourcis. Pour passer des Newtons en kilos, il suffit simplement de les multiplier par la constante gravitationnelle 'g' (qui vaut environ 9.81). Soit $9.81 N \simeq 1 kg$. Il en équivaut alors la même formule introduisant les mètres : $9.81 N.m = 1 kg.m$.



## La vitesse de rotation

La vitesse de rotation est mesurée par rapport à l'axe de rotation du moteur. Imaginons que le moteur entraîne son axe, lorsqu'il est alimenté par un courant, ce dernier va avoir une vitesse de rotation. Il peut tourner lentement ou rapidement. On mesure une vitesse de rotation en mesurant l'angle en radians parcourus par cet axe pendant une seconde. C'est à dire que le moteur est en fonctionnement, que son axe tourne et que l'on mesure jusqu'où va l'axe de rotation, à partir d'un point de départ fixe, en une seconde. Regardez plutôt l'image suivante pour mieux visualiser ce que je veux vous dire (comprenez que le truc gris et rond c'est le moteur que j'ai dessiné. :roll: On le voit de face et le cercle au milieu c'est son axe) :

![Marquage de l'axe du moteur par un point jaune](/media/galleries/954/5c78a5d2-742e-46b9-ab22-0c29e0239738.png.960x960_q85.jpg)

![Mesure de l'angle](/media/galleries/954/a4926611-0ec9-4f78-a006-dcfd823c696f.png.960x960_q85.jpg)

Marquage de l'axe du moteur par un point jaune (première image). Au bout d'une seconde (seconde image), mesure de l'angle $\alpha$ entre la position de départ et d'arrivée du point jaune. On obtient alors la vitesse de rotation de l'axe du moteur. Cette mesure est exprimée en angle par seconde.

Savez-vous pourquoi l'on mesure ainsi la vitesse de rotation de l'axe du moteur ? Eh bien car cette mesure est indépendante du diamètre de cet axe. Et oui, car un point éloigné du centre de l'axe du moteur a une distance beaucoup plus grande à parcourir que son homologue proche du centre de l'axe. Du coup, pour aller parcourir une distance plus grande en un temps donné il est obligé d'aller plus vite :

![La distance parcourue par le point jaune et vert est nulle](/media/galleries/954/a8c8a446-9126-4992-8f71-f5b08ebbe9e8.png.960x960_q85.jpg)

![La distance parcourue par chaque point est différente](/media/galleries/954/1f23f8df-0af9-4a00-8efe-2e68e7a2965b.png.960x960_q85.jpg)

En prenant la mesure à partir d'un point de départ fixe, la distance parcourue par le point jaune et vert est nulle (première image). En faisant tourner l'axe du moteur pendant une seconde, on s'aperçoit que la distance parcourue par chaque point est différente (seconde image). La distance parcourue par le point vert est quasiment 20 fois plus grande que celle parcourue par le point jaune ! Et c'est pourquoi le point vert aura été plus rapide que le point jaune car la distance qu'il parcourt en un même temps est beaucoup plus grande.

En mécanique, comme on aime les choses marrantes on exprime la vitesse de rotation en radians par seconde $rad/s$ et son symbole est le caractère grec $\omega$, prononcez 'oméga'. Pour rappel, 360 est aux degrés ce que 2 pi est aux radians (autrement dit, une vitesse de 2pi/secondes équivaut à dire "l'axe fait un tour par seconde"). Cela se traduit par $360$°$= 2\pi$ radian. Malheureusement, la vitesse de rotation angulaire n'est pas donnée avec les caractéristiques du moteur. En revanche, on trouve une vitesse en tour/minutes ($tr/mn$). Vous allez voir que pour passer de cette unité aux rad/s, c'est assez facile. En effet, on sait qu'un tour correspond à une rotation de l'axe sur 360°. Soit 1tr = 360°. Et dans une minute il y a 60 secondes. Donc l'axe tourne $\frac 1 {60}$ de tour par seconde, s'il fait un tour par minute. On peut alors établir la relation suivante :

$$1 tr/mn = 360 \times \frac 1 {60} = 6 {^{\circ}}/s$$

Hors, on sait que $360 {^{\circ}} = 2\pi rad$, ce qui donne une nouvelle relation :

$$1 tr/mn = 2\pi \times \frac 1 {60} = \frac \pi {30} rad/s$$

On peut finalement donner la formule qui convertit un radian par seconde en tours par minutes :

$$1 rad/s = \frac 1 {\frac \pi {30}} = \frac {30} {\pi} \approx 9,55 trs/mn$$

[[question]]
|Et je fais comment si je veux savoir à quelle vitesse ira mon robot ?

Eh bien comme je vous l'expliquais précédemment, pour répondre à cette question il faut connaitre le diamètre de la roue. Prenons l'exemple d'une roue ayant 5cm de diamètre (soit 0.05 mètres) et un moteur qui tourne à 20 rad/s. Le périmètre de la roue vaut donc 15.7 cm (0.157 m) d'après la formule du périmètre d'un cercle qui est $P = 2 \times \pi \times r$, avec $r$ le rayon du cercle. Cela signifie qu'en faisant tourner la roue sur une surface plane et en lui faisant faire un tour sur elle-même, la roue aura parcouru 0,157m sur cette surface. On admet que le moteur tourne à 20 rad/s ce qui représente donc 3.18 tours de l'axe du moteur par seconde (d'après la dernière formule que je vous ai donnée). On peut donc calculer la distance parcourue en une seconde grâce à la formule :

$$V = \frac d t$$

Avec :

* $V$ : la vitesse en mètre par seconde (m/s)
* $d$ : la distance en mètre (m)
* $t$ : le temps en secondes (s)

On va donc adapter cette formule avec la distance qu'a parcouru la roue en faisant un tour sur elle-même ($d_{roue}$) et le nombre de tours par seconde de l'axe du moteur ($t_{tour}$) : $V = \frac{d_{roue}}{t_{tour}}$ On sait que $d_{roue} = 0.157m$ et que $t_{tour} = 3,18tr/s = \frac 1 {3,18} tr.s$ $V = \frac {0,157} {\frac 1 {3,18}} = 0,157 \times 3,18$ $V = 0,5 m/s$ Le robot parcourt donc une distance de 50 centimètres en une seconde (ce qui équivaut à 1800 mètres par heure). Vous avez maintenant toutes les cartes en main pour pouvoir faire avancer votre robot à la vitesse que vous voulez !

## Les réducteurs

Un moteur électrique est bien souvent très rapide en rotation. Hors si vous avez besoin de faire un robot qui ne va pas trop vite, il va falloir faire en sorte de réduire sa vitesse de rotation. On peut très bien mettre un "frein" qui va empêcher le moteur de tourner vite, ou bien le piloter (on va voir ça toute à l'heure). Cela dit, même si on réduit sa vitesse de rotation, le moteur ne va pas pouvoir supporter des charges lourdes. Autrement dit, votre robot ne pourra même pas se supporter lui-même ! Nous avons donc besoin de couple. Et pour avoir du couple, tout en réduisant la vitesse de rotation, on va utiliser ce que l'on appelle un **réducteur**. Un réducteur est un ensemble composé d'**engrenages** qui permet de réduire la vitesse de rotation de l'axe du moteur tout en augmentant le couple de sortie. Sur l'image suivante, extraite du site de l'[Académie d'Aix Marseille](http://www.technologie.ac-aix-marseille.fr/spip/spip.php?article35&id_document=51), on peut observer un ensemble moteur + réducteur + roue :

![Ensemble moteur + réducteur + roue](/media/galleries/954/e08b5a55-77c3-48d6-8a42-8743019d9044.png.960x960_q85.jpg)

Source : http://www.technologie.ac-aix-marseille.fr/spip/spip.php?article35&id_document=51

La règle qui régit son fonctionnement indique qu'entre deux engrenages la puissance est conservée (aux pertes près qui sont dues au frottement des engrenages entre eux). Et comme la puissance mécanique est dépendante du couple et de la vitesse (partie suivante), on peut facilement passer de l'un à l'autre. Reprenons notre roue faisant 5cm de diamètre. Mettez en contact contre elle une grande roue de 10cm de diamètre (deux fois plus grande). Lorsque la petite roue fait un tour, elle va entrainer la deuxième roue plus grande qui va faire... un demi-tour. Oui car le périmètre de la grande roue est deux fois plus grand que celui de la petite. Lorsque la petite parcourt 0,157m en faisant un tour sur elle-même, la grande parcourt elle aussi cette distance mais en ne faisant qu'un demi-tour sur elle-même.

![La petite entraîne la grande](/media/galleries/954/31d744ad-2e7d-4ea9-b18a-6307e79c4ff5.png.960x960_q85.jpg)

![Lorsque la petite roue fait un demi tour, la grande roue fait un quart de tour](/media/galleries/954/21b6ad08-53bc-40b6-a44a-bac9caf6db18.png.960x960_q85.jpg)

Deux roues en contact, la petite entraîne la grande dont le diamètre est deux fois plus grand que la petite (première image). Le point vert et jaune sert à repérer la rotation de chaque roue. Lorsque la petite roue fait un demi tour, la grande roue fait un quart de tour (seconde image). Si elle fait un tour complet, la grande roue ne fera qu'un demi-tour.

Ce que l'on ne voit pas sur mon dessin, c'est le couple. Hors, ce que vous ne savez peut-être pas, c'est que l'axe de la grande roue bénéficie en fait de deux fois plus de couple que celui de la petite. Car les réducteurs ont pour propriété, je le disais, de modifier le couple de sortie et la vitesse. Et ce selon la relation suivante qui donne le **rapport de réduction** :

$$R = \frac{\omega_{entree}}{\omega_{sortie}} = \frac{C_{sortie}}{C_{entree}}$$

Avec :

* $R$ : le rapport de réduction du réducteur
* $\omega_{entree}$ : la vitesse de rotation de l'axe du moteur en entrée du réducteur
* $\omega_{sortie}$ : la vitesse de rotation de l'axe du moteur en sortie du réducteur
* $C_{sortie}$ : couple exercé par l'axe de sortie du réducteur
* $C_{entree}$ : couple exercé par l'axe du moteur, en entrée du réducteur

Un réducteur s'apparente donc à un système qui modifie deux grandeurs qui sont liées : le couple et la vitesse. On peut schématiser le fonctionnement d'un réducteur de la manière suivante :

![Schéma d'un réducteur](/media/galleries/954/c51ec9af-7356-406b-9147-7010094cd511.png.960x960_q85.jpg)

[[question]]
|C'est quoi ça, les pertes mécaniques ? :roll:

Justement, venons-en à un autre point que je voudrais aborder.

## La puissance et le rendement

Dans un moteur, on trouve deux puissances distinctes :

* La première est la **puissance électrique**. Elle représente la quantité d'énergie électrique dépensée pour faire tourner l'axe du moteur. Elle représente aussi la quantité d'énergie électrique induite lorsque le moteur tourne en générateur, c'est à dire que le moteur transforme une énergie mécanique de rotation en une énergie électrique. Elle se calcule simplement à partir de la formule suivante :


Puissance = Tension x Courant

$$P_{elec} = U \times I$$

Selon les conventions, la tension est exprimée en Volt et le courant en Ampère. Quant à la puissance, elle est exprimée en **Watt** (**W**).


* La seconde est la **puissance mécanique**. Elle correspond au couple du moteur multiplié par sa vitesse angulaire :

$$P_{meca} = C \times \omega$$

Le couple doit être exprimé en Newton-Mètre (Nm) et la vitesse en radians par seconde (rad/s). Pour la puissance mécanique, il s'agit encore de Watt.

[[information]]
|Une puissance (mécanique ou électrique) s'exprime habituellement en **Watts** (symbole **W**). On retrouve cependant d'autres unités telle que le Cheval Vapeur (CV), avec 1 CV qui vaut (arrondi) 735,5 W.

Mais comme dans tout système, la perfection n'existe pas, on va voir la différence qu'il y a entre la puissance mécanique et électrique, alors que *à priori* elles devraient être équivalentes. Lorsque le moteur est en fonctionnement, il génère des **pertes**. Ces pertes sont dues à différents **phénomènes électriques** ou **thermiques** (échauffement) ou tels que les **frottements mécaniques** (air, pièces en contact, magnétique). **Il y a donc une différence entre la puissance (électrique) en entrée du moteur et la puissance (mécanique) en sa sortie.** Cette différence s'exprime avec la notion de **rendement**. Le rendement est une caractéristique intrinsèque à chaque moteur et permet de définir l'écart entre la puissance d'entrée du moteur et sa puissance de sortie. Il s’exprime sans unité. Il permet également de savoir quel est le pourcentage de pertes provoquées par le moteur. Le rendement se note avec la lettre grecque *eta* ($\eta$) et se calcule grâce à la formule suivante :

$$\eta = \frac{P_{sortie}}{P_{entree}}$$

Dans le cas du moteur, on aurait alors les puissances électrique et mécanique telles quelles :

$$\eta = \frac{P_{meca}}{P_{elec}}$$

Et dans le cas où le moteur est utilisé en générateur électrique (on fait tourner l'axe à la main par exemple), la formule reste la même mais la place des puissances électrique et mécanique est inversée :

$$\eta = \frac{P_{elec}}{P_{meca}}$$

[[attention]]
|Attention, le rendement est une valeur **sans unité**, on peut en revanche l'exprimer sous forme de pourcentage.

Si l'on prend un exemple : un moteur de puissance électrique 100W, ayant une puissance mécanique de 84W aura un rendement de : $\eta = \frac{P_{meca}}{P_{elec}}$ $\eta = \frac{P_{84}}{P_{100}}$ $\eta = 0,84$ Ce qui correspond à 84%. Sachez toutefois que le rendement ne pourra dépasser les 100% (ou 1), car **il n'existe pas de systèmes capables de fournir plus d'énergie qu'ils n'en reçoivent**. Cela dit, si un jour vous parvenez à en trouver un, vous pourrez devenir le Roi du Monde !! :Pirate:

[[information]]
|Les moteurs électriques ont habituellement un bon rendement, entre 80% (0.8) et 95% (0.95). Cela signifie que pour 100W électriques injectés en entrée, on obtiendra en sortie 80 à 95W de puissance mécanique. Tandis qu'un moteur à explosion de voiture dépasse à peine les 30% de rendement !



# Quelques relations

Une toute dernière chose avant de commencer la suite, il y a deux relations à connaitre vis-à-vis des moteurs.

## Lien entre vitesse et tension

Dans un moteur CC, quelque soit sa taille et sa puissance, il faut savoir que la tension à ses bornes et la vitesse de sortie sont liées. Plus la tension sera élevée et plus la vitesse sera grande. Nous verrons cet aspect dans la prochaine partie. Faites attention à bien rester dans les plages de tension d'alimentation de votre moteur et ne pas les dépasser. Il pourrait griller ! En effet, vous pouvez dépasser **de manière temporaire** la tension maximale autorisée pour donner un coup de fouet à votre moteur, mais ne restez jamais dans une plage trop élevée ! Une deuxième conséquence de cette relation concerne le moment du démarrage du moteur. En effet, la relation entre tension et vitesse n'est pas tout à fait linéaire pour les tensions faibles, elle est plutôt "écrasée" à cet endroit. Du coup, cela signifie que le moteur n'arrivera pas à tourner pour une tension trop basse. C'est un peu comme si vous aviez une tension de seuil de démarrage. En dessous de cette tension, le moteur est à l'arrêt, et au dessus il tourne correctement avec une relation de type "100 trs/min/volts" (autrement dit, le moteur tournera à 100 tours par minutes pour 1 volt, puis 200 tours par minutes pour 2 volts et etc etc... bien entendu le 100 est pris comme un exemple purement arbitraire, chaque moteur a sa caractéristique propre).

## Lien entre courant et couple

Comme nous venons de le voir, la vitesse est une sorte d'image de la tension. Passons maintenant à une petite observation : Lorsque l'on freine l'axe du moteur, par exemple avec le doigt, on sent que le moteur insiste et essaye de repousser cette force exercée sur son axe. Cela est du au courant qui le traverse et qui augmente car le moteur, pour continuer de tourner à la même vitesse, doit fournir plus de couple. Hors, le couple et le courant sont liés : si l'un des deux augmente alors l'autre également. Autrement dit, pour avoir plus de couple le moteur consomme plus de courant. Si votre alimentation est en mesure de le fournir, il pourra éventuellement bouger, sinon, comme il ne peut pas consommer plus que ce qu'on lui donne, il restera bloqué et consommera le maximum de courant fourni.

[[attention]]
|Si vous faites circuler trop de courant dans un moteur pour trop longtemps, il va chauffer. Les moteurs sont des composants sans protection. Même s'ils chauffent ils ne feront rien pour s’arrêter, bien au contraire. Cela peut mener à une surchauffe et une destruction du moteur (les bobines à l'intérieur sont détruites). Attention donc à ne pas trop le faire forcer sur de longues périodes continues.