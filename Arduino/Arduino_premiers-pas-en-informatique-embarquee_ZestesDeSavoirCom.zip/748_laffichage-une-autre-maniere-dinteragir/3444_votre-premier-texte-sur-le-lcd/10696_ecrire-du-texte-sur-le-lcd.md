# Afficher du texte

Vous vous rappelez quand je vous disais il y a longtemps "Les développeurs Arduino sont des gens sympas, ils font les choses clairement et logiquement !" ? Eh bien, ce constat se reproduit (encore) pour la bibliothèque `LiquidCrystal` ! En effet, une fois que votre écran LCD est bien paramétré, il nous suffira d'utiliser qu'une seule fonction pour afficher du texte ! Allez je vous laisse 10 secondes pour deviner le nom de la fonction que nous allons utiliser. Un indice, ça a un lien avec la voie série... C'est trouvé ? Félicitations à tous ceux qui auraient dit print(). En effet, une fois de plus nous retrouvons une fonction `print()`, comme pour l'objet Serial, pour envoyer du texte. Ainsi, pour saluer tous les zesteurs de la terre nous aurons juste à écrire :

```cpp
lcd.print("Salut ca zeste ?");
```

et pour code complet avec les déclarations, on obtient :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// initialise l'écran avec les bonnes broches

// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !

LiquidCrystal lcd(8,9,4,5,6,7);

void setup() {
   lcd.begin(16, 2);
   lcd.print("Salut ca zeste ?");
}

void loop() {

}
```


[[q]]
| Mais c'est nul ton truc on affiche toujours au même endroit, en haut à gauche !

Oui je sais, mais chaque chose en son temps, on s'occupera du positionnement du texte bientôt, promis !

# Afficher une variable

Afficher du texte c'est bien, mais afficher du contenu dynamique c'est mieux ! Nous allons maintenant voir comment afficher une variable sur l'écran. Là encore, rien de difficile. Je ne vais donc pas faire un long discours pour vous dire qu'il n'y a qu'une seule fonction à retenir... le suspens est terrible... OUI évidemment cette fonction c'est **`print()`** !Décidément elle est vraiment tout-terrain (et rédacteur du tutoriel Arduino devient un vrai boulot de feignant, je vais finir par me copier-coller à chaque fois !) Allez zou, un petit code, une petite photo et en avant Guingamp !

```cpp
    int mavariable = 42;
    lcd.print(mavariable);
```
Code: `Print` pour afficher une variable

# Combo ! Afficher du texte ET une variable

Bon vous aurez remarqué que notre code possède une certaine faiblesse... On n'affiche au choix qu'un texte ou qu'un nombre, mais pas les deux en même temps ! Nous allons donc voir maintenant une manière d'y remédier.

## La fonction solution

La solution se trouve dans les bases du langage C , grâce à une fonction qui s'appelle **`sprintf()`** (aussi appelé "string printf"). Les personnes qui ont fait du C doivent la connaitre, ou connaitre sa cousine "printf". Cette fonction est un peu particulière, car elle ne prend pas un nombre d'arguments fini. En effet, si vous voulez afficher 2 variables vous ne lui donnerez pas autant d'arguments que pour en afficher 4 (ce qui parait logique d'une certaine manière). Pour utiliser cette dernière, il va falloir utiliser un tableau de char qui nous servira de *buffer*. Ce tableau sera celui dans lequel nous allons écrire notre chaine de caractère. Une fois que nous aurons écrit dedans, il nous suffira de l'envoyer sur l'écran en utilisant... print() !

*[buffer]: Zone tampon, permet de garder en mémoire un certain nombre de données

## Son fonctionnement

Comme dit rapidement plus tôt, `sprintf()` n'a pas un nombre d'arguments fini. Cependant, elle en aura au minimum deux qui sont le tableau de la chaine de caractère et une chaine à écrire. Un exemple simple serait d'écrire :

```cpp
char message[16] = "";
sprintf(message,"J'ai 42 ans");
```
Code: `sprintf` pour mettre une chaine dans une tableau de char

Au début, le tableau message ne contient rien. Après la fonction `sprintf()`, il possédera le texte "J'ai 42 ans". Simple non ?
[[i]]
| J'utilise un tableau de 16 cases car mon écran fait 16 caractères de large au maximum, et donc inutile de gaspiller de la mémoire en prenant un tableau plus grand que nécessaire.

Nous allons maintenant voir comment changer mon âge en le mettant en dynamique dans la chaine grâce à une variable. Pour cela, nous allons utiliser des **marqueurs de format**. Le plus connu est **%d** pour indiquer un nombre entier (nous verrons les autres ensuite). Dans le contenu à écrire (le deuxième argument), nous placerons ces marqueurs à chaque endroit où l'on voudra mettre une variable. Nous pouvons en placer autant que nous voulons. Ensuite, il nous suffira de mettre dans le même ordre que les marqueurs les différentes variables en argument de `sprintf()`. Tout va être plus clair avec un exemple !

```cpp
char message[16] = "";
int nbA = 3;
int nbB = 5;
sprintf(message,"%d + %d = %d", nbA, nbB, nbA+nbB);
```
Code: `sprintf` pour enregistrer une (des) variables dans une chaine

Cela affichera :

```bash
3 + 5 = 8
```

## Les marqueurs

Comme je vous le disais, il existe plusieurs marqueurs. Je vais vous présenter ceux qui vous serviront le plus, et différentes astuces pour les utiliser à bon escient :

+ **%d** qui sera remplacé par un `int` (signé)
+ **%s** sera remplacé par une chaine (un tableau de `char`)
+ **%u** pour un entier non signé (similaire à %d)
+ **%%** pour afficher le symbole '%' ;)

Malheureusement, Arduino ne les supporte pas tous. En effet, le %f des float ne fonctionne pas. :( Il vous faudra donc bricoler si vous désirez l'afficher en entier (je vous laisse deviner comment). Si jamais vous désirez forcer l'affichage d'un marqueur sur un certain nombre de caractères, vous pouvez utiliser un indicateur de taille de ce nombre entre le '%' et la lettre du marqueur. Par exemple, utiliser "%3d" forcera l'affichage du nombre en paramètre (quel qu'il soit) **sur trois caractères au minimum**. La variable ne sera pas tronquée s'il est plus grand que l'emplacement prévu. Ce paramètre prendra donc toujours autant de place *au minimum* sur l'écran (utile pour maitriser la disposition des caractères). Exemple :

```cpp
int age1 = 42;
int age2 = 5;
char prenom1[10] = "Ben";
char prenom2[10] = "Luc";
char message[16] = "";
sprintf(message,"%s:%2d,%s:%2d",prenom1, age1, prenom2, age2);
```
Code: Différents marqueurs de variable pour `sprintf`

À l'écran, on aura un texte tel que :

```bash
Ben:42,Luc: 5
```

On note l'espace avant le 5 grâce au forçage de l'écriture de la variable sur 2 caractères induits par *%2d*.

# Exercice, faire une horloge

## Consigne

Afin de conclure cette partie, je vous propose un petit exercice. Comme le titre l'indique, je vous propose de réaliser une petite horloge. Bien entendu elle ne sera pas fiable du tout car nous n'avons aucun repère réel dans le temps, mais ça reste un bon exercice. L'objectif sera donc d'afficher le message suivant : "Il est hh:mm:ss" avec 'hh' pour les heures, 'mm' pour les minutes et 'ss' pour les secondes. Ça vous ira ? Ouais, enfin je ne vois pas pourquoi je pose la question puisque de toute manière vous n'avez pas le choix ! :diable: Une dernière chose avant de commencer. Si vous tentez de faire plusieurs affichages successifs, le curseur ne se replacera pas et votre écriture sera vite chaotique. Je vous donne donc rapidement une fonction qui vous permet de revenir à la position en haut à gauche de l'écran : `home()`. Il vous suffira de faire un `lcd.home()` pour replacer le curseur en haut à gauche. Nous reparlerons de la position curseur dans le chapitre suivant !

## Solution

Je vais directement vous parachuter le code, sans vraiment d'explications car je pense l'avoir suffisamment commenté (et entre nous, l'exercice est sympa et pas trop dur). ;)

[[s]]
| ```cpp
| #include "LiquidCrystal.h" // on inclut la librairie
|
| // initialise l'écran avec les bonnes broches
| // ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
| LiquidCrystal lcd(8,9,4,5,6,7);
|
| int heures,minutes,secondes;
| char message[16] = "";
|
| void setup()
| {
|     lcd.begin(16, 2); // règle la taille du LCD : 16 colonnes et 2 lignes
|
|     // changer les valeurs pour démarrer à l'heure souhaitée !
|     heures = 0;
|     minutes = 0;
|     secondes = 0;
| }
|
| void loop()
| {
|     // on commence par gérer le temps qui passe...
|     if(secondes == 60) // une minute est atteinte ?
|     {
|         secondes = 0; // on recompte à partir de 0
|         minutes++;
|     }
|     if(minutes == 60) // une heure est atteinte ?
|     {
|         minutes = 0;
|         heures++;
|     }
|     if(heures == 24) // une journée est atteinte ?
|     {
|         heures = 0;
|     }
|
|     // met le message dans la chaine à transmettre
|     sprintf(message,"Il est %2d:%2d:%2d",heures,minutes,secondes);
|
|     lcd.home();           // met le curseur en position (0;0) sur l'écran
|
|     lcd.write(message);   // envoi le message sur l'écran
|
|     delay(1000);          // attend une seconde
|     // une seconde s'écoule...
|     secondes++;
| }
| ```