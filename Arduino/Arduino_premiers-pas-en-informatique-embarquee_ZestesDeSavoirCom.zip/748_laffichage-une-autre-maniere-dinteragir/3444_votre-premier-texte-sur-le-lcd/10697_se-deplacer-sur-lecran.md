Bon, autant vous prévenir, ce morceau de chapitre ne sera pas digne du nom de "tutoriel". Malheureusement, pour se déplacer sur l'écran (que ce soit le curseur ou du texte) il n'y a pas 36 solutions, juste quelques appels relativement simples à des fonctions. Désolé d'avance pour le "pseudo-listing" de fonctions que je vais faire tout en essayant de le garder intéressant...

# Gérer l'affichage

Les premières fonctions que nous allons voir concernent l'écran dans son ensemble. Nous allons apprendre à enlever le texte de l'écran mais le garder dans la mémoire pour le réafficher ensuite. En d'autres termes, vous allez pouvoir faire un mode "invisible" où le texte est bien stocké en mémoire, mais pas affiché sur l'écran. Les deux fonctions permettant ce genre d'action sont les suivantes :

+ `noDisplay()` : fait disparaître le texte
+ `display()` : fait apparaître le texte (s'il y en a évidemment)

Si vous tapez le code suivant, vous verrez le texte clignoter toutes les secondes :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// initialise l'écran avec les bonnes broches
// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

void setup() {
    // règle la  taille du LCD
    lcd.begin(16, 2);
    lcd.print("Salut ca zeste ?");
}

void loop() {
    lcd.noDisplay();
    delay(500);
    lcd.display();
    delay(500);
}
```
Code: Afficher ou non un texte sur le LCD : `display` et `noDisplay`

Utile si vous voulez attirer l'attention de l'utilisateur ! Une autre fonction utile est celle vous permettant de nettoyer l'écran. Contrairement à la précédente, cette fonction va supprimer le texte de manière permanente. Pour le réafficher, il faudra le renvoyer à l'afficheur. Cette fonction au nom évident est : `clear()` (bien sûr, il faut être un peu anglophone pour s'en douter ^^ ). Le code suivant vous permettra ainsi d'afficher un texte puis, au bout de 2 secondes, il disparaitra (pas de loop(), pas nécessaire) :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// initialise l'écran avec les bonnes broches
// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

void setup() {
    // règle la  taille du LCD
    lcd.begin(16, 2);
    lcd.print("Salut ca zeste ?");
    delay(2000);
    lcd.clear();
}
```
Code: Effacer l'écran LCD : `clear`

Cette fonction est très utile lorsque l'on fait des menus sur l'écran, pour pouvoir changer de page. Si on ne fait pas un `clear()`, il risque d'ailleurs de subsister des caractères de la page précédente. Ce n'est pas très joli.

[[a]]
| Attention à ne pas appeler cette fonction plusieurs fois de suite, par exemple en la mettant dans la fonction `loop()`, vous verrez le texte ne s'affichera que très rapidement puis disparaitra et ainsi de suite.

# Gérer le curseur

## Se déplacer sur l'écran

Voici maintenant d'autres fonctions que vous attendez certainement, celles permettant de déplacer le curseur sur l'écran. En déplaçant le curseur, vous pourrez écrire à n'importe quel endroit sur l'écran (attention cependant à ce qu'il y ait suffisamment de place pour votre texte). :P Nous allons commencer par quelque chose de facile que nous avons vu très rapidement dans le chapitre précédent. Je parle bien sûr de la fonction `home()` ! Souvenez-vous, cette fonction permet de replacer le curseur au début de l'écran.
[[q]]
| Mais au fait, savez-vous comment est organisé le repère de l'écran ?

C'est assez simple, mais il faut être vigilant quand même. Tout d'abord, sachez que les coordonnées s'expriment de la manière suivante $(x,y)$. $x$ représente les abscisses, donc les pixels horizontaux et $y$ les ordonnées, les pixels verticaux. L'origine du repère sera logiquement le pixel le plus en haut à gauche (comme la lecture classique d'un livre, on commence en haut à gauche) et à pour coordonnées ... (0,0) ! Eh oui, on ne commence pas aux pixels (1,1) mais bien (0,0). Quand on y réfléchit, c'est assez logique. Les caractères sont rangés dans des chaines de caractères, donc des tableaux, qui eux sont adressés à partir de la case 0. Il parait donc au final logique que les développeurs aient gardé une cohérence entre les deux.

Puisque nous commençons à 0, un écran de 16x2 caractères pourra donc avoir comme coordonnées de 0 à 15 pour $x$ et 0 ou 1 pour $y$. Ceci étant dit, nous pouvons passer à la suite. La prochaine fonction que nous allons voir prend directement en compte ce que je viens de vous dire. Cette fonction nommée `setCursor()` vous permet de positionner le curseur sur l'écran. On pourra donc faire `setCursor(0,0)` pour se placer en haut à gauche (équivalent à la fonction "home()") et en faisant `setCursor(15,1)` on se placera tout en bas à droite (toujours pour un écran de 16x2 caractères). Un exemple :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// initialise l'écran avec les bonnes broches
// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

void setup()
{
    lcd.begin(16, 2);
    lcd.setCursor(2,1);        // place le curseur aux coordonnées (2,1)
    lcd.print("Texte centré"); // texte centré sur la ligne 2
}
```
Code: Positionner le curseur sur l'écran LCD : `setCursor`

## Animer le curseur

Tout comme nous pouvons faire disparaître le texte, nous pouvons aussi faire disparaître le curseur (comportement par défaut). La fonction `noCursor()` va donc l'effacer. La fonction antagoniste `cursor()` de son côté permettra de l'afficher (vous verrez alors un petit trait en bas du carré (5*8 pixels) où il est placé, comme lorsque vous appuyez sur la touche Insér. de votre clavier). Une dernière chose sympa à faire avec le curseur est de le faire clignoter. En anglais clignoter se dit "blink" et donc tout logiquement la fonction à appeler pour activer le clignotement est `blink()`. Vous verrez alors le curseur remplir le carré concerné en blanc puis s'effacer (juste le trait) et revenir. S'il y a un caractère en dessous, vous verrez alternativement un carré tout blanc puis le caractère. Pour désactiver le clignotement, il suffit de faire appel à la fonction `noBlink()`.

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

void setup()
{
    lcd.begin(16, 2);
    lcd.home();        // place le curseur aux coordonnées (0,0)
    lcd.setCursor();   // affiche le curseur
    lcd.blink();       // et le fait clignoter
    lcd.print("Curseur clignotant"); // texte centré sur la ligne 2
}
```
Code: Faire clignoter le curseur : `blink`

[[i]]
| Si vous faites appel à blink() puis à noCursor() le carré blanc continuera de clignoter. En revanche, quand le curseur est dans sa phase "éteinte" vous ne verrez plus le trait du bas.

# Jouer avec le texte

Nous allons maintenant nous amuser avec le texte. Ne vous attendez pas non plus à des miracles, il s'agira juste de déplacer le texte automatiquement ou non.

## Déplacer le texte à la main

Pour commencer, nous allons déplacer le texte manuellement, vers la droite ou vers la gauche. N'essayez pas de produire l’expérience avec votre main, ce n'est pas un écran tactile, hein ! ;) Le comportement est simple à comprendre. Après avoir écrit du texte sur l'écran, on peut faire appel aux fonctions `scrollDisplayRight()` et `scrollDisplayLeft()` vous pourrez déplacer le texte d'un carré vers la droite ou vers la gauche. S'il y a du texte sur chacune des lignes avant de faire appel aux fonctions, c'est le texte de chaque ligne qui sera déplacé par la fonction. Utilisez deux petits boutons poussoirs pour utiliser le code suivant. Vous pourrez déplacer le texte en appuyant sur chacun des poussoirs !

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// les branchements
const int boutonGauche = 2; // le bouton de gauche
const int boutonDroite = 3; // le bouton de droite

// initialise l'écran avec les bonnes broches
// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

// ------------------------------------------------------------------------------

void setup() {
    // règlage des entrées/sorties
    pinMode(boutonGauche, INPUT);
    pinMode(boutonDroite, INPUT);

    // on attache des fonctions aux deux interruptions externes (les boutons)
    attachInterrupt(0, aDroite, RISING);
    attachInterrupt(1, aGauche, RISING);

    // Réglage du LCD
    lcd.begin(16, 2); // règle la  taille du LCD
    lcd.print("Salut ca zeste ?");
}

void loop() {
    // pas besoin de loop pour le moment
}

// fonction appelée par l'interruption du premier bouton
void aGauche() {
    lcd.scrollDisplayLeft(); // on va à gauche !
}

// fonction appelée par l'interruption du deuxième bouton
void aDroite() {
    lcd.scrollDisplayRight(); // on va à droite !
}
```
Code: Déplacer le texte : `scrollDisplay`

->!(https://www.youtube.com/watch?v=G-uCc0qYdWg) <-

## Déplacer le texte automatiquement

De temps en temps, il peut être utile d'écrire toujours sur le même pixel et de faire en sorte que le texte se décale tout seul (pour faire des effets zolis par exemple). ^^ Un couple de fonctions va nous aider dans cette tâche. La première sert à définir la direction du défilement. Elle s'appelle `leftToRight()` pour aller de la gauche vers la droite et `rightToLeft()` pour l'autre sens. Ensuite, il suffit d'activer (ou pas si vous voulez arrêter l'effet) avec la fonction `autoScroll()` (et `noAutoScroll()` pour l’arrêter). Pour mieux voir cet effet, je vous propose d'essayer le code qui suit. Vous verrez ainsi les chiffres de 0 à 9 apparaitre et se "pousser" les uns après les autres :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

void setup()
{
    lcd.begin(16, 2);
    lcd.setCursor(14,0);
    lcd.leftToRight();  // indique que le texte doit être déplacé vers la gauche
    lcd.autoscroll();   // rend automatique ce déplacement
    lcd.print("{");
    int i=0;
    for(i=0; i<10; i++)
    {
        lcd.print(i);
        delay(1000);
    }
    lcd.print("}");
}
```
Code: Deplace le texte automatiquement : `autoscroll`