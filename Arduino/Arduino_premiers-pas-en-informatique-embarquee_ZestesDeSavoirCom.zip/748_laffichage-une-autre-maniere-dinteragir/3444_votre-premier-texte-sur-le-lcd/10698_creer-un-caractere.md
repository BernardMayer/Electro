Dernière partie avant la pratique, on s'accroche vous serez bientôt incollable sur les écrans LCD ! En plus, réjouissez-vous ! je vous ai gardé un petit truc sympa pour la fin. En effet, dans ce dernier morceau, toute votre âme créatrice va pouvoir s'exprimer ! Nous allons créer des caractères !

## Principe de la création

Créer un caractère n'est pas très difficile, il suffit d'avoir un peu d'imagination. Sur l'écran, les pixels sont en réalité divisés en grille de 5x8 (5 en largeur et 8 en hauteur). C'est parce que le contrôleur de l'écran connait l'alphabet qu'il peut dessiner sur ces petites grilles les caractères et les chiffres. Comme je viens de le dire, les caractères sont une grille de 5x8. Cette grille sera symbolisée en mémoire par un tableau de huit octets (type `byte`). Les 5 bits de poids faible de chaque octet représenteront une ligne du nouveau caractère. Pour faire simple, prenons un exemple. Nous allons dessiner un smiley, avec ses deux yeux et sa bouche pour avoir le rendu suivant :

```text
0 0 0 0 0
X 0 0 0 X
0 0 0 0 0
0 0 0 0 0
X 0 0 0 X
0 X X X 0
0 0 0 0 0
0 0 0 0 0
```

Ce dessin se traduira en mémoire par un tableau d'octet que l'on pourra coder de la manière suivante :

```cpp
byte smiley[8] = {
    B00000,
    B10001,
    B00000,
    B00000,
    B10001,
    B01110,
    B00000,
    B00000
};
```
Code: Tableau de représentation d'un smiley

La lettre 'B' avant l'écriture des octets veut dire "*Je t'écris la valeur en binaire*". Cela nous permet d'avoir un rendu plus facile et rapide.

![Oh le joli smiley !](/media/galleries/954/6d6f9b2d-3f3b-43f9-8838-c4a404edd042.jpg.960x960_q85.jpg)

## L'envoyer à l'écran et l'utiliser

Une fois que votre caractère est créé, il faut l'envoyer à l'écran, pour que ce dernier puisse le connaitre, avant toute communication avec l'écran (oui oui avant le `begin()`). La fonction pour apprendre notre caractère à l'écran se nomme `createChar()` signifiant "créer caractère". Cette fonction prend deux paramètres : "l'adresse" du caractère dans la mémoire de l'écran (de 0 à 7) et le tableau de byte représentant le caractère. Ensuite, l'étape de départ de communication avec l'écran peut-être faite (le begin). Ensuite, si vous voulez écrire ce nouveau caractère sur votre bel écran, nous allons utiliser une nouvelle (la dernière fonction) qui s'appelle `write()`. En paramètre sera passé un `int` représentant le numéro (adresse) du caractère que l'on veut afficher. Cependant, il y a là une faille dans le code Arduino. En effet, la fonction `write()` existe aussi dans une librairie standard d'Arduino et prend un pointeur sur un char. Le seul moyen de les différencier pour le compilateur sera donc de regarder le paramètre de la fonction pour savoir ce que vous voulez faire. Dans notre cas, il faut passer un `int`. On va donc forcer (on dit "caster") le paramètre dans le type "uint8_t" en écrivant la fonction de la manière suivante : `write(uint8_t param)`. Le code complet sera ainsi le suivant :

```cpp
#include "LiquidCrystal.h" // on inclut la librairie

// initialise l'écran avec les bonnes broches
// ATTENTION, REMPLACER LES NOMBRES PAR VOS BRANCHEMENTS À VOUS !
LiquidCrystal lcd(8,9,4,5,6,7);

// notre nouveau caractère
byte smiley[8] = {
    B00000,
    B10001,
    B00000,
    B00000,
    B10001,
    B01110,
    B00000,
};

void setup()
{
    lcd.createChar(0, smiley); // apprend le caractère à l'écran LCD
    lcd.begin(16, 2);
    lcd.write((uint8_t) 0); // affiche le caractère de l'adresse 0
}
```
Code: Insertion et utilisation d'un caractère dans la memoire du LCD