Dans ce TP, on se propose de mettre en place un système de supervision, comme on pourrait en retrouver dans un milieu industriel (en plus simple ici, bien sûr !) ou dans d'autres applications. Le but sera d'afficher des informations sur l'écran LCD en fonction d'évènements qui se passent dans le milieu extérieur. Ce monde extérieur sera représenté par les composants suivants :

+ Deux boutons, qui pourraient représenter par exemple deux barrières infrarouges et dont le signal reçu passe de 1 à 0 lorsqu'un objet passe devant.
+ Deux potentiomètres. Le premier sert de "consigne" et est réglé par l'utilisateur. Le second représentera un capteur. À titre d'exemple, sur la vidéo à la suite vous verrez un potentiomètre rotatif qui représentera la consigne et un autre sous forme de glissière qui sera le capteur.
+ Enfin, une LED rouge nous permettra de faire une alarme visuelle. Elle sera normalement éteinte mais si la valeur du capteur dépasse celle de la consigne alors elle s'allumera.

## Comportement de l'écran

L'écran que j'utilise ne propose que 2 lignes et 16 colonnes. Il n'est donc pas possible d'afficher toutes les informations de manière lisible en même temps. On se propose donc de faire un affichage alterné entre deux interfaces. Chaque interface sera affichée pendant cinq secondes à tour de rôle. La première affichera l'état des boutons. On pourra par exemple lire :

```text
Bouton G : ON
Bouton D : OFF
```

La seconde interface affichera la valeur de la consigne et celle du capteur. On aura par exemple :
```text
Consigne : 287
Capteur  : 115
```

(Sur la vidéo vous verrez "gauche / droite" pour symboliser les deux potentiomètres, chacun fait comme il veut/peut :P ).

Enfin, bien que l'information "consigne/capteur" ne s'affiche que toutes les 5 secondes, l'alarme (la LED rouge), elle, doit être visible à tout moment si la valeur du capteur dépasse celle de la consigne. En effet, imaginez que cette alarme représentera une pression trop élevée, ce serait dommage que tout explose à cause d'un affichage 5 secondes sur 10 ! :P Je pense avoir fait le tour de mes attentes ! Je vous souhaite un bon courage, prenez votre temps, faites un beau schéma/montage/code et à bientôt pour la correction !

->!(https://www.youtube.com/watch?v=rGdUo7j2ou8)<-