Vous avez appris plus tôt comment interagir avec l'ordinateur, lui envoyer de l'information. Mais maintenant, vous voudrez sûrement pouvoir afficher de l'information sans avoir besoin d'un ordinateur. Avec les écrans LCD, nous allons pouvoir afficher du texte sur un écran qui n'est pas très coûteux et ainsi faire des projets sensationnels !

*[LCD]: Liquid Crystal Display