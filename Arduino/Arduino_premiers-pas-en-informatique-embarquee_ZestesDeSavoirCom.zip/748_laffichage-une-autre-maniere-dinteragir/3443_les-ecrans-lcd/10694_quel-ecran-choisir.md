# Les caractéristiques

## Texte ou Graphique ?

Dans la grande famille afficheur LCD, on distingue plusieurs catégories :

+ Les afficheurs alphanumériques
+ Les afficheurs graphiques monochromes
+ Les afficheurs graphiques couleur

Les premiers sont les plus courants. Ils permettent d'afficher des lettres, des chiffres et quelques caractères spéciaux. Les caractères sont prédéfinis (voir table juste au-dessus) et on n'a donc aucunement besoin de gérer chaque pixel de l'écran. Les seconds sont déjà plus avancés. On a accès à chacun des pixels et on peut donc produire des dessins beaucoup plus évolués. Ils sont cependant légèrement plus onéreux que les premiers. Les derniers sont l'évolution des précédents, la couleur en plus (soit 3 fois plus de pixels à gérer : un sous-pixel pour le rouge, un autre pour le bleu et un dernier pour le vert, le tout forme la couleur d'un seul pixel). Pour le TP on se servira d'afficheur de la première catégorie, car ils suffisent à faire de nombreux montages et restent accessibles pour des zesteurs. ;)

![Un écran LCD alphanumérique](http://zestedesavoir.com/media/galleries/954/0bdb01b9-e94e-4936-9cba-0719fb97d915.jpg.960x960_q85.jpg)

## Ce n'est pas la taille qui compte !

Les afficheurs existent dans de nombreuses tailles. Pour les afficheurs de type textes, on retrouve le plus fréquemment le format 2 lignes par 16 colonnes. Il en existe cependant de nombreux autres avec une seule ligne, ou 4 (ou plus) et 8 colonnes, ou 16, ou 20 ou encore plus ! Libre à vous de choisir la taille qui vous plait le plus, sachant que le TP devrait s'adapter sans souci à toute taille d'écran (pour ma part, ce sera un 2 lignes 16 colonnes) !

## La couleur, c'est important

Nan je blague ! Prenez la couleur qui vous plait ! Vert, blanc, bleu, jaune, amusez-vous ! (moi c'est écriture blanche sur fond bleu, mais je rêve d'un afficheur à la matrix, noir avec des écritures vertes !)

# Communication avec l'écran

## La communication parallèle

De manière classique, on communique avec l'écran de manière **parallèle**. Cela signifie que l'on envoie des bits **par blocs**, en utilisant plusieurs broches en même temps (opposée à une transmission série où les bits sont envoyés un par un sur une seule broche). Comme expliqué plus tôt dans ce chapitre, nous utilisons 10 broches différentes, 8 pour les données (en parallèle donc) et 2 pour de la commande (E : Enable et RS : Registre Selector). La ligne R/W peut être connecté à la masse si l'on souhaite uniquement faire de l'écriture.

Pour envoyer des données sur l'écran, c'est en fait assez simple. Il suffit de suivre un ordre logique et un certain timing pour que tout se passe bien. Tout d'abord, il nous faut placer la broche RS à 1 ou 0 selon que l'on veut envoyer une commande, par exemple "déplacer le curseur à la position (1;1)" ou que l'on veut envoyer une donnée : "écris le caractère 'a' ". Ensuite, on place sur les 8 broches de données (D0 à D7) la valeur de la donnée à afficher. Enfin, il suffit de faire une impulsion d'au moins 450 ns pour indiquer à l'écran que les données sont prêtes. C'est aussi simple que ça !

Cependant, comme les ingénieurs d'écrans sont conscients que la communication parallèle prend beaucoup de broches, ils ont inventé un autre mode que j'appellerai "semi-parallèle". Ce dernier se contente de travailler avec seulement les broches de données D4 à D7 (en plus de RS et E) et il faudra mettre les quatre autres (D0 à D3) à la masse. Il libère donc quatre broches. Dans ce mode, on fera donc deux fois le cycle "envoi des données puis impulsion sur E" pour envoyer un octet complet.

[[i]]
| Ne vous inquiétez pas à l'idée de tout cela. Pour la suite du chapitre, nous utiliserons une libraire nommée **LiquidCrystal** qui se chargera de gérer les timings et l'ensemble du protocole.

Pour continuer ce chapitre, le mode "semi-parallèle" sera choisi. Il nous permettra de garder plus de broches disponibles pour de futurs montages et est souvent câblé par défaut dans de nombreux shields (dont le mien). La partie suivante vous montrera ce type de branchement. Et pas de panique, je vous indiquerai également la modification à faire pour connecter un écran en mode "parallèle complet".

## La communication série

Lorsque l'on ne possède que très peu de broches disponibles sur notre Arduino, il peut être intéressant de faire appel à un composant permettant de communiquer par voie série avec l'écran. Un tel composant se chargera de faire la conversion entre les données envoyées sur la voie série et ce qu'il faut afficher sur l'écran. Le gros avantage de cette solution est qu'elle nécessite seulement un seul fil de donnée (avec une masse et le VCC) pour fonctionner là où les autres méthodes ont besoin de presque une dizaine de broches.

Toujours dans le cadre du prochain TP, nous resterons dans le classique en utilisant une connexion parallèle. En effet, elle nous permet de garder l'approche "standard" de l'écran et nous permet de garder la liaison série pour autre chose (encore que l'on pourrait en émuler une sans trop de difficulté). Ce composant de conversion "Série -> parallèle" peut-être réalisé simplement avec un 74h595 :) (je vous laisse coder le driver comme exercice si vous voulez :P )

## Et par liaison I²C

Un dernier point à voir, c'est la communication de la carte Arduino vers l'écran par la liaison I²C. Cette liaison est utilisable avec seulement 2 broches (une broche de donnée et une broche d'horloge) et nécessite l'utilisation de deux broches analogiques de l'Arduino (broche 4 et 5).