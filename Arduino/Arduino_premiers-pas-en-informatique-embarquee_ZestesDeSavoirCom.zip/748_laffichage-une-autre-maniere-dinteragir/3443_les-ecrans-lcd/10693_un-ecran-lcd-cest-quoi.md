Mettons tout de suite au clair les termes : LCD signifie "Liquid Crystal Display" et se traduit, en français, par "Écran à Cristaux Liquides" (mais on n'a pas d'acronymes classe en français donc on parlera toujours de LCD). Ces écrans sont PARTOUT ! Vous en trouverez dans plein d'appareils électroniques disposant d'afficheur : les montres, le tableau de bord de votre voiture, les calculatrices, etc. Cette utilisation intensive est due à leur faible consommation et coût. Mais ce n'est pas tout ! En effet, les écrans LCD sont aussi sous des formes plus complexes telles que la plupart des écrans d'ordinateur ainsi que les téléviseurs à écran plat. Cette technologie est bien maîtrisée et donc le coût de production est assez bas. Dans les années à venir, ils vont avoir tendance à être remplacés par les écrans à affichage LED qui sont pour le moment trop chers.

[[e]]
| J'en profite pour mettre l'alerte sur la différence des écrans à LED. Il en existe deux types :
| 
| - les écrans à rétro-éclairage LED : ce sont des écrans LCD tout à fait ordinaires qui ont simplement la particularité d'avoir un rétro-éclairage à LED à la place des tubes néon. Leur prix est du même ordre de grandeur que les LCD "normaux". En revanche, la qualité d'affichage des couleurs semble meilleure comparés aux LCD "normaux".
| - les écrans à affichage LED : ceux-ci ne disposent pas de rétro-éclairage et ne sont ni des écrans LCD, ni des écrans plasma. Ce sont des écrans qui, en lieu et place des pixels, se trouvent des LED de très très petite taille. Leur coût est prohibitif pour le moment, mais la qualité de contraste et de couleur inégale tous les écrans existants !

Les deux catégories précédentes (écran LCD d'une montre par exemple et celui d'un moniteur d'ordinateur) peuvent être différenciées assez rapidement par une caractéristique simple : *la couleur*. En effet, les premiers sont monochromes (une seule couleur) tandis que les seconds sont colorés (rouge, vert et bleu). Dans cette partie, nous utiliserons uniquement le premier type pour des raisons de simplicité et de coût.

## Fonctionnement de l'écran

N'étant pas un spécialiste de l'optique ni de l'électronique "bas-niveau" (jonction et tout le tralala) je ne vais pas vous faire un cours détaillé sur le "comment ca marche ?" mais plutôt aller à l'essentiel, vers le "pourquoi ça s'allume ?". Comme son nom l'indique, un écran LCD possède des cristaux liquides. Mais ce n'est pas tout ! En effet, pour fonctionner il faut plusieurs choses. Si vous regardez de très près votre écran (éteint pour ne pas vous bousiller les yeux) vous pouvez voir une grille de carré. Ces carrés sont appelés des pixels (de l'anglais "Picture Element", soit "Élément d'image" en français, encore une fois c'est moins classe). :P Chaque pixel est un cristal liquide. Lorsqu'aucun courant ne le traverse, ses molécules sont orientées dans un sens (admettons, 0°). En revanche lorsqu'un courant le traverse, ses molécules vont se tourner dans la même direction (90°). Voilà pour la base.

![Composition d'un écran LCD](/media/galleries/954/bf2bdec4-85a8-45a7-95ef-b368e773726e.png.960x960_q85.jpg)
Figure: Composition d'un écran LCD - (CC-BY, [ed g2s](http://commons.wikimedia.org/wiki/File:LCD_layers.svg))

[[q]]
| Mais pourquoi il y a de la lumière dans un cas et pas dans l'autre ?

Tout simplement parce que cette lumière est **polarisée**. Cela signifie que la lumière est orientée dans une direction (c'est un peu compliqué à démontrer, je vous demanderais donc de l'admettre). En effet, entre les cristaux liquides et la source lumineuse se trouve un filtre polariseur de lumière. Ce filtre va orienter la lumière dans une direction précise. Entre vos yeux et les cristaux se trouve un autre écran polariseur, qui est perpendiculaire au premier. Ainsi, il faut que les cristaux liquides soient dans la bonne direction pour que la lumière passe de bout en bout et revienne à vos yeux. Un schéma vaut souvent mieux qu'un long discours, je vous conseille donc de regarder celui sur la droite de l'explication pour mieux comprendre (source : Wikipédia). Enfin, vient le rétro-éclairage (fait avec des LED) qui vous permettra de lire l'écran même en pleine nuit (sinon il vous faudrait l'éclairer pour voir le contraste).

[[i]]
| Si vous voulez plus d'informations sur les écrans LCD, j'invite votre curiosité à se diriger vers ce lien [Wikipédia](http://fr.wikipedia.org/wiki/%C3%89cran_%C3%A0_cristaux_liquides) ou d'autres sources. :)

# Commande du LCD

Normalement, pour pouvoir afficher des caractères sur l'écran il nous faudrait activer individuellement chaque pixel de l'écran. Un caractère est représenté par un bloc de 7*5 pixels. Ce qui fait qu'un écran de 16 colonnes et 2 lignes représente un total de 16*2*7*5 = 1120 pixels ! :P Heureusement pour nous, des ingénieurs sont passés par là et nous ont simplifié la tâche.

## Le décodeur de caractères

Tout comme il existe un driver vidéo pour votre carte graphique d'ordinateur, il existe un driver "LCD" pour votre afficheur. Rassurez-vous, aucun composant ne s'ajoute à votre liste d'achats puisqu'il est intégré dans votre écran. Ce composant va servir à décoder un ensemble "simple" de bits pour afficher un caractère à une position précise ou exécuter des commandes comme déplacer le curseur par exemple. Ce composant est fabriqué principalement par *Hitachi* et se nomme le **HC44780**. Il sert de **décodeur de caractères**. Ainsi, plutôt que de devoir multiplier les signaux pour commander les pixels un à un, il nous suffira d'envoyer des octets de commandes pour lui dire "écris moi 'zeste' à partir de la colonne 3 sur la ligne 1". Ce composant possède 16 broches que je vais brièvement décrire :

->

N° | Nom | Rôle
---|-----|------
1 | VSS | Masse
2 | Vdd | +5V |
3 | V0 | Réglage du contraste
4 | RS | Sélection du registre (commande ou donnée)
5 | R/W | Lecture ou écriture
6 | E | Entrée de validation
7 à 14 | D0 à D7 | Bits de données
15 | A | Anode du rétroéclairage (+5V)
16 | K | Cathode du rétroéclairage (masse)

Table: Liste des broches du LCD et leur rôle

<-
[[i]]
| Normalement, pour tous les écrans LCD (non graphiques) ce brochage est le même. Donc pas d'inquiétude lors des branchements, il vous suffira de vous rendre sur cette page pour consulter le tableau. ;)

Par la suite, les broches utiles qu'il faudra relier à l'Arduino sont les broches 4, 5 (facultatives), 6 et les données (7 à 14 pouvant être réduite à 8 à 14) en n'oubliant pas l'alimentation et la broche de réglage du contraste. Ce composant possède tout le système de traitement pour afficher les caractères. Il contient dans sa mémoire le schéma d'allumage des pixels pour afficher chacun d'entre eux. Voici la table des caractères affichables :

![Une table ASCII](http://zestedesavoir.com/media/galleries/954/17681090-dea7-4201-a447-26120b83b486.png.960x960_q85.png)
Figure: Une table ASCII - (Domaine public - [LanoxxthShaddow](http://commons.wikimedia.org/wiki/File:ASCII-Table-wide.svg))