Comme expliqué précédemment, je vous propose de travailler avec un écran dont seulement quatre broches de données sont utilisées. Pour le bien de tous je vais présenter ici les deux montages, mais ne soyez pas surpris si dans les autres montages ou les vidéos vous voyez seulement un des deux. ;)

# Le branchement

L'afficheur LCD utilise 6 à 10 broches de données ((D0 à D7) ou (D4 à D7) + RS + E) et deux d'alimentations (+5V et masse). La plupart des écrans possèdent aussi une entrée analogique pour régler le contraste des caractères. Nous brancherons dessus un potentiomètre de 10 kOhms. Les 10 broches de données peuvent être placées sur n'importe quelles entrées/sorties numériques de l'Arduino. En effet, nous indiquerons ensuite à la librairie LiquidCrystal qui est branché où.

## Le montage à 8 broches de données

![Branchement du LCD avec  fils de données](/media/galleries/954/8e1e99f9-d2d5-4a42-956a-e0da476af763.png.960x960_q85.jpg)

![Branchement du LCD avec 8 fils de données - montage](/media/galleries/954/5f4ac7b5-1e16-42ae-8668-386e581bee08.png.960x960_q85.jpg)

## Le montage à 4 broches de données

![Branchement du LCD avec 4 fils de données](/media/galleries/954/148f7f0d-5ed7-4ba1-92c8-affb7ab579c7.png.960x960_q85.jpg)

![Branchement du LCD avec 4 fils de données - montage](/media/galleries/954/9bf76e8f-17d7-4cb7-a6bd-ebca7a6e4e8f.png.960x960_q85.jpg)

# Le démarrage de l'écran avec Arduino

Comme écrit plus tôt, nous allons utiliser la librairie "LiquidCrystal". Pour l'intégrer, c'est très simple, il suffit de cliquer sur le menu "Import Library" et d'aller chercher la bonne. Une ligne `#include "LiquidCrystal.h"` doit apparaitre en haut de la page de code (les prochaines fois vous pourrez aussi taper cette ligne à la main directement, ça aura le même effet). Ensuite, il ne nous reste plus qu'à dire à notre carte Arduino où est branché l'écran (sur quelles broches) et quelle est la taille de ce dernier (nombre de lignes et de colonnes). Nous allons donc commencer par déclarer un objet (c'est en fait une variable évoluée, plus de détails dans la prochaine partie) `lcd`, de type `LiquidCrystal` et qui sera global à notre projet. La déclaration de cette variable possède plusieurs formes [(lien vers la doc.)](http://arduino.cc/en/Reference/LiquidCrystalConstructor) :

+ `LiquidCrystal(rs, enable, d0, d1, d2, d3, d4, d5, d6, d7)` où rs est le numéro de la broche où est branché "RS", "enable" est la broche "E" et ainsi de suite pour les données.
+ `LiquidCrystal(rs, enable, d4, d5, d6, d7)` (même commentaire que précédemment)

Ensuite, dans le `setup()` il nous faut démarrer l'écran en spécifiant son nombre de **colonnes** puis de **lignes**. Cela se fait grâce à la fonction `begin(cols,rows)`. Voici un exemple complet de code correspondant aux deux branchements précédents (commentez la ligne qui ne vous concerne pas) :

```cpp
#include "LiquidCrystal.h" // ajout de la librairie

// Vérifiez les broches !
LiquidCrystal lcd(11,10,9,8,7,6,5,4,3,2); // liaison 8 bits de données
LiquidCrystal lcd(11,10,5,4,3,2); // liaison 4 bits de données

void setup()
{
   lcd.begin(16,2); // utilisation d'un écran 16 colonnes et 2 lignes
   lcd.write("Salut ca zeste ?"); // petit test pour vérifier que tout marche
}

void loop() {}
```
Code: Setup minimal pour un écran LCD

[[e]]
| Surtout ne mettez **pas d'accents** ! L'afficheur ne les accepte pas par défaut et affichera du grand n'importe quoi à la place.

Vous remarquez que j'ai rajouté une ligne dont je n'ai pas parlé encore. Je l'ai juste mise pour vérifier que tout fonctionne bien avec votre écran, nous reviendrons dessus plus tard. Si tout se passe bien, vous devriez obtenir l'écran suivant :

->![Notre premier texte !](/media/galleries/954/bbf325b8-46f9-4af2-bbe8-7a7c4b8b1df5.jpg.960x960_q85.jpg)<-

[[a]]
| Si jamais rien ne s'affiche, essayez de tourner votre potentiomètre de contraste. Si cela ne marche toujours pas, vérifier les bonnes attributions des broches (surtout si vous utilisez un shield).