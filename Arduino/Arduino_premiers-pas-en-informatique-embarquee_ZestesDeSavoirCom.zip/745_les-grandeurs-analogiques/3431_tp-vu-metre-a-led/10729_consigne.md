## Vu-mètre, ça vous parle ?
Dans ce TP, nous allons réaliser un **vu-mètre**. Même si le nom ne vous dit rien, je suis sur que vous en avez déjà rencontré. Par exemple, sur une chaîne hi-fi ou sur une table de mixage on voit souvent des loupiotes s'allumer en fonction du volume de la note joué. Et bien c'est ça un vu-mètre, c'est un système d'affichage sur plusieurs LED, disposées en ligne, qui permettent d'avoir un retour visuel sur une information analogique (dans l'exemple, ce sera le volume).

## Objectif

Pour l'exercice, nous allons réaliser la visualisation d'une tension. Cette dernière sera donnée par un potentiomètre et sera affichée sur 10 LED. Lorsque le potentiomètre sera à 0V, on allumera 0 LED, puis lorsqu'il sera au maximum on les allumera toutes. Pour les valeurs comprises entre 0 et 5V, elles devront allumer les LED proportionnellement. Voilà, ce n'est pas plus compliqué que ça. Comme d'habitude voici une petite vidéo vous montrant le résultat attendu et bien entendu ...

-> **BON COURAGE !** <-

->!(https://www.youtube.com/watch?v=UkmQEM_5ZIE)<-