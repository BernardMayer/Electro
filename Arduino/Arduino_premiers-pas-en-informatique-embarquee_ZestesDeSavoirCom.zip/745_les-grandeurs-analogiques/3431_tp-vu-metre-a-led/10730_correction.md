J’espère que tout c'est bien passé pour vous et que l'affichage cartonne ! Voici maintenant venu l'heure de la correction, en espérant que vous n'en aurez pas besoin et que vous la consulterez juste pour votre culture. ;) Comme d'habitude nous allons commencer par voir le schéma puis ensuite nous étudierons le code.

# Schéma électronique

Le schéma n'est pas très difficile. Nous allons retrouver 10 LEDs et leurs résistances de limitations de courant branchées sur 10 broches de l'Arduino (histoire d'être original nous utiliserons 2 à 11). Ensuite, nous brancherons un potentiomètre entre le +5V et la masse. Sa broche centrale, qui donne la tension variable sera connectée à l'entrée analogique 0 de l'Arduino. Voici le schéma obtenu :

[[s]]
| -> ![Vumètre - Schéma](/media/galleries/954/61060034-98e1-4fa7-8ec4-898f64f0e50f.png.960x960_q85.png)
|
| ![Vumètre - Montage](/media/galleries/954/d1c98f35-8b3a-4f9b-98a1-ff4a045ff476.png.960x960_q85.png)
| <-

# Le code

Là encore vous commencez à avoir l'habitude, nous allons d'abord étudier le code des variables globales (pourquoi elles existent ?), voir la fonction setup(), puis enfin étudier la boucle principale et les fonctions annexes utilisées.

## Variables globales et setup

Dans ce TP nous utilisons 10 LEDs, ce qui représente autant de sorties sur la carte Arduino donc autant de "const int ..." à écrire. Afin de ne pas se fatiguer de trop, nous allons déclarer un tableau de "const int" plutôt que de copier/coller 10 fois la même ligne. Ensuite, nous allons déclarer la broche analogique sur laquelle sera branché le potentiomètre. Enfin, nous déclarons une variable pour stocker la tension mesurée sur le potentiomètre. Et c'est tout pour les déclarations !

```cpp
// Déclaration et remplissage du tableau...
// ...représentant les broches des LEDs
const int leds[10] = {2,3,4,5,6,7,8,9,10,11};
// le potentiomètre sera branché sur la broche analogique 0
const int potar = 0;
// variable stockant la tension mesurée
int tension = 0;
```
Code: TP Vumètre, les variables

Une fois que l'on à fait ces déclarations, il ne nous reste plus qu'à déclarer les broches en sortie et à les mettre à l'état HAUT pour éteindre les LEDs. Pour faire cela de manière simple (au lieu de 10 copier/coller), nous allons utiliser une boucle for pour effectuer l'opérations 10 fois (afin d'utiliser la puissance du tableau).

```cpp
void setup()
{
    int i = 0;
    for(i = 0; i < 10; i++)
    {
        // déclaration de la broche en sortie
        pinMode(leds[i], OUTPUT);
        // mise à l'état haut
        digitalWrite(leds[i], HIGH);
    }
}
```
Code: TP Vumètre, le `setup`

## Boucle principale

Alors là vous allez peut-être être surpris mais nous allons avoir une fonction principale super light. En effet, elle ne va effectuer que deux opérations : Mesurer la tension du potentiomètre, puis appeler une fonction d'affichage pour faire le rendu visuel de cette tension. Voici ces deux lignes de code :

```cpp
void loop()
{
    // on récupère la valeur de la tension du potentiomètre
    tension = analogRead(potar);
    // et on affiche sur les LEDs cette tension
    afficher(tension);
}
```
Code: TP Vumètre, la `loop`

Encore plus fort, la même écriture mais en une seule ligne !

```cpp
void loop()
{
    // la même chose qu'avant même en une seule ligne !
    afficher(analogRead(potar));
}
```

## Fonction d'affichage

Alors certes la fonction principale est très légère, mais ce n'est pas une raison pour ne pas avoir un peu de code autre part. En effet, le gros du traitement va se faire dans la fonction d'affichage, qui, comme son nom et ses arguments l'indiquent, va servir à afficher sur les LEDs la tension mesurée. Le but de cette dernière sera d'allumer les LEDs de manière proportionnelle à la tension mesuré. Par exemple, si la tension mesuré vaut 2,5V (sur 5V max) on allumera 5 LEDs (sur 10). Si la tension vaut 5V, on les allumera toutes. Je vais maintenant vous montrer une astuce toute simple qui va tirer pleinement parti du tableau de broches créé tout au début. Tout d'abord, mettons-nous d'accord. Lorsque l'on fait une mesure analogique, la valeur retournée est comprise entre 0 et 1023. Ce que je vous propose, c'est donc d'allumer une LED par tranche de 100 unités. Par exemple, si la valeur est comprise entre 0 et 100, une seule LED est allumée. Ensuite, entre 100 et 200, on allume une LED supplémentaire, etc. Pour une valeur entre 700 et 800 on allumera donc... 8 LEDs, bravo à ceux qui suivent ! :s Ce comportement va donc s'écrire simplement avec une boucle for, qui va incrémenter une variable i de 0 à 10. Dans cette boucle, nous allons tester si la valeur (image de la tension) est inférieure à i multiplier par 100 (ce qui représentera nos différents pas). Si le test vaut VRAI, on allume la LED i, sinon on l'éteint. Démonstration :

```cpp
void afficher(int valeur)
{
    int i;
    for(i=0; i < 10; i++)
    {
        if(valeur < (i*100))
            digitalWrite(leds[i], LOW); // on allume la LED
        else
            digitalWrite(leds[i], HIGH); // ou on éteint la LED
    }
}
```
Code: TP Vumètre, fonction d'affichage