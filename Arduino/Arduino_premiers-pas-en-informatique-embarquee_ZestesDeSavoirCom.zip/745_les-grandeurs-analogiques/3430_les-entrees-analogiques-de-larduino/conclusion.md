Au programme :

* Le prochain chapitre est un TP faisant usage de ces voies analogiques
* Le chapitre qui le suit est un chapitre qui vous permettra de créer des tensions analogiques avec votre carte Arduino, idéal pour mettre en œuvre la deuxième solution d'amélioration de la précision de lecteur du convertisseur !

En somme, ce chapitre vous a permis de vous familiariser un peu avec les tensions analogiques, ce qui vous permettra par la suite de gérer plus facilement les grandeurs renvoyées par des capteurs quelconques.