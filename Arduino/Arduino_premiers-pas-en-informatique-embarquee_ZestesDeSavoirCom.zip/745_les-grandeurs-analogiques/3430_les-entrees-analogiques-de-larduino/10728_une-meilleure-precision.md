[[q]]
| Est-il possible d'améliorer la précision du convertisseur ?

Voilà une question intéressante à laquelle je répondrai qu'il existe deux solutions plus ou moins faciles à mettre en œuvre.

# Solution 1 : modifier la plage d'entrée du convertisseur

 C'est la solution la plus simple ! Voyons deux choses...

## Tension de référence interne

 Le micro-contrôleur de l'Arduino possède plusieurs tensions de référence utilisables selon la plage de variation de la tension que l'on veut mesurer. Prenons une tension, en sortie d'un capteur, qui variera entre 0V et 1V et jamais au delà. Par défaut, la mesure se fera entre 0 et 5V sur 1024 niveaux (soit une précision de 4.88 mV). Ce qui veut dire qu'on aura seulement les 204 premiers niveaux d'utiles puisque tout le reste correspondra à plus d'un volt. Pour améliorer la précision de lecture, on va réduire la plage de mesure d'entrée du convertisseur analogique - > numérique en réduisant la tension de référence utilisée (initialement 5V). Pour cela, rien de matériel, tout se passe au niveau du programme puisqu'il y a une fonction qui existe : [`analogReference()`](http://arduino.cc/en/Reference/AnalogReference). Cette fonction prend en paramètre le nom de la référence à utiliser :

+ DEFAULT : La référence de 5V par défaut (ou 3,3V pour les cartes Arduino fonctionnant sous cette tension, telle la Due)
+ INTERNAL : Une référence interne de 1.1V (pour la Arduino Uno)
+ INTERNAL1V1 : Comme ci-dessus mais pour la Arduino Mega
+ INTERNAL2V56 : Une référence de 2.56V (uniquement pour la Mega)
+ EXTERNAL : La référence sera celle appliquée sur la broche ARef

Dans notre cas, le plus intéressant sera de prendre la valeur INTERNAL pour pouvoir faire des mesures entre 0 et 1.1V. Ainsi, on aura 1024 niveaux ce qui nous fera une précision de 1.07mV. C'est bien meilleur ! Le code est à placer dans la fonction setup() de votre programme :

```cpp
void setup()
{
    // permet de choisir une tension de référence de 1.1V
    analogReference(INTERNAL);
}
```
Code: Changement de la référence : INTERNAL

## Tension de référence externe

 Maintenant que se passe t'il si notre mesure devait être faite entre 0 et 3V ? On ne pourrait plus utiliser INTERNA1V1 puisqu'on dépasse les 1.1V. On risquerais alors de griller le comparateur. Dans le cas d'une Arduino Mega, on ne peut pas non plus utiliser INTERNAL2V56 puisqu'on dépasse les 2.56V. Nous allons donc ruser en prenant une référence externe à l'aide de la valeur EXTERNAL comme ceci :

```cpp
void setup()
{
    // permet de choisir une tension de référence externe à la carte
    analogReference(EXTERNAL);
}
```
Code: Changement de la référence : EXTERNAL

Ensuite, il ne restera plus qu'à apporter une tension de référence supérieur à 3V sur la broche ARef de la carte pour obtenir notre nouvelle référence.

[[i]]
| Astuce : la carte Arduino produit une tension de 3.3V (à côté de la tension 5V). Vous pouvez donc utiliser cette tension directement pour la tension de référence du convertisseur. ;) Il suffit pour cela de relier avec un fil la sortie indiquée 3.3V à l'entrée AREF.

[[e]]
| Attention cependant, la tension maximale de référence **ne peut être supérieure à +5V** et **la minimale inférieure à 0V**. En revanche, toutes les tensions comprises entre ces deux valeurs sont acceptables.

[[q]]
| Mais, si je veux que ma tension d'entrée puisse varier au-delà de +5V, comment je fais ? Y a-t-il un moyen d'y parvenir ? o_O

Oui, voyez ce qui suit...

![Schéma du pont diviseur de tension](/media/galleries/954/ffb2c42f-05fb-46ed-ad9b-ed57268da5ec.png.960x960_q85.png)

# Solution 2 : utiliser un pont diviseur de tension

 Nous avons vu cela à la partie précédente avec le potentiomètre. Il s'agit en fait de diviser votre signal par un certain ratio afin de l'adapter aux contraintes d'entrées du convertisseur. Par exemple, imaginons que nous ayons une mesure à faire sur un appareil qui délivre une tension comprise entre 0 et 10V. Cela ne nous arrange pas puisque nous ne sommes capable de lire des valeurs qu'entre 0 et 5V. Nous allons donc diviser cette mesure par deux afin de pouvoir la lire sans risque. Pour cela, on utilisera deux résistances de valeur identique (2 fois $10 k\Omega$ par exemple) pour faire un pont diviseur de tension. La tension à mesurer rentre dans le pont ( $U$ sur le schéma ci-contre) et la tension mesurable sort au milieu du pont (tension $U_s$ ). Il ne reste plus qu'à connecter la sortie du pont à une entrée analogique de la carte Arduino et lire la valeur de la tension de sortie.

[[i]]
| Libre à vous de modifier les valeurs des résistances du pont diviseur de tension pour faire rentrer des tensions différentes (même au delà de 10V !). Attention cependant à ne pas dépasser les +5V en sortie du pont !

# Solution 3 : utiliser un CAN externe

 La deuxième solution consisterait simplement en l'utilisation d'un convertisseur analogique -> numérique externe. A vous de choisir le bon. Il en existe beaucoup, ce qu'il faut principalement regarder c'est :

+ la **précision** (10 bits pour Arduino, existe d'autre en 12bits, 16bits, ...)
+ la **vitesse d'acquisition** (celui d'Arduino est à une vitesse de 100µs)
+ le **mode de transfert** de la lecture (liaison série, I²C, ...)
+ le **nombre d'entrées** (6 sur Arduino Uno)
+ la **tension d'entrée** maximale et minimale (max +5V et min 0V)

# Solution 4 : Modifier la fréquence de fonctionnement de l'ADC

Cette solution et ses limites sont illustrées dans [ce billet de Titi_Alone](https://zestedesavoir.com/billets/2068/arduino-accelerer-analogread/). C'est une manipulation un peu plus avancée qui fera appel à la manipulation de registres internes au microcontrôleur de l'Arduino. Les paramètres de base devraient cependant convenir à la majorité de vos applications.