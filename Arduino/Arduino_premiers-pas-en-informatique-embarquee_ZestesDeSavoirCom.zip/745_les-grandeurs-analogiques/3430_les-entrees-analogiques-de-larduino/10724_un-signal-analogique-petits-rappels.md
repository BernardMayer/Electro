Faisons un petit rappel sur ce que sont les signaux analogiques. D'abord, jusqu'à présent nous n'avons fait qu'utiliser des grandeurs numériques binaires. Autrement dit, nous n'avons utilisé que des états logiques HAUT et BAS. Ces deux niveaux correspondent respectivement aux tensions de 5V et 0V. Cependant, une valeur analogique ne se contentera pas d'être exprimée par 0 ou 1. Elle peut prendre *une infinité de valeurs* dans un intervalle donné. Dans notre cas, par exemple, la grandeur analogique pourra varier aisément de 0 à 5V en passant par 1.45V, 2V, 4.99V, etc. Voici un exemple de signal analogique, le très connu signal sinusoïdal :

![Un signal analogique périodique](/media/galleries/954/76f244be-94a5-4e6e-b1e8-a1ffe7a47421.png.960x960_q85.jpg)

[[information]]
| On retiendra que l'on ne s'occupe que de la tension et non du courant, en fonction du temps.

Si on essaye de mettre ce signal (ce que je vous déconseille de faire) sur une entrée numérique de l'Arduino et qu'on lit les valeurs avec digitalRead(), on ne lira que 0 ou 1. Les broches numériques de l'Arduino étant incapable de lire les valeurs d'un signal analogique.

## Signal périodique

Dans la catégorie des signaux analogiques et même numériques (dans le cas d'horloge de signal pour le cadencement des micro-contrôleurs par exemple) on a les **signaux dits périodiques**. La période d'un signal est en fait un motif de ce signal qui se répète et qui donne ainsi la forme du signal. Prenons l'exemple d'un signal binaire qui prend un niveau logique 1 puis un 0, puis un 1, puis un 0, ...

![Représentation d'une période](/media/galleries/954/9aa1e5f4-780f-4330-a365-b10a3c819c3b.png.960x960_q85.png)

La période de ce signal est le motif qui se répète tant que le signal existe. Ici, c'est le niveau logique 1 et 0 qui forme le motif. Mais cela aurait pu être 1 1 et 0, ou bien 0 1 1, voir 0 0 0 1 1 1, les possibilités sont infinies ! Pour un signal analogique, il en va de même. Reprenons le signal de tout à l'heure :

![Période d'un signal analogique](/media/galleries/954/2e8195b9-b78f-4ed6-9016-e43f21db0a33.png.960x960_q85.jpg)

Ici le motif qui se répète est "la bosse de chameau" ou plus scientifiquement parlant : une période d'un signal sinusoïdal. ^^ Pour terminer, la période désigne aussi le temps que met un motif à se répéter. Si j'ai une période de 1ms, cela veut dire que le motif met 1ms pour se dessiner complètement avant de commencer le suivant. Et en sachant le nombre de fois que se répète le motif en 1 seconde, on peut calculer la fréquence du signal selon la formule suivante : $F = \frac 1 T$ ; avec F la fréquence, en hertz, du signal et T la période, en seconde, du signal.

## Notre objectif

L'objectif va donc être double. Tout d'abord, nous allons devoir être capables de convertir cette valeur analogique en une valeur numérique, que l'on pourra ensuite manipuler à l'intérieur de notre programme. Par exemple, lorsque l'on mesurera une tension de 2,5V nous aurons dans notre programme une variable nommée "tension" qui prendra la valeur 250 lorsque l'on fera la conversion (ce n'est qu'un exemple). Ensuite, nous verrons avec Arduino ce que l'on peut faire avec les signaux analogiques. Je ne vous en dis pas plus...