# Lire la tension sur une broche analogique

 Un truc très sympa avec Arduino, c'est que c'est facile à prendre en main. Et ça se voit une fois de plus avec l'utilisation des convertisseurs numérique -> analogique ! En effet, vous n'avez qu'une seule nouvelle fonction à retenir : `analogRead()` !

## `analogRead(pin)`

 Cette fonction va nous permettre de lire la valeur lue sur une entrée analogique de l'Arduino. Elle prend un argument et retourne la valeur lue :

+ L'argument est le numéro de l'entrée analogique à lire (explication ci-dessous)
+ La valeur retournée (un `int`) sera le résultat de la conversion analogique- >numérique

Sur une carte Arduino Uno, on retrouve 6 CAN. Ils se trouvent tous du même côté de la carte, là où est écrit "Analog IN" :

![Positions des entrées analogiques](/media/galleries/954/2e7b1fd3-441c-48f5-8f49-9d1aae220bb1.png.960x960_q85.jpg)

Ces 6 entrées analogiques sont numérotées, tout comme les entrées/sorties logiques. Par exemple, pour aller lire la valeur en sortie d'un capteur branché sur le convertisseur de la broche analogique numéro 3, on fera : `valeur = analogRead(3);`.

[[e]]
| Ne confondez pas les entrées analogiques et les entrées numériques ! Elles ont en effet le même numéro pour certaines, mais selon comment on les utilise, la carte Arduino saura si la broche est analogique ou non.

Mais comme nous sommes des programmeurs intelligents et organisés, on nommera les variables proprement pour bien travailler de la manière suivante :

```cpp
// broche analogique 3 OU broche numérique 3
const int monCapteur = 3;

// la valeur lue sera comprise entre 0 et 1023
int valeurLue = 0;

// fonction setup()
{

}

void loop()
{
    // on mesure la tension du capteur sur la broche analogique 3
    valeurLue = analogRead(monCapteur);

    // du code et encore du code ...
}
```
Code: Mesure simple d'une entrée analogique

# Convertir la valeur lue

 Bon c'est bien, on a une valeur retournée par la fonction comprise entre 0 et 1023, mais ça ne nous donne pas vraiment une tension ça ! Il va être temps de faire un peu de code (et de math) pour **convertir** cette valeur... Et si vous réfléchissiez un tout petit peu pour trouver la solution sans moi ? ^^ ... Trouvée ?

## Conversion

 Comme je suis super sympa je vais vous donner la réponse, avec en prime : une explication ! Récapitulons. Nous avons une valeur entre 0 et 1023. Cette valeur est l'image de la tension mesurée, elle-même comprise entre 0V et +5V. Nous avons ensuite déterminé que le pas du convertisseur était de 4.88mV par unité. Donc, deux méthodes sont disponibles :

+ avec un simple produit en croix
+ en utilisant le pas calculé plus tôt

**Exemple :** La mesure nous retourne une valeur de 458.

+ Avec un produit en croix on obtient : $\frac{458 \times 5}{1023} = 2.235V$ ;
+ En utilisant le pas calculé plus haut on obtient : $458 \times 4.88 = 2.235V$ .

[[a]]
| Les deux méthodes sont valides, et donnent les mêmes résultats. La première à l'avantage de faire ressortir l'aspect "physique" des choses en utilisant les tensions et la résolution du convertisseur.

Voici une façon de le traduire en code :

```cpp
// variable stockant la valeur lue sur le CAN
int valeurLue;
// résultat stockant la conversion de valeurLue en Volts
float tension;

void loop()
{
    valeurLue = analogRead(uneBrocheAvecUnCapteur);
    // produit en croix, ATTENTION, donne un résultat en mV !
    tension = valeurLue * 4.88;
    // formule à aspect "physique", donne un résultat en V !
    tension = valeurLue * (5 / 1023);
}
```
Code: Conversion d'une mesure en tension

[[q]]
| Mais il n'existe pas une méthode plus "automatique" que faire ce produit en croix ?

Eh bien SI ! En effet, l'équipe Arduino a prévu que vous aimeriez faire des conversions facilement et donc une fonction est présente dans l'environnement Arduino afin de vous faciliter la tâche ! Cette fonction se nomme `map()`. À partir d'une valeur d'entrée, d'un intervalle d'entrée et d'un intervalle de sortie, la fonction vous retourne la valeur équivalente comprise entre le deuxième intervalle. Voici son prototype de manière plus explicite :

```cpp
sortie = map(valeur_d_entree,
    valeur_extreme_basse_d_entree,
    valeur_extreme_haute_d_entree,
    valeur_extreme_basse_de_sortie,
    valeur_extreme_haute_de_sortie
);
// cette fonction retourne la valeur calculée équivalente
// entre les deux intervalles de sortie
```
Code: La fonction `map`

Prenons notre exemple précédent. La valeur lue se nomme "valeurLue". L'intervalle d'entrée est la gamme de la conversion allant de 0 à 1023. La gamme (ou intervalle) de "sortie" sera la tension réelle à l'entrée du micro-contrôleur, donc entre 0 et 5V. En utilisant cette fonction nous écrirons donc :

```cpp
// conversion de la valeur lue en tension en mV
tension = map(valeurLue, 0, 1023, 0, 5000);
```
Code: Utilisation de la fonction `map`

[[q]]
| Pourquoi tu utilises 5000mV au lieu de mettre simplement 5V ?

Pour la simple et bonne raison que la fonction `map` utilise des entiers. Si j'utilisais 5V au lieu de 5000mV j'aurais donc seulement 6 valeurs possibles pour ma tension (0, 1, 2, 3, 4 et 5V). Pour terminer le calcul, il sera donc judicieux de rajouter une dernière ligne :

```cpp
// conversion de la valeur lue en tension en mV
tension = map(valeurLue, 0, 1023, 0, 5000);
// conversion des mV en V
tension = tension / 1000;
```

Au retour de la liaison série (seulement si on envoie les valeurs par la liaison série) on aurait donc (valeurs à titre d'exemple) :

```
valeurLue = 458
tension = 2.290V
```

[[a]]
| On est moins précis que la tension calculée plus haut, mais on peut jouer en précision en modifiant les valeurs de sortie de la fonction map(). Ou bien garder le calcul théorique et le placer dans une "fonction maison".