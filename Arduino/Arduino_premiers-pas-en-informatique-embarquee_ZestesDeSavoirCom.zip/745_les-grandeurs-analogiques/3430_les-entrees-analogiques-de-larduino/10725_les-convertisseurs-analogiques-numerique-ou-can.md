[[question]]
| Qu'est-ce que c'est ?

C'est un dispositif qui va convertir des grandeurs analogiques en grandeurs numériques. La valeur numérique obtenue sera proportionnelle à la valeur analogique fournie en entrée, bien évidemment. Il existe différentes façons de convertir une grandeur analogique, plus ou moins faciles à mettre en œuvre, plus ou moins précises et plus ou moins onéreuses. Pour simplifier, je ne parlerai que des tensions analogiques dans ce chapitre.

## La diversité

Je vais vous citer quelques types de convertisseurs, sachez cependant que nous n'en étudierons qu'un seul type.

* **Convertisseur à simple rampe** : ce convertisseur "fabrique" une tension qui varie proportionnellement en un cours laps de temps entre deux valeurs extrêmes. En même temps qu'il produit cette tension, il compte. Lorsque la tension d'entrée du convertisseur devient égale à la tension générée par ce dernier, alors le convertisseur arrête de compter. Et pour terminer, avec la valeur du compteur, il détermine la valeur de la grandeur d'entrée. Malgré sa bonne précision, sa conversion reste assez lente et dépend de la grandeur à mesurer. Il est, de ce fait, peu utilisé.
* **Convertisseur flash** : ce type de convertisseur génère lui aussi des tensions analogiques. Pour être précis, il en génère plusieurs, chacune ayant une valeur plus grande que la précédente (par exemple 2V, 2.1V, 2.2V, 2.3V, etc.) et compare la grandeur d'entrée à chacun de ces paliers de tension. Ainsi, il sait entre quelle et quelle valeur se trouve la tension mesurée. Ce n'est pas très précis comme mesure, mais il a l'avantage d'être rapide et malheureusement cher.
* **Convertisseur à approximations successives** : Pour terminer, c'est ce convertisseur que nous allons étudier...

# Arduino dispose d'un CAN

Vous vous doutez bien que si je vous parle des CAN, c'est qu'il y a une raison. Votre carte Arduino dispose d'un tel dispositif intégré dans son cœur : le micro-contrôleur. Ce convertisseur est un convertisseur "à approximations successives". Je vais détailler un peu plus le fonctionnement de ce convertisseur par rapport aux autres dont je n'ai fait qu'un bref aperçu de leur fonctionnement (bien que suffisant).

[[information]]
| Ceci rentre dans le cadre de votre culture générale électronique, ce n'est pas nécessaire de lire comment fonctionne ce type de convertisseur. Mais je vous recommande vivement de le faire, car il est toujours plus agréable de comprendre comment fonctionnent les outils qu'on utilise ! :)

## Principe de dichotomie

La dichotomie, ça vous parle ? Peut-être que le nom ne vous dit rien, mais il est sûr que vous en connaissez le fonctionnement. Peut-être alors connaissez-vous [le jeu "plus ou moins](http://fr.openclassrooms.com/informatique/cours/apprenez-a-programmer-en-c/tp-plus-ou-moins-votre-premier-jeu#ss_part_1) en programmation ? Si oui alors vous allez pouvoir comprendre ce que je vais expliquer, sinon lisez le principe sur le lien que je viens de vous donner, cela vous aidera un peu. La dichotomie est donc une méthode de recherche conditionnelle qui s'applique lorsque l'on recherche une valeur comprise entre un minimum et un maximum. L'exemple du jeu "plus ou moins" est parfait pour vous expliquer le fonctionnement. Prenons deux joueurs. Le joueur 1 choisit un nombre compris entre deux valeurs extrêmes, par exemple 0 et 100. Le joueur 2 ne connait pas ce nombre et doit le trouver. La méthode la plus rapide pour que le joueur 2 puisse trouver quel est le nombre choisi par le joueur 1 est :

```
Joueur 1 dit : "quel est le nombre mystère ?"
> 40

Joueur 1 dit : "Ce nombre est plus grand"
> 80

Joueur 1 dit : "Ce nombre est plus petit"
> 60

Joueur 1 dit : "Ce nombre est plus grand"
> 70

Joueur 1 dit : "Ce nombre est plus grand"
> 75

Joueur 1 dit : "Ce nombre est plus petit"
> 72

Bravo, Joueur 2 a trouvé le nombre mystère !
```

Je le disais, le joueur 2, pour arriver le plus rapidement au résultat, doit choisir une méthode rapide. Cette méthode, vous l'aurez deviné, consiste à couper en deux l'espace de recherche. Au début, cet espace allait de 0 à 100, puis au deuxième essai de 40 à 100, au troisième essai de 40 à 80, etc.

[[attention]]
| Cet exemple n'est qu'à titre indicatif pour bien comprendre le concept.

En conclusion, cette méthode est vraiment simple, efficace et rapide ! Peut-être l'aurez-vous observé, on est pas obligé de couper l'espace de recherche en deux parties égales.

# Le CAN à approximations successives

On y vient, je vais pouvoir vous expliquer comment il fonctionne. Voyez-vous le rapport avec le jeu précédent ? Pas encore ? Alors je m'explique. Prenons du concret avec une valeur de tension de 3.36V que l'on met à l'entrée d'un CAN à approximations successives (j'abrégerai par CAN dorénavant).

![Le CAN à approximations successives](/media/galleries/954/a1527f7e-7433-407e-be48-4226020687c8.png.960x960_q85.jpg)

[[information]]
| Notez le symbole du CAN qui se trouve juste au-dessus de l'image. Il s'agit d'un "U" renversé et du caractère #.

Cette tension analogique de 3.36V va rentrer dans le CAN et va ressortir sous forme numérique (avec des 0 et 1). Mais que se passe-t-il à l'intérieur pour arriver à un tel résultat ? Pour que vous puissiez comprendre correctement comment fonctionne ce type de CAN, je vais être obligé de vous apprendre plusieurs choses avant.

## Le comparateur

Commençons par le **comparateur**. Comme son nom le laisse deviner, c'est quelque chose qui compare. Ce quelque chose est un composant électronique. Je ne rentrerai absolument pas dans le détail, je vais simplement vous montrer comment il fonctionne.

[[question]]
| Comparer, oui, mais quoi ?

Des tensions ! :D Regardez son symbole, je vous explique ensuite...

![Le comparateur](/media/galleries/954/f6814640-3ac6-4091-9527-de4f850f0b3b.png.960x960_q85.jpg)

Vous observez qu'il dispose de deux entrées $E_1$ et $E_2$ et d'une sortie $S$. Le principe est simple :

* Lorsque la tension $E_1  \gt E_2$ alors $S = +V_{cc}$ ($+V_{cc}$ étant la tension d'alimentation positive du comparateur)
* Lorsque la tension $E_1  \lt E_2$ alors $S = -V_{cc}$ ($-V_{cc}$ étant la tension d'alimentation négative, ou la masse, du comparateur)
* $E_1 = E_2$ est une condition quasiment impossible, si tel est le cas (si on relie $E_1$ et $E_2$) le comparateur donnera un résultat faux

Parlons un peu de la tension d'alimentation du comparateur. Le meilleur des cas est de l'alimenter entre 0V et +5V. Comme cela, sa sortie sera soit égale à 0V, soit égale à +5V. Ainsi, on rentre dans le domaine des tensions acceptées par les micro-contrôleurs et de plus il verra soit un état logique BAS, soit un état logique HAUT. On peut réécrire les conditions précédemment énoncées comme ceci :

* $E_1  \gt E_2$ alors $S = 1$
* $E_1  \lt E_2$ alors $S = 0$
* $E_1 = E_2$, alors $S = indefini$

Simple n'est-ce pas ?

## Le démultiplexeur

Maintenant, je vais vous parler du **démultiplexeur**. C'est en fait un nom un peu barbare pour désigner un composant électronique qui fait de *l'aiguillage de niveaux logiques* (il en existe aussi qui font de l'aiguillage de tensions analogiques). Le principe est là encore très simple. Le démultiplexeur à plusieurs sorties, une entrée et des entrées de sélection :

![Le démultiplexeur](/media/galleries/954/7cf22c0a-2b88-48ef-b270-8722604d165e.png.960x960_q85.jpg)

* $E$ est l'entrée où l'on impose un niveau logique 0 ou 1.
* Les sorties $S$ sont là où se retrouve le niveau logique d'entrée. UNE seule sortie peut être active à la fois et recopier le niveau logique d'entrée.
* Les entrées $A$ permettent de sélectionner quelle sera la sortie qui est active. La sélection se fait grâce aux combinaisons binaires. Par exemple, si je veux sélectionner la sortie 4, je vais écrire le code 0100 (qui correspond au chiffre décimal 4) sur les entrées $A_1$ à $A_4$

![Le démultiplexeur en action](/media/galleries/954/c21f0421-7a4f-4c7b-b0de-8f2264326226.png.960x960_q85.jpg)

[[attention]]
| Je rappelle que, pour les entrées de sélection, le bit de poids fort est $A_4$ et le bit de poids faible $A_1$. Idem pour les sorties, $S_1$ est le bit de poids faible et $S_{10}$, le bit de poids fort.

## La mémoire

Ce composant électronique sert simplement à stocker des données sous forme binaire.

## Le convertisseur numérique analogique

Pour ce dernier composant avant l'acte final, il n'y a rien à savoir si ce n'est que c'est l'opposé du CAN. Il a donc plusieurs entrées et une seule sortie. Les entrées reçoivent des valeurs binaires et la sortie donne le résultat sous forme de tension.

## Fonctionnement global

Rentrons dans les explications du fonctionnement d'un CAN à approximations successives. Je vous ai fait un petit schéma rassemblant les éléments précédemment présentés :

![Chaîne de fonctionnement du CAN](/media/galleries/954/86a6310f-191b-451f-bcba-d94822c4811f.png.960x960_q85.jpg)

Voilà donc comment se compose le CAN. Si vous avez compris le fonctionnement de chacun des composants qui le constituent, alors vous n'aurez pas trop de mal à suivre mes explications. Dans le cas contraire, je vous recommande de relire ce qui précède et de bien comprendre et rechercher sur internet de plus amples informations si cela vous est nécessaire.

![Chaîne de fonctionnement du CAN en action](/media/galleries/954/8b1aa04e-aa72-4f62-ad24-a540e79b2ca3.png.960x960_q85.jpg)

En premier lieu, commençons par les conditions initiales :

* $V_e$ est la tension analogique d'entrée, celle que l'on veut mesurer en la convertissant en signal numérique.
* **La mémoire** contient pour l'instant que des **0** sauf pour le bit de poids fort ($S_{10}$) qui est à **1**. Ainsi, le convertisseur numérique $\to$ analogique va convertir ce nombre binaire en une tension analogique qui aura pour valeur 2.5V.
* Pour l'instant, le démultiplexeur n'entre pas en jeu.

Suivons le fonctionnement étape par étape :

**Étape 1 :**

![Chaîne de fonctionnement du CAN - Exemple - Etape 1](/media/galleries/954/7d8925c7-649f-41a4-b26a-89ec403dfe05.png.960x960_q85.jpg)

* J'applique une tension $V_e = 3.5100V$ précisément.
* Le comparateur compare la tension $V_{comp} = 2.5V$ à la tension $V_e = 3.5100V$. Étant donné que $V_e  \gt V_{comp}$, on a un Niveau Logique **1** en sortie du comparateur.
* Le multiplexeur entre alors en jeux. Avec ses signaux de sélections, il va sélectionner la sortie ayant le poids le plus élevé, soit $S_{10}$.
* La mémoire va alors enregistrer le niveau logique présent sur la broche $S_{10}$, dans notre cas c'est **1**.

**Étape 2 :**

![Chaîne de fonctionnement du CAN - Exemple - Etape 2](/media/galleries/954/fe965021-ccfd-4b00-8ccd-2b70a7d5e87a.png.960x960_q85.jpg)

* Au niveau de la mémoire, on change le deuxième bit de poids fort (mais moins fort que le premier) correspondant à la broche $S_9$ en le passant à **1**.
* En sortie du CNA, on aura alors une tension de $3.75V$
* Le comparateur compare, il voit $V_{comp} \gt V_e$ donc il donne un état logique **0**.
* La mémoire enregistre alors le niveau sur la broche $S_9$ qui est à **0**.

**Étape 3 :**

Redondante aux précédentes

![Chaîne de fonctionnement du CAN - Exemple - Etape 3](/media/galleries/954/b333dc03-874c-4bc7-86fb-92763684d860.png.960x960_q85.jpg)

* On passe le troisième bit le plus fort (broche $S_8$) à **1**.
* Le CNA converti le nombre binaire résultant en une tension de $3.125V$.
* Le comparateur voit $V_e  \gt V_{comp}$, sa sortie passe à **1**.
* La mémoire enregistre l'état logique de la broche $S_8$ qui est à **1**.

Le CAN continue de cette manière pour arriver au dernier bit (celui de poids faible). En mémoire, à la fin de la conversion, se trouve le résultat. On va alors lire cette valeur binaire que l'on convertira ensuite pour l'exploiter. Bon, j'ai continué les calculs à la main (n'ayant pas de simulateur pour le faire à ma place), voici le tableau des valeurs :

->

| Poids du bit | NL en sortie du comparateur | Bits stockés en mémoire | Tension en sortie du convertisseur CNA (en V) |
|--------------|-----------------------------|-------------------------|-----------------------------------------------|
| 10           | 1                           | 1                       | 2.5                                           |
| 9            | 0                           | 0                       | 3.75                                          |
| 8            | 1                           | 1                       | 3.125                                         |
| 7            | 1                           | 1                       | 3.4375                                        |
| 6            | 0                           | 0                       | 3.59375                                       |
| 5            | 0                           | 0                       | 3.515625                                      |
| 4            | 1                           | 1                       | 3.4765625                                     |
| 3            | 1                           | 1                       | 3.49609375                                    |
| 2            | 1                           | 1                       | 3.505859375                                   |
| 1            | 0                           | 0                       | 3.5107421875                                  |

Table: Lien entre tension et bits 

<-

**Résultat :** Le résultat de la conversion donne :

->

| Résultat de conversion (binaire) | Résultat de conversion (décimale) | Résultat de conversion (Volts) |
|----------------------------------|-----------------------------------|--------------------------------|
| 1011001110                       | 718                               | 3,505859375                    |

Table: Exemple de résultat d'une conversion

<-
Observez la précision du convertisseur. Vous voyez que la conversion donne un résultat (très) proche de la tension réelle, mais elle n'est pas exactement égale. Ceci est dû au pas du convertisseur.

## Pas de calcul du CAN

Qu'est-ce que **le pas de calcul** ? Eh bien il s'agit de la tension minimale que le convertisseur puisse "voir". Si je mets le bit de poids le plus faible à 1, quelle sera la valeur de la tension $V_{comp}$ ? Le convertisseur a une tension de référence de 5V. Son nombre de bit est de 10. Donc il peut "lire" : $2^{10}$ valeurs pour une seule tension. Ainsi, sa précision sera de : $\frac{5}{2^{10}} = 0,0048828125 V$ La formule à retenir sera donc :

$$ \frac{V_{ref}}{2^N} $$

Avec :

+ $V_{ref}$ : tension de référence du convertisseur
+ $N$ : nombre de bit du convertisseur

Il faut donc retenir que, pour ce convertisseur, sa précision est de $4.883mV$. Donc, si on lui met une tension de $2mV$ par exemple sur son entrée, le convertisseur sera incapable de la voir et donnera un résultat égal à 0V.

## Les inconvénients

Pour terminer avant de passer à l'utilisation du CNA avec Arduino, je vais vous parler de ses inconvénients. Il en existe trois principaux :

+ **la plage de tension d'entrée** : le convertisseur analogique de l'Arduino ne peut recevoir à son entrée que des tensions comprises entre 0V et +5V. On verra plus loin comment améliorer la précision du CAN.
+ **la précision** : la précision du convertisseur est très bonne sauf pour les deux derniers bits de poids faible. On dit alors que la précision est de $\pm 2 LSB$ (à cause du pas de calcul que je viens de vous expliquer).
+ **la vitesse de conversion** : le convertisseur N/A de la carte Arduino n'a pas une très grande vitesse de conversion par rapport à un signal audio par exemple. Ainsi , si l'on convertit un signal audio analogique en numérique grâce à la carte Arduino, on ne pourra entendre que les fréquences en dessous de 10kHz. Dans bien des cas cela peut être suffisant, mais d'en d'autre il faudra utiliser un convertisseur A/N externe (un composant en plus) qui sera plus rapide afin d'obtenir le spectre audio complet d'un signal sonore.

*[CAN]: Convertisseur Analogique Numérique