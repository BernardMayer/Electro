# Le potentiomètre

[[q]]
| Qu'est-ce que c'est que cette bête-là encore ?

 Le **potentiomètre** (ou "potar" pour les (très) intimes) est un composant très fréquemment employé en électronique. On le retrouve aussi sous le nom de résistance variable. Comme ce dernier nom l'indique si bien, un potentiomètre nous permet *entre autres* de réaliser une résistance variable. En effet, on retrouve deux applications principales que je vais vous présenter juste après. Avant toute chose, voici le symbole du potentiomètre :

![Symbole du potentiomètre](/media/galleries/954/6db854b6-e393-4d60-8408-3379830ddf55.jpg.960x960_q85.jpg)

## Cas n°1 : le pont diviseur de tension

 On y remarque une première chose importante, le potentiomètre a trois broches. Deux servent à borner les tensions maximum (A) et minimum (B) que l'on peut obtenir à ses bornes, et la troisième (C) est reliée à un curseur mobile qui donne la tension variable obtenue entre les bornes précédemment fixées. Ainsi, on peut représenter notre premier cas d'utilisation comme un "diviseur de tension réglable". En effet, lorsque vous déplacez le curseur, en interne cela équivaut à modifier le point milieu. En termes électroniques, vous pouvez imaginer avoir deux résistances en série (R1 et R2 pour être original). Lorsque vous déplacez votre curseur vers la borne basse, R1 augmente alors que R2 diminue et lorsque vous déplacez votre curseur vers la borne haute, R2 augmente alors que R1 diminue. Voici un tableau montrant quelques cas de figure de manière schématique :

->

Schéma équivalent | Position du curseur | Tension sur la broche C
------------------|---------------------|------------------------
![Curseur 50/50](/media/galleries/954/8efbf9d3-9b2a-476d-a72f-5c46a7368f57.png.960x960_q85.jpg) | Curseur à **la moitié** | $V_{signal} = (1-\frac{50}{100})\times 5 = 2.5 V$
![Curseur 25/75](/media/galleries/954/90150aa8-e5ea-4fc9-a88c-6f7a81caa480.png.960x960_q85.jpg) | Curseur à **25% du départ** | $V_{signal} = (1-\frac{25}{100})\times 5 = 3.75 V$
![Curseur 75/25](/media/galleries/954/a6e8e846-85bc-48ab-ab5e-7ddb133ca38c.png.960x960_q85.jpg) | Curseur à **75% du départ** | $V_{signal} = (1-\frac{75}{100})\times 5 = 1.25 V$

Table: Illustrations de la position du curseur et sa tension résultante

<-

[[i]]
| Si vous souhaitez avoir plus d'informations sur les résistances et leurs associations ainsi que sur les potentiomètres, je vous conseille d'aller jeter un œil sur [ce chapitre](http://fr.openclassrooms.com/sciences/cours/l-electronique-de-zero/resistance-et-resistor). ;)

## Cas n°2 : la résistance variable

 Le deuxième cas d'utilisation du potentiomètre est la **résistance variable**. Cette configuration est très simple, il suffit d'utiliser le potentiomètre comme une simple résistance dont les bornes sont A et C ou B et C. On pourra alors faire varier la valeur ohmique de la résistance grâce à l'axe du potentiomètre.

[[a]]
| Attention, il existe des potentiomètres **linéaires** (la valeur de la tension évolue de manière proportionnelle au déplacement du curseur), mais aussi des potentiomètres **logarithmique/anti-logarithmique** (la valeur de la tension évolue de manière logarithmique ou anti-logarithmique par rapport à la position du curseur). Choisissez-en dont un qui est linéaire si vous souhaitez avoir une proportionnalité.

# Utilisation avec Arduino

 Vous allez voir que l'utilisation avec Arduino n'est pas vraiment compliquée. Il va nous suffire de raccorder les alimentations sur les bornes extrêmes du potentiomètre, puis de relier la broche du milieu sur une entrée analogique de la carte Arduino :

![Potentiomètre - Schéma](/media/galleries/954/9e00676c-0658-4cb0-9ecb-bdd3e77313ed.png.960x960_q85.png)

![Potentiomètre - Montage](/media/galleries/954/6c046d78-9d95-4632-8377-1c6679ab57ca.png.960x960_q85.png)

Une fois le raccordement fait, nous allons faire un petit programme pour tester cela. Ce programme va simplement effectuer une mesure de la tension obtenue sur le potentiomètre, puis envoyer la valeur lue sur la liaison série (ça nous fera réviser ^^ ). Dans l'ordre, voici les choses à faire :

+ Déclarer la broche analogique utilisée (pour faire du code propre
+ Mesurer la valeur
+ L'afficher !

Je vous laisse chercher ? Aller, au boulot ! :diable: ... Voici la correction, c'est le programme que j'ai fait, peut-être que le vôtre sera mieux :

```cpp
// le potentiomètre, branché sur la broche analogique 0
const int potar = 0;
// variable pour stocker la valeur lue après conversion
int valeurLue;
// on convertit cette valeur en une tension
float tension;

void setup()
{
    // on se contente de démarrer la liaison série
    Serial.begin(9600);
}

void loop()
{
    // on convertit en nombre binaire la tension lue en sortie du potentiomètre
    valeurLue = analogRead(potar);

    // on traduit la valeur brute en tension (produit en croix)
    tension = valeurLue * 5.0 / 1023;

    // on affiche la valeur lue sur la liaison série
    Serial.print("valeurLue = ");
    Serial.println(valeurLue);

    // on affiche la tension calculée
    Serial.print("Tension = ");
    Serial.print(tension,2);
    Serial.println(" V");

    // on saute une ligne entre deux affichages
    Serial.println();
    // on attend une demi-seconde pour que l'affichage ne soit pas trop rapide
    delay(500);
}
```
Code: Voltmètre simple

Vous venez de créer votre premier voltmètre ! :D