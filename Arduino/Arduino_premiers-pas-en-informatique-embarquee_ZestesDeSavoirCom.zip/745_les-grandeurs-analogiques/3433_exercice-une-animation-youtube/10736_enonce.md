Pour clôturer votre apprentissage avec les voies analogiques, nous allons faire un petit exercice pour se détendre. Le but de ce dernier est de réaliser une des animations les plus célèbres de l'internet : le .gif de chargement YouTube (qui est aussi utilisé sur d'autres plateformes et applications).

Nous allons le réaliser avec des LED et faire varier la vitesse de défilement grâce à un potentiomètre. Pour une fois, plutôt qu'une longue explication je vais juste vous donner une liste de composants utiles et une vidéo qui parle d'elle même !

-> **Bon courage !** <-

+ 6 LED + leurs résistances de limitation de courant
+ Un potentiomètre
+ Une Arduino, une breadboard et des fils !

->!(https://www.youtube.com/watch?v=SyxXHZzCoHY)<-