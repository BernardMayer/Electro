Je vais vous présenter deux méthodes possibles qui vont vous permettre de convertir des données numériques en grandeur analogique (je ne parlerai là encore de tension). Mais avant, plaçons-nous dans le contexte.

[[q]]
| Convertir du binaire en analogique, pour quoi faire ? C'est vrai, avec la conversion analogique->numérique il y avait une réelle utilité, mais là, qu'en est-il ?

L'utilité est tout aussi pesante que pour la conversion A->N. Cependant, les applications sont différentes, à chaque outil un besoin dirais-je. En effet, la conversion A->N permettait de transformer une grandeur analogique non-utilisable directement par un système à base numérique en une donnée utilisable pour une application numérique.

Ainsi, on a pu envoyer la valeur lue sur la liaison série. Quant à la conversion opposée, conversion N->A, les applications sont différentes, je vais en citer une plus ou moins intéressante : par exemple commander une, ou plusieurs, LED tricolore (Rouge-Vert-Bleu) pour créer un luminaire dont la couleur est commandée par le son (nécessite une entrée analogique :-° ). Tiens, en voilà un projet intéressant ! Je vais me le garder sous la main... :ninja:

[[q]]
| Alors ! alors ! alors !! Comment on fait !? :D

Serait-ce un léger soupçon de curiosité que je perçois dans vos yeux frétillants ? :p Comment fait-on ? Suivez -le guide !

# Convertisseur Numérique->Analogique

La première méthode consiste en l'utilisation d'un convertisseur Numérique->Analogique (que je vais abréger CNA). Il en existe, tout comme le CAN, de plusieurs sortes :


+ **CNA à résistances pondérées** : ce convertisseur utilise un grand nombre de résistances qui ont chacune le double de la valeur de la résistance qui la précède. On a donc des résistances de valeur R, 2R, 4R, 8R, 16R, ..., 256R, 512R, 1024R, etc. Chacune des résistances sera connectée grâce au micro-contrôleur à la masse ou bien au +5V. Ces niveaux logiques correspondent aux bits de données de la valeur numérique à convertir. Plus le bit est de poids fort, plus la résistance à laquelle il est adjoint est grande (maximum R). À l'inverse, plus il est de poids faible, plus il verra sa résistance de sortie de plus petite valeur. Après, grâce à un petit montage électronique, on arrive à créer une tension proportionnelle au nombre de bit à 1.
+ **CNA de type R/2R** : là, chaque sortie du micro-contrôleur est reliée à une résistance de même valeur (2R), elle-même connectée au +5V par l'intermédiaire d'une résistance de valeur R. Toujours avec un petit montage, on arrive à créer une tension analogique proportionnelle au nombre de bit à 1.

Cependant, je n'expliquerai pas le fonctionnement ni l'utilisation de ces convertisseurs car ils doivent être connectés à autant de broches du micro-contrôleur qu'ils ne doivent avoir de précision. Pour une conversion sur 10 bits, le convertisseur doit utiliser 10 sorties du microcontrôleur !

# PWM ou MLI

Bon, s'il n'y a pas moyen d'utiliser un CNA, alors on va ~~le créer~~ utiliser ce que peut nous fournir la carte Arduino : la **PWM**. Vous vous souvenez que j'ai évoqué ce terme dans le chapitre sur la conversion A->N ? Mais concrètement, c'est quoi ?

[[a]]
| Avant de poursuivre, je vous conseille d'aller [relire cette première partie](https:// zestedesavoir.com/tutoriels/537/arduino-premiers-pas-en-informatique-embarquee/745/les-grandeurs-analogiques/3430/les-entrees-analogiques-de-larduino/#1-un-signal-analogique-petits-rappels) du chapitre sur les entrées analogiques pour revoir les rappels que j'ai faits sur les signaux analogiques. ;)

## Définition

N'ayez point peur, je vais vous expliquer ce que c'est au lieu de vous donner une définition tordue comme on peut en trouver parfois dans les dictionnaires. ;) D'abord, la PWM sa veut dire : **Pulse Width Modulation** et en français cela donne **Modulation à Largeur d'Impulsion** (MLI). La PWM est en fait un signal numérique qui, à une **fréquence** donnée, a un **rapport cyclique** qui change.

[[q]]
| Y'a plein de mots que je comprends pas, c'est normal ? o_O

Oui, car pour l'instant je n'en ai nullement parlé. Voilà donc notre prochain objectif.

## La fréquence et le rapport cyclique

La *fréquence* d'un signal périodique correspond au nombre de fois que la période se répète en UNE seconde. On la mesure en **Hertz**, noté **Hz**. Prenons l'exemple d'un signal logique qui émet un 1, puis un 0, puis un 1, puis un 0, etc. autrement dit un signal créneaux, on va mesurer sa période (en temps) entre le début du niveau 1 et la fin du niveau 0 :

![Représentation d'une période](/media/galleries/954/9aa1e5f4-780f-4330-a365-b10a3c819c3b.png.960x960_q85.png)

Ensuite, lorsque l'on aura mesuré cette période, on va pouvoir calculer sa fréquence (le nombre de périodes en une seconde) grâce à la formule suivante :

$$ F = \frac 1 T $$

Avec :

+ $F$ : fréquence du signal en Hertz (Hz)
+ $T$ : temps de la période en seconde (s)

Le *rapport cyclique*, un mot bien particulier pour désigner le fait que le niveau logique 1 peut ne pas durer le même temps que le niveau logique 0. C'est avec ça que tout repose le principe de la PWM. C'est-à-dire que la PWM est un signal de fréquence fixe qui a un rapport cyclique qui varie avec le temps suivant "les ordres qu'elle reçoit" (on reviendra dans un petit moment sur ces mots).

Le rapport cyclique est mesuré en pourcentage (%). Plus le pourcentage est élevé, plus le niveau logique 1 est présent dans la période et moins le niveau logique 0 l'est. Et inversement. Le rapport cyclique du signal est donc le pourcentage de temps de la période durant lequel le signal est au niveau logique 1. En somme, cette image extraite de la [documentation officielle](http://arduino.cc/en/Tutorial/PWM) d'Arduino nous montre quelques exemples d'un signal avec des rapports cycliques différents :

![Des signaux aux rapports cycliques différents](/media/galleries/954/908c2a28-bd80-4322-a8e8-d20e2b954e79.gif.960x960_q85.png)
Figure: Des signaux aux rapports cycliques différents - (CC-BY-SA - [Timothy Hirzel](http://arduino.cc/en/Tutorial/PWM))

[[i]]
| Astuce : Rapport cyclique ce dit **Duty Cycle** en anglais.

Ce n'est pas tout ! Après avoir généré ce signal, il va nous falloir le transformer en signal analogique. Et oui ! Pour l'instant ce signal est encore constitué d'états logiques, on va donc devoir le transformer en extrayant sa *valeur moyenne*... Je ne vous en dis pas plus, on verra plus bas ce que cela signifie.