# Avant de commencer à programmer

## Les broches de la PWM

Sur votre carte Arduino, vous devriez disposer de 6 broches qui sont compatibles avec la génération d'une PWM. Elles sont repérées par le symbole *tilde* **~** . Voici les broches générant une PWM : 3, 5, 6, 9, 10 et 11.

## La fréquence de la PWM

Cette fréquence, je le disais, est fixe, elle ne varie pas au cours du temps. Pour votre carte Arduino elle est de environ 490Hz.

## La fonction analogWrite()

Je pense que vous ne serez pas étonné si je vous dis que Arduino intègre une fonction toute prête pour utiliser la PWM ? Plus haut, je vous disais ceci :

> la PWM est un signal de fréquence fixe qui a un rapport cyclique qui varie avec le temps suivant "les ordres qu'elle reçoit"
Source: Moi :P

C'est sur ce point que j'aimerais revenir un instant. En fait, les ordres dont je parle sont les paramètres passés dans la fonction qui génère la PWM. Ni plus ni moins. Étudions maintenant la fonction permettant de réaliser ce signal : `analogWrite()`. Elle prend deux arguments :

+ Le premier est le numéro de la broche où l'on veut générer la PWM
+ Le second argument représente la valeur du rapport cyclique à appliquer. Malheureusement on n'exprime pas cette valeur en pourcentage, mais avec un nombre entier compris entre 0 et 255

Si le premier argument va de soi, le second mérite quelques précisions. Le rapport cyclique s'exprime de 0 à 100 % en temps normal. Cependant, dans cette fonction il s'exprimera de 0 à 255 (sur 8 bits). Ainsi, pour un rapport cyclique de 0% nous enverrons la valeur 0, pour un rapport de 50% on enverra 127 et pour 100% ce sera 255. Les autres valeurs sont bien entendu considérées de manière proportionnelle entre les deux. Il vous faudra faire un petit calcul pour savoir quel est le pourcentage du rapport cyclique plutôt que l'argument passé dans la fonction.

## Utilisation

Voilà un petit exemple de code illustrant tout ça :

```cpp
// une sortie analogique sur la broche 6
const int sortieAnalogique = 6;

void setup()
{
    pinMode(sortieAnalogique, OUTPUT);
}

void loop()
{
    // on met un rapport cyclique de 107/255 = 42 %
    analogWrite(sortieAnalogique, 107);
}
```
Code: Exemple simple d'utilisation de la PWM

# Quelques outils essentiels

Savez-vous que vous pouvez d'ores et déjà utiliser cette fonction pour allumer plus ou moins intensément une LED ? En effet, pour un rapport cyclique faible, la LED va se voir parcourir par un courant moins longtemps que lorsque le rapport cyclique est fort. Or, si elle est parcourue moins longtemps par le courant, elle s'éclairera également moins longtemps. En faisant varier le rapport cyclique, vous pouvez ainsi faire varier la luminosité de la LED.

## La LED RGB ou RVB

**RGB** pour Red-Green-Blue en anglais. Cette LED est composée de trois LED de couleurs précédemment énoncées. Elle possède donc 4 broches et existe sous deux modèles : à anode commune et à cathode commune. Exactement comme les afficheurs 7 segments. Choisissez-en une à *anode commune*.

## Mixer les couleurs

Lorsque l'on utilise des couleurs, il est bon d'avoir quelques bases en arts plastiques. Révisons les fondements. La lumière, peut-être ne le savez-vous pas, est composée de trois couleurs primaires qui sont :

+ Le **rouge**
+ Le **vert**
+ Le **bleu**

À partir de ces trois couleurs, il est possible de créer n'importe quelle autre couleur du spectre lumineux visible en mélangeant ces trois couleurs primaires entre elles. Par exemple, pour faire de l'orange on va mélanger du rouge (2/3 du volume final) et du vert (à 1/3 du volume final). Je vous le disais, la fonction analogWrite() prend un argument pour la PWM qui va de 0 à 255. Tout comme la proportion de couleur dans les logiciels de dessin ! On parle de "norme RGB" faisant référence aux trois couleurs primaires. Pour connaître les valeurs RGB d'une couleur, je vous propose de regarder avec le logiciel **Gimp** (gratuit et multiplateforme)[^nbp]. Pour cela, il suffit de deux observations/clics :

[^nbp]: La même chose est réalisable avec des sites comme http://htmlcolorcodes.com/color-picker/

1. Tout d'abord on sélectionne la "boîte à couleurs" dans la boîte à outils
2. Ensuite, en jouant sur les valeurs R, G et B on peut voir la couleur obtenue

![La boite à couleur de Gimp](/media/galleries/954/beb62f94-971b-4457-8870-3b0661ea9398.png.960x960_q85.jpg)

![Le ColorPicker de Gimp](/media/galleries/954/1a9fef4e-bb6b-41f2-8a3e-24e5ab56383b.png.960x960_q85.jpg)

Afin de faire des jolies couleurs, nous utiliserons analogWrite() trois fois (une pour chaque LED). Prenons tout de suite un exemple avec du **orange** et regardons sa composition sous Gimp :

![La couleur orange avec Gimp](/media/galleries/954/b2f01e19-42b9-430f-9479-9ef540315ec0.png.960x960_q85.png)

À partir de cette image nous pouvons voir qu'il faut :

+ 100 % de rouge (255)
+ 56 % de vert (144)
+ 0% de bleu (0)

Nous allons donc pouvoir simplement utiliser ces valeurs pour faire une jolie couleur sur notre LED RGB :

```cpp
const int ledRouge = 11;
const int ledVerte =  9;
const int ledBleue = 10;

void setup()
{
    // on déclare les broches en sorties
    pinMode(ledRouge, OUTPUT);
    pinMode(ledVerte, OUTPUT);
    pinMode(ledBleue, OUTPUT);

    // on met la valeur de chaque couleur
    analogWrite(ledRouge, 255);
    analogWrite(ledVerte, 144);
    analogWrite(ledBleue, 0);
}

void loop()
{
    // on ne change pas la couleur donc rien à faire dans la boucle principale
}
```
Code: Utilisation d'une led RGB

[[q]]
| Moi j'obtiens pas du tout de l'orange ! Plutôt un bleu étrange...

C'est exact. Souvenez-vous que c'est une LED à anode commune, or lorsqu'on met une tension de 5V en sortie du microcontrôleur, la LED sera éteinte. Les LED sont donc pilotées **à l'état bas**. Autrement dit, ce n'est pas la durée de l'état haut qui est importante mais plutôt celle de l'état bas. Afin de pallier cela, il va donc falloir mettre la valeur "inverse" de chaque couleur sur chaque broche en faisant l'opération  $ValeurReelle = 255 - ValeurTheorique$ . Le code précédent devient donc :

```cpp
const int ledRouge = 11;
const int ledVerte =  9;
const int ledBleue = 10;

void setup()
{
    // on déclare les broches en sorties
    pinMode(ledRouge, OUTPUT);
    pinMode(ledVerte, OUTPUT);
    pinMode(ledBleue, OUTPUT);

    // on met la valeur de chaque couleur
    analogWrite(ledRouge, 255-255);
    analogWrite(ledVerte, 255-144);
    analogWrite(ledBleue, 255-0);
}
```
Code: Utilisation d'une led RGB à anode commune

On en a fini avec les rappels, on va pouvoir commencer un petit exercice.

# À vos claviers, prêt... programmez !

## L'objectif

L'objectif est assez simple, vous allez générer trois PWM différentes (une pour chaque LED de couleur) et créer 7 couleurs (le noir ne compte pas ! :P ) distinctes qui sont les suivantes :

+ rouge
+ vert
+ bleu
+ jaune
+ bleu ciel
+ violet
+ blanc

Ces couleurs devront "défiler" une par une (dans l'ordre que vous voudrez) toutes les 500ms.

## Le montage à réaliser

Vous allez peut-être être surpris car je vais utiliser pour le montage une LED à anode commune, afin de bien éclairer les LED avec la bonne proportion de couleur. Donc, lorsqu'il y aura la valeur 255 dans analogWrite(), la LED de couleur rouge, par exemple, sera complètement illuminée.

![RGB schéma](/media/galleries/954/d7b4a56c-6cc0-4e86-a7b4-00d84cef0af3.png.960x960_q85.jpg)

![RGB montage](/media/galleries/954/212f12b8-8d78-4851-8047-46c423d0045d.png.960x960_q85.png)

** C'est parti ! ;) **

## Correction

Voilà le petit programme que j'ai fait pour répondre à l'objectif demandé :

```cpp
// définition des broches utilisée (vous êtes libre de les changer)
const int led_verte = 9;
const int led_bleue = 10;
const int led_rouge = 11;

int compteur_defilement = 0; // variable permettant de changer de couleur


void setup()
{
    // définition des broches en sortie
    pinMode(led_rouge, OUTPUT);
    pinMode(led_verte, OUTPUT);
    pinMode(led_bleue, OUTPUT);
}

void loop()
{
    couleur(compteur_defilement); // appel de la fonction d'affichage
    compteur_defilement++; // incrémentation de la couleur à afficher

    // si le compteur dépasse 6 couleurs
    if(compteur_defilement> 6)
        compteur_defilement = 0;

    delay(500);
}

void couleur(int numeroCouleur)
{
    switch(numeroCouleur)
    {
    case 0 : // rouge
        // rapport cyclique au minimum pour une meilleure luminosité de la LED
        analogWrite(led_rouge, 0);
        // qui je le rappel est commandée en "inverse"
        // (0 -> LED allumée ; 255 -> LED éteinte)
        analogWrite(led_verte, 255);
        analogWrite(led_bleue, 255);
        break;
    case 1 : // vert
        analogWrite(led_rouge, 255);
        analogWrite(led_verte, 0);
        analogWrite(led_bleue, 255);
        break;
    case 2 : // bleu
        analogWrite(led_rouge, 255);
        analogWrite(led_verte, 255);
        analogWrite(led_bleue, 0);
        break;
    case 3 : // jaune
        analogWrite(led_rouge, 0);
        analogWrite(led_verte, 0);
        analogWrite(led_bleue, 255);
        break;
    case 4 : // violet
        analogWrite(led_rouge, 0);
        analogWrite(led_verte, 255);
        analogWrite(led_bleue, 0);
        break;
    case 5 : // bleu ciel
        analogWrite(led_rouge, 255);
        analogWrite(led_verte, 0);
        analogWrite(led_bleue, 0);
        break;
    case 6 : // blanc
        analogWrite(led_rouge, 0);
        analogWrite(led_verte, 0);
        analogWrite(led_bleue, 0);
        break;
    default : // "noir"
        analogWrite(led_rouge, 255);
        analogWrite(led_verte, 255);
        analogWrite(led_bleue, 255);
        break;
    }
}
```
Code: Exercice, affichage de plusieurs couleurs

Bon ben je vous laisse lire le code tout seul, vous êtes assez préparé pour le faire, du moins j'espère. Pendant ce temps je vais continuer la rédaction de ce chapitre. :-°