Bon, on est arrivé à modifier les couleurs d'une LED RGB juste avec des "impulsions", plus exactement en utilisant directement le signal PWM.

[[q]]
| Mais comment faire si je veux un signal complètement analogique ?

C'est justement l'objet de cette sous-partie : créer un signal analogique à partir d'un signal numérique.

[[a]]
| Cependant, avant de continuer, je tiens à vous informer que l'on va aborder des notions plus profondes en électronique et que vous n'êtes pas obligé de lire cette sous-partie si vous ne vous en sentez pas capable. Revenez plus tard si vous le voulez. Pour ceux qui cela intéresserait vraiment, je ne peux que vous encourager à vous accrocher et éventuellement lire [ce chapitre](http://fr.openclassrooms.com/sciences/cours/l-electronique-de-zero/le-condensateur-en-regime-continu) pour mieux comprendre certains points essentiels utilisés dans cette sous-partie.

# La valeur moyenne d'un signal

Sur une période d'un signal périodique, on peut calculer sa valeur moyenne. En fait, il faut faire une moyenne de toutes les valeurs que prend le signal pendant ce temps donné. C'est une peu lorsque l'on fait la moyenne des notes des élèves dans une classe, on additionne toutes les notes et on divise le résultat par le nombre total de notes. Je ne vais prendre qu'un seul exemple, celui dont nous avons besoin : le signal carré.

## Le signal carré

Reprenons notre signal carré :

![Un signal carré](/media/galleries/954/44fcfab6-95b2-4698-ae5b-6b60011678f7.png.960x960_q85.png)

J'ai modifié un peu l'image pour vous faire apparaitre les temps. On observe donc que du temps  $0$  (l'origine) au temps  $T$ , on a une période du signal.  $aT$  correspond au moment où le signal change d'état. En somme, il s'agit du temps de l'état haut, qui donne aussi le temps à l'état bas et finalement permet de calculer le rapport cyclique du signal. Donnons quelques valeurs numériques à titre d'exemple :


+  $T = 1ms$
+  $a = 0.5$  (correspond à un rapport cyclique de 50%)

La formule permettant de calculer la valeur moyenne de cette période est la suivante :

$$ \langle U \rangle = \frac{U_1 \times aT + U_2 \times (T - aT)}T $$

[[i]]
| La valeur moyenne d'un signal se note avec des chevrons <, > autour de la lettre indiquant de quelle grandeur physique il s'agit.

## Explications

Premièrement dans la formule, on calcule la tension du signal sur la première partie de la période, donc de  $0$  à  $aT$ . Pour ce faire, on multiplie  $U_1$ , qui est la tension du signal pendant cette période, par le temps de la première partie de la période, soit  $aT$ . Ce qui donne :  $U_1 \times aT$ . Deuxièmement, on fait de même avec la deuxième partie du signal. On multiplie le temps de ce bout de période par la tension  $U_2$  pendant ce temps. Ce temps vaut  $T - aT$ . Le résultat donne alors :  $U_2 \times (T - aT)$  Finalement, on divise le tout par le temps total de la période après avoir additionné les deux résultats précédents. Après simplification, la formule devient :  $\langle U \rangle = a \times U_1 + U_2 - a \times U_2$  Et cela se simplifie encore en :

$$ \langle U \rangle = a \times (U_1 - U_2) + U_2 $$

[[i]]
| Dans notre cas, comme il s'agit d'un signal carré ayant que deux valeurs : 0V et 5V, on va pouvoir simplifier le calcul par celui-ci :  $\langle U \rangle = a \times U_1$ ,car  $U_2 = 0$

[[e]]
| Les formules que l'on vient d'apprendre ne s'appliquent que pour **une seule** période du signal. Si le signal a toujours la même période et le même rapport cyclique alors le résultat de la formule est admissible à l'ensemble du signal. En revanche, si le signal a un rapport cyclique qui varie au cours du temps, alors le résultat donné par la formule n'est valable que pour un rapport cyclique donné. Il faudra donc calculer la valeur moyenne pour chaque rapport cyclique que possède le signal.

De ce fait, si on modifie le rapport cyclique de la PWM de façon maitrisée, on va pouvoir créer un signal analogique de la forme qu'on le souhaite, compris entre 0 et 5V, en extrayant la valeur moyenne du signal. On retiendra également que, **dans cette formule uniquement**, le temps n'a pas d'importance.

# Extraire cette valeur moyenne

Alors, mais comment faire pour extraire la valeur moyenne du signal de la PWM, me direz-vous. Eh bien on va utiliser les propriétés d'un certain couple de composants très connu : le **couple RC** ou **résistance-condensateur**.

[[q]]
| La résistance on connait, mais, le condensateur... tu nous avais pas dit qu'il servait à supprimer les parasites ? o_O

Si, bien sûr, mais il possède plein de caractéristiques intéressantes. C'est pour cela que c'est un des composants les plus utilisé en électronique. Cette fois, je vais vous montrer une de ses caractéristiques qui va nous permettre d'extraire cette fameuse valeur moyenne.

## Le condensateur

Je vous ai déjà parlé de la résistance, vous savez qu'elle limite le courant suivant la loi d'Ohm. Je vous ai aussi parlé du condensateur, je vous disais qu'il absorbait les parasites créés lors d'un appui sur un bouton poussoir. À présent, on va voir un peu plus en profondeur son fonctionnement car on est loin d'avoir tout vu ! Le condensateur, je rappel ses symboles : ![Symbole des condensateurs polarisés](/media/galleries/954/03f0c4af-acd1-4d24-960a-e6b3270a2843.png.960x960_q85.jpg) est constitué de deux plaques métalliques, des **armatures**, posées face à face et isolées par... un isolant ! :P Donc, en somme le condensateur **est équivalent** à un interrupteur ouvert puisqu'il n'y a pas de courant qui peut passer entre les deux armatures. Chaque armature sera mise à un potentiel électrique. Il peut être égal sur les deux armatures, mais l'utilisation majoritaire fait que les deux armatures ont un potentiel différent.

## Le couple RC

Bon, et maintenant ? Maintenant on va faire un petit montage électrique,vous pouvez le faire si vous voulez, non en fait faites-le vous comprendrez mes explications en même temps que vous ferez l'expérience qui va suivre. Voilà le montage à réaliser :

![Un couple RC en action](/media/galleries/954/f3fc1822-58d6-40fd-b7eb-21621035b6c1.png.960x960_q85.jpg)

Les valeurs des composants sont :

+  $U = 5V$  (utilisez la tension 5V fournie par votre carte Arduino)
+  $C = 1000 \mu F$
+  $R_{charge} = 1k\Omega$
+  $R_{decharge} = 1k\Omega$

Le montage est terminé ? Alors fermez l'interrupteur...

[[q]]
| Que se passe-t-il ?

Lorsque vous fermez l'interrupteur, le courant peut s'établir dans le circuit. Il va donc aller allumer la LED. Ceci fait abstraction du condensateur. Mais, justement, dans ce montage il y a un condensateur. Qu'observez-vous ? La LED ne s'allume pas immédiatement et met un peu de temps avant d'être complètement allumée. Ouvrez l'interrupteur. Et là, qu'y a-t-il de nouveau ? En théorie, la LED devrait être éteinte, cependant, le condensateur fait des siennes. On voit la LED s'éteindre tout doucement et pendant plus longtemps que lorsqu'elle s'allumait. Troublant, n'est-ce pas ? :D

[[i]]
| Vous pouvez réitérer l'expérience en changeant la valeur des composants, sans jamais descendre en dessous de 220 Ohm pour la résistance de décharge.

## Explications

Je vais vous expliquer ce phénomène assez étrange. Vous l'aurez sans doute deviné, c'est le condensateur qui joue le premier rôle ! En fait, lorsque l'on applique un potentiel différent sur chaque armature, le condensateur n'aime pas trop ça. Je ne dis pas que ça risque de l'endommager, simplement qu'il n'aime pas ça, comme si vous on vous forçait à manger quelque chose que vous n'aimez pas. Du coup, lorsqu'on lui applique une tension de 5V sur une des ses armatures et l'autre armature est reliée à la masse, il met du temps à accepter la tension. Et plus la tension croit, moins il aime ça et plus il met du temps à l'accepter. Si on regarde la tension aux bornes de ce pauvre condensateur, on peut observer ceci :

![La courbe de charge d'un condensateur](/media/galleries/954/08badd92-9b33-4bb5-ac16-4b0afa86117c.png.960x960_q85.jpg)

La tension augmente d’abord très rapidement, puis de moins en moins rapidement aux bornes du condensateur lorsqu'on le **charge** à travers une résistance. Oui, on appelle ça la **charge** du condensateur. C'est un peu comme si la résistance donnait un mauvais goût à la tension et plus la résistance est grande, plus le goût est horrible et moins le condensateur se charge vite. C'est l'explication de pourquoi la LED s'est éclairée lentement. Lorsque l'on ouvre l'interrupteur, il se passe le phénomène inverse. Là, le condensateur peut se débarrasser de ce mauvais goût qu'il a accumulé, sauf que la résistance et la LED l'en empêchent. Il met donc du temps à se **décharger** et la LED s'éteint doucement :

![La courbe de décharge d'un condensateur](/media/galleries/954/ab17a74c-9f83-43a8-a8eb-50148959c14e.png.960x960_q85.jpg)

Pour terminer, on peut déterminer le temps de charge et de décharge du condensateur à partir d'un paramètre très simple, que voici :

$$ \tau = R \times C $$

Avec :

+  $\tau$  : (prononcez "to") temps de charge/décharge en secondes (s)
+  $R$  : valeur de la résistance en Ohm ( $\Omega$ )
+  $C$  : valeur de la capacité du condensateur en Farad (F)

Cette formule donne le temps  $\tau$  qui correspond à 63% de la charge à la tension appliquée au condensateur. On considère que le condensateur est complètement chargé à partir de  $3 \tau$  (soit 95% de la tension de charge) ou  $5\tau$  (99% de la tension de charge).

## Imposons notre PWM !

[[q]]
| Bon, très bien, mais quel est le rapport avec la PWM ?

Ha, haa ! Alors, pour commencer, vous connaissez la réponse.

[[q]]
| Depuis quand ? o_O

Depuis que je vous ai donné les explications précédentes. Dès que l'on aura imposé notre PWM au couple RC, il va se passer quelque chose. Quelque chose que je viens de vous expliquer. À chaque fois que le signal de la PWM sera au NL 1 (Niveau Logique 1), le condensateur va se charger. Dès que le signal repasse au NL 0, le condensateur va se décharger. Et ainsi de suite. En somme, cela donne une variation de tension aux bornes du condensateur semblable à celle-ci :

![Charge et décharge successive](/media/galleries/954/398b18c5-a611-48b6-b92c-7d2b696072f4.png.960x960_q85.jpg)

[[q]]
| Qu'y a-t-il de nouveau par rapport au signal carré, à part sa forme bizarroïde !?

Dans ce cas, rien de plus, si on calcule la valeur moyenne du signal bleu, on trouvera la même valeur que pour le signal rouge. (Ne me demandez pas pourquoi, c'est comme ça, c'est une formule très compliquée qui le dit :P ). Précisons que dans ce cas, encore une fois, le temps de charge/décharge  $3\tau$  du condensateur est choisi de façon à ce qu'il soit égal à une demi-période du signal. Que se passera-t-il si on choisit un temps de charge/décharge plus petit ou plus grand ?

## Constante de temps  $\tau$  supérieure à la période

Voilà le chronogramme lorsque la constante de temps de charge/décharge du condensateur est plus grande que la période du signal :

![Charge et décharge successive](/media/galleries/954/f820390d-87bf-4a9b-bac5-28b5f2e0bdd0.png.960x960_q85.png)

Ce chronogramme permet d'observer un phénomène intéressant. En effet, on voit que la tension aux bornes du condensateur n'atteint plus le +5V et le 0V comme au chronogramme précédent. Le couple RC étant plus grand que précédemment, le condensateur met plus de temps à se charger, du coup, comme le signal "va plus vite" que le condensateur, ce dernier ne peut se charger/décharger complètement. Si on continue d'augmenter la valeur résultante du couple RC, on va arriver à un signal comme ceci :

![Charge et décharge successive](/media/galleries/954/4186bf5d-9273-4d23-9a60-b830107cbd4a.png.960x960_q85.png)

Et ce signal, Mesdames et Messieurs, c'est la valeur moyenne du signal de la PWM !! :D

# Calibrer correctement la constante RC

Je vous sens venir avec vos grands airs en me disant : "*Oui, mais là le signal il est pas du tout constant pour un niveau de tension. Il arrête pas de bouger et monter descendre ! Comment on fait si on veut une belle droite ?*" "*Eh bien*, dirais-je, *cela n'est pas impossible, mais se révèle être une tâche difficile et contraignante. Plusieurs arguments viennent conforter mes dires*".

## Le temps de stabilisation entre deux paliers

Je vais vous montrer un chronogramme qui représente le signal PWM avec deux rapports cycliques différents. Vous allez pouvoir observer un phénomène "qui se cache" :

![Charge et décharge successive](/media/galleries/954/fad3d10e-27fe-40a6-b044-b2450d4175e1.png.960x960_q85.jpg)

Voyez donc ce fameux chronogramme. Qu'en pensez-vous ? Ce n'est pas merveilleux hein ! :( Quelques explications : pour passer d'un palier à un autre, le condensateur met un certain temps. Ce temps est grosso modo celui de son temps de charge (constante RC). C'est-à-dire que plus on va augmenter le temps de charge, plus le condensateur mettra du temps pour se stabiliser au palier voulu. Or si l'on veut créer un signal analogique qui varie assez rapidement, cela va nous poser problème.

## La perte de temps en conversion

C'est ce que je viens d'énoncer, plus la constante de temps est grande, plus il faudra de périodes de PWM pour stabiliser la valeur moyenne du signal à la tension souhaitée. À l'inverse, si on diminue la constante de temps, changer de palier sera plus rapide, mais la tension aux bornes du condensateur aura tendance à suivre le signal. C'est le premier chronogramme que l'on a vu plus haut.

## Finalement, comment calibrer correctement la constante RC ?

Cela s'avère être délicat. Il faut trouver le juste milieu en fonction du besoin que l'on a.


+ Si l'on veut un signal qui soit le plus proche possible de la valeur moyenne, il faut une constante de temps très grande.
+ Si au contraire on veut un signal qui soit le plus rapide et que la valeur moyenne soit une approximation, alors il faut une constante de temps faible.
+ Si on veut un signal rapide et le plus proche possible de la valeur moyenne, on a deux solutions qui sont :
    + mettre un deuxième montage ayant une constante de temps un peu plus grande, en cascade du premier (on perd quand même en rapidité)
    + changer la fréquence de la PWM