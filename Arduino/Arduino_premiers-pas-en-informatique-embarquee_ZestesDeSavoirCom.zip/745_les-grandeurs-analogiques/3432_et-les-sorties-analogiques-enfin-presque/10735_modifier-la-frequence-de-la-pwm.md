On l'a vu, avec la fréquence actuelle de la PWM en sortie de l'Arduino, on va ne pouvoir créer que des signaux "lents". Lorsque vous aurez besoin d'aller plus vite, vous vous confronterez à ce problème. C'est pourquoi je vais vous expliquer comment modifier la fréquence de cette PWM.

[[e]]
| Nouveau message d'avertissement : cette fois, on va directement toucher aux registres du microcontrôleur, donc si vous comprenez pas tout, ce n'est pas très grave car cela requiert un niveau encore plus élevé que celui que vous avez actuellement.

Commençons cette très courte sous-partie.

## Pourquoi changer la fréquence de la PWM ?

Oui, pourquoi ? Tout simplement pour essayer de créer un signal qui se rapproche le plus de la valeur moyenne de la PWM à chaque instant. L'objectif est de pouvoir maximiser l'avantage de la structure ayant une faible constante de temps tout en éliminant au mieux son désavantage. Vous verrez peut-être mieux avec des chronogrammes. En voici deux, le premier est celui où la fréquence de la PWM est celle fournie d'origine par l'Arduino, le second est la PWM à une fréquence deux fois plus élevée, après modification du programme :

![L'impact de la modification de la PWM](/media/galleries/954/317f3b9b-213a-47cf-b045-8c58cb231482.png.960x960_q85.jpg)

Pour une constante de temps identique pour chaque courbe réalisée, on relève que le temps de stabilisation du signal est plus rapide sur le chronogramme où la fréquence est deux fois plus élevée qu'avec la fréquence standard d'Arduino. Ici donc, on a :  $t_2 - t_1 = 2 \times (t_4 - t_3)$ . En effet car le temps (T) est inversement proportionnel à la fréquence (F) selon cette formule :  $F = \frac 1 T$  Avec quelques mots pour expliquer cela, le temps de charge du condensateur, pour se stabiliser au nouveau palier de tension, est plus rapide avec une fréquence plus élevée. À comparaison, pour le premier signal, le temps de charge est deux fois plus grand que celui pour le deuxième signal où la fréquence est deux fois plus élevée.

[[a]]
| Mes dessins ne sont pas très rigoureux, mais mes talents de graphistes me limitent à ça. Soyez indulgent à mon égard. :-° Quoi qu'il en soit, il s'agissait, ici, simplement d'illustrer mes propos et donner un exemple concret.

## Utilisation du registre

[[q]]
| Bigre ! Je viens de comprendre pourquoi on avait besoin de changer la fréquence de la PWM. :D Mais euh... comment on fait ? C'est quoi les registres ? :-°

Les registres............... eh bien............... c'est compliqué ! :ninja: Non, je n'entrerai pas dans le détail en expliquant ce qu'est un registre, de plus c'est un sujet que je ne maitrise pas bien et qui vous sera certainement inutile dans le cas présent. Disons pour l'instant que le registre est une variable très spéciale.

## Code de modification de la fréquence de la PWM

Alors, pour modifier la fréquence de la PWM de l'Arduino on doit utiliser le code suivant :

```cpp
// on définit une variable de type byte
// qui contiendra l'octet à donner au registre pour diviser la fréquence de la PWM

// division par : 1, 8, 64, 256, 1024
byte division_frequence=0x01;
// fréquence : 62500Hz, 7692Hz, ...
// temps de la période : 16µs, 130µs, ...

void setup()
{
    pinMode(6, OUTPUT); // broche de sortie

    // TCCR0B c'est le registre, on opère un masquage sur lui même
    TCCR0B = TCCR0B & 0b11111000 | division_frequence;
    // ce qui permet de modifier la fréquence de la PWM
}

void loop ()
{
    // on écrit simplement la valeur de 0 à 255 du rapport cyclique du signal
    analogWrite(6, 128);
    // qui est à la nouvelle fréquence choisit
}
```
Code: Modification de la fréquence de la PWM

[[i]]
| Vous remarquerez que les nombres binaires avec Arduino s'écrivent avec les caractères **0b** devant.

[[a]]
| Cette sous-partie peut éventuellement être prise pour un *truc et astuce*. C'est quelque peu le cas, malheureusement, mais pour éviter que cela ne le soit complètement, je vais vous expliquer des notions supplémentaires, par exemple la ligne 14 du code.

## Traduction s'il vous plait !

Je le disais donc, on va voir ensemble comment fonctionne la ligne 14 du programme :

```cpp linenostart=14
TCCR0B = TCCR0B & 0b11111000 | division_frequence;
```

Très simplement, `TCCR0B` est le nom du registre utilisé. Cette ligne est donc là pour modifier le registre puisqu'on fait une opération avec et le résultat est inscrit dans le registre. Cette opération est, il faudra l'avouer, peu commune. On effectue, ce que l'on appelle en programmation, un **masquage**. Le masquage est une opération logique que l'on utilise avec des données binaires. On peut faire différents masquages en utilisant les opérations logiques ET, OU, OU exclusif, ... Dans le cas présent, on a la variable `TCCR0B` qui est sous forme binaire et on effectue une opération **ET** (symbole **&**) puis une opération **OU** (symbole **|**). Les opérations ET et OU sont définies par une **table de vérité**. Avec deux entrées, on a une sortie qui donne le résultat de l'opération effectuée avec les deux niveaux d'entrée.

->

+----+----+-----------+-----------+
| Entrées | Sortie ET | Sortie OU |
+----+----+-----------+-----------+
|  A |  B |  A ET B   |  A OU B   |
+====+====+===========+===========+
|  0 |  0 |     0     |     0     |
+----+----+-----------+-----------+
|  0 |  1 |     0     |     1     |
+----+----+-----------+-----------+
|  1 |  0 |     0     |     1     |
+----+----+-----------+-----------+
|  1 |  1 |     1     |     1     |
+----+----+-----------+-----------+

Table: Table de vérité de l'opérateur ET et OU

<-

Les opérations de type ET et OU ont un niveau de priorité comme la multiplication et l'addition. On commence toujours par effectuer l'opération ET, puis on termine avec l'opération OU. On pourrait donc écrire ceci :

```cpp
TCCR0B = (TCCR0B & 0b11111000) | division_frequence;
```

Prenons maintenant un exemple où la variable spéciale `TCCR0B` serait un nombre binaire égal à :

```cpp
TCCR0B = 0b10011101; // valeur du registre
```

À présent, on lui fait un masquage de type ET :

```cpp
TCCR0B = 0b10011101;

TCCR0B = TCCR0B & 0b11111000; // masquage de type ET
```

On fait l'opération à l'aide de la table de vérité du ET (voir tableau ci-dessus) et on trouve le résultat :

```cpp
TCCR0B = 0b10011101;

TCCR0B = TCCR0B & 0b11111000;

// TCCR0B vaut maintenant : 0b10011000
```

En somme, on conclut que l'on a gardé la valeur des 5 premiers bits, mais l'on a effacé la valeur des 3 derniers bits pour les mettre à zéro. Ainsi, quelle que soit la valeur binaire de TCCR0B, on met les bits que l'on veut à l'état bas. Ceci va ensuite nous permettre de changer l'état des bits mis à l'état bas en effectuant l'opération OU :

```cpp
byte division_frequence = 0x01; // nombre haxadécimal qui vaut 0b00000001

TCCR0B = 0b10011101;

TCCR0B = TCCR0B & 0b11111000;
// TCCR0B vaut maintenant : 0b10011000

TCCR0B = TCCR0B | division_frequence;
// TCCR0B vaut maintenant : 0b10011001
```

D'après la table de vérité du OU logique, on a modifié la valeur de `TCCR0B` en ne changeant que le ou les bits que l'on voulait.

[[e]]
| La valeur de `TCCR0B` que je vous ai donnée est bidon. C'est un exemple qui vous permet de comprendre comment fonctionne un masquage.

Ce qu'il faut retenir, pour changer la fréquence de la PWM, c'est que pour la variable `division_frequence`, il faut lui donner les valeurs hexadécimales suivantes :

```cpp
0x01 // la fréquence vaut 62500Hz (fréquence maximale fournie par la PWM => provient de la fréquence du quartz / 256)
// effectue une division par 1 de la fréquence max

0x02 // f = 7692Hz (division par 8 de la fréquence maximale)
0x03 // f = 976Hz, division par 64
0x04 // f = 244Hz, division par 256
0x05 // f = 61Hz, division par 1024
```

[[i]]
| Vous trouverez plus de détails sur [cette page](http://www.arcfn.com/2009/07/secrets-of-arduino-pwm.html) (en anglais).

## Test de vérification

Pour vérifier que la fréquence a bien changé, on peut reprendre le montage que l'on a fait plus haut et enlever l'interrupteur en le remplaçant par un fil. On ne met plus un générateur de tension continue, mais on branche une sortie PWM de l'arduino avec le programme qui va bien. Pour deux fréquences différentes, on devrait voir la LED s'allumer plus ou moins rapidement. On compare le temps à l'état au lorsque l'on écrit 1000 fois un niveau de PWM à 255 à celui mis par le même programme avec une fréquence de PWM différente, grâce à une LED.