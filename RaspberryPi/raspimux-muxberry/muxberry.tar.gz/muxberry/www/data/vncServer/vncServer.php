#! /usr//bin/php
<?php
$vncProxyServer  = false ;
declare (ticks=1) { // Pour toute l'execution permet le suppor des signaux

class vncProxyUser {
	var $webSocket = false	;
	var $vncSocket = false  ;
	var $display = false  	;
	var $closed = false			;

	function __construct($socket) {	
		global $geometry ;
		$adress = "" ;
  	socket_getpeername ( $socket , $adress ) ;
		$this->webSocket = $socket ;
    printf("Open connexion\n") ;
    $options = "-localhost no -geometry 800x600" ;
    $fdp = popen (sprintf("su vnc -c 'vncserver %s'",$options),"r") ;
    while ($buf = fgets($fdp)) {
    	// recherche chaine style : Fichier journal : /home/pascal/.vnc/seaberry:1.log
//    	printf("lu %s",$buf) ;
    	if (!($c = strpos($buf,".log"))) continue ;
    	$c-- ; while (is_numeric(substr($buf,$c,1))) $c-- ;
    	sscanf(substr($buf,$c),":%d.log",$this->display) ;
//    	printf("trouve %s display %d\n",substr($buf,$c),$this->display) ;
    	}
    pclose($fdp) ;
    if ($this->display ==false) {
    	printf("Can't find display\n") ;
    	}
    $address = '127.0.0.1';
		$port = 5900 + $this->display ;
		$this->vncSocket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
		if ($this->vncSocket === false) {
		    echo "socket_create() a échoué : raison :  " . socket_strerror(socket_last_error()) . "\n" ;
		    $this->disconnect() ;
		    }
		$result = socket_connect($this->vncSocket, $address, $port);
		if ($this->vncSocket === false) {
			 	echo "socket_connect() a échoué : raison : ($result) " . socket_strerror(socket_last_error($socket)) . "\n";
		    $this->disconnect() ;
				}
//	printf("connect sur port %d %d\n",$port,$this->vncSocket) ;
  }

	function disconnect() {
//	  printf("Close connexion\n") ;
    if ($this->display != false)
        system (sprintf("su vnc -c 'vncserver -kill :%d'",$this->display)) ;
		if ($this->vncSocket != false) socket_close($this->vncSocket) ;
		if ($this->webSocket != false) socket_close($this->webSocket) ;
		$this->connected = false ;
		$this->vncSocket = false ;
		$this->webSocket = false ;
		$this->closed = true ;
		}
	
	function processWebData($data,$len) {
		if ($this->vncSocket != false) {
			//printf("process out vnc %d byres\n",$len) ;
			if (socket_send($this->vncSocket,$data,$len,0) != $len) {
					printf("Erreur ecriture socket vncServer") ;
					$this->disconnect() ;
					}
			}
		}
		
	function processVncData($data,$len) {
		if ($this->webSocket != false) {
			//	printf("process out web %d byres\n",$len) ;
			if (socket_send($this->webSocket,$data,$len,0) != $len) {
					printf("Erreur ecriture socket webServer") ;
					$this->disconnect() ;
					}
			}
		}
	}
	
class vncProxyServer {
	var	$master = false ;
	var $users = array() ;
	var $bufferLength = 2048 ;
	var $pidWebSockify			;
	
	function __construct($addr, $port, $bufferLength = 2048) {	
	global $port ;
	$this->master = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)  or die("Failed: socket_create()");
  socket_set_option($this->master, SOL_SOCKET, SO_REUSEADDR, 1) or die("Failed: socket_option()");
  socket_bind($this->master, $addr, $port)                      or die("Failed: socket_bind()");
  socket_listen($this->master,20)                               or die("Failed: socket_listen()");
  $this->sockets['m'] = $this->master;
  $this->bufferLength = $bufferLength ;
  printf("Server started\nListening on: $addr:$port\nMaster socket: ".$this->master);

	if ( ($pidWebSockify = pcntl_fork()) == 0) {
		$websockify = exec("which websockify") ;
		pcntl_exec($websockify,array (":5999",sprintf(":%d",$port))) ;
		exit(0) ;
		}
	}
	
	function getUserbySocket($socket) {
		for ($c = 0 ; $c < count ($this->users) ; $c++) {
			if ($this->users[$c]->webSocket == $socket) return $c ;
			if ($this->users[$c]->vncSocket == $socket) return $c ;
			}
		return -1 ;
		}
		
	function run () {	
		global $geometryServer ;	
		while (1) {
		$read = array() ;
		$write = NULL ;
		$except = NULL ;

		$read[] = $this->master ;
		$toClose = array() ;
		
		$newUsers = array() ;
		for ($c = 0 ; $c < count ($this->users) ; $c++) {
			if ($this->users[$c]->closed == true) continue ;
			$newUsers[] = $this->users[$c] ;
			}
		$this->users = $newUsers ;
			
		for ($c = 0 ; $c < count ($this->users) ; $c++) {
			if ($this->users[$c]->closed == true) continue ;
			if ($this->users[$c]->webSocket != false) $read[] = $this->users[$c]->webSocket ;
			if ($this->users[$c]->vncSocket != false) $read[] = $this->users[$c]->vncSocket ;
			}
			
		socket_select($read,$write,$except,1);
    foreach ($read as $socket) {
        if ($socket == $this->master) {
          $client = socket_accept($socket);
          if ($client < 0) {
            $this->stderr("Failed: socket_accept()");
            continue;
          } 
          else {
            $this->users[] = new vncProxyUser($client) ;
            printf("Client connected. " . $client);
          }
        } 
        else {
					if ( ($user = $this->getUserbySocket($socket)) == -1) continue ;					
          $numBytes = socket_recv($socket, $buffer, $this->bufferLength, MSG_DONTWAIT) ; 
          if ($numBytes <= 0) {
          	$this->users[$user]->disconnect() ;
          	continue ;
          	}
					if ($socket == $this->users[$user]->webSocket)
						$this->users[$user]->processWebData($buffer,$numBytes) ;
					else $this->users[$user]->processVncData($buffer,$numBytes) ;
					}
			}
		}
	}
	
	function closeAll() {
		for ($c = 0 ; $c < count ($this->users) ; $c++) {
			$this->users[$c]->disconnect() ;
			}
		socket_close($this->master) ;
		posix_kill($this->pidWebSockify,SIGTERM) ;
		exit(0) ;
	}
}


// gestionnaire de signaux système
function sig_handler($signo)
{
global $vncProxyServer ;
$vncProxyServer->closeAll() ;
exit(0) ;
}


// Recoit les connexions de websockify sur $port
// Recoit la gemoetrie sur $port - 1
$port = "5998" ;

pcntl_signal(SIGTERM, "sig_handler");
pcntl_signal(SIGHUP,  "sig_handler");
pcntl_signal(SIGQUIT, "sig_handler");
pcntl_signal(SIGINT, "sig_handler");
  
for ($c = 0 ; $c < 32 ; $c++) {
  system (sprintf("su vnc -c 'vncserver -kill :%d'",$c)) ;
	}          
            
if (isset($argv[1]) && $argv[1] > 0) $port = $argv[1] ;
$vncProxyServer = new vncProxyServer("0.0.0.0",$port,64 * 1024);
try {
  $vncProxyServer->run();
}
catch (Exception $e) {
	$vncProxyServer->close() ;
  $vncProxyServer->stdout($e->getMessage());
}

}


?>
