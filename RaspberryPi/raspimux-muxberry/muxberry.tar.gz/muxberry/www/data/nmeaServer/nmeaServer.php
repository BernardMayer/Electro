#! /bin/sh php
<?php
require_once('./websockets.php');

class nmeaServer extends WebSocketServer {

  function __construct($addr, $port, $bufferLength) {
    parent::__construct($addr, $port, $bufferLength);
    $this->userClass = 'MyUser';
    $this->stdin = fopen('php://stdin', 'r') ;
		stream_set_blocking($this->stdin, false) ;
  	}

  protected function process ($user, $message) {
  }
  
  protected function connected ($user) {
    // Do nothing: This is just an echo server, there's no need to track the user.
    // However, if we did care about the users, we would probably have a cookie to
    // parse at this step, would be looking them up in permanent storage, etc.
  }
  
  protected function closed ($user) {
    // Do nothing: This is where cleanup would go, in case the user had any sort of
    // open files or other objects associated with them.  This runs after the socket 
    // has been closed, so there is no need to clean up the socket itself here.
  }
  
  protected function tick () {
  	$read = array( $this->stdin ) ;
  	$write  = NULL;
		$except = NULL;
  	$n = stream_select ( $read , $write , $except , 1 ) ;
  	if ($n) { 	 	
  			$buf = fgets($this->stdin) ;		
  			if ($buf == FALSE) exit(0) ; // Rupture du pipe avec nmeaHub
  			for (reset($this->sockets) , $c = 0 ; $c < count ($this->sockets) ; $c++ , next($this->sockets)) {
  				$socket = current($this->sockets) ;
  				if ($socket == $this->master) continue ;
  				$key = key($this->sockets) ;
  				$this->send($this->users[$key],$buf) ;
  				}  				
  			}
  	}
  	
  public function run() { // Modif du timer slect a 0
    while(true) {
      if (empty($this->sockets)) {
        $this->sockets['m'] = $this->master;
      }
      $read = $this->sockets;
      $write = $except = null;
      $this->_tick();
      $this->tick();
      @socket_select($read,$write,$except,0);
      foreach ($read as $socket) {
        if ($socket == $this->master) {
          $client = socket_accept($socket);
          if ($client < 0) {
            $this->stderr("Failed: socket_accept()");
            continue;
          } 
          else {
            $this->connect($client);
            $this->stdout("Client connected. " . $client);
          }
        } 
        else {
          $numBytes = @socket_recv($socket, $buffer, $this->maxBufferSize, 0); 
          if ($numBytes === false) {
            $sockErrNo = socket_last_error($socket);
            switch ($sockErrNo)
            {
              case 102: // ENETRESET    -- Network dropped connection because of reset
              case 103: // ECONNABORTED -- Software caused connection abort
              case 104: // ECONNRESET   -- Connection reset by peer
              case 108: // ESHUTDOWN    -- Cannot send after transport endpoint shutdown -- probably more of an error on our part, if we're trying to write after the socket is closed.  Probably not a critical error, though.
              case 110: // ETIMEDOUT    -- Connection timed out
              case 111: // ECONNREFUSED -- Connection refused -- We shouldn't see this one, since we're listening... Still not a critical error.
              case 112: // EHOSTDOWN    -- Host is down -- Again, we shouldn't see this, and again, not critical because it's just one connection and we still want to listen to/for others.
              case 113: // EHOSTUNREACH -- No route to host
              case 121: // EREMOTEIO    -- Rempte I/O error -- Their hard drive just blew up.
              case 125: // ECANCELED    -- Operation canceled
                
                $this->stderr("Unusual disconnect on socket " . $socket);
                $this->disconnect($socket, true, $sockErrNo); // disconnect before clearing error, in case someone with their own implementation wants to check for error conditions on the socket.
                break;
              default:

                $this->stderr('Socket error: ' . socket_strerror($sockErrNo));
            }
            
          }
          elseif ($numBytes == 0) {
            $this->disconnect($socket);
            $this->stderr("Client disconnected. TCP connection lost: " . $socket);
          } 
          else {
            $user = $this->getUserBySocket($socket);
            if (!$user->handshake) {
              $tmp = str_replace("\r", '', $buffer);
              if (strpos($tmp, "\n\n") === false ) {
                continue; // If the client has not finished sending the header, then wait before sending our upgrade response.
              }
              $this->doHandshake($user,$buffer);
            } 
            else {
              //split packet into frame and send it to deframe
              $this->split_packet($numBytes,$buffer, $user);
            }
          }
        }
      }
    }
  }

}
$port = "2000" ;
if (isset($argv[1]) && $argv[1] > 0) $port = $argv[1] ;
$nmeaServer = new nmeaServer("0.0.0.0",$port,2048);
try {
  $nmeaServer->run();
}
catch (Exception $e) {
  $nmeaServer->stdout($e->getMessage());
}
