<?php
error_reporting ( E_ALL & ~ E_NOTICE & ~ E_STRICT & ~ E_DEPRECATED & ~ E_WARNING);
header('Access-Control-Allow-Origin: *') ;
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
   header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
 if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
  header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
}
$result = array('status' => true ,'warning' => "", 'errorMessage' => "" ) ;

function unProtectFS() {
	global $protectFS ;
	if (!is_dir("/var_orig")) return 0 ;
	if (!($file = @fopen("/var_orig/www/data/tmp/test.tmp","w"))) {
		$x = system("sudo /var/www/data/bin/remountWrite") ;
		if (!($file = @fopen("/var_orig/www/data/tmp/test.tmp","w"))) return -1 ;
		}
	fclose($file) ;
	unlink("/var_orig/www/data/tmp/test.tmp") ;
	$protect = 1 ;
	echo "protect = " ;
	return 0 ;
}

function protectFS() {
	global $protectFS ;
	if ($protectFS == 0) return ;
	$x = system("sudo /var/www/data/bin/remountRead") ;
	$protectFS = 0 ;
	}

function error($message) {
	global $result ;
	$result['status'] = false ;
	$result['errorMessage'] = $message ;
	echo json_encode($result) ;
	exit(0) ;
	}

$dir = "/var/www/data/repetiteur" ;	
if (!is_dir($dir)) $dir = "/tmp" ;
$userName = gethostbyaddr ($_SERVER['REMOTE_ADDR']) ;

// Enregistrement fichier specifique a l'utilisateur
$file = sprintf("%s/%s.json",$dir,$userName) ;
if (unProtectFS() == -1) return ;
if (($fd = fopen($file,"w")) <= 0) {
	error( "can't open " . $file ) ;
	}
else {
		fwrite($fd,$_GET['preferences'],strlen($_GET['preferences'])) ;
		}
fclose($fd) ;
protectFS() ;
echo json_encode($result) ;
?>