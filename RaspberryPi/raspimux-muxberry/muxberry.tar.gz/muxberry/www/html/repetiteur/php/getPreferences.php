<?php
error_reporting ( E_ALL & ~ E_NOTICE & ~ E_STRICT & ~ E_DEPRECATED & ~ E_WARNING);
header('Access-Control-Allow-Origin: *') ;
// Access-Control headers are received during OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
 if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
   header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         
 if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
  header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
}
$result = array('status' => true ,'warning' => "", 'errorMessage' => "",
								'nmeaHost' => 'muxberry' , 
								'opencpnHost' => 'seaberry' , 
								'vncPasswd' => 'opencpn' 
								) ;

function error($message) {
	global $result ;
	$result['status'] = false ;
	$result['errorMessage'] = $message ;
	echo json_encode($result) ;
	exit(0) ;
	}

function resultFusion($jsonBuf) {
	global $result ;
	$object = json_decode($jsonBuf) ;
	if ($object == NULL) return ;
	$array = (array)$object ;
	$result = array_merge ($result,$array) ;
	}

$dir = "/var/www/data/repetiteur" ;	
if (!is_dir($dir)) $dir = "/tmp" ;
$userName = gethostbyaddr ($_SERVER['REMOTE_ADDR']) ;

// Lecture fichier specifique a l'utilisateur
$file = sprintf("%s/%s.json",$dir,$userName) ;
if (($fd = fopen($file,"r")) <= 0) {
	if (is_file($file)) $result['warning'] = "can't read from file : " . $file ;
	}
else {
		while (($buf = fgets($fd))) $jsonBuf .= $buf ;
		resultFusion($jsonBuf) ;
		$result['warning'] = "" ;
		$result['errorMessage'] = "" ;
		}
fclose($fd) ;
// Lecture fichier generique qui ecrasera hostNmea et hostOpencpn par les valeurs generiques
$file = sprintf("%s/initParams.json",$dir) ;
if ( ($fd = fopen($file,"r") ) < 0) {
	$result['warning'] = "can't read from file : " . $file ;
	}
else {
	  $jsonBuf = "" ;
		while (($buf = fgets($fd))) $jsonBuf .= $buf ;
		resultFusion($jsonBuf) ;
		}
fclose($fd) ;
echo json_encode($result) ;
?>