// Load supporting scripts
import createOpencpn from './opencpn.js';
import connexionNmea from './connexionNmea.js';
import * as WebUtil from '../noVNC/app/webutil.js';
import adminInstruments from './adminInstruments.js';


export default  function repetiteur () {
	// On doit attendre le retour des preferences
	this.userPreferences = new preferences({ callback: this.run, scope: this }) ;
	this.nmeaConnexion = null ;	
	}


repetiteur.prototype.checkSocketNmeaStatus = function(params) {
    // 0 Not Open 1 Open 2 Closing 3 close
    if (this.nmeaConnexion && this.nmeaConnexion.ws.readyState < 2) return ;
    params.scope = this.nmeaConnexion ; // Utilise par nmeaConnexion.createSocket
    setTimeout(this.nmeaConnexion.createSocket,3000,params ) ;
    }
    

repetiteur.prototype.run = function () {
var toolBarTimeout = null ;
var Instruments  = null ;	
var Opencpn  = null ;	
var Console  = null ;	
var Admin  = null ;	
var addToolButton = function (side,name) {
	var tool = $('#toolBar' + side) ;
	var tr = tool.find('TR') ;
	tr.append("<TD>\
							<button id=" + name + "Button class='toolBarButton'>\
              <img src='images/" + name + ".png' class='toolBarImg'\
              alt='" + name + "' title='" + name + "'/>\
              </button>\
              </TD>") ;
	}

var addToolButton = function (side,name) {
	var tool = $('#toolBar' + side) ;
	var tr = tool.find('TR') ;
	tr.append("<TD>\
							<button id=" + name + "Button class='toolBarButton'>\
              <img src='images/" + name + ".png' class='toolBarImg'\
              alt='" + name + "' title='" + name + "'/>\
              </button>\
              </TD>") ;
	}

var setToolBarTimeout = function () {
	if (toolBarTimeout) clearTimeout(toolBarTimeout) ;
	toolBarTimeout = setTimeout(closeToolBar, 10000) ;
	}
	
var closeToolBar = function() {
	if (toolBarTimeout) clearTimeout(toolBarTimeout) ;
	toolBarTimeout = null ;
	$('#toolBarMenu').show() ; 
	$('#toolBarLeft').hide() ; 
	$('#toolBarRight').hide() ; 
	$('#toolBar').width($('#toolBarMenu').width()) ;
	$('#toolBar').show() ;
	}

var openToolBar = function() {
	setToolBarTimeout() ;
	$('#toolBarMenu').hide() ; 
	$('#toolBarLeft').show() ; 
	$('#toolBarRight').show() ; 
	$('#toolBar').width('100%') ;
	$('#toolBar').show() ;
	}	

var hideUserScreen = function() {
						$('.userScreen').hide() ;
						$('#toolBar').hide() ;
						} ;
					
	
addToolButton("Menu","menu") ;
addToolButton("Left","gauche") ;
addToolButton("Left","grid") ;
addToolButton("Left","droite") ;
addToolButton("Left","speedometre") ;
addToolButton("Left","anemometre") ;
addToolButton("Left","sondeur") ;
addToolButton("Left","ais") ;
addToolButton("Left","autoroute") ;
addToolButton("Left","opencpn") ;
addToolButton("Right","tools") ;
addToolButton("Right","instruments") ; // icone appelee depuis opencpn
addToolButton("Right","bug") ;

openToolBar() ;
$('#instrumentsButton').hide() ; 
$('#bugButton').hide() ;   // s'affiche si consoleTablette est créee
$('#opencpnButton').hide() ; // s'affiche lorsque la connexion est OK

// Check largeur de la barre de tools pour suprimmer des icones si necessaire
if ($('#toolBarLeft').width() + $('#toolBarRight').width() + 20 > $(body).width()) {
	$('#speedometreButton').hide() ;
	$('#anemometreButton').hide() ;
	$('#sondeurButton').hide() ;
	$('#aisButton').hide() ;
	}
    
var uri = "ws://" + (this.userPreferences.prefs.hostNmea || window.location.hostname) ;  
uri += ":" + (this.userPreferences.prefs.portNmea || 3337) + "/nmea" ;
this.nmeaConnexion = new connexionNmea(uri,{ callback: this.checkSocketNmeaStatus, callbackScope: this } ) ;
//Console = new consoleTablette() ;
Opencpn = new createOpencpn( { 'userPreferences' : this.userPreferences } ) ;
Instruments = new instruments(this.nmeaConnexion,this.userPreferences) ;
Admin = new adminInstruments(Instruments) ;	
Instruments.setPage(0) ;
			        	
// Bouton Menu
$('#menuButton').click( function() {
						openToolBar() ;
						} ) ;
						
// Bouton des instruments pour opencpn
$('#instrumentsButton').click( function() {
						hideUserScreen() ;
						Instruments.show() ;
						$('#toolBar').removeClass('toolBarOpencpn') ;
						$('#toolBar').addClass('toolBar') ;
						$('#instrumentsButton').hide() ;
						$('#toolsButton').show() ;
						closeToolBar() ;
						$('#toolBar').show() ;
						} ) ;
						
$('#opencpnButton').click( function() {
						closeToolBar() ;
						hideUserScreen() ;
						$('#toolBarMenu').hide() ;
						$('#toolBarRight').show() ;
						$('#toolsButton').hide() ;
						$('#instrumentsButton').show() ;
						$('#toolBar').removeClass('toolBar') ;
						$('#toolBar').addClass('toolBarOpencpn') ;
						$('#toolBar').show() ;
						//$('#opencpnWindow').show() ;
						Opencpn.show() ;
						} ) ;
						
$('#gaucheButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('prev') ;
						} ) ;

$('#droiteButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('next') ;
						} ) ;

$('#gridButton').click( function() {
						openToolBar() ;
						$('#toolBarLeft').find('.toolBarButton').show() ;
						$('#opencpnButton').hide() ; // Sera reactive par Opencpn si status actif
						$('.toolBarRight').show() ;
						setToolBarTimeout() ;
						Instruments.setPage('0') ;
						} ) ;
											
$('#speedometreButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('_Speedometre') ;
						} ) ;
						
$('#anemometreButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('_Anemometre') ;
						} ) ;
						
$('#sondeurButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('_Sondeur') ;
						} ) ;		
					
$('#aisButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('_AIS') ;
						} ) ;	
$('#autorouteButton').click( function() {
						setToolBarTimeout() ;
						Instruments.setPage('_AUTOROUTE') ;
						} ) ;	
						
$('#toolsButton').click( function() {
						if (toolBarTimeout) clearTimeout(toolBarTimeout) ;
						hideUserScreen() ;
						//('#toolBarMenu').hide() ;
						$('.toolBarRight').hide() ;
						$('#toolBarLeft').find('.toolBarButton').hide() ;
						$('#gridButton').show() ;
						$('#toolBar').width($('#toolBarMenu').width()) ;
						$('#toolBar').show() ;
						Admin.show() ;
						} ) ;
}
