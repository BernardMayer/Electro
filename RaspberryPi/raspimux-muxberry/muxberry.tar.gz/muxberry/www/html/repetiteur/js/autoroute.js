var autoroute = function(canvasId,paramsInstrument) {
	this.cog = 0 
	this.sog = 0 ;
	this.lat = 0 ;
	this.lng = 0 ;
	this.destLat = 0 ;
	this.destLng = 0 ;
	this.velocity = 0 ;
	this.lastVelocity = 0 ;
	this.trackError = 0 ;
	this.dirSteer = 0 ;
	this.bearingToDest = 0 ;
	this.distanceToDest = 0 ;
	this.lastBearingToDest = 0 ;
	this.canvasId = canvasId ;
	this.height = 0 ;
	this.width = 0 ;
	this.scale = 1 ;
	var me = this ;
	

	var parentDIV = $('#' + this.canvasId).parent('div') ;
	parentDIV.append("<DIV id='autoroute-" + this.canvasId + "' class='autoroute' status='true'>") ;
	$('#autoroute-' + this.canvasId).html("\
										<div style='display:none;'>\
  										<img id='bateauAutoroute' src='images/bateauAutoroute.png'>\
											</div> ") ;	
															  
	this.repaint() ; 		 			 								
}  
 
autoroute.prototype.repaint = function() {
   		var c ;
   		var width , height ;
   		var canvas = document.getElementById(this.canvasId) ;
   		var  mainCtx =  canvas.getContext('2d');		
										
   		// <TD><DIV><canvas></DIV></TD>
   		var tdContainer = $('#' + this.canvasId).parent().parent('TD') ;
			this.width = width = tdContainer.innerWidth()  ;
			this.height = height = tdContainer.innerHeight()  ;
			canvas.width = width ;
			canvas.height = height ;
   		if (!$('#' + this.canvasId).is(":visible")) return ;
   		 
   		// Calcul de la velocity
			if (this.lastVelocity < (Date.now() / 1000) - 10 &&
					this.destLng != 0 && this.destLat != 0 &&
					!isNaN(this.destLng) && !isNaN(this.destLat)) {
					var deltaAngle = this.bearingToDest - this.cog ;
					this.velocity = Math.cos(deltaAngle * Math.PI / 180) * this.sog ;
					}
			// Format d'affichage
			this.velocity = parseFloat(this.velocity).toFixed(2) ;
			this.trackError = parseFloat(this.trackError).toFixed(2) ;
			this.distanceToDest = parseFloat(this.distanceToDest).toFixed(2) ;
			this.sog = parseFloat(this.sog).toFixed(2) ;
			this.bearingToDest = parseFloat(this.bearingToDest).toFixed(0) ;
			// Calcul la fonte de bearing et distance
			 // Affiche bearing et distance
		  var fontSize = 36 ;
		  mainCtx.font = parseInt(fontSize) + "px arial" ;	
	    while (mainCtx.measureText("Distance 0.00 N").width >= this.width / 2 * 0.9 ||
	    				4 * fontSize >= height / 3) {
				mainCtx.font = parseInt(fontSize) + "px arial" ;				
				fontSize -= 2 ;
				}
			var espaceTexte = 3.5 * fontSize ;
			
   		mainCtx.fillStyle = tdContainer.css("background-color") ;
   	  mainCtx.fillRect(0,0,width,height) ;
      
      // Ligne de partage au milieu
      mainCtx.beginPath();
      mainCtx.moveTo(width / 2,0) ;
      mainCtx.lineTo(width / 2,height) ;
      mainCtx.stroke();
      
      // Ligne de partage bas ecran
      mainCtx.beginPath();
      mainCtx.moveTo(0,(height - espaceTexte) + 1) ;
      mainCtx.lineTo(width,(height - espaceTexte) + 3) ;
      mainCtx.stroke();

	    mainCtx.fillStyle = '#D0D0D0' ;
   		mainCtx.beginPath() ;
   		mainCtx.moveTo(0,height - espaceTexte) ;
   		mainCtx.lineTo(3 * (width / 8),0) ;
   		mainCtx.lineTo(4 * (width / 8) - 4,0) ;
   		mainCtx.lineTo(5 * (width / 16),height - espaceTexte) ;
	    mainCtx.fill() ;
	     
	    mainCtx.beginPath() ;
   		mainCtx.moveTo(width,height - espaceTexte) ;
   		mainCtx.lineTo(width - 3 * (width / 8),0) ;
   		mainCtx.lineTo(width - 4 * (width / 8) + 4,0) ;
   		mainCtx.lineTo(width - 5 * (width / 16),height - espaceTexte) ;
	    mainCtx.fill() ;
	     
	    // Dessine me bateau
	    var image = document.getElementById("bateauAutoroute") ;
	    var imageSize = width / 6 ;
	    var x = width / 2 - imageSize / 2 ;
	    if (this.dirSteer == 'R') x = width / 2 - imageSize - 5 ; // x -= imageSize / 2 - 5 ;
	    else  x = width / 2 + 5 ; // x += imageSize / 2 + 5 ;
	    var y = height - espaceTexte - imageSize - 5 ;
	    mainCtx.drawImage(image, x, y, imageSize,imageSize);
	    // Affiche l'xte
	    mainCtx.fillStyle = 'black' ;
	    mainCtx.font = "36px arial" ;
	    fontSize = 36 ;
	    while (mainCtx.measureText("Velocity").width >= this.width / 4) {
				mainCtx.font = parseInt(fontSize) + "px arial" ;
				fontSize -= 2 ;
				}
		  if (this.dirSteer != 'L') {
		  	// Affiche XTE
				var sizeText = mainCtx.measureText("XTE").width ;
				x = width / 6 - sizeText / 2 ;
		  	mainCtx.fillText("XTE", x, fontSize + 10) ;	
		  	var sizeText = mainCtx.measureText(this.trackError).width ;
				x = width / 6 - sizeText / 2 ;
		  	mainCtx.fillText(this.trackError, x, 2 * fontSize + 10) ;
		  	// Affiche Velocity
		  	if (this.velocity) {
					var sizeText = mainCtx.measureText("Velocity").width ;
		  		x = 5 * width / 6 - sizeText / 2 ;
		  		mainCtx.fillText("Velocity", x, fontSize + 10) ;
		  		var sizeText = mainCtx.measureText(this.velocity).width ;
		  		x = 5 * width / 6 - sizeText / 2 ;
		  		mainCtx.fillText(this.velocity, x,2 * fontSize + 10) ;		
		  		}  	
		  	}
		  else {
		  	// Affiche Velocity
		  	if (this.velocity) {
					var sizeText = mainCtx.measureText("Velocity").width ;
					x = width / 6 - sizeText / 2 ;
		  		mainCtx.fillText("Velocity", x, fontSize + 10) ;	
		  		var sizeText = mainCtx.measureText(this.velocity).width ;
		  		x = width / 6 - sizeText / 2 ;
		  		mainCtx.fillText(this.velocity, x, 2 * fontSize + 10) ;
		  		}
		  	// Affiche XTE
				var sizeText = mainCtx.measureText("XTE").width ;
		  	x = 5 * width / 6 - sizeText / 2 ;
		  	mainCtx.fillText("XTE", x, fontSize + 10) ;
		  	var sizeText = mainCtx.measureText(this.trackError).width ;
		  	x = 5 * width / 6 - sizeText / 2 ;
		  	mainCtx.fillText(this.trackError, x,2 * fontSize + 10) ;		  	
		  	}
		  // Affiche bearing et distance
		  fontSize = 36 ;
		  mainCtx.font = parseInt(fontSize) + "px arial" ;	
	    while (mainCtx.measureText("Distance 0.00 N").width >= this.width / 2 * 0.9 ||
	    				4 * fontSize >= height / 3) {
				mainCtx.font = parseInt(fontSize) + "px arial" ;				
				fontSize -= 2 ;
				}
			
			var marge = (this.width / 2 - mainCtx.measureText("Distance 0.00 N").width) / 2 ;
			var margeBottom = fontSize / 2 ;
		  var x_position = marge + mainCtx.measureText("Distance ").width ;
		  mainCtx.fillText("Bearing ", marge , height  - 1.5 * fontSize - margeBottom) ;
		  mainCtx.fillText(this.bearingToDest + " °", x_position, height  - 1.5 * fontSize -  margeBottom) ;
		  mainCtx.fillText("Distance ", marge , height  - margeBottom) ;
		  mainCtx.fillText(this.distanceToDest + " N", x_position, height - margeBottom) ;

		  var x_position = mainCtx.measureText("SOG ").width + this.width / 2 + marge ;
		  mainCtx.fillText("COG ", this.width / 2 + marge , height  - 1.5 * fontSize - margeBottom) ;
		  mainCtx.fillText(this.cog + " °", x_position, height  - 1.5 * fontSize - margeBottom) ;
		  mainCtx.fillText("SOG ", this.width / 2 + marge  , height  - margeBottom) ;
		  mainCtx.fillText(this.sog + " K",  x_position, height  - margeBottom) ;
		  
   	}	// reapaint
   	
autoroute.prototype.calculateBearingDist = function() {
	if (this.lastBearingToDest > (Date.now() / 1000) - 10) return ;
	if (this.destLat == 0 && this.destLng == 0) return ;
	var p1 = new LatLon(this.lat,this.lng) ;
	var p2 = new LatLon(this.destLat,this.destLng) ;	 
	this.distanceToDest = p1.distanceTo(p2) / 1.852 ; 
	this.bearingToDest = p1.bearingTo(p2) ; 
	this.bearingToDestMT = 'T' ;
	}    	

	   		  		   		
autoroute.prototype.setValue = function(value,params) {
   		var decoded ;
   		var phrase  ;
   		phrase = params.nmeaParams.nmeaValues.phrase ;
   		
   		valueName = params.nmeaParams.nmeaValues.valueName ;
   		if (params.data.dirSteer && params.data.trackError) {
   			this.trackError = params.data.trackError ;
   			this.dirSteer = params.data.dirSteer ;
   			}
   		if (params.data.distanceToDest) {
   			this.distanceToDest = params.data.distanceToDest ;
   			}
   			
   		if (params.data.bearingToDest) {
   			this.bearingToDest = params.data.bearingToDest ;
   			this.bearingToDestMT = params.data.bearingToDestMT ;
   			this.lastBearingToDest = Date.now() / 1000 ;
   			}
   		if (params.data.velocity) {
   			this.velocity = params.data.velocity ;
   			this.lastVelocity = Date.now() / 1000 ;
   			}
   		if (params.data.destLat) {
   			this.destLat = params.data.destLat / 100 ;
   			var deg = Math.floor(this.destLat) ;
   			var min = ((this.destLat - deg) * 100) ;
   			this.destLat = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.destLat_sens == "S") this.destLat = this.destLat * -1 ;
   			this.destLng = params.data.destLng / 100 ;
   			var deg = Math.floor(this.destLng) ;
   			var min = ((this.destLng - deg) * 100) ;
   			this.destLng = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.destLng_sens == "W") this.destLng = this.destLng * -1 ;
   			this.calculateBearingDist() ;
   			//console.log("phrase " + phrase + " recalcul "  ) ;
   			}
   		if (params.data.lat) {
   			this.lat = params.data.lat / 100 ;
   			var deg = Math.floor(this.lat) ;
   			var min = ((this.lat - deg) * 100) ;
   			this.lat = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.lat_sens == "S") this.lat = this.lat * -1 ;
   			this.lng = params.data.lng / 100 ;
   			deg = Math.floor(this.lng) ;
   			min = ((this.lng - deg) * 100) ;
   			this.lng = deg + ((min / 60 * 100)) / 100 ;
   			//console.log("ln " + this.lng + " sens " + params.data.lng_sens) ;
   			if (params.data.lng_sens == "W") this.lng = this.lng * -1 ;
   			this.calculateBearingDist() ;
   			//console.log("phrase " + phrase + " recalcul "  ) ;
   			}
   		if (params.data.cog) {
   			this.cog = params.data.cog ;
   			}
   		if (params.data.sog) {
   			this.sog = params.data.sog ;
   			}
   		this.repaint() ;
   		}

