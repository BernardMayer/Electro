var instruments = function(connexion,preferences) {  	
	this.preferences = preferences ;
	this.listeInstruments = new Array() ;
	this.listePages = new Array() ; // { JQelement: page , instrumnts: Array() } 
	this.loch = null ;
	this.sondeur = null ;
	this.anemometre = null ;
	this.sondeur = null ;
	this.ais = null ;
	this.nmeaConnexion = connexion ;
	this.currentPage = 0 ;
	this.lcdColor = steelseries.LcdColor.WHITE ;
	if (preferences.color) this.lcdColor = steelseries.LcdColor[preferences.color] ;
	var me = this ;
		
	this.listeInstruments.push ( { name: 'Digital speedo', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'RMC', altValueName: 'sog' } , 
												  							{ phrase: 'VTG', altValueName: 'sog' } , 
																				{ phrase: 'VHW', valueName: 'speed' } ] ,
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { unitString: " K",
                            									unitStringVisible: true,
                            									headerString: "Speed",
                            									headerStringVisible: true,
                            									detailString: "SOG: ",
                            									detailStringVisible: true,
                            									detailUnit: " K" ,
                            									linkAltValue: false,
                            									lcdColor: this.lcdColor
                            									}
                          } ) ; 
 
 	this.listeInstruments.push ( { name: 'Digital COG/SOG', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'RMC', valueName: 'cog' } ,
												  							{ phrase: 'VTG', valueName: 'cog' } , 
												  							{ phrase: 'RMC', altValueName: 'sog' } ,							  							
												  							{ phrase: 'VTG', altValueName: 'sog' }  ] , 	
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { headerString: "COG",
																							unitString: " °",
                            									lcdDecimals: 0,
                            									unitStringVisible: true,
                            									headerStringVisible: true,
                            									detailString: "SOG: ",
                            									detailUnit: " K" ,
                            									detailLcdDecimals: 1,
                            									detailStringVisible: true,
                            									linkAltValue: false,
                            									lcdColor: this.lcdColor
                            									}
                          } ) ; 

   	this.listeInstruments.push ( { name: 'Digital Destination', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'APB', valueName: 'bearingToDest' } ,
												  							{ phrase: 'RMB', valueName: 'bearingToDest' } , 
												  							{ phrase: 'RMB', altValueName: 'range' } ] , 
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { headerString: "Bearing",
																							unitString: " °",
                            									unitStringVisible: true,
                            									lcdDecimals: 0,
                            									headerStringVisible: true,
                            									detailString: "Range: ",
                            									detailUnit: " N" ,
                            									detailLcdDecimals: 2,
                            									detailStringVisible: true,
                            									linkAltValue: false,
                            									lcdColor: this.lcdColor
                            									}
                          } ) ; 
             
	this.listeInstruments.push ( { name: 'Digital loch', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'VLW', valueName: 'dayDist' } , 
																				{ phrase: 'VLW', altValueName: 'totalDist' } ] ,
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { unitString: " K ",
                            									unitStringVisible: true,
                            									headerString: "Loch",
                            									headerStringVisible: true,
                            									detailString: "Total: ",
                            									detailStringVisible: true,
                            									linkAltValue: false,
                            									lcdColor: this.lcdColor
                            									}
                          } ) ; 

	this.listeInstruments.push ( { name: 'Digital compass',type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'RMC', altValueName: 'cog' } , 
												  							{ phrase: 'VTG', altValueName: 'cog' } , 
																				{ phrase: 'VHW' , valueName: 'headM'} ,
																				{ phrase: 'HDM', valueName: 'hdm' } ] ,
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { unitString: " M  ",
																							unitStringVisible: true,
																							headerString: "Heading",
																							headerStringVisible: true,
																							detailString: "COG: ",
																							detailStringVisible: true,
																							detailUnit: " °" ,
																							linkAltValue: false,
																							lcdDecimals: 0 ,
																							valuesNumeric: true,
                            									lcdColor: this.lcdColor
                            									}
                          } ) ; 

	this.listeInstruments.push ( { name: 'Digital wind', type: 'specif' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'VWR', valueName: 'dir' } ,
												   							{ phrase: 'VWR', altValueName: 'speedK' }] ,
													instrument: digitalWind ,
													paramsInstrument: { unitString: "  ",
																							unitStringVisible: true,
																							headerString: "Angle reel",
																							headerStringVisible: true,
																							detailString: "Vit. reel: ",
																							detailStringVisible: true,
																							detailUnit: " K" ,
																							linkAltValue: false,
																							lcdDecimals: 1 ,
																							valuesNumeric: true,
                            									lcdColor: this.lcdColor
																							} ,
													computePostValue: function(nmeaData) {
																			if (nmeaData.sens == 'L') 
																			 return '> ' + parseInt(nmeaData.dir) ;
																			return parseInt(nmeaData.dir) + ' <' ;
																			}
                          } ) ; 

	this.listeInstruments.push ( { name: 'Digital depth', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'DBT', valueName: 'meters' } ] ,
													instrument: steelseries.DisplaySingle ,
													paramsInstrument: { unitString: " M ",
																							unitStringVisible: true,
																							headerString: "Depth",
																							headerStringVisible: true,
                            									lcdColor: this.lcdColor
																							} 
                          } ) ; 

	this.listeInstruments.push ( { name: 'Temperatures', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'MTA', valueName: 'temp' } ,
												  							 { phrase: 'MTW', altValueName: 'temp' } 	] ,
													instrument: steelseries.DisplayMulti ,
													paramsInstrument: { unitString: "°C",
																							unitStringVisible: true,
																							headerString: "Air temp.",
																							headerStringVisible: true,
																							detailString: "Water temp. ",
																							detailStringVisible: true,
																							detailUnit: " °" ,
																							linkAltValue: false,
																							lcdDecimals: 1 ,
																							valuesNumeric: true,
                            									lcdColor: this.lcdColor
																							} 
                          } ) ;   
                                                  


	this.listeInstruments.push ( { name: 'Anemometre', type: 'specif' ,
													connexion: connexion,
												  instrument: anemometre,
												  paramsInstrument: { lcdColor: this.lcdColor }
                          } ) ; 

	this.listeInstruments.push ( { name: 'Speedometre', type: 'specif' ,
													connexion: connexion,
												  instrument: speedometre,
												  paramsInstrument: { minValue: 0 , maxValue: 12,
                            									lcdColor: this.lcdColor } 
                          } ) ; 

	this.listeInstruments.push ( { name: 'Sondeur', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'DBT', valueName: 'meters' } ] ,
													instrument: sondeur,
													paramsInstrument: { lcdColor: this.lcdColor} 
                          } ) ; 

	this.listeInstruments.push ( { name: 'AIS', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'VDM', valueName: 'raw' } ,
																				{ phrase: 'RMC', valueName: 'raw' } ,
																				{ phrase: 'VDO', valueName: 'raw' } ] ,							
												  instrument: ais ,
												  paramsInstrument: { lcdColor: this.lcdColor } 
                          } ) ; 

	this.listeInstruments.push ( { name: 'AUTOROUTE', type: 'common' ,
													connexion: connexion,
												  nmeaValues: [ { phrase: 'RMC', valueName: 'raw' },
												  							{ phrase: 'APA', valueName: 'raw' },
												  							{ phrase: 'APB', valueName: 'raw' },
												  							{ phrase: 'BWC', valueName: 'raw' },
												  							{ phrase: 'BWW', valueName: 'raw' },
												  							{ phrase: 'GLL', valueName: 'raw' },
												  							{ phrase: 'VTG', valueName: 'raw' },
												  							{ phrase: 'RMB', valueName: 'raw' }
																		   ] ,							
												  instrument: autoroute ,
												  paramsInstrument: { lcdColor: this.lcdColor } 
                          } ) ; 
  if (this.preferences.prefs.pages) {
  	for (var key in this.preferences.prefs.pages) {
  		page = this.preferences.prefs.pages[key] ;
			this.addPage(this.createPage(page.layout,page.instruments,page.name,page.editable)) ;
			}  	
		}
			
  if (this.listePages.length == 0) {
		this.addPage(this.createPage('grid',[ 'Digital speedo' , 'Digital compass' ,
																 'Digital wind' , 'Digital depth' ],'Instruments',false)) ;
		}
	if (!this.isPageExist('_Speedometre'))
 		this.addPage(this.createPage('single',[ 'Speedometre' ],'_Speedometre',false)) ;
	if (!this.isPageExist('_Anemometre'))
 		this.addPage(this.createPage('single',[ 'Anemometre' ],'_Anemometre',false)) ;
	if (!this.isPageExist('_Sondeur'))
 		this.addPage(this.createPage('single',[ 'Sondeur' ],'_Sondeur',false)) ;
	if (!this.isPageExist('_AIS'))
 		this.addPage(this.createPage('single',[ 'AIS' ],'_AIS',false)) ;
	if (!this.isPageExist('_AUTOROUTE'))
 		this.addPage(this.createPage('single',[ 'AUTOROUTE' ],'_AUTOROUTE',false)) ;

	window.addEventListener("resize", this.resize.bind(this)) ;
	this.setPage(this.preferences.prefs.currentPage) ;
  this.show() ;
	}

instruments.prototype.isPageExist = function (name) {
	for (var c = 0 ; c < this.listePages.length ; c++)	
		if (this.listePages[c].name == name) return true ;
	return false ;
	}
	
instruments.prototype.createInstrument = function (container,name) {
	var instrument = null ;
	for (var c = 0 ; c < this.listeInstruments.length && this.listeInstruments[c].name != name ; c++) ;
	if (c == this.listeInstruments.length) return null ;
	// Ajout les preferences dans les parametres
	this.listeInstruments[c].preferences = this.preferences ;
	if (this.listeInstruments[c].type == 'common') {
		// Ajout les preferences dans les parametres
		instrument = new commonInstrument(container,this.listeInstruments[c]) ;		
		return instrument ;																																				
		}
	else {
		instrument = new this.listeInstruments[c].instrument(container,this.listeInstruments[c]) ;	
		return instrument ;																																				
		}	
	return null ;
	}

instruments.prototype.createPage = function(layout,instrumentNames,pageName,editable) {
	var pageNo 	;
	var page		;
	var c				;
	
	if (!layout) layout = 'grid' ;
	if (!Array.isArray(instrumentNames)) {
		instrumentNames = new Array('Digital speedo' , 'Digital compass' , 'Digital wind' , 'Digital depth' ) ;
		}
		
	for (pageNo = 0 ; ; pageNo++) {
		if ($('#pageNo' + pageNo).length) continue ;
		break ;
		}
	$('#body').append("<DIV id='pageNo" + pageNo + "' class='pageInstrument userScreen'></DIV>") ; 
	page = $('#pageNo' + pageNo) ;
	page.height($('#body').height() - $('#toolBar').height()) ;
	switch (layout) {
		// 4 cellules
		case "grid" : page.html("<TABLE class='tableInstrument'>\
																	<TR height='50%'>\
																		<TD width='50%'  class='instrument'>\
																			<div id='pageNo" + pageNo + "_0' class='containerInstrument'/>\
																		</TD>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_1' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	<TR height='50%'>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_2' class='containerInstrument'/>\
																		</TD>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_3' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	</TABLE>") ;
																	break ;
		// 2 cellules horizontales
		case "doubleH" : page.html("<TABLE class='tableInstrument'>\
																	<TR height='100%'>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_0' class='containerInstrument'/>\
																		</TD>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_1' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	</TABLE>") ;
																	break ;
		// 2 cellules verticales	
		case 'double'  :
		case "doubleV" : page.html("<TABLE class='tableInstrument'>\
																	<TR  height='50%'>\
																		<TD width='100%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_0' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	<TR  height='50%'>\
																		<TD width='100%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_1' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	</TABLE>") ;
																	break ;
		// 2 cellules verticales 1/3	
		case "double/single" : page.html("<TABLE class='tableInstrument'>\
																	<TR height='50%'>\
																		<TD width='50' class='instrument'>\
																			<div id='pageNo" + pageNo + "_0' class='containerInstrument'/>\
																		</TD>\
																		<TD width='50%' rowspan='2' class='instrument'>\
																			<div id='pageNo" + pageNo + "_2' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	<TR height='50%'>\
																		<TD width='50%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_1' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	</TABLE>") ;
																	break ;
		
		case "single" : 
		default       : page.html("<TABLE class='tableInstrument'>\
																	<TR height='100%'>\
																		<TD whidth='100%' class='instrument'>\
																			<div id='pageNo" + pageNo + "_0' class='containerInstrument'/>\
																		</TD>\
																	</TR>\
																	</TABLE>") ;
		}
		
	var newPage = { JQelement: page , pageNo: pageNo , 
									layout: layout, instruments: new Array() ,
									instrumentNames: instrumentNames } ;
/* Cree dans setPage pour alléger le démarrage
	for (c = 0 ; c < 4 ; c++) {
		// Pour les 4 cellules, s'il elles existent créé l'instrument
		var id = "#pageNo" + pageNo + "_" + c ;
		if ($(id).length) {
			var instrument = this.createInstrument($(id),instrumentNames[c]) ;
			if (instrument == null) {
					$('#' + 'pageNo' + pageNo).remove() ;
					return null ;
					}
				newPage.instruments.push(instrument) ;
				}
			}
	if (newPage.instruments.length == 0) {
					$('#' + 'pageNo' + pageNo).remove() ;
					return null ;
					}
*/
	newPage.pageNo = pageNo ;
	newPage.name = pageName ? pageName : 'page ' + (pageNo + 1) ;
	newPage.editable = editable === "undefined" ? false : editable ;
	return newPage ;
	}

instruments.prototype.addPage = function (newPage) {
	if (!newPage) return ;
	this.listePages.push(newPage) ;
	if (!this.preferences.prefs.pages) this.preferences.prefs.pages = {} ;
	this.preferences.prefs.pages[newPage.name] = { 
													layout: newPage.layout ,
													instruments: newPage.instrumentNames ,
													name: newPage.name,
													editable: newPage.editable
													} ;	
	}																													  
	
instruments.prototype.setLcdColor = function (lcdColor) {
	this.lcdColor = lcdColor ;
	for (var c = 0 ; c < this.listeInstruments.length ; c++) {
		this.listeInstruments[c].paramsInstrument.lcdColor = lcdColor ;
		}
	var elements = $('.containerInstrument') ;
	for (var c = 0 ; c < elements.length ; c++ ) {
						e = $(elements[c]) ;
            var CORNER_RADIUS = Math.min(e.width(), e.width()) * 0.095;
            CORNER_RADIUS = 20 ;
            //e.css("border-radius",CORNER_RADIUS + "px") ;
            //e.css("-moz-border-radius",CORNER_RADIUS + "px") ;
            //e.css("-webkit-border-radius",CORNER_RADIUS + "px") ;
						}

	$('.containerInstrument').css("background",
																"linear-gradient(" + lcdColor.gradientStartColor + " 0%," + 
																lcdColor.gradientFraction1Color + " 25%," +
																lcdColor.gradientFraction2Color + " 50%," +
																lcdColor.gradientFraction3Color + " 75%," +
																lcdColor.gradientStopColor + " 100%)" ) ;
																
	$('.containerInstrument').css("background",
																"linear-gradient(" + lcdColor.gradientStopColor + " 0%," + 
																lcdColor.gradientFraction1Color + " 25%," +
																lcdColor.gradientFraction2Color + " 50%," +
																lcdColor.gradientFraction3Color + " 75%," +
																lcdColor.gradientStopColor + " 100%)" ) ;
	for (c = 0 ; c < this.listePages.length ; c++) {
		var page = this.listePages[c] ;
		for (var b = 0 ; b < page.instruments.length ; b++) {
			var instrument = page.instruments[b] ;
			if (instrument.gauge && instrument.gauge.setLcdColor) 
				instrument.gauge.setLcdColor(lcdColor) ;
			}
		}
	}

instruments.prototype.deletePage = function (name) {
//console.log("count pages " + this.listePages.length) ;
		for(var c = this.listePages.length - 1; c >= 0; c--) {
    	if (this.listePages[c].name == name) {
    		$('#pageNo' + this.listePages[c].pageNo).remove() ;
    		this.listePages.splice(c,1) ;
//    		console.log("delete " + name + "count pages " + this.listePages.length) ;
    		break ;
   			}
    	}
    delete(this.preferences.prefs.pages[name]) ;
		}
		
instruments.prototype.updatePage = function (oldName,newPage) {
//console.log("count pages " + this.listePages.length) ;
		for(var c = this.listePages.length - 1; c >= 0; c--) {
    	if (this.listePages[c].name == oldName) {
    		$('#pageNo' + this.listePages[c].pageNo).remove() ;
    		this.listePages.splice(c,1) ;
		    this.listePages.splice( c, 0, newPage );
    		console.log("insert " + name + "count pages " + this.listePages.length) ;
    		break ;
   			}
    	}
    if (!this.preferences.prefs.pages) this.preferences.prefs.pages = {} ;
    if (this.preferences.prefs.pages[oldName]) 
    	delete(this.preferences.prefs.pages[oldName]) ;
    this.preferences.prefs.pages[newPage.name] = { 
													layout: newPage.layout ,
													instruments: newPage.instrumentNames ,
													name: newPage.name,
													editable: newPage.editable
													} ;	
		}
	          
instruments.prototype.resize = function() {
    $('.userScreen').width($('#body').innerWidth()) ;
    $('.userScreen').height($('#body').innerHeight() ) ;
	 	$('.containerInstrument').width('1') ; // Pour que la table se resize
	 	$('.containerInstrument').height('1') ;
	 	$('.pageInstrument').width($('#body').innerWidth()) ;
	 	$('.pageInstrument').height($('#body').innerHeight()) ; // - $('#toolBar').height()) ;
	 	$('.tableInstrument').width($('#body').innerWidth()) ;
	 	$('.tableInstrument').height($('#body').innerHeight()) ; // - $('#toolBar').height()) ;

		for (var c = 0 ; c < this.listePages.length ; c++) {
			page = this.listePages[c] ; // Element JQuery
			for (var b = 0 ; b < page.instruments.length ; b++) {
				var instrument = page.instruments[b] ;
				if (instrument && instrument.resize) instrument.resize.call(instrument) ;
				}			
			}
		this.setLcdColor(this.lcdColor) ;
		// Check largeur de la barre de tools pour suprimmer des icones si necessaire
		if ($('#toolBarLeft').width() + $('#toolBarRight').width() + 20 > $(body).width()) {
				$('#speedometreButton').hide() ;
				$('#anemometreButton').hide() ;
				$('#sondeurButton').hide() ;
				$('#aisButton').hide() ;
				}
		} ;	
																							
instruments.prototype.hide = function() {
		$('.pageInstrument').hide() ;
		}
		
instruments.prototype.show = function() {
		$('.userScreen').hide() ;
		var pageNo = this.listePages[this.currentPage].pageNo ;
		$('#pageNo' + pageNo).show() ;
		this.resize() ;
		}
	
instruments.prototype.setPage = function(page) {
		var c = 0 ;
		switch (page) {
			case 'next' : this.currentPage++ ;
							      break ;
			case 'prev' : this.currentPage-- ;
							      break ;
			default     :
					for(c = this.listePages.length - 1; c >= 0; c--) {
						if (this.listePages[c].name == page) {
							this.currentPage = c ;
							break ;
							}
						}
					if (c < 0)
						this.currentPage = parseInt(page) ;
						if (!this.currentPage) this.currentPage = 0 ;
					}
		if (this.currentPage >= this.listePages.length) this.currentPage = 0 ;
		if (this.currentPage < 0) this.currentPage = this.listePages.length - 1 ;
		// Creation des instruments si non encore crées
		var page = this.listePages[this.currentPage] ;
		if (page.instruments.length == 0) {
			for (c = 0 ; c < 4 ; c++) {
				// Pour les 4 cellules, s'il elles existent créé l'instrument
				var id = "#pageNo" + page.pageNo + "_" + c ;
				if ($(id).length) {
					console.log("creation instrument") ;
					var instrument = this.createInstrument($(id),page.instrumentNames[c]) ;
					page.instruments.push(instrument) ;
					}
				}
			}

		this.preferences.prefs['currentPage'] = this.listePages[this.currentPage].name ;
		this.preferences.savePreferences() ;
		this.show() ; 
		}
		
