var ais = function(canvasId,paramsInstrument) {
	this.rayon = 8.0	; // 6 milles de rayon
	this.mouseX = -1 ;
	this.mouseY = -1 ;
	this.scale = 1 ;
	this.cog = 0 
	this.sog = 0 ;
	this.lat = 0 
	this.lng = 0 ;
	this.mouseX = -1 ;
	this.mouseY = -1 ;
	this.startMouseX = -1 ;
	this.startMouseY = -1 ;
	this.aisDecoder = new aivdmDecode({returnJson: false, aivdmPassthrough: true});
	this.aisTargets = new Array() ;
	this.targetPointed = null ;
	this.mmsiPointed = null ;
	this.touches = null ;
	this.lastDoubleTouch = null ;
	this.memoValue = true ; // propriete permettant de recevoir les evenements meme si invisible
	this.lastMouseWeel = Date.now() ;
	this.canvasId = canvasId ;
	this.height = 0 ;
	this.width = 0 ;
	this.aisInfosStatus = false ;
	var me = this ;
	

	var parentDIV = $('#' + this.canvasId).parent('div') ;
	parentDIV.append("<DIV id='aisInfos-" + this.canvasId + "' class='aisInfos' status='true'>") ;
	$('#aisInfos-' + this.canvasId).html("\
										<span></span>\
										<IMG src='images/droite-gauche.png' class='aisInfosImg'\
										onclick=\" { \
																	if ($('#aisInfos-" + this.canvasId + "').attr('status') == 'false') { \
																		$('#aisInfos-" + this.canvasId + "').attr('status','true') ; \
																		$('#aisInfos-" + this.canvasId + "').width('auto') ; \
																		return false ; \
																		} \
																	$('#aisInfos-" + this.canvasId + "').find('span').html('...<BR><BR>') ; \
																		$('#aisInfos-" + this.canvasId + "').attr('status','false') ; \
															  } \">") ;	
															  
	 $('#aisInfos-' + this.canvasId).bind('mousemove', function(e) {
	 		 		$('#' + canvasId).trigger('mousemove',e) ;
	 		 		} ) ;
	 
	 	$('#aisInfos-' + this.canvasId).bind('touchmove', function(e) {
	 		 		$('#' + canvasId).trigger('touchmove',e) ;
	 		 		console.log('touchmove') ;
	 		 		} ) ;
	 		 		
	 	$('#aisInfos-' + this.canvasId).bind('touchstart', function(e) {
	 		 		$('#' + canvasId).trigger('touchstart',e) ;
	 		 		console.log('touchmove') ;
	 		 		} ) ;
		 		 			 								
		// Handlers
   	$('#' + this.canvasId).bind('mousemove',function(event,params) {
   				var ais = me ;
   				var c ;
   				me.event = event ;
   				event.preventDefault() ;
					// redirection par la divInfos
   				if (!event.pageX && !event.pageY && params && params.pageX && params.pageY)
   					event = params ;
   				var point = { x: event.pageX, y: event.pageY  } ;
   				for (c = 0 ; c < me.aisTargets.length ; c++) {
   					if (!me.aisTargets[c].polygon) continue ;
	   				if (me.isPointInPoly (point,me.aisTargets[c].polygon)) {
	   							if (ais.mmsiPointed == me.aisTargets[c]) return ;
	   							ais.mmsiPointed = me.aisTargets[c].mmsi ;
	   							me.repaint() ;
	   							return ;
   								} 
   							}
   				} ) ;
   	
   	$('#' + this.canvasId).bind('mousewheel',function(event) {
   				var ais = me ;
   				var delta = 0 ;
   				me.event = event ;
   				event.preventDefault() ;
   				if (Date.now() - me.lastMouseWeel < 1000) return ;
   				me.lastMouseWeel = Date.now() ;
   				if (event.originalEvent) event = event.originalEvent ;
   				delta = event.deltaY ? -event.deltaY : event.wheelDelta/40 ;
   				if (delta > 0) {
   					if (ais.rayon < 32) ais.rayon *= 2 ;
   					}
   				else if (ais.rayon > 0.25) ais.rayon /= 2 ;
   				ais.repaint() ;
   				} ) ;
   	
   	$('#' + this.canvasId).bind('touchmove',function(event,params) {
   				var ais = me ;
   				var dx ;
   				var dy ;
   				var redirect = false ;
   				
   				event.preventDefault() ;
					// redirection par la divInfos
   				if (!event.touches && params && params.touches) {
   					redirect = true ;
   					event = params ;
   					}

   				if (event.touches.length == 2) {
   					var touches = event.touches ;
   					if (!ais.touches) return ;
   					if (Date.now() - ais.lastDoubleTouch < 300) return ;
   					ais.lastDoubleTouch = Date.now() ;
   					if (redirect) {
   							var	position = $('#aisInfos-' + me.canvasId).position() ;
   							if (ais.touches[0]) {
   								position = $('#aisInfos-' + me.canvasId).position() ;
   								ais.touches[0].screenX += position.left ;
   								ais.touches[0].screenY += position.top ;
   								}
   							if (ais.touches[1]) {
   								position = $('#aisInfos-' + me.canvasId).position() ;
   								ais.touches[1].screenX += position.left ;
   								ais.touches[1].screenY += position.top ;
   								}
   							}
   					var dx0 = Math.sqrt ( ( (ais.touches[1].screenX) * (ais.touches[0].screenX - ais.touches[1].screenX) ) +
   																( (ais.touches[0].screenY - ais.touches[1].screenY) * (ais.touches[0].screenY - ais.touches[1].screenY) )) ;
   					var dx1 = Math.sqrt ( ( (touches[0].screenX - touches[1].screenX) * (touches[0].screenX - touches[1].screenX) ) +
   																( (touches[0].screenY - touches[1].screenY) * (touches[0].screenY - touches[1].screenY) )) ;
						if ((dx1 - dx0) > 0 ) {
							if (ais.rayon < 32) ais.rayon *= 2 ;
							}
   					else if (ais.rayon > 0.25) ais.rayon /= 2 ;
   					ais.startMouseX = ais.mouseX = -1 ;
	   				ais.startMouseY = ais.mouseY = -1 ;
   					ais.repaint() ;
   					return ;
   					}
   				ais.touches = null ;

					if (ais.startMouseX == -1 || ais.startMouseY == -1) return ;
   				dx = event.touches[0].pageX - ais.startMouseX ;
   				dy = event.touches[0].pageY - ais.startMouseY ;
   				ais.mouseX += dx ;
   				ais.mouseY += dy ;
					var d = Math.sqrt( (ais.mouseX - ais.width / 2) * (ais.mouseX - ais.width / 2) +
														 (ais.mouseY - ais.height / 2) * (ais.mouseY - ais.height / 2) ) ;
					if (d > ais.rayon * ais.scale * 1.2) { // ne pas prende en compte  
						ais.mouseX -= dx ;
   					ais.mouseY -= dy ;
   					}
   				ais.startMouseX += dx ;
   				ais.startMouseY += dy ;
   				var point = { x: ais.mouseX, y: ais.mouseY } ;
   				for (var c = 0 ; c < ais.aisTargets.length ; c++) {
   					if (!ais.aisTargets[c].polygon) continue ;
	   				if (ais.isPointInPoly (point,ais.aisTargets[c].polygon)) {
	   							if (ais.mmsiPointed == ais.aisTargets[c]) break ;
	   							ais.mmsiPointed = ais.aisTargets[c].mmsi ;
	   							break ;
   								} 
   							}
   				ais.repaint() ;
   				} ) ;
   				
   			$('#' + this.canvasId).unbind('touchstart') ;
   			$('#' + this.canvasId).bind('touchstart',function(event,params) {
   				var ais = me ;
   				var redirect = false ;
   				event.preventDefault() ;
					// redirection par la divInfos
   				if (!event.touches && params && params.touches) {
   					redirect = true ;
   					event = params ;
   					}

   				if (event.touches.length > 1) { // Deux touches gestion du zoom
   					ais.touches = event.touches ;
   					ais.lastDoubleTouch = null ;
   					return ;
   					}
   				ais.touches = null ;
   				if (ais.startMouseX == -1 || ais.startMouseY == -1) {
   					ais.mouseX = event.touches[0].pageX ;
   					ais.mouseY = event.touches[0].pageY ;
						var d = Math.sqrt( (ais.mouseX - ais.width / 2) * (ais.mouseX - ais.width / 2) +
														 (ais.mouseY - ais.height / 2) * (ais.mouseY - ais.height / 2) ) ;
						if (d > ais.rayon * ais.scale * 1.2) { // ne pas prende en compte 
							ais.mouseX = ais.mouseY = -1 ;
							return ;
							} 
   					}
   				ais.startMouseX = event.touches[0].pageX ;
   				ais.startMouseY = event.touches[0].pageY ;
   				ais.repaint() ;
   				} ) ;
   	   this.repaint() ;  
   	}
   	
  
 
ais.prototype.repaint = function() {
   		var c ;
   		var width , height ;
   		var canvas = document.getElementById(this.canvasId) ;
   		var  mainCtx =  canvas.getContext('2d');		
			var aisStatus = [	{ type: 0 , txt: 'Under way using engine' } ,
												{ type: 1 , txt: 'At anchor' } ,
												{ type: 2 , txt: 'Not under command' } ,
												{ type: 3 , txt: 'Restricted manoeuverability' } ,
												{ type: 4 , txt: 'Constrained by her draught' } ,
												{ type: 5 , txt: 'Moored' } ,
												{ type: 6 , txt: 'Aground' } ,
												{ type: 7 , txt: 'Engaged in Fishing' } ,
												{ type: 8 , txt: 'Under way sailing' } ,
												{ type: 9 , txt: ' ' } ,
												{ type: 10 , txt: ' ' } ,
												{ type: 11 , txt: ' ' } ,
												{ type: 12 , txt: ' ' } ,
												{ type: 13 , txt: ' ' } ,
												{ type: 14 , txt: 'AIS-SART is active' } ,
												{ type: 15 , txt: '' } 
												] ;
										
   		// <TD><DIV><canvas></DIV></TD>
   		var tdContainer = $('#' + this.canvasId).parent().parent('TD') ;
			this.width = width = tdContainer.innerWidth()  ;
			this.height = height = tdContainer.innerHeight()  ;
			canvas.width = width ;
			canvas.height = height ;
   		var tmpTargets = new Array() ;
   		if (!$('#' + this.canvasId).is(":visible")) return ;
   		 
   		this.scale = (((height > width ? width : height) * 0.8) / 2) / this.rayon  ;
   		mainCtx.fillStyle = tdContainer.css("background-color") ;
   	  mainCtx.fillRect(0,0,width,height) ;
            
   		this.targetPointed = null ;
   		for (c = 0 ; c < this.aisTargets.length ; c++) {
   				if ( ((Date.now() - this.aisTargets[c].timestamp) / 1000) > 600) continue ;
   				if (this.mmsiPointed == this.aisTargets[c].mmsi)
   					this.targetPointed = this.aisTargets[c] ;
   				tmpTargets.push(this.aisTargets[c]) ;
   				}
   		 this.aisTargets = tmpTargets ;
   		 if (this.targetPointed != this.lastTargetPointed) {
   		 	$('#aisInfos-' + this.canvasId).attr('status','true') ;
   		 	}
   		 this.lastTargetPointed = this.targetPointed ;
   		 mainCtx.fillStyle = "#000000" ;
   		 // Point central cercle du bateau
   		 mainCtx.beginPath() ;
   		 mainCtx.arc (width / 2,height / 2,2,0,2 * Math.PI) ;
   		 mainCtx.fill() ;
   		 // Creation des cercles de distance 
   		 mainCtx.strokeStyle = '#000000'
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(width / 2,height / 2,(this.rayon * this.scale) * 4 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(width / 2,height / 2,(this.rayon * this.scale) * 3 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(width / 2,height / 2,(this.rayon * this.scale) * 2 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(width / 2,height / 2,(this.rayon * this.scale) * 1 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 
			// COG et SOG et cibles
    	mainCtx.fillStyle = "black" ;
 
    	var startX = 0 ;
    	var startY = 25 ;
			var text ;
			var fontSize = 20 ;

			if (this.rayon >= 1) text = parseInt(this.rayon) + ' Mn' ;
			else text = this.rayon.toFixed(2) + ' Mn' ;		
			text += " / COG : " + parseInt(this.cog) + ' °' ;
			text += " / SOG : " + parseFloat(this.sog).toFixed( 1 ) + ' K' ;
			mainCtx.font = "24px arial" ;
			while (mainCtx.measureText(text).width > this.width - 20) {
				mainCtx.font = parseInt(fontSize) + "px arial" ;
				fontSize -= 2 ;
				}
			startX = (this.width - mainCtx.measureText(text).width) / 2 ;
			mainCtx.fillText(text, startX, startY) ;
			if (this.targetPointed) {
					var p1, p2, b, d ;
    			var divInfos = $('#aisInfos-' + this.canvasId) ;
					var html = "" ;
    			startY += 25 ; 
    			var p1 = new LatLon(this.lat,this.lng) ;
    			var p2 = new LatLon(this.targetPointed.lat,this.targetPointed.lon) ;
    			var d = (p1.distanceTo(p2) / 1.852).toFixed( 2 ) ; 
					var b = p1.bearingTo(p2).toFixed( 2 ) ; 
					if (d > this.rayon) { // En cas de zoom -
						this.mmsiPointed = null ;
						this.targetPointed = null ;
						this.repaint() ;
						return ;
						}
					var name = this.targetPointed.shipname ;
					if (this.targetPointed.name) name = this.targetPointed.name ;
					if (!name) name = '' ;
					if (!this.targetPointed.mmsi) this.targetPointed.mmsi = '' ;
					if (!this.targetPointed.speed) this.targetPointed.speed = '0' ;
					if (this.targetPointed.course == NaN) this.targetPointed.course = '0' ;
					if (!this.targetPointed.classe) this.targetPointed.classe = '-' ;
					var cpa = this.getCpa(this.targetPointed) ;
					var html ;
					html = "Nom : " + name + "<BR><BR>" ;
					html += "MMSI : " + (this.targetPointed.mmsi || '-') + "<BR>" ;
					html += "Bearing : " + b + ' °' + "<BR>" ;
					html += "Distance : " + d + " Mn" + "<BR>" ;
					html += "Cog : " + (this.targetPointed.course || 0) % 360 + ' °' + "<BR>" ;
					html += "Sog : " + (this.targetPointed.speed  || 0) + ' Kn' + "<BR>" ;
					html += "TCPA : " + (cpa.tcpa || '-') +" ' " + "<BR>" ;
					html += "CPA : " + (cpa.cpa || '-') +" Mn" + "<BR>" ;
					var min = parseInt(((Date.now() - this.targetPointed.timestamp) / 1000) / 60) ;
					var sec = parseInt(((Date.now() - this.targetPointed.timestamp) / 1000) % 60) ;
					html += "Last receive : " + min +"' " + sec + "\"" + "<BR>" ;
					if (this.targetPointed.type > 0 && this.targetPointed.type < 15) {
						html += "Status : " + aisStatus[this.targetPointed.type-1].txt + "<BR>" ;
						}
					html += "CLASSE : " + this.targetPointed.classe + "<BR>" ;
					var divInfos = $('#aisInfos-' + this.canvasId) ;
					if (divInfos.attr('status') == 'false') html = "....<BR><BR>" ;
					divInfos.css('bottom',$('#toolBar').height()) ;
					divInfos.css('font-size',fontSize) ;
					divInfos.find("span").html(html) ;
					divInfos.show() ;
					while ( fontSize > 0 && divInfos.height() > this.height - $('#toolBar').height() - startY) {
						fontSize -= 2 ;
						divInfos.css('font-size',fontSize) ;
						}
   		 		}
   		 else $('#aisInfos-' + this.canvasId).hide() ;
			// Dessine les cibles
			var nCibles = 0 ;
			if (this.lat && this.lng) {
				for (c = 0 ; c < this.aisTargets.length ; c++) {
						if (!this.aisTargets[c].lat || !this.aisTargets[c].lon) continue ;
						var p1 = new LatLon(this.lat,this.lng) ;
						var p2 = new LatLon(this.aisTargets[c].lat,this.aisTargets[c].lon) ;
						var d = p1.distanceTo(p2)  / 1.852 ; 
						var b = p1.bearingTo(p2); 
						if (d < this.rayon) nCibles++ ;
						else continue ;
						this.aisTargets[c].polygon = this.drawTarget( { me: this, target: this.aisTargets[c] } ) ;
					}
				if (this.targetPointed) this.drawTarget( { me: this, target: this.targetPointed } ) ;
				}	
		
			// Cibles
			mainCtx.font="20px arial" ;
    	mainCtx.fillStyle = "black" ;
			mainCtx.fillText(nCibles + " / " + this.aisTargets.length + " Cibles",(width / 6) + 10,height - 10) ;

			// touch point
			if (this.mouseX >= 0 && this.mouseY >= 0) {
   						mainCtx.beginPath() ;
   						mainCtx.fillStyle = "red" ;
   						mainCtx.arc (this.mouseX,this.mouseY,4,0,2 * Math.PI) ;
   						mainCtx.fill() ;
   						}
   	}	// reapaint
   	
   	
ais.prototype.drawTarget = function (params) {
   			var target = params.target ;
   			if (!target.lat || !target.lon) return new Array() ;
   			if (target.type == 21) return this.drawFixTarget(params) ;
   			if (!target.course) target.course = 0 ;
   			var mainCtx =  document.getElementById(this.canvasId).getContext('2d');
   			if (!this.lat || !this.lng) return new Array() ;
				var p1 = new LatLon(this.lat,this.lng) ;
				var p2 = new LatLon(target.lat,target.lon) ;
				var d = p1.distanceTo(p2)  / 1.852 ; 
				var b = p1.bearingTo(p2); 
				var course = target.course ;
				var angle = (course * Math.PI / 180) - (Math.PI / 2) ;
				var x , y ; // Centre du bateau cible
				var x1 , y1 ;
				var l = 8 ; // largeur bateau a dessiner
				var L = 30 ; // longueur bateau a dessiner
				polygon = new Array() ;
				age = (Date.now() - target.timestamp) / 1000  ;
				if (age  < 180) mainCtx.fillStyle = "#00ff00" ;
				else if (age < 300) mainCtx.fillStyle = "yellow" ;
				else if (age < 480) mainCtx.fillStyle = "orange" ;
				else  mainCtx.fillStyle = "red" ;
				if (this.targetPointed && this.targetPointed.mmsi == target.mmsi) mainCtx.fillStyle = "#ff33cc" ;
				mainCtx.beginPath() ;
				x = (this.width / 2) + Math.cos((b - 90) * Math.PI / 180) * d * this.scale ;
				y = (this.height / 2) + Math.sin((b - 90) * Math.PI / 180) * d * this.scale ;
				polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.moveTo(x,y) ;
   		 	x1 = x + (l * Math.cos(angle + (Math.PI / 2))) ;
   		 	y1 = y + (l * Math.sin(angle + (Math.PI / 2))) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + (L * Math.cos(angle)) ;
   		 	y1 = y + (L * Math.sin(angle)) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + (l * Math.cos(angle + (3 * Math.PI / 2))) ;
   		 	y1 = y + (l * Math.sin(angle + (3 * Math.PI / 2))) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	mainCtx.lineTo(x,y) ;
   		 	polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.fill() ;
				return polygon ;
	   		}
 
ais.prototype.drawFixTarget = function (params) {
   			var target = params.target ;
   			var mainCtx =  document.getElementById(this.canvasId).getContext('2d');
   			if (!this.lat || !this.lng) return new Array() ;
				var p1 = new LatLon(this.lat,this.lng) ;
				var p2 = new LatLon(target.lat,target.lon) ;
				var d = p1.distanceTo(p2)  / 1.852 ; 
				var b = p1.bearingTo(p2); 
				var x , y ; // Centre de la cible
				var x1 , y1 ;
				var l = 12 ; // largeur bateau a dessiner
				polygon = new Array() ;
				age = (Date.now() - target.timestamp) / 1000  ;
				mainCtx.fillStyle = "blue" ;
				if (this.targetPointed && this.targetPointed.mmsi == target.mmsi) mainCtx.fillStyle = "#ff33cc" ;
				mainCtx.beginPath() ;
				x = (this.width / 2) + Math.cos((b - 90) * Math.PI / 180) * d * this.scale ;
				y = (this.height / 2) + Math.sin((b - 90) * Math.PI / 180) * d * this.scale ;
				polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.moveTo(x,y) ;
   		 	x1 = x + l ;
   		 	y1 = y ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + l ;
   		 	y1 = y + l ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x  ;
   		 	y1 = y + l ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	mainCtx.lineTo(x,y) ;
   		 	polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.fill() ;
				return polygon ;
	   		}
	   		
	   		  		   		
ais.prototype.setValue = function(value,params) {
   		var decoded ;
   		var phrase  ;
   		phrase = params.nmeaParams.nmeaValues.phrase ;
   		if (phrase == "VDM" || phrase == "VDO") {
   			decoded = this.aisDecoder.decode(value) ;
   			decoded.timestamp = Date.now() ;
   			if (decoded.type == 18 || decoded.type == 19 ||  decoded.type == 24) decoded.classe = 'B' ;
   			if (decoded.type == 1 || decoded.type == 2 ||  decoded.type == 3 ||
   						decoded.type == 5) decoded.classe = 'A' ;
   			for (var c = 0 ; c < this.aisTargets.length ; c++) { 
   				if (this.aisTargets[c].mmsi == decoded.mmsi) {
   					// Joint le message
   					for(var key in decoded) { this.aisTargets[c][key] = decoded[key] ; }
   					break ;
   					}
   				}
   			if (c == this.aisTargets.length) {
   				this.aisTargets.push(decoded) ;
   				}
   			}
   		if (phrase == "RMC") {
   			this.lat = params.data.lat / 100 ;
   			var deg = parseInt(this.lat) ;
   			var min = ((this.lat - deg) * 100) ;
   			this.lat = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.lat_sens == "S") this.lat = this.lat * -1 ;
   			this.lng = params.data.lng / 100 ;
   			deg = parseInt(this.lng) ;
   			min = ((this.lng - deg) * 100) ;
   			this.lng = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.lng_sens == "W") this.lng = this.lng * -1 ;
   			this.sog = params.data.sog ;
   			this.cog = params.data.cog ;
   			}
   		this.repaint() ;
   		}

ais.prototype.isPointInPoly = function (pt, poly) {
    	for(var c = false, i = -1, l = poly.length, j = l - 1; ++i < l; j = i)
        ((poly[i].y <= pt.y && pt.y < poly[j].y) || (poly[j].y <= pt.y && pt.y < poly[i].y))
        && (pt.x < (poly[j].x - poly[i].x) * (pt.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x)
        && (c = !c);
    	return c;
			}
		   
ais.prototype.getCpa = function(cible) {
	 		var p1 = new LatLon(this.lat,this.lng) ;
	 		var p2 = new LatLon(cible.lat,cible.lon) ;
	 
	 		var d = p1.distanceTo(p2) ; 

		 for (var t = 0 ; t < 60 ; t++) {
					p1 = p1.destinationPoint(Number(this.cog), this.sog * 1.852 / 60) ;	 	 				 
					p2 = p2.destinationPoint(Number(cible.course), parseFloat(cible.speed) * 1.852 / 60) ;	
					var d1 = p1.distanceTo(p2) ;  
					if (d1 >= d) break ;
					d = d1 ;
				}
			return ( { tcpa: t == 0 ? '-' : t , cpa: t == 0 ? '-' : parseFloat(d / 1.852).toFixed(2) } ) ;
		}   			
   

