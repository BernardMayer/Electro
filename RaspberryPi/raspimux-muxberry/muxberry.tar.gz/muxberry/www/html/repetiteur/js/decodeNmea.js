var decodeNmea = function(buf) {
	var listValues = buf.split(",") ;
	var type = listValues[0].substr(listValues[0].length - 3, 3) ;

	var nmeaPhrase = [ { type: "GLL" , 
											 values : [ "lat", "lat_sens", "lng", "lng_sens" ,"utc", "status" ] 
										 } ,
										 { type: "RMC" , 
											 values : [ "utc", "status", "lat", "lat_sens", "lng", "lng_sens" ,"sog", "cog", "date", "magVar" ] 
										 } ,
										 { type: "GGA" , 
											 values : [ "utc", "lat", "lat_sens", "lng", "lng_sens" , "fixquality" ,"numsat", "dilution", "altitude", "height" ] 
										 } ,
										 { type: "BWW" , 
											 values : [ "bearingOrigToDest", "T", "bearingOrigToDestMag", "M" ] 
										 } ,
										 { type: "VTG" , 
											 values : [ "cog", "T", "cogM", "M", "sog", "N" ,"sogK", "K" ] 
										 } ,
										 { type: "VHW" , 
											 values : [ "headT", "T", "headM", "M", "speed", "N" ,"speedK", "K" ] 
										 } ,
										 { type: "VLW" , 
											 values : [ "totalDist", "N", "dayDist", "N" ] 
										 } ,
										 { type: "DBT" , 
											 values : [ "feet", "f", "meters", "M" , "fathoms", "F" ] 
										 } ,
										 { type: "MTA" , 
											 values : [ "temp", "C" ] 
										 } ,
										 { type: "MTW" , 
											 values : [ "temp", "C" ] 
										 } ,
										 { type: "APA" , 
											 values : [ "A", "A", "trackError", "dirSteer", "unit" , "arrival" , 
											 						"passed" , "bearingOrigToDest" , "bearingOrigToDestMT" , "wpId" ] 
										 } ,
										 { type: "APB" , 
											 values : [ "A", "A", "trackError", "dirSteer", "unit" , "arrival" , "passed" , 
											 						"bearingOrigToDest" , "bearingOrigToDestMT" , "wpId" , "bearingToDest", 
											 						"bearingToDestMT", "headingToDest", "headingToDestMT" ] 
										 } ,										 
										 { type: "RMB" , 
											 values : [ "status", "trackError", "dirSteer", "toWpId" , "fromWpId" , 
											 						"destLat" , "destLat_sens" , "destLng" , "destLng_sens" , 
											 						"distanceToDest", "bearingToDest", "velocity", "arrivalStatus" ] 
										 } ,										 
										 { type: "BWC" , 
											 values : [ "utc", "destLat", "destLat_sens", "destLng" , "destLng_sens" , 
											 						"bearingToDest" , "T" , "bearingToDestMag" , "M" , "distanceToDest", 
											 						"N", "wpId" ] 
										 } ,	
										 { type: "XTE" , 
											 values : [ "status", "status", "trackError", "dirSteer", "N" ] 
										 } ,									 
										 { type: "VWR" , 
											 values : [ "dir", "sens", "speed", "N", "speedK", "K" ] 
										 } ,
										 { type: "VWT" , 
											 values : [ "dir", "sens", "speed", "N", "speedK", "K" ] 
										 },
										 { type: "HDM" , 
											 values : [ "hdm", "M" ] 
										 } ,
										 { type: "VDM" , 
											 values : [ ] 
										 } ,
										 { type: "VDO" , 
											 values : [  ] 
										 }
									 ] ;

	var model = nmeaPhrase.find(function(phrase) { if (phrase.type == type) return true ; return false } ) ;
	if (!model) return { nmeaPhrase: "unknown" } ;
  // console.log(buf) ;
	var ret = { status: true, nmeaPhrase: type , raw: buf} ;
	for (var c = 0 ; c < model.values.length ; c++) {
			ret[model.values[c]] = listValues[c + 1] ;
			}
	return ret ;
	}
	
	

	