// renvoi un id unique
var uniqueId = (function() {
	var id = 0;
	return function() {
		return id++;
	};
})();


		
		
var commonInstrument = function(JQelement,params) { // Creation d'une cellule dans un TD
	this.params = params || {} ;
	this.JQelement = JQelement ;
	this.connexion = params.connexion ;
	this.nmeaValues = params.nmeaValues ;
	this.suscribers = new Array() ;
	this.gauge = null ;
	this.computePostValue = (undefined === params.computePostValue ? false : params.computePostValue),
	this.computePostAltValue = (undefined === params.computePostAltValue ? false : params.computePostAltValue),
	this.canvasId = 'canvas_' + uniqueId() ;
	this.width = null ;
	this.height = null ;
	
	// Ajoute les preferences a paramsInstrument
	this.params.paramsInstrument.preferences = params.preferences ;

	$(JQelement).html("<canvas id='" + this.canvasId + "' class='canvasInstrument'>") ;

	this.resize() ;
	if (params.instrument) {
		params.paramsInstrument.canvasId = this.canvasId ;
		this.gauge = new params.instrument(this.canvasId,params.paramsInstrument) ;
		}
	if (this.connexion && this.nmeaValues) {
			for (var c = 0 ; c < this.nmeaValues.length ; c++) {
				var suscriber = { phrase: this.nmeaValues[c].phrase, 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this.gauge , nmeaValues:this.nmeaValues[c] }
            						} ;
        this.suscribers.push(suscriber) ;
        }
			this.connexion.suscribe(this.suscribers) ;
      } 
	}
	
commonInstrument.prototype.resize = function() {
			// <TD><DIV JQELEMENT><canvas></DIV></TD>
			var tdContainer = this.JQelement.parent('TD') ;
			var width = tdContainer.innerWidth()  ;
			var height = tdContainer.innerHeight()  ;
			//if (this.width == width && this.height == height) return ;
			this.width = width ;
			this.height = height ;
			this.JQelement.width(width) ;
			this.JQelement.height(height) ;
			$('#' + this.canvasId).width(width) ;
			$('#' + this.canvasId).height(height) ;

			this.params.paramsInstrument.width = $('#' + this.canvasId).innerWidth()  ;
			this.params.paramsInstrument.height = $('#' + this.canvasId).innerHeight() ;
			this.params.paramsInstrument.old = this.gauge ;	// Pour l'historique (sondeur)
			// Recree l'instrument à la bonne taile
			if (this.gauge && this.gauge.destroy) this.gauge.destroy() ;
			delete this.gauge ;
			this.gauge = new this.params.instrument(this.canvasId,this.params.paramsInstrument) ;
			delete this.params.paramsInstrument.old ;
			this.params.paramsInstrument.old = null ;
			}
commonInstrument.prototype.isNumeric = function (n) {
		 return !isNaN(parseFloat(n)) && isFinite(n) ; 
		 }		
commonInstrument.prototype.callbackNmea = function (data,params) {
			if (!this.JQelement.is(":visible") && !this.gauge.memoValue) return ;
      if (!data) return ;	
			if (!params || !params.nmeaValues || !params.nmeaValues.phrase) return ;
      if ( (data.nmeaPhrase  == params.nmeaValues.phrase) 
      			&& data[params.nmeaValues.valueName] !== undefined) { 
      			var value = data[params.nmeaValues.valueName] ;
      			if (value == '') return ;
      			if (this.computePostValue) {
      				value = this.computePostValue(data) ;
      				}
      			else {
      				if (this.isNumeric(value)) {
      					value = parseFloat(data[params.nmeaValues.valueName]) ; 
	      				if (isNaN(value)) value = 0.00 ;
	      				}
	      			}
	      		if (params.callback && this.gauge[params.callback]) {
	      			this.gauge[params.callback].call(this.gauge,value,{ data: data , nmeaParams: params } ) ;
	      			}
      			else this.gauge.setValue.call(this.gauge,value,{ data: data , nmeaParams: params } ) ;
      			}
      if ( (data.nmeaPhrase  == params.nmeaValues.phrase) 
      			&& data[params.nmeaValues.altValueName] !== undefined) { 
      			var value = data[params.nmeaValues.altValueName] ;
      			if (value == '') return ;
      			if (this.computePostAltValue) {
      				value = this.computePostAltValue(data) ;
      				}
      			else {
      				if (this.isNumeric(value)) {
      					value = parseFloat(data[params.nmeaValues.altValueName]) ; 
	      				if (isNaN(value)) value = 0.00 ;
	      				}
	      			}
      			this.gauge.setAltValue.call(this.gauge,value,{ data: data , nmeaParams: params } ) ;
      			}
			} 
       
commonInstrument.prototype.destroy = function() {
  	this.connexion.unsuscribe(this.suscribers) ;
  	if (this.gauge.destroy) this.gauge.destroy() ;
  	} 
  

	
