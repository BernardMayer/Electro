var anemometre = function(JQelement,params) {
	this.parameters = params.paramsInstrument || { } ;
	this.connexion = params.connexion ;
	this.canvasId = 'canvas_' + uniqueId() ;
	this.suscribers = new Array() ;
	this.preferences = params.preferences ;
	this.prefValues = { windAngle: 'Reel' , windSpeed: 'Reel' } ;
	this.JQelement = JQelement ;
	this.steelseries = params.steelseries || steelseries.WindDirection ;
	this.width = null ;
	this.height = null ;
	this.gauge = null ;
	
	JQelement.html("<canvas id='" + this.canvasId + "' class='canvasInstrument'>") ;

	this.parameters.titleString = this.parameters.titleString || 'vent' ;
  this.parameters.frameDesign = this.parameters.frameDesign || steelseries.FrameDesign.BLACK_METAL ;
  this.parameters.backgroundColor = this.parameters.backgroundColor || steelseries.BackgroundColor.WHITE ;
  this.parameters.pointerTypeLatest = this.parameters.pointerTypeLatest || steelseries.PointerType.TYPE2 ;
  this.parameters.pointerColor = this.parameters.pointerColor || steelseries.ColorDef.GREEN ;
  this.parameters.degreeScaleHalf = true ;
  this.parameters.provideWindSpeed = true ;
  this.parameters.pointSymbolsVisible = false ;
  
  this.parameters.lcdTitleStrings = this.parameters.lcdTitleStrings || [ 'vitesse vrai' , 'angle vent vrai'] ;
  this.parameters.section = Array( steelseries.Section(0,160,'rgba(0,255,0,0.3)'),
                            	steelseries.Section(200,360,'rgba(255,0,0,0.3)')) ;
  this.parameters.area = Array(steelseries.Section(0,45,'rgba(0,255,0,0.5)'),
                    			steelseries.Section(315,360,'rgba(255,0,0,0.5)') ) ;
  this.resize() ;
	this.suscribers = [ { phrase: 'VWR', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this }
            						},
            						{ phrase: 'VWT', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this.gauge }
            						} ] ;
  this.connexion.suscribe(this.suscribers) ;
	}
	
anemometre.prototype.callbackNmea = function (data,obj) {
			if (!this.gauge || !data || !this.JQelement.is(":visible")) return ;
			var type    ;
      if (!data) return ;
      if (data.nmeaPhrase == 'VWR') { 
      	type = 'Apparent' ;
      	}
      else {
      	type = 'Reel' ;
      	}

			try {
			if (this.preferences.prefs.windAngle != this.prefValues.windAngle ||
								this.preferences.prefs.windSpeed != this.prefValues.windSpeed) {
						this.prefValues = $.extend( {} , this.preferences.prefs) ;
						var titles = new Array() ;
						titles[0] = this.prefValues.windSpeed == 'Reel' ? 'vitesse Reel' : 'vitesse App.' ;
						titles[1] = this.prefValues.windAngle == 'Reel' ? 'angle Reel' : 'angle App.' ;
						this.gauge.setLcdTitleStrings(titles) ;
						}
			} catch(error) { console.log("erreur preferences " + error) ; }
			
			if (type == this.prefValues.windAngle) {
				var wind_dir = parseInt(data.dir) ;
				if (data.sens == 'L') wind_dir = 360 - wind_dir ;
				var cur_wind = this.gauge.getValueAverage() ;
				this.gauge.setPointerColor(data.sens == 'R' ? steelseries.ColorDef.GREEN : steelseries.ColorDef.RED) ;
				this.gauge.setValueLatest.call(this.gauge,wind_dir) ;
				}
			if (type == this.prefValues.windSpeed) {
				var wind_speed = parseFloat(data.speed) ;
				this.gauge.setWindSpeed(wind_speed) ;
				}
			} ;
	
  
anemometre.prototype.resize = function() {
			var size ;
			if (!$('#' + this.canvasId).is(":visible")) return ;
			var tdContainer = this.JQelement.parent('TD') ;
			var width = tdContainer.innerWidth()  ;
			var height = tdContainer.innerHeight()  ;
			// if (this.width == width && this.height == height) return ;
			this.width = width ;
			this.height = height ;
			this.JQelement.width(width) ;
			this.JQelement.height(height) ;
			// On doit avoir un carre
			if (width > height) size = height ;
			if (height > width) size = width ;
			size -= 20 ;
			$('#' + this.canvasId).width(size) ;
			$('#' + this.canvasId).height(size) ;
			$('#' + this.canvasId).css('margin-top',(height - size) / 2) ;
			this.parameters.size = width ;
			delete this.gauge ;
			this.gauge = new this.steelseries(this.canvasId ,this.parameters) ;
			}
              	
anemometre.prototype.destroy = function() {
  	this.connexion.unsuscribe(this.suscribers) ;
  	} ;