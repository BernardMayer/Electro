var tools = function() {
	var init = function() {
		var html ;
		html = "<table cellpadding=5  style='text-align:left'>" ;
		html += "<tr><td>Mode simulation </td><td><input id='simulButton' type='checkbox' name='simul' value:'1' ></td></tr>" ;
		html += "<tr><td>Angle du vent</td><td><select id='selectAngleVent'><option value='vrai'>vrai</option> <option value='apparent'>apparent</option></select></td></tr>" ;
		html += "<tr><td>Vitesse du vent</td><td><select id='selectVitesseVent'><option value='vrai'>vrai</option> <option value='apparent'>apparent</option></select></td></tr>" ;
		html += "</table>" ;
		$("#tools").html(html) ;
		$('#simulButton').attr('checked',userPreferences.preferences.modeSimulation == "NAVIGATION" ? false : true) ;
		}
	init() ;
	
	$('#selectVitesseVent').val(userPreferences.getPreferences().windSpeed) ;
	$('#selectAngleVent').val(userPreferences.getPreferences().windDir) ;
	$('#simulButton').click( function() {
						if (userPreferences.preferences.modeSimulation == "NAVIGATION") {
							userPreferences.preferences.modeSimulation = "SIMULATION" ;
							$.ajax("../startSimul.php") ;
							}
						 else {
						 	userPreferences.preferences.modeSimulation = "NAVIGATION" ;
						 	$.ajax("../stopSimul.php") ;
						 	}
						$('#simulButton').text(userPreferences.preferences.modeSimulation) ;
						} ) ;
						
						
	$('#selectVitesseVent').click( function() {
						if (userPreferences.getPreferences().windSpeed == 'vrai')
								userPreferences.setPreferences({ windSpeed: 'apparent' }) ;
						else userPreferences.setPreferences({ windSpeed: 'vrai' }) ;
						} ) ;
						
	$('#selectAngleVent').click( function() {
						if (userPreferences.getPreferences().windDir == 'vrai')
								userPreferences.setPreferences({ windDir: 'apparent' }) ;
						else userPreferences.setPreferences({ windDir: 'vrai' }) ;
						} ) ;
						
	}