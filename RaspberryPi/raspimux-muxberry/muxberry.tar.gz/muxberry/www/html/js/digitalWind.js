var digitalWind = function(JQelement,params) {
	this.parameters = params.paramsInstrument || { } ;
	this.connexion = params.connexion ;
	this.canvasId = 'canvas_' + uniqueId() ;
	this.suscribers = new Array() ;
	this.preferences = params.preferences ;
	this.prefValues = { windAngle: 'Reel' , windSpeed: 'Reel' } ;
	this.JQelement = JQelement ;
	this.steelseries = params.steelseries || steelseries.DisplayMulti ;
	this.width = null ;
	this.height = null ;
	this.gauge = null ;
	
	$(JQelement).html("<canvas id='" + this.canvasId + "' class='canvasInstrument'>") ;
  this.resize() ;
	this.suscribers = [ { phrase: 'VWR', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this.gauge }
            						},
            						{ phrase: 'VWT', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this.gauge }
            						} ] ;
  this.connexion.suscribe(this.suscribers) ;
	}
	
digitalWind.prototype.callbackNmea = function (data,obj) {
			if (!this.gauge || !data || !this.JQelement.is(":visible")) return ;
			var type    ;
      if (!data) return ;
      if (data.nmeaPhrase == 'VWR') { 
      	type = 'Apparent' ;
      	}
      else {
      	type = 'Reel' ;
      	}

			try {
			if (this.preferences.prefs.windAngle != this.prefValues.windAngle ||
								this.preferences.prefs.windSpeed != this.prefValues.windSpeed) {
						this.prefValues = $.extend( {} , this.preferences.prefs) ;
						this.parameters.headerString = this.prefValues.windAngle == 'Reel' ? 'Reel ' : 'App. ' ;
						this.parameters.detailString = this.prefValues.windSpeed == 'Reel' ? 'Reel ' : 'App. ' ;
						this.resize() ;
						}
			} catch(error) { console.log("erreur preferences " + error) ; }
			
			if (type == this.prefValues.windAngle) {
				var wind_dir ;
				if (data.sens == 'L') wind_dir =  '> ' + parseInt(data.dir) ;
				else wind_dir =  parseInt(data.dir) + ' <' ;
				this.gauge.setValue(wind_dir) ;
				}
			if (type == this.prefValues.windSpeed) {
				var wind_speed = parseFloat(data.speed) ;
				this.gauge.setAltValue(wind_speed) ;
				}
			} ;
	
digitalWind.prototype.resize = function() {
			// <TD><DIV JQELEMENT><canvas></DIV></TD>
			var tdContainer = this.JQelement.parent('TD') ;
			var width = tdContainer.innerWidth()  ;
			var height = tdContainer.innerHeight()  ;
			//if (this.width == width && this.height == height) return ;
			this.width = width ;
			this.height = height ;
			this.JQelement.width(width) ;
			this.JQelement.height(height) ;
			$('#' + this.canvasId).width(width) ;
			$('#' + this.canvasId).height(height) ;
			this.parameters.width = width  ;
			this.parameters.height = height ;
			if (this.gauge) delete this.gauge ;
			this.gauge = new this.steelseries(this.canvasId ,this.parameters) ;
			} 
			             	
digitalWind.prototype.destroy = function() {
  	this.connexion.unsuscribe(this.suscribers) ;
  	} ;