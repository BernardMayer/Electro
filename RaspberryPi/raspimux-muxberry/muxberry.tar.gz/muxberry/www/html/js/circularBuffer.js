var circularBuffer = function(param) {
	this.minSize = 256 ;
	this.values = new Array() ; // Liste de valeurs
	this.firstIndex = 0 ; // premier element du tableau (le plus ancien)
	this.addIndex = 0 ; // prochain index à memoriser
	this.values ; // nombre de valeurs max initialisee à 100
	this.nValues = this.minSize ; // Nombre d'entrees dans le tableau values
	this.countValues = 0 ; // nombre de valeurs memorises ente 0 et nValues
	this.maxValue = 3 ; // valeur max
	this.index = 0 ;
	
	if ( param instanceof (circularBuffer)) {
			this.values = new Array() ; // Liste de valeurs
			this.values.concat(param.values) ;
			this.firstIndex = param.firstIndex ; // premier element du tableau (le plus ancien)
			this.addIndex = param.addIndex ; // prochain index à memoriser
			this.nValues = param.nValues ; // nombre de valeurs max initialisee à 100
			this.countValues = param.countValues ; // nombre de valeurs memorises ente 0 et nValues
			this.maxValue = param.maxValue ;
			}
	
	else if (typeof(param) == 'number') this.nValues = this.param ;
	else { if (param && param instanceof (Object) && param.size) this.nValues = param.size ;
				 if (param && param instanceof (Object) && param.max) this.maxValue = param.max ;
			}
	}	
	
circularBuffer.prototype.add = function(value) {   // Set the size - also clears the canvas
   		var c			 ;
   		var oldValue = 0 ;
   		if (!value || value == 'undefined') return ;
   		// Si tableau plein
   		if (this.countValues == this.nValues) oldValue = this.values[this.addIndex] ;
			this.values[this.addIndex++] = value ;
			if (this.countValues < this.nValues) this.countValues++ ;
   		if (this.addIndex >= this.nValues) this.addIndex = 0 ;
   		if (this.countValues == this.nValues) this.firstIndex = this.addIndex + 1 ;
   		if (this.firstIndex >= this.nValues) this.firstIndex = 0 ;
   		if (value > this.maxValue) this.maxValue = value ;
   		// Recalcule le max si necessaire
   		if (oldValue == this.maxValue) {
   			for (this.maxValue = 0 , c = 0 ; c < this.countValues ;c++) 
   					if (this.values[c] > this.maxValue) this.maxValue = this.values[c] ;
   			}
   		if (this.maxValue < 3) this.maxValue = 3 ;
   		}  
		   	
circularBuffer.prototype.size = function() { return this.nValues } ;
circularBuffer.prototype.count = function() { return this.countValues } ;	 
circularBuffer.prototype.max = function() { return this.maxValue } ;	 
circularBuffer.prototype.reset = function() { this.index = this.firstIndex ; }
circularBuffer.prototype.value = function() { 
	 	if (this.index == this.nValues) this.index = 0 ;
	 	return this.values[this.index] ;
	 	}
circularBuffer.prototype.next = function() { 
	 	if (++this.index >= this.nValues) this.index -= this.nValues ;
	 	return this.values[this.index] ;
	 	}
circularBuffer.prototype.last = function() { 
	 	var x = addIndex ;
	 	if (addIndex == 0) x = this.nValues - 1 ;
	 	return this.values[x] ;
	 	}
		 
circularBuffer.prototype.resize = function(size) {
			if (typeof(size) != 'number' || !size || size < this.minSize) return  ;
   		var newValues = new Array() ;
			var b , c ;
			this.maxValue = 0 ;
			for (c = 0 ; c < size && c < this.nValues && c < this.countValues ; c++) {
						b = this.firstIndex + c ;
						if (b > this.nValues) b -= this.nValues ;
						newValues[c] = this.values[b] ;
						if (newValues[c] > this.maxValue) this.maxValue = newValues[c] ;
						}
				this.values = newValues ;
				this.nValues = size ;
				this.firstIndex = 0 ;
				this.addIndex = c ;
				this.countValues = c ;
				if (this.addIndex >= size) {
						this.addIndex = 0 ;
						this.firstIndex = 1 ;
						}
		   	}
	