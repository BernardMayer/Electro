
var sondeur = function(canvasId,paramsInstrument) {
	this.max = 0	 ;
	this.scale = 1	 ;
	this.mouseX = -1 ;
	this.mouseY = -1 ;
	this.startMouseX = -1 ;
	this.startMouseY = -1 ;
	this.canvasId = canvasId ;
	// Gestion des valeurs en tableau tournat
	this.buffer = new circularBuffer(100) ;
	this.memoValue = true ; // pour nmeaCommon
	this.sonde = 0 ;
	this.width = 0 ;
	this.height = 0 ;
	this.preferences = paramsInstrument.preferences || {} ;
	
	// Handlers
	var me = this ;
	$('#' + this.canvasId).unbind('mousemove') ;
  $('#' + this.canvasId).mousemove(function(event) {
   				var sondeur = me ;
   				sondeur.mouseX = event.offsetX ;
   				sondeur.mouseY = event.offsetY ;
   				sondeur.repaint() ;
   				} ) ;
   				
	$('#' + this.canvasId).unbind('touchmove') ;
  $('#' + this.canvasId).bind('touchmove',function(event) {
   				var sondeur = me ;
   				var dx ;
   				var dy ;
   				event.preventDefault() ;   				
   				if (sondeur.startMouseX == -1 || sondeur.startMouseY == -1) return ;
   				dx = event.touches[0].pageX - sondeur.startMouseX ;
   				dy = event.touches[0].pageY - sondeur.startMouseY ;
   				sondeur.mouseX += dx ;
   				sondeur.mouseY += dy ;
   				sondeur.startMouseX += dx ;
   				sondeur.startMouseY += dy ;
   				sondeur.repaint() ;
   				} ) ;
   				
   		$('#' + this.canvasId).unbind('touchstart') ;
   		$('#' + this.canvasId).bind('touchstart',function(event) {
   				var sondeur = me ;
   				event.preventDefault() ;
   				if (sondeur.startMouseX == -1 || sondeur.startMouseY == -1) {
   					sondeur.mouseX = event.touches[0].pageX ;
   					sondeur.mouseY = event.touches[0].pageY ;
   					}
   				sondeur.startMouseX = event.touches[0].pageX ;
   				sondeur.startMouseY = event.touches[0].pageY ;
   				sondeur.repaint() ;
   				} ) ;	
  this.repaint() ;  		
	}

sondeur.prototype.getPrefs = function () {
	this.offsetSondeur = parseFloat(this.preferences.prefs.offsetSondeur) || 0.4 ;
	this.largeurBateau = parseInt(this.preferences.prefs.largeurBateau) || 4 ;
	this.tirantEau = parseFloat(this.preferences.prefs.tirantEau) || 1.65 ;
	}
	
sondeur.prototype.repaint = function() {
   		var b , c , h ;
   		var width , height ;
   		var canvas = document.getElementById(this.canvasId) ;
   		var  mainCtx =  canvas.getContext('2d');		
   		// <TD><DIV><canvas></DIV></TD>
   		var tdContainer = $('#' + this.canvasId).parent().parent('TD') ;
   		this.getPrefs() ;
			width = tdContainer.innerWidth()  ;
			height = tdContainer.innerHeight()  ;
			if (width != this.width || height != this.height) {
					this.width = width ;
					this.height = height ;
					canvas.width = width ;
					canvas.height = height ;
					// Regenere le buffer de donnees
					this.scale = (height * 0.6) / this.buffer.max() ;
					this.buffer.resize( Math.floor(width - ((this.largeurBateau / 2) * this.scale) -10))  ;
					}
   		if (!$('#' + this.canvasId).is(":visible")) return ;
			var newScale = (height * 0.6) / this.buffer.max() ;
   		if (newScale != this.scale) {
   			this.scale = newScale ;
				// Regenere le buffer de donnees
				this.buffer.resize( Math.floor(width - ((this.largeurBateau / 2) * this.scale) -10))  ;
				}
    	
    	// Vide l'ecran
   		mainCtx.fillStyle = 'white';
   		mainCtx.beginPath() ;
			mainCtx.lineTo(0,0) ;
			mainCtx.lineTo(width,0) ;
			mainCtx.lineTo(width,height) ;
			mainCtx.lineTo(0,height) ;
			mainCtx.fill(); 		
    			
   		// Remplissage du fond bleu
   		mainCtx.fillStyle = '#66c2ff';
   		mainCtx.beginPath() ;
			mainCtx.lineTo(0,height * 0.2) ;
			mainCtx.lineTo(width,height * 0.2) ;
			mainCtx.lineTo(width,height) ;
			mainCtx.lineTo(0,height) ;
			mainCtx.fill(); 		
			
   		// Remplissage de la hauteur d'eau
   		mainCtx.fillStyle = '#E0CDA9' ; // sable
   		mainCtx.beginPath() ;
   		// L'espace non encore peuple
   		this.buffer.reset() ;
   		if (this.buffer.count()) {
	   		var posX = this.buffer.size() - this.buffer.count() ;
  	 		mainCtx.moveTo(0,(height * 0.2) + (this.buffer.value() * this.scale)) ;
   			mainCtx.lineTo(posX,(height * 0.2) + (this.buffer.value() * this.scale)) ;
   			// Les lignes de sonde memorisees
   			var prevValue = -1 ;
   			var value ;
	   		for (c = 1 ; c < this.buffer.count() ; c++, posX++) {
  	 			value = this.buffer.next() ;
   				if (value == prevValue) continue ;
   				mainCtx.lineTo(posX,(height * 0.2) + (value * this.scale)) ;
   				prevValue = this.buffer.value() ;
					}
				mainCtx.lineTo(width,(height * 0.2) + (this.sonde * this.scale)) ;
				mainCtx.lineTo(width,(height * 0.2)) ;
				mainCtx.lineTo(width,height) ;
				mainCtx.lineTo(0,height) ;
				mainCtx.fill(); 
				}		
   			  		
   		// Dessine le bateau
   		mainCtx.fillStyle = "#C0C0C0" ; // gris silver
   		mainCtx.beginPath() ;	
   		// Ellipse largeurBateau et largeurBateau / 2
   		// largeurBateau / 6 ressort de l'eau
   		var centreX = width - ((this.largeurBateau / 2) * this.scale) - 10 ;
   		var centreY = height * 0.2 - (this.scale * (this.largeurBateau / 8) ) ;
   		var rayonX = (this.largeurBateau / 2) * this.scale ;
   		var rayonY = ((this.largeurBateau / 2) / 2) * this.scale ;
   		mainCtx.ellipse(centreX,centreY,rayonX,rayonY,0,0,Math.PI) ;
   		mainCtx.fill() ;
   		// Point fond de quille
   		mainCtx.beginPath() ;	
   		mainCtx.fillStyle = "#ff9933" ;
   		// startY quille
   		var startY = height * 0.2 + this.tirantEau * this.scale ;
   		// Quille 40 cm de large (2 fois 0.2m)
   		mainCtx.moveTo(centreX + (0.2 * this.scale),startY) ; 	
   		var deltaX = Math.cos(80 * Math.PI / 180) * rayonX ;
   		var deltaY = Math.sin(80 * Math.PI / 180) * rayonY ;
   		mainCtx.lineTo(centreX + deltaX,centreY + deltaY) ;
   		var deltaX = - Math.cos(80 * Math.PI / 180) * rayonX ;
   		mainCtx.lineTo(centreX + deltaX,centreY + deltaY) ;
   		mainCtx.lineTo(centreX - (0.2 * this.scale),startY) ;
  		mainCtx.fill() ;		
			// Materialise la tete sondeur
			// la tete sondeur est a this.(this.largeurBateau / 8) + this.offsetSondeur du centre de l'elipse
			// Calcul du point Y
			var angle = Math.asin( (((this.largeurBateau / 8) + this.offsetSondeur) * this.scale) / rayonY) ;
			angle = angle *180 / Math.PI ;
   		deltaX = Math.cos(angle * Math.PI / 180) * rayonX ;
   		if (angle == 90) deltaY = 0 ;
   		else deltaY = ((this.largeurBateau / 8) + this.offsetSondeur) * this.scale ;
   		mainCtx.beginPath() ;
   		mainCtx.fillStyle = "black" ;
   		mainCtx.arc (centreX + deltaX,
   								 centreY + deltaY,
   								 0.1 * this.scale,
   								 0,2 * Math.PI) ;
   		mainCtx.fill() ;

   		mainCtx.font="20px Georgia";
   		if (this.mouseX >= 0 && this.mouseY >= 0  &&
   			this.mouseY > height * 0.2 && this.mouseY < height - 10) {
	   			var depth = (this.mouseY - (height * 0.2)) / this.scale ;
   				// Le point de sonde
   				mainCtx.beginPath() ;
   				mainCtx.fillStyle = "red" ;
   				mainCtx.arc (this.mouseX,this.mouseY,2,0,2 * Math.PI) ;
   				mainCtx.fill() ;
   				mainCtx.fillStyle = "black" ;
					mainCtx.fillText(parseFloat(depth).toFixed( 2 ) + ' m',this.mouseX + 5,this.mouseY + 5);
					}
			else this.startMouseX = this.startMouseY = -1 ;
			
			mainCtx.fillText(parseFloat(this.sonde).toFixed( 2 ) + ' m',(width / 6) + 10,height * 0.2 + 15) ;
   		}
   		 		   		
sondeur.prototype.setValue = function(value) {
			this.getPrefs() ;
			value += this.offsetSondeur ;
   		if (!value || value == 'undefined') return ;
   		if (value < this.tirantEau / 2) return ;
   		this.buffer.add(value) ;
   		this.sonde = value ;
   		this.repaint() ;
   		}  				 
   			
   

