import * as WebUtil from '../noVNC/app/webutil.js';
import RFB from '../noVNC/core/rfb.js';
import * as jQuery from '../js/Jquery/jquery.3.3.1.js';


export default function createOpencpn(params) {
		if (!params) params = {} ;
		this.askResize = false ;
		this.userPreferences = params.userPreferences || {} ;
		if (!this.userPreferences.prefs) this.userPreferences.prefs = {} ;
    this.rfb = null ; 
    this.host = this.userPreferences.prefs.hostOpencpn || window.location.hostname ;
    this.port = this.userPreferences.prefs.portOpencpn || 5999 ;
    this.username = this.userPreferences.prefs.vncUsername || 'vnc' ;
    this.password = this.userPreferences.prefs.vncPasswd || 'opencpn' ;
          
    $('body').append("<div id='opencpnWindow' class='opencpnWindow userScreen'/>") ;
    $('#opencpnWindow').width(window.innerWidth) ;
    $('#opencpnWindow').height(window.innerHeight) ;
    this.connectVNC() ;
    this.show() ; // Doit etre activée au depart pour ios
    setTimeout(this.watchDog,2000,{ scope: this  }) ; 
    window.onresize = this.resize ;
    }

                		     		       
createOpencpn.prototype.updateState = function () {
    var size = this.rfb._screenSize() ;
    var hiddenOpencpn = false ;
    var hiddenOpencpn = true ;
  	if ((this.meAskResize || this.rfb.resizeSession != true) && size.w && size.h) this.rfb.resizeSession = true ;      
  	      this.meAskResize = false ;
           
    // Le bouton opencpn doit etre cache tant que le status n'a jamais ete connecte 
    if (!$('#opencpnButton').is(":visible")) hiddenOpencpn = true ;
    if (!this.rfb) return ;
    if (this.rfb._rfb_connection_state == "connected") {
    if (hiddenOpencpn) {
        	$('#opencpnButton').show() ; 
        	}
   	  	}       
    }

createOpencpn.prototype.resize = function () {
    var width = $('#body').innerWidth() ;
    var height = $('#body').innerHeight() ;
    $('.userScreen').width(width) ;
    $('.userScreen').height(height) ;
    $('#opencpnWindow').width(width) ;
    $('#opencpnWindow').height(height) ;
    this.meAskResize = true ; 
    } ;        
        		
createOpencpn.prototype.show = function() {
    this.resize() ;
    $('#opencpnWindow').show() ;
    }
        
createOpencpn.prototype.hide = function() {
    $('#opencpnWindow').hide() ;
    }
        
createOpencpn.prototype.connectVNC = function(params) {
    if (params && params.scope) return param.scope.connectVNC.call() ;	
            
		this.rfb = new RFB(document.getElementById('opencpnWindow'),
												  'ws://' + this.host + ':' + this.port, 
                          { repeaterID: '',
                            shared: true,
                            credentials: {  password: this.password } 
                        	}
                        ) ;
    }	
          	
createOpencpn.prototype.watchDog = function(params) {
		if (params && params.scope) 
			return params.scope.watchDog.call(params.scope) ;

    var x ;
    if (!this.rfb) {
     	x = setTimeout(params.scope.watchDog,2000,{ scope: params.scope }) ;
     	return ;
     }
    switch (this.rfb._rfb_connection_state) {
    		case 'disconnected':
             // PP Reconnect
             //console.log("re connect") ;
             this.connectVNC() 
             //console.log("re connect ok") ;
             break ;
        	default:             break;
          }
      this.updateState() ;
      x = setTimeout(this.watchDog,2000,{ scope: this }) ;
      //console.log("WatchDog => " + x ) ;
      }
        	
  
