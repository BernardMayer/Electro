steelseries.speedometre = function(canvas,parameters) {
	//parameters.titleString = parameters.titleString || 'Speedometre' ;
  parameters.frameDesign = parameters.frameDesign || steelseries.FrameDesign.BLACK_METAL ;
  parameters.backgroundColor = parameters.backgroundColor || steelseries.BackgroundColor.WHITE ;
  parameters.pointerTypeAverage = parameters.pointerTypeAverag || steelseries.PointerType.TYPE2 ;
  parameters.pointerColorAverage = parameters.pointerColorAverage || steelseries.ColorDef.GREEN ;
  parameters.pointerTypeLatest = parameters.pointerTypeLatest || steelseries.PointerType.TYPE12 ;
  parameters.pointerColor = parameters.pointerColor || steelseries.ColorDef.WHITE ;
  parameters.pointSymbolsVisible = false ;  
  parameters.secondValue = true ;
  parameters.lcdTitleStrings = [ 'SOG' , 'VITESSE'] ; 
  //parameters.unitString = 'Knts' ; 
  parameters.ledVisible = false ;
  parameters.thresholdVisible = false ;
  parameters.tickFont = "30px Verdana" ;
	$.extend(this,new steelseries.Radial(canvas,parameters)) ;
	}
	
var speedometre = function(JQelement,params) {
	this.parameters = params.paramsInstrument || { } ;
	this.parameters.steelseries = steelseries.speedometre ;
	this.connexion = params.connexion ;
	this.steelseries = steelseries.speedometre ;
	this.JQelement = JQelement ;
	this.canvasId = 'canvas_' + uniqueId() ;
	this.gauge = null ;
	this.width = null ;
	this.height = null ;
	
	JQelement.html("<canvas id='" + this.canvasId + "' class='canvasInstrument'>") ;
	this.suscribers = [ { phrase: 'RMC', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this } },
            					{ phrase: 'VTG', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this } },
            					{ phrase: 'VHW', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this } },
            				 ] ;
  this.resize() ;
  this.connexion.suscribe(this.suscribers) ;
	}
	
speedometre.prototype.callbackNmea = function (data,obj) {
			if (!this.gauge || !data || !this.JQelement.is(":visible")) return ;
      if (!data) return ;
      if (data.nmeaPhrase == "RMC" || data.nmeaPhrase == "VTG") 			
      	if (this.gauge.setValueAverage)	{
  				this.gauge.setValueAverage.call(this.gauge,isNaN(data.sog) ? 0 : data.sog) ;
  			if (this.gauge.setSecondValue)	
  				this.gauge.setSecondValue.call(this.gauge,isNaN(data.sog) ? 0 : data.sog) ;
  			}
  		if (data.nmeaPhrase == "VHW") 			
  			this.gauge.setValue.call(this.gauge,isNaN(data.speed) ? 0 : data.speed) ;
			} ;
 
speedometre.prototype.resize = function() {
			var size ;
			if (!$('#' + this.canvasId).is(":visible")) return ;

			var tdContainer = this.JQelement.parent('TD') ;
			var width = tdContainer.innerWidth()  ;
			var height = tdContainer.innerHeight()  ;
			// if (this.width == width && this.height == height) return ;
			this.width = width ;
			this.height = height ;
			this.JQelement.width(width) ;
			this.JQelement.height(height) ;
			if (width > height) size = height ;
			if (height > width) size = width ;
			size -= 20 ;
			$('#' + this.canvasId).width(size) ;
			$('#' + this.canvasId).height(size) ;
			$('#' + this.canvasId).css('margin-top',(height - size) / 2) ;
			this.parameters.size = width ;

			var canvas = document.getElementById(this.canvasId) ;
   		var  mainCtx =  canvas.getContext('2d');		
   		delete this.gauge ;
			this.gauge = new this.steelseries(this.canvasId ,this.parameters) ;
			}
              	
speedometre.prototype.destroy = function() {
  	this.connexion.unsuscribe(this.suscribers) ;
  	} ;
 
