<?php
// Afficher les erreurs à l'écran
$protectFS = 0 ;

function unProtectFS() {
	global $protectFS ;
	if (!is_dir("/var_orig")) return 0 ;
	if (!($file = @fopen("/var_orig/www/data/tmp/test.tmp","w"))) {
		$x = system("sudo /var/www/data/bin/remountWrite") ;
		if (!($file = @fopen("/var_orig/www/data/tmp/test.tmp","w"))) return -1 ;
		}
	fclose($file) ;
	unlink("/var_orig/www/data/tmp/test.tmp") ;
	$protect = 1 ;
	echo "protect = " ;
	return 0 ;
}

function protectFS() {
	global $protectFS ;
	if ($protectFS == 0) return ;
	$x = system("sudo /var/www/data/bin/remountRead") ;
	$protectFS = 0 ;
	}

// Lecture du fichier de configuration
function sortCmpPhrases($a,$b) {
        return strcmp($a['phrase'],$b['phrase']) ;
        }
        
function _readConfig($file) {
global $listePhrases ;
global $devices ;
global $models  ;
global $counter_device ;


$fd = fopen($file,"r") ;
if ($fd <= 0) {
	printf("Error open %s<BR>",$file) ;
	return ;
	}
while ( ($line = fgets($fd)) ) {
	$line = trim($line) ;
	if (!strncmp($line,"#DEF",4)) {
		$tab = explode("|",$line) ;
		$listePhrases[$tab[1]] = $tab[2] ;
		continue ;
		}
	if (!strlen($line) || !strncmp($line,"#",1) ) continue ;
	$tab = explode("|",$line) ;
	if (!strcmp($tab[0],"GENERIC")) $models[] = new model($tab) ;
	if (!strcmp($tab[0],"DEVICE")) $devices[] = new device($tab) ;
	}
fclose($fd) ;
// Lecture stats
$fd = fopen("/var/www/data/nmeaHub/nmeaHub.stat","r") ;
if ($fd <= 0) {
	printf("Error open var/www/data/nmeaHub/nmeaHub.stat\n") ;
	return ;
	}
while ( ($line = fgets($fd)) ) {
	$line = trim($line) ;
	if (!strlen($line) || !strncmp($line,"#",1) ) continue ;
	$tab = explode("|",$line) ;
		for ($c = 0 ; $c < count($devices) ; $c++) 
			if (!strcmp($devices[$c]->name,$tab[0])) $devices[$c]->addInOut($tab) ;
		}
fclose($fd) ;

reset ($listePhrases) ;
for ($l = 0 ; $l < count($listePhrases) ; $l++ , next($listePhrases)) {
	for ($c = 0 ; $c < count($devices) ; $c++) {
		$devices[$c]->getPhraseId(key($listePhrases)) ;
		}
	}
for ($c = 0 ; $c < count($devices) ; $c++) {
        usort($devices[$c]->tabPhrases, 'sortCmpPhrases');
        }
}

function readConfig($file = "") {
global $devices ;
global $models  ;
global $counter_device ;


$models = array() ;
$devices = array() ;
$counter_device = 0 ;

_readConfig("/var/www/data/nmeaHub/nmeaHub.def") ;
_readConfig("/var/www/data/nmeaHub/nmeaHub.conf") ;
}

function writeConfig() {
global $devices ;
global $models  ;
umask(0) ;
if (unProtectFS() == -1) return ;
$fdw = fopen("/var/www/data/nmeaHub/nmeaHub.conf.tmp","w") ;
if ($fdw <= 0) {
	printf("Error open /var/www/data/nmeaHub/nmeaHub.conf.tmp\n") ;
	return ;
	}

for ($c = 0 ; $c < count($devices) ; $c++) {
	$devices[$c]->write($fdw) ;
	}
fclose($fdw) ;
chmod("/var/www/data/nmeaHub/nmeaHub.conf.tmp",0666) ;
unlink("/var/www/data/nmeaHub/nmeaHub.conf") ;
link("/var/www/data/nmeaHub/nmeaHub.conf.tmp","/var/www/data/nmeaHub/nmeaHub.conf") ;
unlink("/var/www/data/nmeaHub/nmeaHub.conf.tmp") ;
if (is_dir("/var_orig"))
	system ("cp /var/www/data/nmeaHub/nmeaHub.conf /var_orig/www/data/nmeaHub/nmeaHub.conf") ;
protectFS() ;
}
?>
