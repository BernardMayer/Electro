<?php
include "multiplexer.php" ;

class model {
var $name ;
var $tabPhrases = array() ;

function model($tab) {
	$this->name = $tab[1] ;
	for ($c = 2 ; $c < count($tab) && $tab[$c] ; $c+= 3) {
		$this->addPhrase($tab[$c],$tab[$c+1],$tab[$c+2]) ;
		}
	}
		
function getPhraseId($phrase) {
	for ($c = 0 ; $c < count($this->tabPhrases) ; $c++) {
		if (!strcmp($this->tabPhrases[$c]['phrase'],$phrase)) return $c ;
		}
	$this->tabPhrases[] = array(	"phrase" => $phrase , 
								"priority" => 0 , 
								 "output" => 0,
								 "in" => 0 , "out" => 0) ;
	return $c  ;
	}

function addPhrase($phrase,$priority,$output) {
		global $listePhrases ;
		$phrase = trim($phrase) ;
		if (!strlen($phrase)) return ;		
		if (!array_key_exists($phrase,$listePhrases)) $listePhrases[$phrase] = "Undefine" ;
		$c = $this->getPhraseId($phrase) ;
		$this->tabPhrases[$c]['priority'] = $priority ;
		$this->tabPhrases[$c]['output'] = $output ;
		}
	
function write($fd) {
	fprintf($fd,"GENERIC|%s",$this->name) ;
	for ($c = 0 ; $c < count($this->tabPhrases) ; $c++) {
		if (!strlen($this->tabPhrases[$c]['phrase'])) continue ;
		fprintf($fd,"|%s|%s|%s",	$this->tabPhrases[$c]['phrase'],
														$this->tabPhrases[$c]['priority'],
														$this->tabPhrases[$c]['output']) ;
							
		}
	fprintf($fd,"\n") ;
	}
}
?>