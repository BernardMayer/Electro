<?php
function listInstruments() {
global	$listePhrases  ; 
global  $models ;
global	$devices ;
global	$counter_device  ;
// Creation de la table

printf("<TABLE width='100%%' border=1>") ;
	for ($c = 0 ; $c < count($devices) ; $c++) {
		$typeDevice = "TTY" ;
		$ipAdress = "" ;
		$ipPort = "" ;
		$tmpTab = explode(":",$devices[$c]->name) ;
		if (count($tmpTab) == 2) {
			$ipAdress = $tmpTab[0] ;
			$ipPort = $tmpTab[1] ;
			}
		$ipName = false ;
		if (filter_var($ipAdress, FILTER_VALIDATE_IP)) {
			$typeDevice = "TCP" ;
			$ipName = gethostbyaddr ($ipAdress) ;
			}
		// ******** Ligne nickname et save
		printf("<TR><TD>") ;
			printf("<FORM method='POST'>
									<INPUT type='HIDDEN' name='op' value='updateHeader'>
									<INPUT type='HIDDEN' name='deviceId' value='%d'>",$c) ;
			printf("<TABLE border='0' width='100%%'>") ;
			printf("<TR>
									<TD width='90px'>Nom : </TD>
									<TD width='50%%'><input type='text' size='16' name='nickname' value='%s'>
											<INPUT class='saveButton' type='submit' value='Update'>
									</TD>
									<TD>%s</TD>
									<TD width='68px'><INPUT type='submit' value='Detail' class='detailButton'
											onclick='this.form.action=\"detail.php\" ;
																this.form.elements[\"op\"].value=\"\" ;
																this.form.submit() ;
																return false ; '></TD>
							</TR>",$devices[$c]->nickname,$devices[$c]->getTotalStats()) ;
			// ******** Ligne vitesse
			if ($typeDevice == "TTY") {
				printf("<TR><TD>Vitesse</TD>") ;
				printf("<TD> <select name='speed' 
									onchange=\"this.form.submit() ; \">") ;
									printf("<option value='AUTO' %s> AUTO </option>",$devices[$c]->speed == "AUTO" ? "selected" : "") ;
									printf("<option value='4800' %s> 4800 </option>",$devices[$c]->speed == 4800 ? "selected" : "") ;
									printf("<option value='9600' %s> 9600 </option>",$devices[$c]->speed == 9600 ? "selected" : "") ;
									printf("<option value='19200' %s> 19200 </option>",$devices[$c]->speed == 19200 ? "selected" : "") ;
									printf("<option value='38400' %s> 38400 </option>",$devices[$c]->speed == 38400 ? "selected" : "") ;
									printf("<option value='57600' %s> 57600 </option>",$devices[$c]->speed == 56600 ? "selected" : "") ;
							printf("</select>") ;
							printf("<TD></TD>") ;
							printf("</TD>
											<TD>
											<INPUT type='submit' value='Delete' class='deleteButton'
											onclick='if (confirm(\"Delete\") == false) return false ;
																this.form.elements[\"op\"].value=\"deleteHeader\" ;
																this.form.submit() ;
																return false ; '>
											</TD></TR>") ;
					}
				else { // TCP
					printf("<TR><TD></TD><TD></TD>") ;
												printf("</TD>
											<TD></TD>
											<TD>
											<INPUT type='submit' value='Delete' class='deleteButton'
											onclick='if (confirm(\"Delete\") == false) return false ;
																this.form.elements[\"op\"].value=\"deleteHeader\" ;
																this.form.submit() ;
																return false ; '>
											</TD></TR>") ;
					}
				// ******** Nom
				if ($ipName != false) {
						printf("<TR>
								<TD>Device : </TD>
								<TD>%s:%s</TD></TR>",$ipName,$ipPort) ;
						}
				else {
					printf("<TR>
								<TD nowrap>Device Path : </TD>
								<TD nowrap colspan='3'>%s</TD>
								</TR>",$devices[$c]->name) ;
						}
			printf("</TABLE>") ;
	printf("</TD>") ;
	printf("</TR>") ;							
	printf("</FORM>") ;							
	}
printf("</TABLE>") ;
printf("</FORM>\n") ;
}
?>
