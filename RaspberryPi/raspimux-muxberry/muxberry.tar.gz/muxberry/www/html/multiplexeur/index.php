<link href="multiplexer.css" rel="stylesheet" type="text/css" media="screen" />
<?php
include "multiplexer.php" ;
include "listeInstruments.php" ;

//var_dump($_POST) ;
// main
function postHandler() {
global $_POST ;
global $devices ;

if (!isset($_POST["deviceId"])) return ;
$id = $_POST["deviceId"] ;
switch($_POST["op"]) {
	case "updateHeader" : $devices[$id]->getValues() ;
												writeConfig() ; ;
												break ;
	case "deleteHeader" : $devices[$id]->delete = 1 ;
												writeConfig() ; ;
												readConfig() ;
												break ;
	}
}

readConfig() ;
postHandler() ;
?>
<HTML>
<TABLE border=1 width='100%'>
	<TR>
			<TD width='50%'><?php  listInstruments() ; ?> </TD>
			<TD width='50%' valign='top' width='100%'>
			<div style="position:fixed;top:10px;width:100%;" >
				<div id='divIframe'>
					<iframe class='frame' id='dataStream' width='100%'></iframe>
				</div>
			</div>
			</TD>
	</TR>
</TABLE>
