if test `whoami` != root
        then
        echo $0 doit etre execute avec sudo
        exit 1
        fi


#packages
export PATH=$PATH:`pwd`/scripts
export PATH=$PATH:`pwd`/../muxberry/scripts

apt-get update
apt-get upgrade
apt-get install can-utils hostapd dnsmasq php unionfs-fuse \
							  socat ftp i2c-tools

echo "


"
#
#CAN Fichier config.txt
#
question "Voulez vous parametrer /boot/config.txt pour le support CAN"
if test $? -eq 1  
	then
	param-boot
	fi

#
#Fichiers de config reseau hostaps et dnsmasq
#
question "Voulez vous installer le mode Access Point (SSID muxberry pass muwberry) ?"
if test $? -eq 1  
	then
	./scripts/param-network
	fi
echo "-------------------------------------"
echo ""

#Fichiers executables /usr/local/bin
echo "copie des executables vers /usr/local/bin"
cp bin/* /usr/local/bin
saveOrigFile /etc/sudoers
cat etc/sudoers >>/etc/sudoers

#scripts de demarrage
echo "copie des fichiers services nmeaHub et phpWebServer"
cp etc/init.d/nmeaHub /etc/init.d
/usr/sbin/update-rc.d nmeaHub defaults
systemctl daemon-reload

# www
echo "copie des fichiers www"
cd ../muxberry
cp -r www /var
cd ../seaberry
chown -R www-data:www-data /var/www/*
chown root:root /var/www/data/bin/remount*
chmod +s /var/www/data/bin/remount*

#fstab
question "Voulez vous parametrer fstab pour un systeme  safe (readOnly)"
if test $? -eq 1  
	then
	param-fstab
	fi

#crontab root
question "Voulez parametrer crontab root pour le mode protect"
if test $? -eq 1  
	then
	param-crontab
	fi


#bme280 
question "Voulez parametrer bme280 capteur pression barometre"
if test $? -eq 1  
	then
	pip3 install bme280
	fi


