#! /bin/sh
#exec php -f /var/www/data/simul/traces.php /var/www/data/simul/tracesGps.log
exec php -f /var/www/data/simul/traces.php /var/www/data/simul/traces-raspi-mux.log

