<?php
$fileInput = true ;

function openTrace() {
	global $argv ;
	global $fileInput ;
	if (!isset($argv[1]) || !($fd = fopen($argv[1],"r"))) {
		printf("Mode ligne de commande active\n") ;
		$fileInput = false ;
		$fd = fopen('php://stdin', 'r') ;
		}
	return $fd ;
	}
if (!isset($argv) && !file_exists($argv[1])) {
	printf("usage traces.php %s fichier_trace\n") ;
	}
	
$out = popen("socat - TCP:localhost:3335","w") ;
$fd = openTrace()  ;
$lastSendMTA = false ;
while (1) {
	$buf = fgets($fd) ;
	if (!$buf) {
		if ($fileInput) {
				fclose($fd) ;
				$fd = openTrace() ;
				continue ;
				}
			else break ;
			}
		$buf = trim($buf) ;
		if (substr($buf,$buf + strlen($buf) - 3,1) == "*") 
			$buf = substr($buf,0,strlen($buf) - 3) ; 
		if (substr($buf,$buf + strlen($buf) - 2,1) == "*") 
			$buf = substr($buf,0,strlen($buf) - 2) ; 
		// recalcul du checksum
		for ($cks = 0 , $c = 1 ; $c < strlen($buf) ; $c++) {
			$cks = $cks ^ ord($buf[$c]) ;
			}
		$buf = $buf . sprintf("*%02x\r\n",$cks) ;
		usleep (strlen($buf) * (800000 / 480)) ;
/*
		// Se synchronise su MTA centrale une fois toutes les 4 secondes
		while ($lastSendMTA && $lastSendMTA > time() - 4) {
			usleep(100000) ;
			}
*/
		if (!fputs($out,$buf)) break ;
		if (!strncmp($buf,"\$IIMTA",6)) {
			$lastSendMTA = time() ;
			}
		}
