<?php
header("Access-Control-Allow-Origin: *");
?>
<!DOCTYPE html>
<html>
<head>
    <title>seaBerry</title>
    <meta charset="UTF-8">
    <meta name="author" content="Pascal PINOT">
    <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame
                Remove this if you use the .htaccess -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!-- Apple iOS Safari settings -->
    <!-- <meta name="apple-mobile-web-app-capable" content="yes"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	

    <!-- Stylesheets -->

    <link rel="stylesheet" href="css/vnc.css">
    
    <script language='javascript' src="../repetiteur/js/Jquery/jquery.3.3.1.js"></script>
    

</head>

<body id='body'>
<script type="module">
import createVNC from './createVNC.js';
// Memorise Opencpn dans document pour avoir un acces des scripts non importes
$(document).ready( function() {
	var mainObject = new createVNC() ;
	} ) ;
</script>
</body>


