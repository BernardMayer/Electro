import * as WebUtil from '../repetiteur/noVNC/app/webutil.js';
import RFB from '../repetiteur/noVNC/core/rfb.js';
import * as jQuery from '../repetiteur/js/Jquery/jquery.3.3.1.js';


export default function createVNC(params) {
		if (!params) params = {} ;
		this.askResize = false ;
		this.userPreferences = params.userPreferences || {} ;
		if (!this.userPreferences.prefs) this.userPreferences.prefs = {} ;
    this.rfb = null ; 
    this.host = this.userPreferences.prefs.hostOpencpn || window.location.hostname ;
    this.host="192.168.1.47" ;
    this.port = this.userPreferences.prefs.portOpencpn || 5999 ;
    this.username = this.userPreferences.prefs.vncUsername || 'pi' ;
    this.password = this.userPreferences.prefs.vncPasswd || 'gudhull' ;
          
console.log(this.host + " " + this.port + " " + this.username + " " + this.password) ;

    $('body').append("<div id='vncWindow' class='vncWindow userScreen'/>") ;
    $('#vncWindow').width(window.innerWidth) ;
    $('#vncWindow').height(window.innerHeight) ;
    this.connectVNC() ;
    this.show() ; // Doit etre activée au depart pour ios
    setTimeout(this.watchDog,2000,{ scope: this  }) ; 
    window.onresize = this.resize ;
    }

                		     		       
createVNC.prototype.updateState = function () {
    var size = this.rfb._screenSize() ;
    var hiddenOpencpn = false ;
    var hiddenOpencpn = true ;
  	if ((this.meAskResize || this.rfb.resizeSession != true) && size.w && size.h) this.rfb.resizeSession = true ;      
  	      this.meAskResize = false ;
           
    if (!this.rfb) return ;
    if (this.rfb._rfb_connection_state == "connected") {
   	  	}       
    }

createVNC.prototype.resize = function () {
    var width = $('#body').innerWidth() ;
    var height = $('#body').innerHeight() ;
    $('.userScreen').width(width) ;
    $('.userScreen').height(height) ;
    $('#vncWindow').width(width) ;
    $('#vncWindow').height(height) ;
    this.meAskResize = true ; 
    } ;        
        		
createVNC.prototype.show = function() {
    this.resize() ;
    $('#vncWindow').show() ;
    }
        
createVNC.prototype.hide = function() {
    $('#vncWindow').hide() ;
    }
        
createVNC.prototype.connectVNC = function(params) {
    if (params && params.scope) return param.scope.connectVNC.call() ;	
 console.log("connect") ;
		this.rfb = new RFB(document.getElementById('vncWindow'),
		  'ws://' + this.host + ':' + this.port, 
                          { repeaterID: '',
                            shared: true,
			    logging: 'debug' ,
                            credentials: {  username: this.username, password: this.password } 
                       	}
                        ) ;
    }	
          	
createVNC.prototype.watchDog = function(params) {
		if (params && params.scope) 
			return params.scope.watchDog.call(params.scope) ;

    var x ;
    if (!this.rfb) {
     	x = setTimeout(params.scope.watchDog,2000,{ scope: params.scope }) ;
     	return ;
     }
    switch (this.rfb._rfb_connection_state) {
    		case 'disconnected':
             // PP Reconnect
             //console.log("re connect") ;
             this.connectVNC() 
             //console.log("re connect ok") ;
             break ;
        	default:             break;
          }
      this.updateState() ;
      x = setTimeout(this.watchDog,2000,{ scope: this }) ;
      //console.log("WatchDog => " + x ) ;
      }
        	
  
