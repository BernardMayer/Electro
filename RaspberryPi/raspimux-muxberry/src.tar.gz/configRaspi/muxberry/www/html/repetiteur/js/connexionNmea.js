import * as WebUtil from '../noVNC/app/webutil.js';

export default function connexionNmea  (uri,params) {
			this.suscribers = new Array() ;
			this.stateOpened = false ;
			this.bufToSend = '' ;	
    	this.uri = uri ;
    	this.createSocket(params) ;
    	}	
    	
    	
connexionNmea.prototype.createSocket = function(params,recall) {
	var me = this ;
	if (!recall && params && params.scope && params.scope.createSocket) {
		console.log("reditect create socket") ;
		me = params.scope ;
		return me.createSocket.call(me,params,true) ;
		}
	//console.log(this) ;
	//console.log(params) ;
	params.redirect = false ;
	this.ws = new WebSocket(me.uri) ;
	this.ws.onmessage = function (event) {
			var suscribers = me.suscribers ;
			var msg = event.data ;
			if (!msg.length) return ;
			var tabMsg = msg.split("\n") ;
			for (var n = 0 ; n < tabMsg.length ; n++) {
				if (tabMsg[n] == "") continue ;
				try {
						var data = decodeNmea(tabMsg[n]) ;
						} catch (e) {
							console.error("Parsing error:", e) ; 
							console.log(msg) ;
							continue ;
							}
					if (data.nmeaPhrase == "unknown") continue ;
					for (var c = 0 ; c < suscribers.length ; c++) {
							if (data.nmeaPhrase == suscribers[c].phrase) {
							if (me.suscribers[c].callback && me.suscribers[c].scope) 
								me.suscribers[c].callback.call(me.suscribers[c].scope,data,me.suscribers[c].params) ;
							else me.suscribers[c].callback(data,me.suscribers[c].params) ;
							}
						}
					}
				} ;
				
				
	this.ws.onopen = function () {
			me.stateOpened = true ;
			if (params && params.callback) {
					if (params.callbackScope) params.callback.call(params.callbackScope,params) ;
					else params.callback(params) ;
					}
			} ;
									
	this.ws.onclose = function (e) {
			me.stateOpened = false ;
			if (params && params.callback) {
				if (params.callbackScope) params.callback.call(params.callbackScope,params) ;
				else params.callback(params) ;
				}
			} ;
								
	this.ws.onerror = function (e) {
			console.log("WebSocket nmea on-error event " + e);
			} ;
					
	this.ws.send = function(str) {
		me.bufToSend = me.bufToSend.concat(str) ;
		if (me.stateOpen == true) me.ws.send(me.bufToSend) ;
		}
  }

    
connexionNmea.prototype.suscribe = function(suscribers) { // suscribe to an NMEA phrase
        		if (!suscribers) return ;
        		if (!Array.isArray(suscribers)) {
        			var tmp = new Array() ;
        			tmp.push(suscribers) ;
        			suscribers = tmp ;
        			} 
        		for (var c = 0 ; c < suscribers.length ; c++) {
        			suscribers[c].phrase = suscribers[c].phrase.toUpperCase() ;
        			this.suscribers.push(suscribers[c]) ;
        			}
        		}
        		
connexionNmea.prototype.unsuscribe = function(suscribers) { // unsuscribe to an NMEA phrase
        		if (!suscribers) return ;
        		if (!Array.isArray(suscribers)) {
        			var tmp = new Array() ;
        			tmp.push(suscribers) ;
        			suscribers = tmp ;
        			} 
        		for (var c = 0 ; c < suscribers.length ; c++) {
        			suscribers[c].phrase = suscribers[c].phrase.toUpperCase() ;
        			for (var x = 0 ; x < this.suscribers.length ; x++) {
        				if (this.suscribers[x] == suscribers[c] ) {
        					this.suscribers.splice(x,1) ;
        					break ;
        					}
        				}
        			}
        		}