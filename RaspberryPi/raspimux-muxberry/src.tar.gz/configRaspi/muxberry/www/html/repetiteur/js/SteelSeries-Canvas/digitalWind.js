var digitalWind = function(JQelement,params) {
	this.parameters = params.paramsInstrument || { } ;
	this.connexion = params.connexion ;
	this.canvasId = 'canvas_' + uniqueId() ;
	this.suscribers = new Array() ;
	this.preferences = params.preferences ;
	this.prefValues = { windAngle: 'Reel' , windSpeed: 'Reel' } ;
	this.JQelement = JQelement ;
	this.steelseries = params.steelseries || steelseries.DisplayMulti ;
	this.width = null ;
	this.height = null ;
	this.gauge = null ;
	
	JQelement.html("<canvas id='" + this.canvasId + "' class='canvasInstrument'>") ;
  this.resize() ;
	this.suscribers = [ { phrase: 'VWR', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this }
            						},
            						{ phrase: 'VWT', 
            						callback: this.callbackNmea, 
            						scope: this, 
            						params: { gauge: this.gauge }
            						} ] ;
  this.connexion.suscribe(this.suscribers) ;
	}
	
anemometre.prototype.callbackNmea = function (data,obj) {
			if (!this.gauge || !data || !this.JQelement.is(":visible")) return ;
			var type    ;
      if (!data) return ;
      if (data.nmeaPhrase == 'VWR') { 
      	type = 'Apparent' ;
      	}
      else {
      	type = 'Reel' ;
      	}

			try {
			if (this.preferences.prefs.windAngle != this.prefValues.windAngle ||
								this.preferences.prefs.windSpeed != this.prefValues.windSpeed) {
						this.prefValues = $.extend( {} , this.preferences.prefs) ;
						this.parameters.headerString = this.prefValues.windAngle == 'Reel' ? 'angle Reel' : 'angle App.' ;
						this.parameters.detailString = this.prefValues.windSpeed == 'Reel' ? 'vitesse Reel' : 'vitesse App.' ;
						this.resize() ;
						}
			} catch(error) { console.log("erreur preferences " + error) ; }
			
			if (type == this.prefValues.windAngle) {
				var wind_dir ;
				if (data.sens == 'L') wind_dir =  '> ' + parseInt(data.dir) ;
				else wind_dir =  parseInt(data.dir) + ' <' ;
				this.gauge.setValue(wind_dir) ;
				}
			if (type == this.prefValues.windSpeed) {
				var wind_speed = parseFloat(data.speed) ;
				this.gauge.setAltValue(wind_speed) ;
				}
			} ;
	
  
anemometre.prototype.resize = function() {
			var size ;
			if (!$('#' + this.canvasId).is(":visible")) return ;
			var tdContainer = this.JQelement.parent('TD') ;
			var width = tdContainer.innerWidth()  ;
			var height = tdContainer.innerHeight()  ;
			// if (this.width == width && this.height == height) return ;
			this.width = width ;
			this.height = height ;
			this.JQelement.width(width) ;
			this.JQelement.height(height) ;
			// On doit avoir un carre
			if (width > height) size = height ;
			if (height > width) size = width ;
			size -= 20 ;
			$('#' + this.canvasId).width(size) ;
			$('#' + this.canvasId).height(size) ;
			$('#' + this.canvasId).css('margin-top',(height - size) / 2) ;
			this.parameters.size = width ;
			delete this.gauge ;
			this.gauge = new this.steelseries(this.canvasId ,this.parameters) ;
			}
              	
anemometre.prototype.destroy = function() {
  	this.connexion.unsuscribe(this.suscribers) ;
  	} ;