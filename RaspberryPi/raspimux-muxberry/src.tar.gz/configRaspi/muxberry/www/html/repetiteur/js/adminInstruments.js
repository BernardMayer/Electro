export default  function adminInstruments (instruments) {
	// On doit attendre le retour des preferences
	$('#body').append("<div id='adminInstruments' class='userScreen'>\
											<div id='adminWin' class='adminInstruments containerInstrument'/>\
											<div id='adminCreateWin' class='adminInstruments containerInstrument'/>\
										</div>") ;
	this.jQContainer = $('#adminInstruments') ;
	this.jQWin = $('#adminWin') ;
	this.jQCreateWin = $('#adminCreateWin') ;
	this.instruments = instruments ;
	var myAdmin = this ;
	instruments.setLcdColor(instruments.lcdColor) ;

	this.jQWin.append("<TABLE width='100%'>\
				<TR><TD colspan='2'><center>Parametres generaux</center></TD</TR>\
				<TR>\
					<TD>Background : </TD><TD><select id='adminSelectBackground'/></TD>\
				</TR>\
				<TR>\
					<TD>Largeur bateau : </TD><TD><input id='adminLargeurBateau'/></TD>\
				</TR>\
				<TR>\
					<TD>Tirant d'eau : </TD><TD><input id='adminTirantEau'/></TD>\
				</TR>\
				<TR>\
					<TD>Offset sonde : </TD><TD><input id='adminOffsetSonde'/></TD>\
				</TR>\
				<TR>\
					<TD> Angle vent : </TD><TD><select id='adminSelectWindAngle'/></TD>\
				</TR>\
				<TR>\
					<TD> Vitesse vent : </TD><TD><select id='adminSelectWindSpeed'/></TD>\
				</TR>\
				</TABLE>\
				<TABLE width='100%'>\
				<TR><TD colspan='3'><center>Parametres page</center></TD</TR>\
				<TR style='font-size:20px' align='center'>\
					<TD>Editer page</TD>\
					<TD>Ajouter Page</TD>\
					<TD>Supprimer Page</TD>\
				</TR>\
				<TR align='center' style='font-size:20px'>\
					<TD><select id='adminSelectEditPage'/></TD>\
					<TD><button id='adminButtonAddPage'>Ajouter</button></TD>\
					<TD><select id='adminSelectDeletePage'/></TD>\
				</TR>\
				<TABLE>\
				") ;
	// ********************************************************************
	// Selection de  l'offset sonde
	// Ajoute les options
	var input = $('#adminOffsetSonde') ;
	input.val(instruments.preferences.prefs.offsetSondeur) ;
	input.blur(function() { 
					var value = $('#adminOffsetSonde')[0].value ;
					instruments.preferences.prefs.offsetSondeur = value ;
					instruments.preferences.savePreferences() ;
					} ) ;
					
	input = $('#adminLargeurBateau') ;
	input.val(instruments.preferences.prefs.largeurBateau) ;
	input.blur(function() { 
					var value = $('#adminLargeurBateau')[0].value ;
					instruments.preferences.prefs.largeurBateau = value ;
					instruments.preferences.savePreferences() ;
					} ) ;
						
	input = $('#adminTirantEau') ;
	input.val(instruments.preferences.prefs.tirantEau) ;
	input.blur(function() { 
					var value = $('#adminTirantEau')[0].value ;
					instruments.preferences.prefs.tirantEau = value ;
					instruments.preferences.savePreferences() ;
					} ) ;	
					
	// ********************************************************************
	// Selection du background ecran
	// Ajoute les options
	input = $('#adminSelectBackground') ;
	for ( var key in steelseries.LcdColor ) {
			input.append($('<option>', {
    				value: key,
    				text:  key,
    				selected: instruments.lcdColor == steelseries.LcdColor[key] ? true : false 
						}));
	   }
	input.change(function() { 
					var value = $('#adminSelectBackground')[0].value ;
					var lcdColor = steelseries.LcdColor[value] ;
					instruments.preferences.prefs.color = value ;
					var lcdColor = steelseries.LcdColor[value] ;
					instruments.setLcdColor(lcdColor) ;
					instruments.preferences.savePreferences() ;
					$('#adminInstruments').css('color', lcdColor.textColor) ;
					} ) ;
					
	// ********************************************************************
	// Parametre Offset sonde
	
	// ********************************************************************
	// Parametre Vent
	var inputAngle = $('#adminSelectWindAngle') ;
	var inputSpeed = $('#adminSelectWindSpeed') ;
	if (instruments.preferences.windAngle == "undefined") instruments.preferences.windAngle = 0 ;
	if (instruments.preferences.windSpeed == "undefined") instruments.preferences.windAngle = 0 ;
	inputAngle.append($('<option>', { value: 'Reel', text:  'Reel',
			selected: instruments.preferences.prefs.windAngle == 'Reel' ? true : false } )) ;
	inputAngle.append($('<option>', { value: 'Apparent', text:  'Apparent',
			selected: instruments.preferences.prefs.windAngle == 'Apparent' ? true : false } )) ;
	inputSpeed.append($('<option>', { value: 'Reel', text:  'Reel',
			selected: instruments.preferences.windSpeed == 'Reel' ? true : false } )) ;
	inputSpeed.append($('<option>', { value: 'Apparent', text:  'Apparent',
			selected: instruments.preferences.prefs.windSpeed == 'Apparent' ? true : false } )) ;
	inputAngle.change(function() { 
					instruments.preferences.prefs.windAngle = $('#adminSelectWindAngle')[0].value ;
					instruments.preferences.savePreferences() ;
					} ) ;
	inputSpeed.change(function() { 
					instruments.preferences.prefs.windSpeed = $('#adminSelectWindSpeed')[0].value ;
					instruments.preferences.savePreferences() ;
					} ) ;

	// ********************************************************************
	// Parametres Edition page
	// Parametres suppression page
	this.updateFromPreferences() ; 
	// ********************************************************************
	// Callback delete page
	// ********************************************************************
	input = $('#adminSelectDeletePage') ;
	input.change(function() { 
					var value = $('#adminSelectDeletePage')[0].value ;
					if (value == "") return ;
					if (confirm('Supprimer page : ' + value)) {	
						$('#adminWin').find('select option[value=\'' + value + '\']').remove() ;
						instruments.deletePage(value) ;
						instruments.preferences.savePreferences() ;
						}
					} ) ;
		// ********************************************************************
	// Callback edit page
	// ********************************************************************
	input = $('#adminSelectEditPage') ;
	input.change(function() { 
					var value = $('#adminSelectEditPage')[0].value ;
					if (value == "") return ;
					myAdmin.editPage.call(myAdmin,value) ;
					} ) ;
	// ********************************************************************
	// Callback add page
	// ********************************************************************
	$('#adminButtonAddPage').click( function() {
						myAdmin.editPage.call(myAdmin) ;
						} ) ;
						
	window.addEventListener("resize", this.resize.bind(this)) ;
	this.hide() ;
	}
	
adminInstruments.prototype.updateFromPreferences = function() {
	var inputEdit = $('#adminSelectEditPage') ;
	var inputDelete = $('#adminSelectDeletePage') ;
	$(inputEdit.find('option')).remove() ;
	$(inputDelete.find('option')).remove() ;
	inputEdit.append($('<option>', { value: "" , text: '...' } )) ;
	inputDelete.append($('<option>', { value: "" , text: '...' } )) ;
	for ( var c = 0 ; c < this.instruments.listePages.length ; c++) {	
			if (this.instruments.listePages[c].editable == false) continue ;
			var params = { value: this.instruments.listePages[c].name , text:  this.instruments.listePages[c].name } ;
			inputEdit.append($('<option>', params)) ;
			inputDelete.append($('<option>', params)) ;
	   }	
	}
	   
adminInstruments.prototype.resize = function() {
    this.jQContainer.width($('#body').innerWidth()) ;
    this.jQContainer.height($('#body').innerHeight() ) ;
    var delta = Math.abs(this.jQWin.width() - this.jQWin.innerWidth()) ;
    this.jQWin.width(this.jQContainer.innerWidth() - delta) ;
    this.jQCreateWin.width(this.jQContainer.innerWidth() - delta) ;
    delta = Math.abs(this.jQWin.height() - this.jQWin.innerHeight()) ;
    this.jQWin.height(this.jQContainer.innerHeight() - delta) ;
    this.jQCreateWin.height(this.jQContainer.innerHeight() - delta) ;
  	}
		
adminInstruments.prototype.show = function() {
		this.resize() ;
		this.jQWin.show() ;
		this.jQCreateWin.hide() ;
	  this.jQContainer.show() ;
		}

adminInstruments.prototype.hide = function() {
	  this.jQContainer.hide() ;
		}
	
adminInstruments.prototype.editPage = function(name) {
	this.nomPage = '' ;
	this.layout = 'single'   ;
	this.typeLayout = new Array ( 'single' , 'doubleH' , 'doubleV' , 'double/single' , 'grid' ) ;
	this.instrumentNames = new Array ( 'Digital speedo' , 'Digital compass' ,
																 'Digital true wind' , 'Digital depth' ) ;
	this.oldName = name ;
	var me = this ;	
	
	this.doTabScreenItems = function() {
		var html ;
		$('#adminScreenItems').html('') ;
		switch(this.layout) {
			case 'single' : html = "<TR><TD class='amdinScreenItem' screen='1'>1</TD></TR>" ; 
								 break ;
			case 'doubleV' : html = "<TR><TD class='amdinScreenItem' screen='1'>1</TD>\</TR>\
												 <TR><TD class='amdinScreenItem' screen='2'>2</TD></TR>" ; 
								 break ;
			case 'doubleH' : html = "<TR><TD class='amdinScreenItem' screen='1'>1</TD>\
											   		 <TD class='amdinScreenItem' screen='2'>2</TD></TR>" ; 
								 break ;
			case 'double/single' : html = "<TR><TD class='amdinScreenItem' screen='1'>1</TD>\
													<TD  class='amdinScreenItem' screen='3' colspan=2 rowspan=2>3</TD></TR>\
												 <TR><TD class='amdinScreenItem' screen='2'>2</TD></TR>" ;
								 break ;
			case 'grid' : html = "<TR><TD class='amdinScreenItem' screen='1'>1</TD>\
												     <TD class='amdinScreenItem' screen='2'>2</TD></TR>\
												 <TR><TD class='amdinScreenItem' screen='3'>3</TD>\
												     <TD class='amdinScreenItem' screen='4'>4</TD></TR>" ;
								 break ;
			default  : html ="<TR><TD id='amdinScreen_1'>1</TD></TR>" ; 
								 break ;
			}
		$('#adminScreenItems').html("<TABLE class='adminTabScreen'>" + html + "</TABLE>") ;
		$('.amdinScreenItem').append("<BR><select>Instrument : </select>") ;
		var tabSelect = $('#adminScreenItems').find('select') ;
		for (var c = 0 ; c < tabSelect.length ; c++) {
			for (var b = 0 ; b < this.instruments.listeInstruments.length ; b++) {
				var params = { value: this.instruments.listeInstruments[b].name , text:  this.instruments.listeInstruments[b].name } ;
				if (this.instrumentNames[c] == this.instruments.listeInstruments[b].name) params.selected = true ;
				$(tabSelect[c]).append($('<option>', params)) ;
				var me = this ;
				$(tabSelect[c]).change(function() {
					var index = $(this).parent('.amdinScreenItem').attr('screen') - 1 ;
					me.instrumentNames[index] = this.value ;
					} ) ;
				}
			}
		}	
			
	this.jQCreateWin.html("") ;
	this.jQCreateWin.append("<TABLE width='100%'>\
				<TR><TD colspan='2'><center>Parametres page</center></TD</TR>\
				<TR>\
					<TD width='50%'>Nom : </TD><TD width='50%'><input id='adminNomPage'/></TD>\
				</TR>\
				<TR>\
					<TD>Disposition: </TD>\
						<TD><TABLE>\
									<TR>\
										<TD><img layoutValue='0' src='images/layout-1.png' class='adminLayoutIMG'></TD>\
										<TD><img layoutValue='1' src='images/layout-2.png' class='adminLayoutIMG'></TD>\
									</TR>\
									<TR>\
										<TD><img layoutValue='2' src='images/layout-3.png' class='adminLayoutIMG'></TD>\
										<TD><img layoutValue='3' src='images/layout-4.png' class='adminLayoutIMG'></TD>\
									</TR>\
									<TR>\
										<TD><img layoutValue='4' src='images/layout-5.png' class='adminLayoutIMG'></TD>\
									</TR>\
								</TABLE>\
						</TD>\
						</TR>\
						<TR>\
							<TD colspan='2' width='100%'><DIV id='adminScreenItems' width='100%'></DIV></TD>\
						</TR>\
						<TR>\
							<TD  colspan='2'><INPUT id='adminEnregistrer' type='button' value='ENREGISTER'></TD>\
						</TR>\
				</TABLE>\
				") ;
	this.jQWin.hide() ;
	this.jQCreateWin.show() ;
	if (name) {
		for (var c = 0 ; c < this.instruments.listePages.length ; c++) {
			if (this.instruments.listePages[c].name == name) break ;
			}
		if (c < this.instruments.listePages.length) {
			this.nomPage = name ;
			$('#adminNomPage').attr('value',name) ;
			this.layout = this.instruments.listePages[c].layout ;
			this.instrumentNames = this.instruments.listePages[c].instrumentNames ;
			}
		}
	this.doTabScreenItems() ;
	
	// ********************************************************************
	// Selection du nom de page
	var input = $('#adminNomPage') ;
	input.bind('blur',{ scope: this } ,function(event) { 
					var value = $('#adminNomPage')[0].value ;
					event.data.scope.nomPage = value ;
					} ) ;

	// ********************************************************************
	// Selection du layout
	var curLayout = this.typeLayout.indexOf(this.layout) ;
	var tabButton = this.jQCreateWin.find('.adminLayoutIMG') ;
	for (var c = 0 ; c < tabButton.length ; c++) {
		var button = tabButton[c] ;
		$(button).bind('click ', { scope: this } ,  function(event) {
				var value = $(this).attr('layoutValue') ;
				event.data.scope.layout = event.data.scope.typeLayout[parseInt(value)] ;
				event.data.scope.doTabScreenItems.call(event.data.scope) ;
				}	) ;
			}
		// Bouton enregistrer
		var me = this ;	
		$('#adminEnregistrer').click(function () {
			var page = me.instruments.createPage(me.layout,me.instrumentNames,me.nomPage,true) ;
			if (me.oldName) {
				me.instruments.updatePage(me.oldName,page) ;
				}
			else me.instruments.addPage(page) ;
			me.updateFromPreferences() ;
			me.instruments.setPage(me.nomPage) ;
			me.instruments.preferences.savePreferences() ;
			} ) ;
}