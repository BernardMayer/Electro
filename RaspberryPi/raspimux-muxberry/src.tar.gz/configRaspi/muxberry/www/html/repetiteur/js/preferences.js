var preferences = function(params) {
	this.prefs = {
		hostNmea: 'muxberry' ,
		portNmea: 3337 ,
		hostOpencpn: 'seaberry' ,
		portOpencpn: 5999 ,
		vncUsername: 'opencpn' ,
		vncPasswd: 'opencpn' ,
		windAngle: 'Apparent' ,
		windSpeed: 'Reel' ,
		largeurBateau: '4',
		tirantEau: '1.65',
		offsetSondeur: '0.4',
		modeSimulation: false ,
		currentPage: 0		
		}	;						
	this.loadPreferences(params || {} ) ;
	}
		
preferences.prototype.loadPreferences = function(params) {
				var me = this ;
				$.ajax({url: "php/getPreferences.php", success: function(resultString) {
				var result = { status: false } ;
				try {
					var result = JSON.parse(resultString) ;
					}
				catch (error) {
					console.log ("Erreur retour preferences.php " + error) ;
					}
				if (result.status == true) {
					if (result.warning && result.warning != '') alert(result.warning) ;
					me.prefs = $().extend(me.prefs,result) ;
					}
				else alert(result.errorMessage || "error") ;
				if (params.callback) 
						if (params.scope) params.callback.call(params.scope,params) ;
						else params.callback(params) ;
				} ,
				error: function(xhr,status,error) {
					console.log("error ajax") ;
					alert("error getPreferences()") ;
			 	} ,
			 	async: true
			 	} ) ;
		}
		
preferences.prototype.savePreferences = function() {
				var jsonPrefs = JSON.stringify(this.prefs) ;
				$.ajax({url: "php/setPreferences.php?preferences=" + jsonPrefs , success: function(result){
				} } ) ;
		}
		
preferences.prototype.getPreferences = function() { return this.preferences } ;		
		
preferences.prototype.setPreferences = function(preferences) {
			if (typeof preferences == 'object') {
				$.extend(this.preferences,preferences) ;
				this.savePreferences() ;
				}
			return this.preferences ;
			}
