<?php
header("Access-Control-Allow-Origin: *");
?>
<!DOCTYPE html>
<html>
<head>
    <title>seaBerry</title>
    <meta charset="UTF-8">
    <meta name="author" content="Pascal PINOT">
    <!-- Always force latest IE rendering engine (even in intranet) & Chrome Frame
                Remove this if you use the .htaccess -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <!-- Apple iOS Safari settings -->
    <!-- <meta name="apple-mobile-web-app-capable" content="yes"> -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	

    <!-- Stylesheets -->

    <link rel="stylesheet" href="css/repetiteur.css">
    
    <script language='javascript' src="js/Jquery/jquery.3.3.1.js"></script>
    <script language='javascript' src="js/SteelSeries-Canvas/steelseries.js"></script>
    <script language='javascript' src="js/SteelSeries-Canvas/tween.js"></script>
    <script language='javascript' src="js/circularBuffer.js"></script>
    <script language='javascript' src="js/consoleTablette.js"></script>
    <script language='javascript' src="js/commonInstruments.js"></script>
    <script language='javascript' src="js/decodeNmea.js"></script>
    <script language='javascript' src="js/digitalWind.js"></script>
    <script language='javascript' src="js/wind.js"></script>
    <script language='javascript' src="js/sondeur.js"></script>
    <script language='javascript' src="js/speedometre.js"></script>
    <script language='javascript' src="js/tools.js"></script>
    <script language='javascript' src="js/preferences.js"></script>
    <script language='javascript' src="js/ais.js"></script>
    <script language='javascript' src="js/autoroute.js"></script>
    <script language='javascript' src="js/LatLon.js"></script>
    <script language='javascript' src='js/ais/aivdmDecode.js'> </script>
    <script language='javascript' src='js/ais/sprintf.js'> </script>
    <script language='javascript' src='js/ais/variable_.js'> </script>
    <script language='javascript' src="js/instruments.js"></script>
    

</head>

<body id='body'>
 <div id="toolBar" class="toolBar">
 	<TABLE id="toolBarMenu" class="toolBarMenu"><TR></TR></TABLE>
	<TABLE id="toolBarLeft" class="toolBarLeft"><TR></TR></TABLE>
	<TABLE id="toolBarRight" class="toolBarRight"><TR></TR></TABLE>
 </div>
</body>
</html>

<script  type="module">
import repetiteur from './js/repetiteur.js';
// Memorise Opencpn dans document pour avoir un acces des scripts non importes
$(document).ready( function() {
	var mainObject = new repetiteur() ;
	} ) ;
</script>


