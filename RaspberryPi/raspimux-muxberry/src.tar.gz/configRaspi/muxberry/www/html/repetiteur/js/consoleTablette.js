function consoleTablette () {
	var isActive = false ;
	isActive = true ;
	$('#body').append("<div id='console' class='console userScreen'>\
    								 	<button id='consoleClearButton' type='button' class='consoleButton'>Clear</button>\
										 	<div id='consoleText' class='consoleText'/>\
        							</div>") ;

	$('#bugButton').css('display','inline') ;
	console.log = function(msg) {
		if (console && console.warn) console.warn(msg) ;
		try {
			if (typeof(msg) == 'object') msg = JSON.stringify(msg) ;
			} 
		catch(err) {
				// maby not possible
				}
		if (typeof(msg) != 'string') return ;
		while(msg.substr(0,160).length) {
					$('#consoleText').html( $('#consoleText').html() + msg.substr(0,80) + "<BR>")	;
					msg = msg.substr(80) ;
					}
		if ( $('#consoleText').html().length > 1024 * 4) {
					$('#consoleText').html( $('#consoleText').html().substr(1024) ) ;
					}
		$('#consoleText').scrollTop($('#consoleText').height()) ;
		}
		
	console.debug = console.log;
	console.info = console.log;
	//console.warn = console.log;
	console.error = console.log;
	
	
	this.resize =  function() {
				$('#console').width = window.innerWidth ;
       	$('#console').height ( window.innerHeight - $('#toolBar').height()) ;
				$('#consoleText').width = window.innerWidth ;
       	$('#consoleText').height ( window.innerHeight - $('#toolBar').height()) ;
				}
				
	this.hide = function() {
  	this.isActive = false ;
  	$('#console').css('display','none') ;
  	}
  	
  this.show = function() {
  	this.isActive = true ;
  	$('#console').css('display','table') ;
  	this.resize() ;
  	}			
  	
	$('#consoleClearButton').click ( function () {
            	$('#consoleText').html('') ;
            	window.scrollTo(0,0) ;
            	} ) ;
  	
  $('#bugButton').click ( { console:this } , function (event) { 
  		var me = event.data.console ;
  		if (me.isActive == true) me.hide()
  		else me.show() ;
  		}	 ) ;	
  window.addEventListener("resize", this.resize);	
  this.resize() ;
	}