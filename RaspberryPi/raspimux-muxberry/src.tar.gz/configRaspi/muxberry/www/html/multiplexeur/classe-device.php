<?php
include_once  "multiplexer.php" ;

class device extends model {
var $speed ;
var $nickname ;
var $prefix ;
var $id ;
var $delete ;

function device($tab) {
	global $counter_device ;
	$this->name = $tab[1] ;
	$this->speed = $tab[2] ;
	$this->nickname = $tab[3] ;
	$this->prefix = $tab[4] ;
	$this->id = $counter_device++ ;
	$this->delete = 0 ;
	for ($c = 5 ; $c < count($tab) && $tab[$c] ; $c+= 3) {
		$this->addPhrase($tab[$c],$tab[$c+1],$tab[$c+2]) ;
		}
	}
		
function write($fd) {
	if ($this->delete) return ;
	if (strlen($this->nickname) == 0) $this->nickname = "Unknown" ;
	if (strlen($this->speed) == 0) $this->speed = "AUTO" ;
	if (strlen($this->prefix) == 0) $this->prefix = "XX" ;
	fprintf($fd,"DEVICE|%s|%s|%s|%s",$this->name,$this->speed,$this->nickname,$this->prefix) ;
	for ($c = 0 ; $c < count($this->tabPhrases) ; $c++) {
		if (!strlen($this->tabPhrases[$c]['phrase'])) continue ;
		//if (!$this->tabPhrases[$c]['priority'] && ! $this->tabPhrases[$c]['output']) continue ;
		fprintf($fd,"|%s|%s|%s",	$this->tabPhrases[$c]['phrase'],
														$this->tabPhrases[$c]['priority'],
														$this->tabPhrases[$c]['output']) ;
							
		}
	fprintf($fd,"\n") ;
	}

function addInOut($tab) { // Ajoute les stat et eventuellement une nouvelle phrase
	global $listePhrases ;
	$inOut = $tab[1] ;
	if (strcmp($inOut,"IN") && strcmp($inOut,"OUT")) return ;
	for ($c = 2 ; $c < count($tab) && $tab[$c] ; $c+=2 ) {	
			if (!array_key_exists($tab[$c],$listePhrases)) $listePhrases[$tab[$c]] = "Undefine" ;
			$b = $this->getPhraseId($tab[$c]) ;
			if (!strcmp($inOut,"IN")) $this->tabPhrases[$b]['in'] =  $tab[$c+1] ;
			else $this->tabPhrases[$b]['out'] =  $tab[$c+1] ;
			} 
	}		

function getGroup($phrase) {
	global $nmeaGroups ;
	global $phraseTypes ;
	for ($c = 0 ; $c < count($nmeaGroups) ; $c++) {
		$group = $nmeaGroups[$c] ;
		if (in_array($phrase,$phraseTypes[$group])) return $group ;
		}
	}
	
function getPriority($group) {
	for ($c = 0 ; $c < count ($this->tabPhrases) ; $c++) {
		$phrase = $this->tabPhrases[$c]['phrase'] ;
		if (!strcmp($this->getGroup($phrase),$group)) {
			return $this->tabPhrases[$c]['priority'] ;
			}
	}
return "OTHERS" ;
}
	
function getInHtml($phrase) {
	$n = $this->getPhraseId($phrase) ;
	$p = $this->tabPhrases[$n] ;
	$inId = sprintf("priority-%d-%d",$this->id,$n) ;
	$selectId = sprintf("select-%d-%d",$this->id,$n) ;
	
	$ret = sprintf("<INPUT type='hidden' name='%s' id='%s' value='%d'>",$inId,$inId,$p['priority']) ;
	$ret .= "<TABLE border='0'><TR><TD rowspan='2'>" ;
	$ret .= sprintf("<INPUT type='image' width='20' style='border:none;outline:none;' src='images/%s' 
												onclick=\"if (this.src.includes('accept.png')) {
																		 this.src = 'images/cancel.png' ;
																		 var el = getElementById('%s') ;
																		 if (el) {
																		 			el.disabled = true ;  
																		 			el.value = 0 ;
																		 			}
																		 getElementById('%s').value = 0 ;
																		 }
																	else { 
																				this.src = 'images/accept.png' ; 
																				var el = getElementById('%s') ;
																		 		if (el) {
																		 				 el.disabled = true ;  
																						 el.value = 1 ;
																						 }
																				getElementById('%s').value = 1 ;
																				} 
																	this.form.submit() ;
																	return false ;
																	\"
												>",$p['priority'] ? "accept.png" : "cancel.png",
													$selectId,$inId,
													$selectId,$inId) ;
	if ($p['priority']) 
		$ret .= sprintf("<div align='center' style='color:%s;font-size:12px;'>%d</div>",	$p['in'] ? "green" : "red",$p['in']) ;
	$ret .= "</TD><TD align='center' style='font-size:12px;'>" ;
 	$ret .= "Priority" ;
 	$ret .= "</TD></TR><TR><TD align='center' style='font-size:12px;'>" ;
	$ret .= sprintf("<SELECT name='%s' id='%s' style='border:none;outline:none;' %s
										onChange='getElementById(\"%s\").value = this.value ; 
															this.form.submit() ;'>
										<option hidden value='0' %s>-</option>
										<option value='1' %s>1</option>
										<option value='2' %s>2</option>
										<option value='3' %s>3</option>
										<option value='4' %s>4</option>
										<option value='5' %s>5</option>
									</select>",$selectId,$selectId,
														$p['priority'] == 0 ? "disabled" : "",
														$inId,
													  $p['priority'] == 0 ? "selected" : "",
													  $p['priority'] == 1 ? "selected" : "",
													  $p['priority'] == 2 ? "selected" : "",
													  $p['priority'] == 3 ? "selected" : "",
													  $p['priority'] == 4 ? "selected" : "",
													  $p['priority'] == 5 ? "selected" : "") ;
	$ret .= "</TD></TR></TABLE>" ;			
	return $ret ;
	}
	
function getOutHtml($phrase) {
	$n = $this->getPhraseId($phrase) ;
	$p = $this->tabPhrases[$n] ;
	$outId = sprintf("output-%d-%d",$this->id,$n) ;

	$ret = sprintf("<INPUT type='hidden' name='%s' id='%s' value='%d'>",$outId,$outId,$p['output']) ;		
	$ret .= sprintf("<INPUT type='image' style='border:none;outline:none;' width='20' src='images/%s' 
												onclick=\"if (this.src.includes('accept.png')) {
																		 this.src = 'images/cancel.png' ;
																		 getElementById('%s').value = 0 ;  
																		 }
																	else { 
																				this.src = 'images/accept.png' ; 
																				getElementById('%s').value = 1 ;  
																				} 
																	this.form.submit() ;
																	return false ;
																	\"
												>",$p['output'] ? "accept.png" : "cancel.png",
													 $outId,
													 $outId ) ;
												
	if ($p['output']) 
		$ret .= sprintf("<span style='color:%s;font-size:12px;'>%d</span>",	$p['out'] ? "green" : "red",$p['out']) ;		
	return $ret ;
	}
	
function getTotalStats() {
	$n = 0 ;
	for ($c = 0 ; $c < count($this->tabPhrases) ; $c++) {
		$n+= $this->tabPhrases[$c]['in'] ;
		$n+= $this->tabPhrases[$c]['out'] ;
		}
	if (!$n) return "&nbsp;" ;
	return sprintf("<A HREF='#' style='color:green;'
									onclick='var url=\"streamWindow.php?device=%s&open=true\" ;
									document.getElementById(\"dataStream\").src=url ;
									return false ;'
									>IO : %d</A>",$this->name,$n) ;
	}

function getValues() {
global $_POST ;
		if (isset($_POST['nickname'])) $this->nickname = $_POST['nickname'] ;
		if (isset($_POST['speed'])) $this->speed = $_POST['speed'] ;
		for ($c = 0 ; $c < count($this->tabPhrases) ; $c++) {
			$inId = sprintf("priority-%d-%d",$this->id,$c) ;
			$outId = sprintf("output-%d-%d",$this->id,$c) ;
			if (isset($_POST[$inId])) {
				$this->tabPhrases[$c]['priority'] = $_POST[$inId] ;
				}
			if (isset($_POST[$outId])) {
/*
				if ($this->tabPhrases[$c]['output'] != $_POST[$outId]) {
					printf("%s %d out = %d -> %d<BR>",$this->tabPhrases[$c]['phrase'],$c,$this->tabPhrases[$c]['output'] ,$_POST[$outId]) ;
					}
*/
				$this->tabPhrases[$c]['output'] = $_POST[$outId] ;
				}
			}
		}
		
function setPhrasePriority($phrase,$priority) {
		$n = $this->getPhraseId($phrase) ;
		$this->tabPhrases[$n]['priority'] = $priority ;
	}
	
function setModel($name) {
	global $models ;
	for ($c = 0 ; $c < count($models) && strcmp($name,$models[$c]->name) ; $c++) ;
	if ($c == count($models)) return ;
	$model = $models[$c] ;
	for ($n = 0 ; $n < count($this->tabPhrases) ; $n++) {
		$this->tabPhrases[$n]['priority'] = 0 ;
		$this->tabPhrases[$n]['output'] = 0 ;
		}
	for ($n = 0 ; $n < count($model->tabPhrases) ; $n++) {
		$b = $this->getPhraseId($model->tabPhrases[$n]['phrase']) ;
		$this->tabPhrases[$b]['priority'] = $model->tabPhrases[$n]['priority'] ;
		$this->tabPhrases[$b]['output'] = $model->tabPhrases[$n]['output'] ;
		}
	}
}
?>
