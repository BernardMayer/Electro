<link href="multiplexer.css" rel="stylesheet" type="text/css" media="screen" />
<?php
include "multiplexer.php" ;

/*
echo "<pre>" ;
var_dump($_POST) ;
echo "</pre>" ;
*/

function detailHandler() {
global $_POST ;
global $device ;
global $phraseTypes ;

	// Mise à jour du model
	if (isset($_POST['model']) && strlen($_POST['model'])) { // setmodel
			$device->setModel($_POST['model']) ;
			writeConfig() ;
			return ;
			}

	// Mise à jour GenericPriority (pour tout un groupe GPS,AIS,INSTRUMENTS ...
	if (isset ($_POST['op']) && $_POST['op'] == "updateGenericPriority") {
		reset($phraseTypes) ;
		for ($c = 0 ; $c < count($phraseTypes) ; $c++ , next($phraseTypes) ) {
			$selectId = sprintf("priority-generic-%s",key($phraseTypes)) ;
			if (($priority = $_POST[$selectId]) >= 0) {
				// Priorite a mettre à jour
				$listePhrases = current($phraseTypes) ;
				for ($b = 0 ; $b < count($listePhrases) ; $b++) {
					$device->setPhrasePriority($listePhrases[$b],$priority) ;
					}
				}
			}
		writeConfig() ;
		return ;
		}
	$device->getValues() ;
	writeConfig() ;
}

readConfig() ;
$device = $devices[$_POST['deviceId']] ;
detailHandler() ;

$device = $devices[$_POST['deviceId']] ;
printf ("<FORM method='POST'>") ;
printf ("<INPUT type='HIDDEN' name='deviceId' value='%d'>",$device->id) ;
printf ("<INPUT type='HIDDEN' name='op' value='updatePriority'>",$device->id) ;
printf("<TABLE border=0 width='100%%'><TR>
				<TD nowrap><A HREF='index.php'><IMG width='60' src='images/back.jpg'></A></TD>
				<TD width='60'> Model :</TD>
				<TD width='100'><select name='model' 
									onchange=\"this.form.submit() ; \">") ;
									printf("<option value=''> - </option>") ;
									for ($m = 0 ; $m < count($models) ; $m++) {
											printf("<option value='%s'> %s </option>",$models[$m]->name,$models[$m]->name) ;
											}
printf("</select></TD>
				<TD style='font-size:40px;font-weight:bold;'><CENTER>%s</CENTER></TD></TR></TABLE>",$device->nickname != "" ? $device->nickname : $device->name) ;

// genere le tableau autres
$keyPhrases = array() ; // Liste de toutes les phrases definies
reset($phraseTypes) ;
for ($c = 0 ; $c < count($phraseTypes) ; $c++ , next($phraseTypes)) {
	$listePhrases = $phraseTypes[key($phraseTypes)] ;
	for ($b = 0 ; $b < count($listePhrases) ; $b++) {
		$keyPhrases [$listePhrases[$b]] = $listePhrases[$b] ;
		}
	}

for ($c = 0 ; $c < count($device->tabPhrases) ; $c++) {
		$phrase = $device->tabPhrases[$c]['phrase'] ;
		if (!strlen($phrase)) continue ;
		if (!array_key_exists ($phrase,$keyPhrases)) {
			$phraseTypes['OTHERS'][] = $device->tabPhrases[$c]['phrase'] ;
			}
		}
		
// Tableau et titres
printf ("<TABLE><TR>") ;
reset($phraseTypes) ;
for ($c = 0 ; $c < count($phraseTypes) ; $c++ , next($phraseTypes)) {
	$tab = current($phraseTypes) ;
	if (key($phraseTypes) == "OTHERS" && count($tab) == 0) continue ;
	$selectId = sprintf("priority-generic-%s",key($phraseTypes)) ;
	printf("<TD><TABLE width='100%%'>
					<TR>
						<TD align='CENTER' style='font-size:20px;font-weight:bold;'>%s
						</TD>
					</TR>",key($phraseTypes)) ;
	printf("<TR><TD align='CENTER'>") ;
  		if (key($phraseTypes) != "OTHERS") {
  				$priority = $device->getPriority(key($phraseTypes)) ;
					printf("<SPAN style='font-size:10px;'>Priority :</SPAN>") ;
					printf("<SELECT name='%s' id='%s' style='border:none;outline:none;'
										onChange='this.form.op.value=\"updateGenericPriority\";
															this.form.submit() ;'>
										<option value='0' %s>-</option>
										<option value='1' %s>1</option>
										<option value='2' %s>2</option>
										<option value='3' %s>3</option>
										<option value='4' %s>4</option>
										<option value='5' %s>5</option>
									</select></TD></TR></TABLE>",$selectId,$selectId,
									$priority == 0 ? 'selected' : "",
									$priority == 1 ? 'selected' : "",
									$priority == 2 ? 'selected' : "",
									$priority == 3 ? 'selected' : "",
									$priority == 4 ? 'selected' : "",
									$priority == 5 ? 'selected' : ""
									) ;
									}
			else printf("&nbsp;</TD></TR></TABLE>") ;			
	printf("</TD>") ;
	}

// Les tables de phrases
reset($phraseTypes) ;
printf("<TR>") ;
for ($c = 0 ; $c < count($phraseTypes) ; $c++ , next($phraseTypes)) {
	$tab = $phraseTypes ;
	if (key($phraseTypes) == "OTHERS" && count($tab) == 0) continue ;
	printf ("<TD valign='top'><TABLE border='1'>") ;
	printf("<TR>\n") ;
	$listePhrases = current($phraseTypes) ;
	if (!count($listePhrases)) continue ; // Si pas Autres
	reset($listePhrases) ;
	for ($b = 0 ; $b < count($listePhrases) ; $b++) {
		$phrase = $listePhrases[$b] ;
		for ($l = 0 ; $l < count($device->tabPhrases) ; $l++) {
				if ($device->tabPhrases[$l]['phrase'] == $phrase) break ;
				}
		if ($l == count($device->tabPhrases)) continue ;
		$p = $device->tabPhrases[$l] ;
		printf ("<TR><TD><TABLE><TR>") ;
		printf("<TD><A style='color:%s;' href='#' onclick='return false' title='%s'>%s</A></TD><TD width='60' align='center'>%s</TD><TD width='60' align='center'>%s</TD>\n",
							$p['in'] ? 'green' : 'red' ,
							array_key_exists($phrase,$listePhrases) ? $listePhrases[$phrase] : "",
							$phrase,
							$device->getInHtml($phrase),
							$device->getOutHtml($phrase)) ;
		printf("</TR></TABLE></TD></TR>") ;
		}
	printf("</TABLE></TD>") ;
	}
printf("</TR></TABLE>") ;
printf ("</FORM>") ;

?>
