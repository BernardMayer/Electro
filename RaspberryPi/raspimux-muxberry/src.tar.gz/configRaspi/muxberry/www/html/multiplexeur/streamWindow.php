<?php
include_once  "multiplexer.php" ;

//var_dump($_GET) ;
// Maintient le fichier flag
// Les enregistrements sont :
// deviceName|time_IN|time_OUT
function updateStreams($device) {
	global $dataDir ;
	$devStreams = array() ;
	$ctlFile = sprintf("%s/stream.flag",$dataDir) ;
	// Lecture du fichier
	if (file_exists($ctlFile) && ($fd = fopen($ctlFile,"r"))) {
		while (($buf = fgets($fd))) { // ligne Device|timestamp
			$tab = explode("|",$buf) ;
			$deviceName = $tab[0] ;
			$time = $tab[1] ;
			if ($time < time() - 5) continue ;
			$devStreams[$deviceName] = array( "TIME" => $tab[1] ) ;
			}
		fclose($fd) ;
		}
	if (!array_key_exists($device,$devStreams)) $devStreams[$device] = array( 'TIME' => time() ) ;
	else  $devStreams[$device]['TIME'] = time() ;

	// Ecriture du fichier
	reset($devStreams) ;
	umask(0) ;
	if (count($devStreams) && ($fd = fopen($ctlFile,"w"))) {
		for ($c = 0 ; $c < count($devStreams) ; $c++ , next($devStreams)) {
			$stream = current($devStreams) ;
			if ($stream['TIME'] < time() - 5) continue ;
			fprintf($fd,"%s|%d\n",key($devStreams),$stream['TIME']) ;
			}
		 fclose($fd) ;
		}
	}

global $dataDir ;
if (!isset($_GET['device'])) exit(0) ;
updateStreams($_GET['device']) ;
$tab = explode("/",$_GET['device']) ;
$nameDev = $tab[count($tab) - 1] ;
$streamFile = sprintf("%s/%s.IO",$dataDir,$nameDev) ;
if (isset($_GET['open'])) {
	if (file_exists($streamFile)) @unlink($streamFile) ;
	readConfig() ;
	for ($c = 0 ; $c < count($devices) ; $c++) {
		if (!strcmp($devices[$c]->name,$_GET['device'])) {
			$nickname = $devices[$c]->nickname ;
			break ;
			}
		}
	}
else { // La fenetre demande un rafraichissement
	if (file_exists($streamFile) && ($fd = fopen($streamFile,"r"))) {
		while( ($line = fgets($fd))) {
			$color = "black" ;
			if (strstr($line,"IN]")) $color = "green" ;
			else if (strstr($line,"OUT]")) $color = "blue" ;
			else $color = "red" ;
			echo "<p style='color:$color; margin:0px; padding:0px;'>$line</p>" ;
			$i++ ;
			}
		fclose($fd) ;
		}
	if (file_exists($streamFile)) @unlink($streamFile) ;
	exit(0) ;
	}


?>
<HTML>
<link href="multiplexer.css" rel="stylesheet" type="text/css" media="screen" />
<script language='javascript' src="Jquery/jquery.3.3.1.js"></script>
<?php echo ($nickname && $nickname != "Unknown") ? $nickname : $_GET['device'] ; ?>
<FORM>
	<INPUT type="submit" value="close" onclick='window.location="empty.html";'>
	<INPUT type="submit" value="pause" onclick='pause = (pause == 0) ? 1 : 0 ; 
																							if (pause == 0) getStream() ;
																							this.value = (pause == 0) ? "pause" : "restart" ;
																							return false ;'>
	<INPUT type="submit" value="clear" onclick='element = document.getElementById("streamWindow") ;
																							element.textContent = "" ;
																							return false ;'>
</FORM>
<div id="streamWindow" style="overflow:auto; max-height:400px; white-space: nowrap;">
</div>
<script language='javascript'>
var pause = 0 ;

function getStream()
{ 
    var xhr; 
    try {  xhr = new ActiveXObject('Msxml2.XMLHTTP');   }
    catch (e) 
    {
        try {   xhr = new ActiveXObject('Microsoft.XMLHTTP'); }
        catch (e2) 
        {
           try {  xhr = new XMLHttpRequest();  }
           catch (e3) {  xhr = false;   }
         }
    }
  
    xhr.onreadystatechange  = function() 
    { 
       if(xhr.readyState  == 4)
       {
        if(xhr.status  == 200) {
            var element = document.getElementById("streamWindow") ;
            var lines = $('#streamWindow').find("p") ;
            console.log(lines.length) ;
            var startIndex = 0 ;
            $('#streamWindow').html("") ; 
            if (lines.length > 100) startIndex = lines.length - 100 ;
            for (var c = startIndex ; c < lines.length ; c++) {
            	$('#streamWindow').append(lines[c]) ; 
            	}
            //element.textContent += xhr.responseText ;
            //element.scrollTop = element.scrollHeight - element.clientHeight ; 
            $('#streamWindow').append(xhr.responseText) ; 
            $('#streamWindow').scrollTop( 100000 );
            //$('#streamWindow').animate({scrollTop:$('#streamWindow').height()});
            if (pause == 0) setTimeout (getStream,  1000) ;
            }
        else
            document.ajax.dyn="Error code " + xhr.status;
        }
    }; 
 
   xhr.open("GET", "streamWindow.php?device=<?php echo $_GET['device']?>",  true) ; 
   xhr.send(null); 
} 


getStream() ;
</script>
</HTML>
