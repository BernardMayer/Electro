<?php
$listePhrases = array() ; // Permet d'avoir pour chaque device la meme liste de phrase 
$nmeaGroups = array( "GPS" , "AIS" , "PILOTE" , "INSTRUMENTS" ,"NAVIGATION" ) ;

$phraseTypes = array () ;
$phraseTypes['GPS'] = array ( "GGA" , "GLL" , "GSA" , "GSV" ,"VTG" , "RMC" , "ZDA" ,"ZDU" , "ZZU" ) ;
$phraseTypes['INSTRUMENTS'] = array( "DBT" , "DPT" , "MTA" ,"MTW" ,
																"MWD" , "MWV" , "VHW" , "VLW" , "VWR" , "VWT" ) ;
$phraseTypes['NAVIGATION'] = array( "APA" , "AAM" ,"APB" , "RMB" , "XTE" , "BOD" , "BWC" ,
																 "WPL" , "RTE" , "ZTG" ) ;
$phraseTypes['AIS'] = array( "VDM" , "VDO" ) ;
$phraseTypes['PILOTE'] = array( "HDG" , "HDM" , "HDT" ) ;

$models = array() ;
$devices = array() ;
$counter_device = 0 ;

$dataDir = "/var/www/data/tmp" ;
include_once "classe-model.php" ;
include_once "classe-device.php" ;
include_once "readWrite.php" ;
?>