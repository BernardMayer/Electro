if test `whoami` != root
        then
        echo $0 doit etre execute avec sudo
        exit 1
        fi


#packages
export PATH=$PATH:`pwd`/scripts
export PATH=$PATH:`pwd`/../muxberry/scripts
export PATH=$PATH:`pwd`/../seaberry/scripts

apt-get update
apt-get upgrade
apt-get install can-utils php unionfs-fuse socat ftp\
	libgtk-3-dev libwebkit2gtk-4.0-dev qt5-default qtcreator


echo "
"
#
#CAN Fichier config.txt
#
question "Voulez vous parametrer /boot/config.txt pour le support CAN"
if test $? -eq 1  
	then
	param-boot
	fi

#
#Fichiers de config reseau 
#
question "Voulez vous parametrer le reseau pour l'acces a MUXBERRY?"
if test $? -eq 1  
	then
	./scripts/param-network
	fi

#Fichiers executables /usr/local/bin
echo "copie des executables vers /usr/local/bin"
cp ../muxberry/bin/* /usr/local/bin
saveOrigFile /etc/sudoers
cat etc/sudoers >>/etc/sudoers

#scripts de demarrage
echo "copie des fichiers service canbus nmeaHub"
cp ../muxberry/etc/init.d/nmeaHub /etc/init.d
/usr/sbin/update-rc.d nmeaHub defaults
cp ../muxberry/etc/init.d/phpWebServer /etc/init.d
/usr/sbin/update-rc.d phpWebServer defaults
systemctl daemon-reload
systemctl disable nmeaHub

# www
echo "copie des fichiers www"
cd ../muxberry
cp -r www /var
cd ../repetiteur
chown -R www-data:www-data /var/www/*
chown root:root /var/www/data/bin/remount*
chmod +s /var/www/data/bin/remount*

#swap off
question "Voulez vous arreter le systeme de swap"
if test $? -eq 1  
	then
	dphys-swapfile uninstall
	systemctl disable dphys-swapfile
	fi

#fstab
question "Voulez vous parametrer fstab pour un systeme  safe (readOnly)"
if test $? -eq 1  
	then
	param-fstab
	fi

#crontab root
question "Voulez parametrer crontab root pour le mode protect"
if test $? -eq 1  
	then
	param-crontab
	fi


#support ecran hyperpixel4
question "Voulez parametrer le support ecran hyperPixel4"
if test $? -eq 1  
	then
	curl https://get.pimoroni.com/hyperpixel4 | bash
	fi

question "Voulez parametrer le support ecran e-link waveshare 6 pouces"
if test $? -eq 1  
	then
	curl  http://www.airspayce.com/mikem/bcm2835/bcm2835-1.58.tar.gz | gunzip | tar xvf -
	cd bcm2835-1.58
	./configure
	make
	make install
	fi
echo creation utilisateur repetiteur
param-addUser repetiteur repetiteur
param-userRepetiteur
./scripts/param-desktop

