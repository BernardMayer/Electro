export PATH=$PATH:`pwd`/scripts
export PATH=$PATH:`pwd`/../muxberry/scripts

./scripts/param-network
