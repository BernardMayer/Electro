if test `whoami` != root
        then
        echo $0 doit etre execute avec sudo
        exit 1
        fi


export PATH=$PATH:`pwd`/scripts
export PATH=$PATH:`pwd`/../muxberry/scripts

#installation des packages
apt-get update
apt-get upgrade
apt-get install can-utils hostapd dnsmasq apache2 php unionfs-fuse \
								socat websockify tigervnc-standalone-server ftp ftpd florence at-spi2-core


echo "


"
#
#CAN Fichier config.txt
#
question "Voulez vous parametrer /boot/config.txt pour le support CAN"
if test $? -eq 1  
	then
	param-boot
	fi
#
#Users
#
echo  "Creation des utilisateurs"
param-addUser pascal gudhull
param-addUser opencpn opencpn
param-addUser vnc opencpn
param-users

echo "configuration reseau"
./script/param-network

question "Voulez vous installer les packages samba ?"
if test $? -eq 1
        then
	apt-get update
	apt-get install samba
        param-samba
        fi


question "Voulez vous installer opencpn ?"
if test $? -eq 1
        then
	echo installation opencpn
	param-opencpn
        fi



question "Voulez vous installer zygrib ?"
if test $? -eq 1
        then
	echo installation zygrib
	param-zygrib
        fi

#Fichiers executables /usr/local/bin
echo "copie des executables vers /usr/local/bin"
cp ../muxberry/bin/* /usr/local/bin
saveOrigFile /etc/sudoers
cat ../muxberry/etc/sudoers >>/etc/sudoers

# www
echo "copie des fichiers www"
cd ../muxberry
cp -r www /var
cd ../seaberry
chown -R www-data:www-data /var/www/*
chown root:root /var/www/data/bin/remount*
chmod +s /var/www/data/bin/remount*

#parametrage vnc server 
cp etc/init.d/vncserver /etc/init.d
cp ../muxberry/etc/init.d/nmeaHub /etc/init.d
chown root:root /etc/init.d/vncserver
chmod +x /etc/init.d/vncserver
chown root:root /etc/init.d/nmeaHub
chmod +x /etc/init.d/nmeaHub
/usr/sbin/update-rc.d vncserver defaults
/usr/sbin/update-rc.d nmeaHub defaults
systemctl daemon-reload
systemctl disable nmeaHub
systemctl enable vncserver

iquestion "Voulez vous installer twofing ?"
if test $? -eq 1
        then
        echo installation twofing
        param-twofing
        fi


