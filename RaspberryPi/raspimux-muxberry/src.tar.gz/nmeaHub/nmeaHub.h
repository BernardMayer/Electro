#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <signal.h>
#include <termio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <arpa/inet.h>
#include<sys/socket.h>	
#include <errno.h>
#include <getopt.h>
#include <time.h>
#include <pthread.h>
#include <semaphore.h>

#define	CONFIG_DEF	"/var/www/data/nmeaHub/nmeaHub.def"
#define	CONFIG_DEVICE	"/var/www/data/nmeaHub/nmeaHub.conf"
#define	STAT_FILE	"/var/www/data/nmeaHub/nmeaHub.stat"
#define	DIR_PHP_DATA	"/var/www/data/tmp"

#define MAX_CONNEXIONS	32
#define MAX_MODELS			16
#define SIZE_PHRASE			128
#define SIZE_POOL_MESSAGE 8
#define	MAX_TYPE_PHRASE 128

#define XBEE_SOURCE	1
#define	TTY_SOURCE	2
#define	TCP_SOURCE	3
#define	CHILD_SOURCE	4

#define	PORT_API	0xBEE
#define	PORT_IP	3333
#define MAX_CONN_TCP 4 // PORT_IP + 1 en emission
#define MIN_REPET_TIME 1 // Temps minimum pour repetition d'un message

#define IN_STAT 1
#define OUT_STAT 2
#define MAX_COG_SOG_VALUES 32	
	
#define LOAD_ALL_CONFIG -1
#define LOAD_CONFIG_DEF 0
#define	LOAD_CONFIG_CONF 1
#define MAX_PROCESS_ARGS 16

// Priorite par groupe ex : Un Gps et un traceur
// Gps priority 1 traceur 2, mais le traceur envoi GLL, pas le GPS
// GLL etant dans le groupe GPS il est refus
struct priorityGroups {
	char	*name	;
	char	*types[16] ;
	int		priority			; // Priorite courante du groupe
	time_t	lastSend		;
	} ;
	
extern struct priorityGroups priorityGroups[] ;

struct messages_in_out { 
	char type[4] ;
	int  in_priority		; // 0 = poubelle 1 à n
	int  out_autorise		; // 0 = poubelle autre ok
	}  ;

struct models {
	char name[32] ; // Nom du model si model
	struct messages_in_out messages_in_out[MAX_TYPE_PHRASE] ;
	} ;
		
struct	typesStats {
			char	type[4] 			 ;
			unsigned char	num		 ;
			int 	dispatch			 ;
			time_t lastSend			 ;
			} ;	

struct  priorityStats {
	char	type[4] 			    ;
	int		priority					;
	time_t	lastSend	  		;
	}	 ;					

struct poolMessage {
	char  phrase[SIZE_PHRASE * 2] ;
	} ;
	
struct connexion {
				char	name[256]		;
				char	nickname[32];
				char	prefix[3]		;	// GP AI II etc...
				int		speed				;
				char	def_speed[8];
				int		fd_in				;
				int		fd_out			;
				int	  mode				;
				int	  speedOk			; // 1 quand la bonne vitesse est trouvee
				int		source			;
				char	**args	  	;
				int		pidChild		;
				int		write				;
				char	phrase[SIZE_PHRASE] ;
				int		errorChars		;
				int		errorPhrases 	;
				int 	nreads				;
				struct messages_in_out  messages_in_out[MAX_TYPE_PHRASE]  ;
				struct	typesStats in_stats[MAX_TYPE_PHRASE] ;
				struct	typesStats out_stats[MAX_TYPE_PHRASE] ;
				pthread_t thread ;
				int			poolCurrent ;
				int			poolNext ;
				struct 	poolMessage poolMessage[SIZE_POOL_MESSAGE]  ;
				int			nPool ;
				time_t lastRead		;	
				time_t timestamp	;
				time_t phpStreamIo ;
				}	;
				
extern char *groupGPS [] ;
extern char *groupTRACK [] ;

extern struct models models[MAX_MODELS] ;		
extern struct connexion connexions[MAX_CONNEXIONS]	;
extern float sogValues[MAX_COG_SOG_VALUES]  ;
extern float cogValues[MAX_COG_SOG_VALUES]  ;
extern int filterValue  ;
extern int genere_RMB_XTE_ok ;
extern int genere_GLL_ok ;
extern int genere_MWV_ok ;
extern int top_connexion ;
extern int logOutStream  ;

extern	int errno ;
extern int	debugLevel	;
extern struct priorityStats priorityStats[MAX_TYPE_PHRASE] ;
extern	sem_t mutex ;
extern	sem_t mutexMalloc ;
extern	int	portIP ;

void messageAddChar( struct connexion *con, char ch) ;  
void changeSpeed(struct connexion *con) ;   
void scanusbtty(char *dirname,char *prefix) ;
void sigend(int sig) ;
void sigsegv(int sig) ;     
void checkNmeaPhrase(struct connexion *con) ;
void messageAddChar( struct connexion *con, char ch) ;
struct typesStats *getStatsElement(struct connexion *con,char *type,int inOut) ;
struct priorityStats *getStatsPriority(char *type) ;
struct messages_in_out *getMessageInOut(struct connexion *con,char *type) ;
void filtrageCogSog(char *phrase) ;
int getCogValue() ;
void checkNmeaPhrase(struct connexion *con) ;
void dispatch(struct connexion *con,char *type,struct typesStats *t) ;
void closeConnexion(struct connexion *con) ;
void readApiUDP(int fd) ;
void readUDP(int fd) ;
void acceptTCP(int fd,int port) ;
int readConfig(int noConnexion) ;
void writeStats() ;        
void writeDevice(int c,FILE *fd) ;        
int checkForCheckSum( char *phrase) ;
void genereRMB_XTE(struct connexion *con) ;        
void genereGLL(struct connexion *con) ;        
void genereMWV(struct connexion *con) ;        
void addDeviceToConfig(int c) ;
void pushPool(struct connexion *con,char *phrase) ;
struct poolMessage  *popPool(struct connexion *con) ;
void *threadFunc (void *arg ) ;
void createThread (struct connexion *con ) ;
void pushToFree (struct connexion *con , struct poolMessage *msg) ;
char *myStrtok(char *str,char sep) ;
void trim(char *buf) ;
void rtrim(char *buf) ;
void ltrim(char *buf) ;
void sigusr1() ;
void sigusr2() ;
void sigpipe() ;
void sigalrm() ;
void sigchld() ;
void protect() ;
void unprotect() ;
void protectMalloc() ;
void unprotectMalloc() ;
void *myMalloc(unsigned short n) ;
void myFree(void *memo) ;
void scanAndStat() ;
void setTopConnexion() ;
void myLog(char *fmt, ...) ;
void logNmea(struct connexion *con,char *phrase,char *sens) ;
void scanPhpStreamIo() ;
void logPhpNmea(struct connexion *con,char *phrase,char *stream) ;
int createChildProcess(char *name,char **args) ;
struct	 priorityGroups *getPriorityGroups(char *type) ;
