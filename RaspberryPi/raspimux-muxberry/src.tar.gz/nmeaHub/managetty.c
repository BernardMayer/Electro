#include "nmeaHub.h"

void setSpeed(struct connexion *con) {
	struct termios options ;
	tcgetattr(con->fd_in, &options) ;
	// raw input
	options.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
	// raw output
	options.c_oflag &= ~OPOST;
	options.c_cc[VMIN] = 0;
	options.c_cc[VTIME] = 0;
	// vitesse
	cfsetispeed(&options, con->speed);
	tcsetattr(con->fd_in, TCSAFLUSH, &options) ;
	}

void changeSpeed(struct connexion *con) {
	char buf [128] ;
	char speed[8] ;
	
	// Ne change pas la vitesse si non definie en AUTO
	if (strcmp(con->def_speed,"AUTO")) return ;
	switch (con->speed) {
		case B4800 : con->speed = B38400 ; strcpy(speed,"38400") ; break ;
		case B38400: con->speed = B9600 ; strcpy(speed,"9600") ; break ;
		case B9600 : con->speed = B19200 ; strcpy(speed,"19200") ; break ;
		case B19200: con->speed = B57600 ; strcpy(speed,"57600") ; break ;
		case B57600: con->speed = B4800 ; strcpy(speed,"4800") ; break ;
		default : con->speed = B4800 ; strcpy(speed,"4800") ; break ;
		} 
	setSpeed(con) ;
	myLog("%s Change speed %s",*con->nickname ? con->nickname : con->name,speed) ;
	}	
	
void scanusbtty(char *dirname,char *prefix) {
	struct dirent	*ent  ; 
	int c								;
	char	name[128]			;
	FILE  *fd 					;
	struct	stat st			;
	int inode						;
	
	DIR* dir = NULL ;
	
	if (!(dir = opendir(dirname))) {
			if (debugLevel >= 1) myLog("Can't open %s",dirname) ;
			return ;
			}
	while ((ent = readdir(dir))) {
		if (prefix && strlen(prefix) && strncmp(ent->d_name,prefix,strlen(prefix))) continue ;
		if (strlen(ent->d_name) > sizeof(name) - 1 - (strlen(dirname) + 1)) continue ;
		if (*ent->d_name == '.') continue ;
		sprintf(name,"%s/%s",dirname,ent->d_name) ;
		stat(name,&st) ;
		inode = st.st_ino ;
		
		for (c = 0 ; c < top_connexion ; c++) {
			if (connexions[c].source != TTY_SOURCE) continue ;
			if (!strcmp(name,connexions[c].name)) break ; // already in list
			stat(connexions[c].name,&st) ;
			if (st.st_ino == inode) {
				if (debugLevel >= 8) myLog("%s deja ouvert sur %s",name,connexions[c].name) ;
				break ;
				}
			}
		if (c < top_connexion) continue ;

		for (c = 0 ; c < MAX_CONNEXIONS && *connexions[c].name ; c++) ;
		if (c ==  MAX_CONNEXIONS ) {
			if (debugLevel >= 1) myLog("To many usbTTY connexions opened") ;
			closedir(dir) ;
			return ;
			}
		memset(&connexions[c],0,sizeof(struct connexion)) ;
		if ((connexions[c].fd_in = open(name,O_RDWR /* |O_NDELAY | O_NONBLOCK */ )) < 0) {
				if ((connexions[c].fd_in = open(name,O_RDONLY|O_NDELAY)) < 0) {
					if (debugLevel >= 2) myLog("Can't open %s",name) ;
					continue ;
					}
				connexions[c].mode = 0 ;
				if (debugLevel >= 1) myLog("Opening %s readonly",name) ;
				}
			else {
				connexions[c].mode = 2 ;
				if (debugLevel >= 1) myLog("Opening %s readwrite",name) ;
				}
			strcpy(connexions[c].name,name) ;
			connexions[c].source = TTY_SOURCE ;
			setTopConnexion() ;
			if (readConfig(c) == 0) { // le device est inconnu
				addDeviceToConfig(c) ;
				}
			connexions[c].fd_out = connexions[c].fd_in ;
			setSpeed(&connexions[c]) ;
			myLog("Opening %s %s",connexions[c].nickname,name) ;
			createThread(&connexions[c]) ;
			}
closedir(dir) ;
}
