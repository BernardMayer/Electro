#include "nmeaHub.h"


void myFree(void *p) {
	protectMalloc() ;
	free(p) ;
	unprotectMalloc() ;
	}
	
void *myMalloc(unsigned short n) {
	void *p ;
	protectMalloc() ;
	p = malloc(n) ;
	unprotectMalloc() ;
	return p ;
	}
	
void protectMalloc() {
	struct timespec timer ;
	int c ;
	timer.tv_sec = 0 ;
	timer.tv_nsec = 300000000 ; // 0.3 secondes
	if (sem_timedwait(&mutexMalloc,&timer) == -1) {
		if (errno == ETIMEDOUT) { // Recree un semaphore
			sem_t newMutex ;
			myLog ("Semaphore semMalloc bloque") ;
			sem_init(&newMutex, 0, 32) ;
			sem_destroy(&mutexMalloc) ;
			memcpy(&mutexMalloc,&newMutex,sizeof(sem_t)) ;
			myLog("le semaphore semMalloc est recree") ;
			}
		protectMalloc() ; // Rappel protect
		}
	}

void unprotectMalloc() {
	sem_post(&mutexMalloc) ;
	}

void protect() {
	struct timespec timer ;
	int c ;
	timer.tv_sec = 0 ;
	timer.tv_nsec = 300000000 ; // 0.3 secondes
	if (sem_timedwait(&mutex,&timer) == -1) {
		if (errno == ETIMEDOUT) { // Recree un semaphore
			sem_t newMutex ;
			sem_init(&newMutex, 0, 32) ;
			sem_destroy(&mutex) ;
			memcpy(&mutex,&newMutex,sizeof(sem_t)) ;
			}
		protect() ; // Rappel protect
		}
	}

void unprotect() {
	sem_post(&mutex) ;
	}
	
	
void pushPool (struct connexion *con,char *phrase) {
	//protect() ;
	if ( ((con->poolNext + 1) % SIZE_POOL_MESSAGE) == con->poolCurrent) {
		myLog("%s congestion next=%d current=%d=> purge queue",
				*con->nickname ? con->nickname : con->name,con->poolNext,con->poolNext) ;
		//sigusr1() ; // print des quues
		con->poolNext = con->poolCurrent = 0 ;
		con->nPool = 0 ;
		}
	strcpy(con->poolMessage[con->poolNext++].phrase,phrase) ;
	if (con->poolNext == SIZE_POOL_MESSAGE) con->poolNext = 0 ;
	con->nPool++ ;
	unprotect() ;
	}

struct poolMessage *popPool(struct connexion *con) {
	struct poolMessage *msg ;
	protect() ;
	if (con->poolCurrent == con->poolNext) msg = NULL ;
	else msg = &con->poolMessage[con->poolCurrent++] ;
	if (con->poolCurrent == SIZE_POOL_MESSAGE) con->poolCurrent = 0 ;
	if (msg) con->nPool-- ;
	unprotect() ;
	return msg ;
	}

void createThread(struct connexion *con) {
pthread_attr_t thread_attr;

if (pthread_attr_init (&thread_attr) != 0) {
    myLog ( "pthread_attr_init error");
    exit (1);
		}
if (pthread_attr_setdetachstate (&thread_attr, PTHREAD_CREATE_DETACHED) != 0) {
    myLog ( "pthread_attr_setdetachstate error");
		exit (1);
  }
if (pthread_create(&con->thread, &thread_attr, threadFunc, (void *)con) != 0) {
		myLog("Creation thread refuse") ;
		exit(0);
		}
}

void logNmea(struct connexion *con,char *phrase,char *sens) {
char *ptr ;
char logName[256] ;
FILE *fdw ;

if (*con->nickname) {
	ptr = con->nickname ;
	}
else {
	for (ptr = con->name + strlen(con->name) - 1 ; ptr > con->name && *ptr != '/' ; ptr--) ;
	if (*ptr == '/') ptr++ ;
	}
	
sprintf(logName,"/tmp/%s_%s.log",ptr,sens && !strcmp(sens,"OUT") ? "OUT" : "IN") ;
if ((fdw = fopen(logName,"a+")) > 0) {
	fprintf(fdw,"%s",phrase) ;
	fclose(fdw) ;
	}
}

void *threadFunc (void *arg  ) {
struct connexion *con  ;
int x , send , toWrite ;
struct poolMessage *msg ;
char	buf [SIZE_PHRASE] ;

		con = (struct connexion *)arg ;
		pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL) ;
		while (1) {
			pthread_testcancel ();
			//usleep(200000) ;
			usleep(50000) ;
			do {
				msg = popPool(con) ;
				if (!msg) break ;
				if (logOutStream) logNmea(con,msg->phrase,"OUT") ;
				if (con->phpStreamIo) logPhpNmea(con,msg->phrase,"OUT") ;

				strcpy(buf,msg->phrase) ;
				toWrite = strlen(buf) ;
				send = 0 ;
				while (send != toWrite) {
					x = write(con->fd_out,buf + send ,toWrite - send) ;
					if (x <= 0) {
						if (errno == EINTR) continue ;
						if (errno == EPIPE) {
								myLog("EPIPE sur write %s",*con->nickname ? con->nickname : con->name) ;
								break ;
								}
						else 	{
									myLog("%s ecriture thread perte de donnees",*con->nickname ? con->nickname : con->name) ;
									break ; 
									}
						}
					send += x ;
					}
				} while(msg) ;
		}
}



