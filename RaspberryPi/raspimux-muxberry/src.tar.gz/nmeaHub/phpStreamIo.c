#include "nmeaHub.h"

// Scan le repertoire /var/www/data
// pour des fichiers nom-device-tty.flag
// contenant IN et/ou OUT
// Si oui et fichier datant de moins de 5 seconde valide les flag phpStreamIN/OUT a l'heure courante
// Si phpStreamIN/OUT age de plus de 5 secondes remise a 0
void scanPhpStreamIo() {
	char		name[256]			;
	time_t	phpIo					;
	char		buf[256]			;
	char		*ptr					;
	int 	  c	, count  		;
	FILE  *ctlFile;
	time_t	heure					;
	
	sprintf(buf,"%s/stream.flag",DIR_PHP_DATA) ;
	if ((ctlFile = fopen(buf,"r")) == NULL) return ;
	while (fgets(buf,sizeof(buf),ctlFile)) {
		if (!(ptr = strtok(buf,"|"))) continue ;
		strcpy(name,ptr) ;
		if (!(ptr = strtok(NULL,"|"))) continue ;
		phpIo = atol(ptr) ;
		
		for (count = c = 0 ; c < top_connexion ; c++) {
			heure = time(NULL) ;
			if (connexions[c].phpStreamIo < heure - 5) connexions[c].phpStreamIo = 0 ;
			if (strcmp(connexions[c].name,name)) continue ;
			if (phpIo < heure - 5) phpIo = 0 ;
			connexions[c].phpStreamIo = phpIo ;
			if (phpIo) count++ ;
			strcpy(buf,name) ;
			for (ptr = name + strlen(name) - 1 ; ptr > name && *ptr != '/' ; ptr--) ;
			if (*ptr == '/') ptr++ ;
			if (!connexions[c].phpStreamIo) {
				sprintf(buf,"%s/%s.IO",DIR_PHP_DATA,name) ;
				unlink(buf) ;
				}
			}
		if (!count) {
			sprintf(buf,"%s/stream.flag",DIR_PHP_DATA,name) ;
			unlink(buf) ;
			}	
		}
	fclose(ctlFile) ;
}

void logPhpNmea(struct connexion *con,char *phrase,char *stream) {
	char		nameFile[256]	;
	FILE 		*fd ;
	char 		*ptr ;
	int			mask ;
	
	if (con->phpStreamIo < time(NULL) - 5) return ;
	for (ptr = con->name + strlen(con->name) - 1 ; ptr > con->name && *ptr != '/' ; ptr--) ;
	if (*ptr == '/') ptr++ ;
	sprintf(nameFile,"%s/%s.IO",DIR_PHP_DATA,ptr) ;
	mask = umask(0) ;
	if (fd = fopen(nameFile,"a+")) {
		char 		date [32] ;
		time_t 	now ;
		struct 	tm *tm ;
		struct timeval tp ;
		now = time(0) ;
		tm = localtime(&now) ;
		gettimeofday(&tp,NULL) ;
		fprintf(fd,"[%02d:%02d:%02d.%03d %s] ",
								tm->tm_hour,tm->tm_min,tm->tm_sec,tp.tv_usec / 1000,stream) ;
		fputs(phrase,fd) ;
		if (*(phrase + strlen(phrase) - 1) != '\n') fputs("\r\n",fd) ;
		fclose(fd) ;
		}
	umask(mask) ;
	}
