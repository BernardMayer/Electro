#include "nmeaHub.h"

void dispatch(struct connexion *con,char *type,struct typesStats *t) {
	int c, x		;
	int send 		;
	int	toWrite	;
	time_t timestamp ;
	static time_t lastRMB = 0 ;
	static time_t lastGLL = 0 ;
	timestamp = time(0) ;
	struct messages_in_out *m ;
	struct typesStats *out ;
		
	if (!strncmp(type,"RMB",3)) lastRMB = timestamp ;
	if (!strncmp(type,"GLL",3)) lastGLL = timestamp ;
	if (!strncmp(type,"GGA",3) && lastGLL < timestamp - 2 && genere_GLL_ok) {
		lastGLL = timestamp ;
		genereGLL(con) ;
		}
	if (!strncmp(type,"VWR",3)  && genere_MWV_ok) {
		genereMWV(con) ;
		}
	if (!strncmp(type,"RMC",3)) {
			filtrageCogSog(con->phrase) ;
 			if (lastRMB < timestamp - 2 && genere_RMB_XTE_ok) { // Pour NASA repetiteur GPS
					genereRMB_XTE(con) ;
					}
			}

	if (debugLevel >= 7) myLog("dispatch %s %s ",*con->nickname ? con->nickname : con->name,type) ;
	strcat(con->phrase,"\r\n") ;

	for (c = 0 ; c < top_connexion ; c++) {
		if (!*connexions[c].name) continue ;
		if (!connexions[c].speedOk) continue ;
		if (con == &connexions[c]) continue ;
		if (connexions[c].mode != O_RDWR) continue ;
		if ( !(m = getMessageInOut(&connexions[c],type)) || m->out_autorise == 0) {
				if (debugLevel >= 7) myLog("%s %s m->type %s non autorise",*connexions[c].nickname ? connexions[c].nickname : connexions[c].name,type,m ? m->type : "NULL") ;
				continue ;
				}
		
		if (debugLevel >= 7) myLog("dispatch %s %s => %s",*con->nickname ? con->nickname : con->name,type,*connexions[c].nickname ? connexions[c].nickname : connexions[c].name) ;
		pushPool(&connexions[c],con->phrase) ;
		if (!t) t = getStatsElement(con,type,IN_STAT) ;
		if (t) t->dispatch++ ;
		if ( (out = getStatsElement(&connexions[c],type,OUT_STAT)) ) out->num++ ;
		connexions[c].timestamp = timestamp ;
		}
	*con->phrase = 0 ;
	}
