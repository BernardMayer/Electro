#include "nmeaHub.h"


void	readConfigChilds() {
FILE *fd 							;
char	buf[1024] 			;
char *type						;
char *name						;

if (debugLevel == 9)
	myLog("readConfigChilds") ;

if ((fd = fopen (CONFIG_DEF,"r")) == NULL) {
	int mask = umask(0) ;
	fd = fopen (CONFIG_DEF,"w") ; // cree si n'existe pas
	umask(mask) ;
	fclose(fd) ;
	if ((fd = fopen (CONFIG_DEF,"r")) == NULL) {
		myLog("Erreur read config %s",CONFIG_DEF) ;
		return ;
		}
	}
		
while (fgets(buf,sizeof(buf) - 1,fd)) {
	while (strlen(buf) >  0 && buf[strlen(buf) - 1] < ' ') buf[strlen(buf) - 1] = 0 ;
	if (!*buf || *buf == '#') continue ;
	if (debugLevel == 9) myLog("readConfigChilds : ligne : %s",buf) ;	
	type = strtok(buf,"|") ;
	name = strtok(NULL,"|") ;

	if (type && name && !strcmp(type,"CHILD")) {
			char	**args ;
			char	*ptr	;
			int n = 0 ;
			args = (char **)malloc(sizeof(char *) * MAX_PROCESS_ARGS) ;
			while ((ptr = strtok(NULL,"|"))) { 
					args[n] = malloc(strlen(ptr) + 1) ;
					strcpy(args[n],ptr) ;
					n++ ;
					}					
			args[n] = NULL ;
		  createChildProcess(name,args) ;
			}		
	}
fclose(fd) ;
}


int _readConfig(int noConnexion,int mode) { 
																	 // Renvoi 0 si le device en paramatre n'a pas de definition 
																	 // Si nouvelle connexion noConnexion est le numero de connexion																	 
FILE *fd 							;
char	buf[1024] 			;
char *type						;
char *device					;
char *in_priority			;
char *out_autorise		;
char *fileName				;
int	c, n							;
int	nModels = 0 				;
struct messages_in_out *m ;	
struct models *model ;	
int findConfigDevice = 0 ;	

if (debugLevel == 9)
	myLog("read config") ;

if (mode == LOAD_CONFIG_DEF) fileName = CONFIG_DEF ;
else fileName = CONFIG_DEVICE ;
	
if ((fd = fopen (fileName,"r")) == NULL) {
	int mask = umask(0) ;
	fd = fopen (fileName,"w") ; // cree si n'existe pas
	umask(mask) ;
	if (fd) fclose(fd) ;
	if ((fd = fopen (fileName,"r")) == NULL) {
		myLog("Erreur read config") ;
		return 1 ;
		}
	}

if (mode == LOAD_CONFIG_DEF) {
	memset(models,0,sizeof(struct models) * MAX_MODELS) ;
	}

if (noConnexion == LOAD_ALL_CONFIG) {
	for (c = 0 ; c < top_connexion ; c++) {
		memset(connexions[c].messages_in_out,0,sizeof(struct messages_in_out) * MAX_TYPE_PHRASE) ;
		}
	}

while (fgets(buf,sizeof(buf) - 1,fd)) {
	while (strlen(buf) >  0 && buf[strlen(buf) - 1] < ' ') buf[strlen(buf) - 1] = 0 ;
	if (!*buf || *buf == '#') continue ;
	if (debugLevel == 9) myLog("read config : ligne : %s",buf) ;	
	type = strtok(buf,"|") ;
	device = strtok(NULL,"|") ;

	if (type && device && !strcmp(type,"GENERIC") && mode == LOAD_CONFIG_DEF) {
		struct mod ;
		model = &models[nModels++] ;
		strncpy(model->name,device,sizeof(model->name) - 1) ;
		n = 0 ;
		while ((type = strtok(NULL,"|")) && 
					(in_priority = strtok(NULL,"|")) && 
					(out_autorise = strtok(NULL,"|")) && n < MAX_TYPE_PHRASE) {
					m = &model->messages_in_out[n] ;
					strncpy(m->type,type,sizeof(m->type) - 1) ;
					m->in_priority = atoi(in_priority) ;
					m->out_autorise = atoi(out_autorise) ;
					n++ ;
					}
				continue ;
				}

	if (type && device && !strcmp(type,"DEVICE") && mode == LOAD_CONFIG_CONF) {
		if (noConnexion >= 0 && !strcmp(device,connexions[noConnexion].name)) {
				findConfigDevice = 1 ;
				}
				
		for (c = 0 ; c < top_connexion ; c++) {
			char *nickname ;
			char *prefix ;
			char *speed  ;

			if (strcmp(connexions[c].name,device)) continue ;
			if (!(speed = strtok(NULL,"|"))) continue ;
			if (!(nickname = strtok(NULL,"|"))) continue ;
			if (!(prefix = strtok(NULL,"|"))) continue ;
			
			strncpy(connexions[c].def_speed,speed,sizeof(connexions[c].def_speed)-1) ; 
			*(connexions[c].def_speed + sizeof(connexions[c].def_speed)-1) = 0 ;
			if (!strcmp(speed,"57600")) connexions[c].speed = B57600 ;
			else if (!strcmp(speed,"38400")) connexions[c].speed = B38400 ;
			else if (!strcmp(speed,"19200")) connexions[c].speed = B19200 ;
			else if (!strcmp(speed,"9600")) connexions[c].speed = B9600 ;
			else connexions[c].speed = B4800 ;
			
			strncpy(connexions[c].nickname,nickname,sizeof(connexions[c].nickname) -1) ;
			strncpy(connexions[c].prefix,prefix,sizeof(connexions[c].prefix) -1) ;

			n = 0 ;
			while ((type = strtok(NULL,"|")) && 
							(in_priority = strtok(NULL,"|")) && 
							(out_autorise = strtok(NULL,"|")) &&
							n < MAX_TYPE_PHRASE) {
				m = &connexions[c].messages_in_out[n] ;
				strncpy(m->type,type,sizeof(m->type) - 1) ;
				m->in_priority = atoi(in_priority) ;
				m->out_autorise = atoi(out_autorise) ;
				n++ ;
				if (debugLevel >= 9) myLog("type %s priority %d out_autorise %d",m->type,m->in_priority,m->out_autorise) ;
				}
			}
		}		
	}


	// Verifie que tous les devices ont bien une definition
	if (mode == LOAD_CONFIG_CONF) {
		for (c = 0 ;  c < top_connexion ; c++) {
			struct messages_in_out *m ;
			struct models *model ;
			if (!*connexions[c].name) continue ;
			if (!*connexions[c].messages_in_out[0].type) {
				// Associe par defaut le model gps
				for (n = 0 ; n < MAX_MODELS && strcmp(models[n].name,"DEFAULT")  ; n++) ;
				if (n == MAX_MODELS) {
					if (debugLevel >= 2) myLog("model DEFAULT non trouve") ; 
					continue ;
					}
				memcpy(connexions[c].messages_in_out,
							models[n].messages_in_out,
							sizeof(struct messages_in_out) * MAX_TYPE_PHRASE) ;
				}
			}
		}
fclose(fd) ;
if (noConnexion >= 0) return findConfigDevice ;
return 1 ;
}


int readConfig(int noConnexion) {
	if (noConnexion == LOAD_ALL_CONFIG) {
		_readConfig(LOAD_ALL_CONFIG,LOAD_CONFIG_DEF) ;
		_readConfig(noConnexion,LOAD_CONFIG_CONF) ;
		readConfigChilds() ;
		return 0 ;		
		}
	return _readConfig(noConnexion,LOAD_CONFIG_CONF) ;
}

void addDeviceToConfig(int c) {
FILE *fdw ;
if ((fdw = fopen (CONFIG_DEVICE,"a")) == NULL) {
	myLog("Erreur Append config") ;
	return ;
	}
fseek(fdw,0L,2) ;
writeDevice(c,fdw) ;
fclose(fdw) ;
}

void writeDevice(int c,FILE *fdw) {
struct messages_in_out *m ;
int 	b ;


if (connexions[c].write) return ;
	char speed[8] ;
/*
	switch (connexions[c].speed) {
		case B4800 : strcpy(speed,"4800") ; ; break ;
		case B38400: strcpy(speed,"38400") ; break ;
		case B9600 : strcpy(speed,"9600") ; break ;
		case B19200: strcpy(speed,"19200") ; break ;
		case B57600: strcpy(speed,"57600") ; break ;
		default : strcpy(speed,"4800") ; break ;
		}
*/
	// PP met AUTO
	strcpy(speed,"AUTO") ;
	if (!*connexions[c].prefix) strcpy(connexions[c].prefix,"XX") ;
	if (!*connexions[c].nickname) strcpy(connexions[c].nickname,"Unknown") ;
	fprintf(fdw,"DEVICE|%s|%s|%s|%s",connexions[c].name,speed,connexions[c].nickname,connexions[c].prefix) ;
	
	for (b = 0 , m = connexions[c].messages_in_out ; b < MAX_TYPE_PHRASE && *m->type ; b++ , m++) {
		if (!*m->type) break ;
		// if (!m->in_priority && !m->out_autorise) continue ;
		fprintf(fdw,"|%s|%d|%d",m->type,
												m->in_priority,
												m->out_autorise) ;
		}
 fprintf(fdw,"\n") ;
 connexions[c].write = 1 ;
}
	
