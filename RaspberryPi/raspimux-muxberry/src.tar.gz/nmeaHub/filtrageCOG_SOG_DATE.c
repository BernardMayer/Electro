#include "nmeaHub.h"
#include <math.h>

// Filtrage cog sog
void filtrageCogSog(char *phrase) {
	int c ;
	char *prefix ;
	char *fix ;
	char *status ;
	char *lat ;
	char *lat_sens ;
	char *lng ;
	char *lng_sens ;
	char *sog ;
	char *cog ;
	char *date ;
	char *mag_var ;
	char *mag_sens ;
	float tmpValues[MAX_COG_SOG_VALUES] = { 0.0 } ;
	float sogValue = 0 ;
	float cogValue = 0 ;
	int		calc	;
	char *ptr   	;
	static int updateDate = 0 ;
	char tmp[16]	;
	struct tm tmGps ;
	time_t timeGps  ;

	if (!(prefix = myStrtok(phrase,',')) || !(fix = myStrtok(NULL,',')) || !(status = myStrtok(NULL,',')) ||
			!(lat = myStrtok(NULL,',')) || !(lat_sens = myStrtok(NULL,',')) || !(lng = myStrtok(NULL,',')) ||
			!(lng_sens = myStrtok(NULL,',')) || !(sog = myStrtok(NULL,',')) || !(cog = myStrtok(NULL,',')) ||
			!(date = myStrtok(NULL,',')) || !(mag_var = myStrtok(NULL,',')) || !(mag_sens = myStrtok(NULL,',')) )
			return ;
	if (!updateDate) {
		memset(&tmGps,0,sizeof(tmGps)) ;
		strncpy(tmp,fix,2) ;
		tmGps.tm_hour = atoi(tmp) ;
		strncpy(tmp,fix + 2,2) ;
		tmGps.tm_min = atoi(tmp) ;
		strncpy(tmp,fix + 4,2) ;
		tmGps.tm_sec = atoi(tmp) ;

		strncpy(tmp,date,2) ;
		tmGps.tm_mday = atoi(tmp) ;
		strncpy(tmp,date + 2,2) ;
		tmGps.tm_mon = atoi(tmp) -1 ;
		strncpy(tmp,date + 4,2) ;
		tmGps.tm_year = 2000 + atoi(tmp) - 1900 ;
		tmGps.tm_isdst = -1;
		timeGps = mktime(&tmGps) ;



		if (abs(time(NULL) - timeGps) > 3) {
			time_t heure 	;
			int delta_t	;
			updateDate++	;
			heure = time(NULL) ;
			delta_t = (localtime(&heure))->tm_hour - (gmtime(&heure))->tm_hour ;
			timeGps += (delta_t * 3600) ;
			stime(&timeGps) ;
			myLog("Mise a l'heure %d/%d/%d %d:%d:%d",
					tmGps.tm_mday,tmGps.tm_mon + 1,tmGps.tm_year + 1900,
					tmGps.tm_hour + delta_t,tmGps.tm_min,tmGps.tm_sec) ;
			}
		}
	
	memcpy (&tmpValues[1],sogValues,sizeof(float) * (MAX_COG_SOG_VALUES - 1)) ;
	tmpValues[0] = atof(sog) ;
	memcpy (sogValues,tmpValues,sizeof(float) * MAX_COG_SOG_VALUES) ;
	memset(&sogValues[filterValue],0,sizeof(float) * (MAX_COG_SOG_VALUES - filterValue)) ;
	
	memcpy (&tmpValues[1],cogValues,sizeof(float) * (MAX_COG_SOG_VALUES - 1)) ;
	tmpValues[0] = atof(cog) ;
	memcpy (cogValues,tmpValues,sizeof(float) * MAX_COG_SOG_VALUES) ;
	memset(&cogValues[filterValue],0,sizeof(float) * (MAX_COG_SOG_VALUES - filterValue)) ;
	for (c = 0 ; c < filterValue ; c++) {
		sogValue += sogValues[c] ; 
		}
	sogValue /= (float)filterValue ;
	cogValue = getCogValue() ;
	// Regenere la phrase avec vitesses moyennes
	sprintf(phrase,"%s,%s,%s,%s,%s,%s,%s,%.2f,%.2f,%s,%s,%s",
					prefix,fix,status,lat,lat_sens,lng,lng_sens,
					sogValue,cogValue,date,mag_var,mag_sens) ;
	// Enleve le cks si existe car il n'est plus bon
	if (strlen(phrase) >= 3 && *(phrase + strlen(phrase) - 3) == '*') *(phrase + strlen(phrase) - 3) = 0 ;
	if (strlen(phrase) >= 2 && *(phrase + strlen(phrase) - 2) == '*') *(phrase + strlen(phrase) - 2) = 0 ;
	checkForCheckSum(phrase) ;
	}
	
int getCogValue() {
	int c ;
	float cogValue = 0 ;
	float sumCos = 0 ;
	float sumSin = 0 ;

	for (c = 0 ; c < filterValue ; c++) {
		sumCos += cos(cogValues[c] * M_PI / 180) ;
		sumSin += sin(cogValues[c] * M_PI / 180) ;
		}
	cogValue = atan2(sumSin / (float)filterValue ,sumCos / (float)filterValue) * 180 / M_PI ;
	if (cogValue < 0) cogValue += 360 ;
	if (cogValue > 360) cogValue -= 360 ;
	return cogValue ;
}