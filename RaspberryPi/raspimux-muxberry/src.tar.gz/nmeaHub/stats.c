#include "nmeaHub.h"

struct priorityGroups priorityGroups[] = {
		{ "GPS" ,
			{ "GGA" , "GLL" , "GSA" , "GSV" ,"VTG" , "RMC" , "ZDA" ,"ZDU" , "ZZU" , NULL } ,
			0, 0
		},
		{ "AIS" ,
			{ "VDM" , "VDO" , NULL } ,
			0, 0
		},
		{ "PILOTE" ,
			{ "HDG" , "HDM" , "HDT" , NULL } ,
			0, 0
		},
		{ "INSTRUMENTS" ,
			{ "DBT" , "DPT" , "MTA" ,"MTW" , "MWD" , "MWV" , "VHW" , "VLW" , "VWR" , "VWT", NULL } ,
			0, 0
		},
		{ "NAVIGATION" ,
			{ "APA" , "AAM" ,"APB" , "RMB" , "XTE" , "BOD" , "BWC" , "WPL" , "RTE" , "ZTG", NULL } ,
			0, 0
		},
		{ NULL } 
	} ;
	
	
struct typesStats *getStatsElement(struct connexion *con,char *type,int inOut) {
	struct typesStats *pt  ;
	int c ;
	
	if (inOut == IN_STAT) pt = con->in_stats ;
	else pt = con->out_stats ;

	for (c = 0 ; c < MAX_TYPE_PHRASE ; c++ , pt++) {
			if (!*pt->type) break ;
			if (!strcmp(type,pt->type)) return pt ;
			}
	if (c ==  MAX_TYPE_PHRASE) {
		 	myLog("getStatsElement plus de resources disponibles") ;
		 	return NULL ;
		 	}
	strncpy(pt->type,type,sizeof(pt->type) - 1) ;
	pt->num = 1 ;
	return pt ;
	}
	
// Recupere la structure stat du dernier message envoye
struct priorityStats *getStatsPriority(char *type) {
	int	c ;
	struct priorityStats *pt ;
	
	for (c = 0 , pt = priorityStats ; c < MAX_TYPE_PHRASE ; c++ , pt++) {
		if (!*pt->type) break ;
		if (!strcmp(type,pt->type)) return pt ;
		}
	if (c ==  MAX_TYPE_PHRASE) {
		 	myLog("getStatsPriority plus de resources disponibles") ;
		 	return NULL ;
		 	}
		 	
	strncpy(pt->type,type,sizeof(pt->type) - 1) ;
	pt->priority = 0 ;
	pt->lastSend = 0 ;
	return pt ;
	}

void writeStats() {
FILE *fdw ;
int	c			;

if ((fdw = fopen(STAT_FILE,"w")) == NULL) {
	myLog("Ecriture statistiques echoue") ;
	return ;
	}

for (c = 0 ; c < MAX_CONNEXIONS ; c++) {
	int b ;
	
	if (!*connexions[c].name) continue ;
	
	fprintf(fdw,"%s|IN",connexions[c].name) ;
	for (b = 0 ; b < MAX_TYPE_PHRASE && *connexions[c].in_stats[b].type ; b++ ) {
			fprintf(fdw,"|%s|%d",connexions[c].in_stats[b].type,connexions[c].in_stats[b].num) ;
			}
	fprintf(fdw,"\n") ;
	fprintf(fdw,"%s|OUT",connexions[c].name) ;
	for (b = 0 ; b < MAX_TYPE_PHRASE && *connexions[c].out_stats[b].type ; b++) {
			fprintf(fdw,"|%s|%d",connexions[c].out_stats[b].type,connexions[c].out_stats[b].num) ;
			}
	fprintf(fdw,"\n") ;
	}
fclose(fdw) ;
}

// Permet de recuperer la priority in et l'autorisation out
struct messages_in_out *getMessageInOut(struct connexion *con,char *type) {
	int c ;
	struct messages_in_out *pt ;
	for (c = 0 , pt = con->messages_in_out ; c < MAX_TYPE_PHRASE && *pt->type && strcmp(pt->type,type) ; c++, pt++ ) ;
	if (c == MAX_TYPE_PHRASE) {
			myLog("getMessageInOut plus de resources disponibles") ;
		 	return NULL ;
			}
	if (!*pt->type) {
		strncpy(pt->type,type,sizeof(pt->type) - 1) ;
		pt->in_priority = 100 ;
		pt->out_autorise = 1 ;
		}
	return pt ;
	}


struct	 priorityGroups *getPriorityGroups(char *type) {
	int	b , c 			;

	for (c = 0 ; priorityGroups[c].name ; c++) {
		for (b = 0 ; priorityGroups[c].types[b] && strcmp(type,priorityGroups[c].types[b]) ; b++) ;
			if (priorityGroups[c].types[b]) {
				return &priorityGroups[c] ;
			}
		}
	return NULL ;
	}	
