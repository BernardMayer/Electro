#include <nmeaHub.h>

int createChildProcess(char *name,char **args) {
int fdPipe_in [2] ;
int fdPipe_out[2] ;
int	pid						;
int	c							;
int	flags					;

char *argv[MAX_PROCESS_ARGS + 1]		;


for (c = 0 ; c < top_connexion && strcmp(connexions[c].name,name) ; c++) ;
if (c < top_connexion) {
	return -1 ;
	}

if (pipe(fdPipe_in) == -1) return -1 ;
if (pipe(fdPipe_out) == -1) return -1 ;

if ((pid = fork()) == 0) {
		dup2(fdPipe_in[0],0) ;
		dup2(fdPipe_out[1],1) ;
		close(fdPipe_in[1]) ;
		close(fdPipe_out[0]) ;
		
		for (c = 3 ; c < 128 ; c++) close(c) ;
		sleep(2) ;
		if (execvp(args[0],args) == -1) exit(1) ;
		exit(0) ;
		}
		
	close(fdPipe_in[0]) ;
	close(fdPipe_out[1]) ;
	for (c = 0 ; c < MAX_CONNEXIONS && *connexions[c].name ; c++) ;
	if (c ==  MAX_CONNEXIONS ) {
			if (debugLevel >= 2) myLog("To many Connexions opened") ;
			return -1 ;
			} 
	strcpy(connexions[c].name,name) ;
	connexions[c].args = args ;
	connexions[c].source = CHILD_SOURCE ;
	connexions[c].speedOk = 1 ;
	connexions[c].mode = O_RDWR ;
	connexions[c].pidChild = pid ;
	connexions[c].fd_in = fdPipe_out[0] ;
	flags = fcntl(connexions[c].fd_in,F_GETFL,0) ;
	fcntl(connexions[c].fd_in,F_SETFL,flags | O_NDELAY) ;
	connexions[c].fd_out = fdPipe_in[1] ;
	setTopConnexion() ;
	if (debugLevel >= 8) myLog("New connection from %s",connexions[c].name) ;
	if (readConfig(c) == 0) { // readconfig renvoie 0 si la ligne n'est pas dans le fichier
		addDeviceToConfig(c) ;
		}
	createThread(&connexions[c]) ;
	return pid ;
}


