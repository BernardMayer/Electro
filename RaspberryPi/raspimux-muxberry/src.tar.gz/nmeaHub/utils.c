#include "nmeaHub.h"

void rtrim(char *buf) {
	while (*(buf + strlen(buf) - 1) <= ' ') *(buf + strlen(buf) - 1) = 0 ;
	}
	
void ltrim(char *buf) {
	while (*buf && *buf <= ' ') strcpy(buf,buf + 1) ;
	}

void	trim(char *buf) {
	rtrim(buf) ;
	ltrim(buf) ;
	}		

char *myStrtok(char *str,char sep) { // Retourne un pointeur sur le buffer static NULL en fin de chaine
	static char buf[256] ;
	static char	*curent = NULL ;
	char	 *ptr ;
	char 	 *ret ;
	if (str) {
		curent = buf ;
		strncpy(buf,str,sizeof(buf) - 1) ;
		}
	if (!curent || !*curent) return NULL ;
	ret = curent ;
	for (ptr = curent ; *ptr && *ptr != sep ; ptr++) ;
	if (*ptr == sep) {
			curent = ptr + 1 ;
			*ptr = 0 ;
			}
	else curent = NULL ;
	*ptr = 0 ;
	return ret ;
	}
	
