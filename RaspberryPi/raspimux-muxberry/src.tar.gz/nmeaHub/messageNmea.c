#include "nmeaHub.h"

void messageAddChar( struct connexion *con, char ch) {
	if (!*con ->name) return ; 
	int len ;
	switch(ch) {
		case '!' :
		case '$' : // Si phrase AIS VDM 
							 if (*con->phrase == '!' && (!strcmp(con->phrase + 3,"VDM") || !strcmp(con->phrase + 3,"VDO"))) {
							 		// Contenu phrase AIS pouvant avoir ! ou $
							 		break ; 
							 		}
							 checkNmeaPhrase(con) ;
							 *con->phrase = ch ;
							 *(con->phrase + 1) = 0 ;
							 return ;
		case '\r' :
		case '\n' :
								checkNmeaPhrase(con) ;
								return ;
		
		default   : if (!isascii(ch)) {
		if (debugLevel >=2) myLog("errors [%02x] %d %s",ch,con->errorChars,*con->nickname ? con->nickname : con->name) ;
									if (con->errorChars++ == 16) {
										con->errorChars = 0 ;
										*con->phrase = 0 ;
										if (con->source == TTY_SOURCE) changeSpeed(con) ;
										}									
									return ;
									}
		}
	len = strlen(con->phrase) ;
	if (len == sizeof(con->phrase) - 5) {
		if (debugLevel) myLog("Too many chars in nmea phrase %s (lost char %c)",con->phrase,ch) ;
		return ;
		}
	con->phrase[len] = ch ;
	con->phrase[len + 1] = 0 ;
	}

int checkForCheckSum(char *phrase) {
	int calc ;
	char *ptr ;
	char *ptCks ;
	int cks ;
	
	// Calcul le checksum
	for (calc = 0 , ptr = phrase + 1 ; *ptr && *ptr != '*' ; ptr++) calc = calc ^ *ptr ;

	// Si le checksum existe		
	if (strlen(phrase) >= 3 && *(phrase + strlen(phrase) - 3) == '*' ||
			strlen(phrase) >= 2 && *(phrase + strlen(phrase) - 2) == '*') {
			// Recupere le checksum
			for (ptCks = phrase ; *ptCks && *ptCks != '*' ; ptCks++) ;
			if (*ptCks == '*') {
				ptCks++ ;
				sscanf(ptCks,"%X",&cks) ;
				}
		if (calc != cks) {
			if (debugLevel >= 2) myLog("Checksum error [%s] find cks %s calc cks %02x",phrase,ptCks,calc) ;
			return -1 ; 
			}
		return 0 ;
		}
	// Si le checksum n'existe pas		
	sprintf(phrase + strlen(phrase),"*%02x",calc) ;
	return 0 ;
	}

void checkNmeaPhrase(struct connexion *con) {
	unsigned char  *ptr 		;
	char	type[4]	;
	char	*ptCks	;
	int		cks 		;
	int	  calc		;
	struct typesStats *t ;
	struct messages_in_out *m ;
	struct priorityStats *p	;
	int priority ;
	time_t timestamp ;
	struct priorityGroups *pG ;
	timestamp = time(0) ;

	if (*con->phrase == 0 ) return ;
	if (debugLevel >= 8) myLog("Traitement Phrase %s [%s]",*con->nickname ? con->nickname : con->name,con->phrase) ; 
	if ((*con->phrase != '!' && *con->phrase != '$') ||
			strlen(con->phrase) < 8 || *(con->phrase + 6) != ',' ) {
			if (con->phpStreamIo) logPhpNmea(con,con->phrase,"REJ INCOMPLETE") ;
			if (debugLevel >= 2) myLog("%s phrase [%s] reject",
				*con->nickname ? con->nickname : con->name,
				con->phrase) ;
			con->errorPhrases++ ;
			*con->phrase = 0 ;
			if (con->errorPhrases == 16) closeConnexion(con) ;
			return ;
			}
	for (int c = 1 ; c < 6 ; c++) { // Test !GPGLL
		if (!isupper(*(con->phrase + c))) {
			if (con->phpStreamIo) logPhpNmea(con,con->phrase,"REJ BAD FORMAT") ;
			if (debugLevel >= 2) myLog("%s phrase [%s] reject",
				*con->nickname ? con->nickname : con->name,
				con->phrase) ;
			con->errorPhrases++ ;
			*con->phrase = 0 ;
			if (con->errorPhrases == 16) closeConnexion(con) ;
			return ;
			}
		}
	for (ptr = con->phrase ; *ptr && *ptr != ',' ; ptr++) ;
	if (*ptr != ',') {	
		if (con->phpStreamIo) logPhpNmea(con,con->phrase,"REJ INCOMPLETE") ;
		if (debugLevel >= 2) myLog("%s NMEA PHRASE %s incomplete",
					*con->nickname ? con->nickname : con->name,
					con->phrase) ;
		con->errorPhrases++ ;
		*con->phrase = 0 ;
		if (con->errorPhrases == 16) closeConnexion(con) ;
		return ;
		}
	// Recupere le prefix
	if (!*con->prefix) {
		strncpy(con->prefix,con->phrase + 1,2) ;
		con->prefix[2] = 0 ;
		}
	// Recupere le type de phrase
	strncpy(type,con->phrase + 3,3) ;
	type[3] = 0 ;
	if (logOutStream) logNmea(con,con->phrase,"IN") ;
	if (checkForCheckSum(con->phrase) == -1) {
			if (con->phpStreamIo) logPhpNmea(con,con->phrase,"REJ BAD CHECKSUM") ;
			con->errorPhrases++ ;
			*con->phrase = 0 ;
			return ;
			}
	// Si phrase bonne met speedOk à 1
	if (con->errorPhrases) con->errorPhrases-- ;
	con->lastRead = timestamp ;
	if (!con->speedOk) {
		myLog("%s speedOk sur %s",con->nickname,con->phrase) ;
		con->speedOk = 1 ;
		}

	// Met la phrase dans les stats	
	if ( (t = getStatsElement(con,type,IN_STAT)) ) {
		if (debugLevel >= 8) myLog("%s %s last_send %d in_stat %d",*con->nickname ? con->nickname : con->name,type,timestamp - t->lastSend,t->num) ;
		t->num++ ;
		}
	else if (debugLevel >= 8) myLog("%s %s not in IN_STAT",*con->nickname ? con->nickname : con->name,type) ;

	con->errorChars = 0 ;
	if ( !(m = getMessageInOut(con,type)) || m->in_priority == 0) {
					if (con->phpStreamIo) logPhpNmea(con,con->phrase,"DEL") ;
					if (debugLevel >= 8) myLog("%s %s  in_priotity = 0 => Poubelle",con->name,type) ;
					return ;
					}
			
	p = getStatsPriority(type) ;
	pG = getPriorityGroups(type) ;
	if (debugLevel >= 8) myLog("priority p %x mInOut%x",p,m) ;
	if ( m && p) {
		// Si la priority du device est > à la priority du dernier message envoye dans les 20 sec on envoi pas
		if (debugLevel >= 8) myLog("-> %s %d %d p->type %s p->priority %d p->lastSend %d",m->type,m->in_priority,m->out_autorise,p->type,p->priority,p->lastSend) ;
		if (m->in_priority > p->priority && (time(0) - 20) < p->lastSend) {
			if (debugLevel >= 8) myLog("Priorite %s %d < %d => abandonne",type,p->priority,m->in_priority) ;
			if (con->phpStreamIo) logPhpNmea(con,con->phrase,"DEL PRIORITY") ;
			return ;
			}
	  // Idem pour le groupe, evite 
		if (pG && m->in_priority > pG->priority && (time(0) - 20) < pG->lastSend) {
					if (debugLevel >= 8) myLog("Priorite Groupe %s %d < %d => abandonne",type,pG->priority,m->in_priority) ;
					if (con->phpStreamIo) logPhpNmea(con,con->phrase,"DEL GROUP PRIORITY") ;
					return ;
				}
		priority = m->in_priority ;
		}
	else priority = 1000 ;
	if (p) {
		p->priority = priority ;
		p->lastSend = time(0) ;
		}
	if (pG) {
		pG->priority = priority ;
		pG->lastSend = time(0) ;
		}
	if (!strcmp(type,"RMC")) 
		filtrageCogSog(con->phrase) ;
		
	// Rejette si temps < MIN_REPET_TIME
	if (t) {
		if (t->lastSend && t->lastSend > timestamp - MIN_REPET_TIME && !strcmp(type,"HDM")) { // Permet d'eviter les messages repetes trop rapidement
			if (debugLevel >= 8) myLog("%s %s repetition dans le temps MIN_REPET_TIME => Poubelle",con->name,type) ;
			return ;
			}
		t->lastSend = time(0) ;
		}	
	if (con->phpStreamIo) logPhpNmea(con,con->phrase,"IN") ;
	dispatch(con,type,t) ;
	}


