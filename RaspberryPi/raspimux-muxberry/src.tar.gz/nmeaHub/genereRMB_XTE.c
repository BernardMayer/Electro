#include "nmeaHub.h"

void genereRMB_XTE(struct connexion *con) { // RMB et XTE sont nécessaires au répétiteur NASA
	char savePhrase[SIZE_PHRASE] ;
	strcpy(savePhrase,con->phrase) ;
	sprintf(con->phrase,"$GPRMB,A,,,,,,,,,,,,A") ;
	checkForCheckSum(con->phrase) ;
	if (debugLevel >= 7)
		myLog("RMB [%s]",con->phrase) ;
	dispatch(con,"RMB",NULL) ;
	sprintf(con->phrase,"$GPXTE,A,A,,,") ;
	if (debugLevel >= 7)
		myLog("XTE [%s]",con->phrase) ;
	checkForCheckSum(con->phrase) ;
	dispatch(con,"XTE",NULL) ;
	strcpy(con->phrase,savePhrase) ;
	}

void genereGLL(struct connexion *con) { // Genere GLL a partir de GGA
	char savePhrase[SIZE_PHRASE] ;
	char bufGLL[SIZE_PHRASE] ;
	char bufGGA[SIZE_PHRASE] ;
	char bufHeure[16] ;
	char *tok ;
	
	strcpy(savePhrase,con->phrase) ;
	strcpy(bufGGA,con->phrase) ;
	sprintf(bufGLL,"$GPGLL,") ;
	if (!(tok = strtok(bufGGA, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // GGA
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // Heure
	strncpy(bufHeure,tok,sizeof(bufHeure) - 1) ;
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // Lat
	strcat(bufGLL,tok) ; strcat(bufGLL,",") ;
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // Lat sens
	strcat(bufGLL,tok) ; strcat(bufGLL,",") ;
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // Long
	strcat(bufGLL,tok) ; strcat(bufGLL,",") ;
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; } // Long sens
	strcat(bufGLL,tok) ; strcat(bufGLL,",") ;
	strcat(bufGLL,bufHeure) ; strcat(bufGLL,",") ;
	strcat(bufGLL,"A") ;
	strcpy(con->phrase,bufGLL) ;
	checkForCheckSum(con->phrase) ;
	if (debugLevel >= 7)
		myLog("GLL [%s]",con->phrase) ;
	dispatch(con,"GLL",NULL) ;
	strcpy(con->phrase,savePhrase) ;
	}
/*
MWV Wind Speed and Angle
12345
||||| $--MWV,x.x,a,x.x,a*hh
1) Wind Angle, 0 to 360 degrees
2) Reference, R = Relative, T = True 3) Wind Speed
4) Wind Speed Units, K/M/N
5) Status, A = Data Valid
6) Checksum
*/
void genereMWV(struct connexion *con) { // RMB et XTE sont nécessaires au répétiteur NASA
	char savePhrase[SIZE_PHRASE] ;
	char bufVWR[SIZE_PHRASE] ;
	char bufMWV[SIZE_PHRASE] ;
	int windDir ;
	float speed ;
	char *tok ;
	
	
	strcpy(savePhrase,con->phrase) ;
	
	strcpy(bufVWR,con->phrase) ;
	if (!(tok = strtok(bufVWR, ","))) { strcpy(savePhrase,con->phrase) ; return ; }
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; }
	windDir = atoi(tok) ;
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; }
	if (*tok == 'L') windDir *= -1 ; // sens
	if (!(tok = strtok(NULL, ","))) { strcpy(savePhrase,con->phrase) ; return ; }
	speed = atof(tok) ; // Speed

	windDir += getCogValue() ;
  if (windDir > 360) windDir -= 360 ;
  if (windDir < 0) windDir += 360 ;
	sprintf(bufMWV,"$IIMWV,%d,R,%.2f,N,A",windDir ,speed) ;
	checkForCheckSum(bufMWV) ;
	if (debugLevel >= 7)
		myLog("MWV [%s]",bufMWV) ;
	strcpy(con->phrase,bufMWV) ;
	dispatch(con,"MWV",NULL) ;
	strcpy(con->phrase,savePhrase) ;
	}

