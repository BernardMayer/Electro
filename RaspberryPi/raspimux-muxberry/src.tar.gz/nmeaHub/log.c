#include "nmeaHub.h"
#include <stdarg.h>

void	myLog(char *fmt, ...)
{
  va_list ap          ;
	struct tm *tm 	;
	time_t heure	;
	struct timeval tp ;
	
  
	heure = time(0) ;
	tm = localtime(&heure) ;
	gettimeofday(&tp,NULL) ;
	fprintf(stderr,"%d/%d/%d %02d:%02d:%02d.%d ",
			tm->tm_mday,tm->tm_mon + 1,tm->tm_year + 1900,tm->tm_hour,tm->tm_min,tm->tm_sec,tp.tv_usec / 1000) ;

	fprintf(stderr,"(-d%d) errno=%-3d ",debugLevel,errno) ;
	va_start(ap,fmt) ;
  vfprintf(stderr,fmt,ap) ;
  va_end(ap) ;
  fprintf(stderr,"\n") ;
}
