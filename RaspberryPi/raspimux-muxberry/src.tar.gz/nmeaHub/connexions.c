#include "nmeaHub.h"

void setTopConnexion() {
		for (top_connexion = MAX_CONNEXIONS - 1 ; 
			top_connexion >= 0 && !*connexions[top_connexion].name ; top_connexion--) ;  
		top_connexion++ ; // Limite superieure 
		}

void closeConnexion(struct connexion *con) {
	if (debugLevel >= 2) myLog("Closing connexion to %s",*con->nickname ? con->nickname : con->name) ;
	if (con->thread) pthread_cancel (con->thread) ;
	close(con->fd_in) ;
	if (con->fd_out != con->fd_in) close(con->fd_out) ;
	memset(con,0,sizeof(struct connexion)) ;
	setTopConnexion() ;
	}

/* Ce port devrai permettre de programmer l'interface distante */
void readApiUDP(int fd) {
	char	buf[1024] ;
	int 	c, x ;
	int flags ;
	x = read(fd,buf,sizeof(buf) - 1) ;
	if (x == -1 && errno == EINTR) return ;
	if (x <= 0) {
			close(fd) ;
			return ;
			}
	if (debugLevel >= 2) myLog("API_UDP received ") ;
	for (c = 0 ; c < x ; c++)
		if (debugLevel >= 2) myLog("char %02X",buf[c]) ;
	}

void readUDP(int fd) {
	char	buf[1024] ;
	int 	c, x, n   ;
	struct sockaddr_in sender;
	int sendsize = sizeof(sender);
	pthread_attr_t thread_attr;
  int flags ;
  
  // recherche une connexion disponible
	for (c = 0 ; c < MAX_CONNEXIONS && *connexions[c].name ; c++) ;
		if (c ==  MAX_CONNEXIONS ) {
			if (debugLevel >= 2) myLog("To many ZBEE connexions opened") ;
			return ;
			}
	x = recvfrom(fd, buf, sizeof(buf) - 1, 0, (struct sockaddr *)&sender, (socklen_t *)&sendsize) ;
	if (debugLevel >= 8) myLog("read UPD x = %d c = %d",x,c) ;	
	if (x <= 0) {
			close(fd) ;
			return ;
			}
	sprintf(connexions[c].name,"UDP %s",inet_ntoa(sender.sin_addr)) ;
	// Genere la connexion tcpip sur le meme port meme server
	if ((connexions[c].fd_in = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1) {
        myLog("ERROR opening socket ") ;		
        return ;
        }
  memset(&connexions[c],0,sizeof(struct connexion)) ;
  if (connect(connexions[c].fd_in,(const struct sockaddr *)&sender,sizeof(sender)) < 0) {
  		myLog("ERROR connecting to %s",connexions[c].name) ;
      close(connexions[c].fd_in) ;
      return ;
   		}
	flags = fcntl(connexions[c].fd_in,F_GETFL,0) ;
	fcntl(connexions[c].fd_in,F_SETFL,flags | O_NDELAY) ;
  connexions[c].fd_out = connexions[c].fd_in ;
	connexions[c].speedOk = 1 ;
	setTopConnexion() ;
	connexions[c].source = XBEE_SOURCE ;
	connexions[c].mode = O_RDWR ;
	for (n = 0 ; n < x ; n++) 
		messageAddChar(&connexions[c],buf[c]) ;
		
  createThread(&connexions[c]) ;
	}


void acceptTCP(int fd,int port) {
	int c ;
	struct sockaddr_in sender;
	int sendsize = sizeof(sender);
  struct hostent *server ;
  int flags ;
	// recherche une connexion disponible
	for (c = 0 ; c < MAX_CONNEXIONS && *connexions[c].name ; c++) ;
	if (c ==  MAX_CONNEXIONS ) {
			if (debugLevel >= 2) myLog("To many TCP connexions opened") ;
			return ;
			} 
	memset(&connexions[c],0,sizeof(struct connexion)) ;
	if ( (connexions[c].fd_in = accept(fd,(struct sockaddr *)&sender,(socklen_t *)&sendsize)) == -1) {
		if (debugLevel >= 2) myLog("Accept connexion error %d acceptTCP()",errno) ;
		return ;
		}
	flags = fcntl(connexions[c].fd_in,F_GETFL,0) ;
	fcntl(connexions[c].fd_in,F_SETFL,flags | O_NDELAY) ;
	sprintf(connexions[c].name,"%s:%d",inet_ntoa(sender.sin_addr),port) ;
	connexions[c].source = TCP_SOURCE ;
	connexions[c].speedOk = 1 ;
	connexions[c].mode = O_RDWR ;
	connexions[c].fd_out = connexions[c].fd_in ;
	setTopConnexion() ;
	
	if (debugLevel >= 8) myLog("New connection from %s",connexions[c].name) ;
	if (readConfig(c) == 0) { // readconfig renvoie 0 si la ligne n'est pas dans le fichier
		addDeviceToConfig(c) ;
		}
	createThread(&connexions[c]) ;
	}
	

