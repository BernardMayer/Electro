#include <nmeaHub.h>

struct models models[MAX_MODELS] = { 0 } ;	
struct connexion connexions[MAX_CONNEXIONS]	;
float sogValues[MAX_COG_SOG_VALUES] = { 0.0 } ;
float cogValues[MAX_COG_SOG_VALUES] = { 0.0 } ;
int filterValue = 5 ;
int genere_RMB_XTE_ok = 0 ;
int genere_GLL_ok = 0 ;
int genere_MWV_ok = 0 ;
int top_connexion = 0 ;
int logOutStream = 0 ;
int errno ;
int	debugLevel	;
struct priorityStats priorityStats [MAX_TYPE_PHRASE] = { 0 } ;
sem_t mutex ;
sem_t mutexMalloc ;

char *groupGPS[] = { "GGA" , "RMC" , "GSA" , "GSV" , "GLL" , NULL } ;
char *groupTRACK[] = { "XTE" , "RMB" , "APB" , "BOD" , "BWC" , NULL } ;
int	conIdGPS = -1 ;
int	conIdTRACK = -1 ;
int	timeStampGPS = 0 ;
int	timeStampTRACK = 0  ;
int	portIP = PORT_IP ;

int main(int argc,char *argv[]) {
int x , c , n	 		  ;
int	api_udp	  			;
int	conn_udp				;
int	conn_tcp[MAX_CONN_TCP]			; // Jusqu'a n connexions sur la meme adresse la seconde en emission
char buf[128] 			;
int	max_fd	 				;
fd_set	input				;
int	optval					;
struct sockaddr_in si_me, si_other;
sigset_t set 				;
time_t	lastScanAndStat	= 0 ;
time_t	lastScanPhpStreamIo	= 0 ;
time_t	lastReadConfig	= 0 ;
int	flags ;


myLog("starting process [%d]",getpid()) ;

sigemptyset(&set);
// sigaddset(&set, SIGUSR1); 
//sigaddset(&set, SIGUSR2);
sigaddset(&set, SIGPIPE) ;
//sigaddset(&set, SIGCHLD) ;
//sigaddset(&set, SIGALRM);
pthread_sigmask(SIG_BLOCK, &set, NULL);

signal(SIGUSR1,sigusr1) ;
signal(SIGUSR2,sigusr2) ;
signal(SIGPIPE,sigpipe) ;
signal(SIGCHLD,sigchld) ;


sem_init(&mutexMalloc, 0, 32);
sem_init(&mutex, 0, 32);

opterr = 0 ;
	while ((c = getopt (argc, argv, ":hgrvld:f:")) != -1)
			switch (c) {
					case 'd': debugLevel = atoi(optarg) ;
						  if (debugLevel >= 8) logOutStream = 1 ;
							break ;
					case 'p' : portIP = atoi(optarg) ;
										 break ;
							
					case 'f': filterValue = atoi(optarg) ; 
										if (filterValue < 1 || filterValue == 10) {
											filterValue = 5 ;
											myLog("Bad arg -f set filterValue to 10") ;
											}
							break ;
					case 'r': genere_RMB_XTE_ok = 1 ;
										myLog("Genere RMB et XTE sur reception RMC") ;
							break ;
							
					case 'l': logOutStream = 1 ;
										myLog("Log des emissions dans /tmp OK") ;
							break ;
							
					case 'g': genere_GLL_ok = 1 ;
										myLog("Genere GLL sur reception GGA") ;
							break ;
					case 'v': genere_MWV_ok = 1 ;
										myLog("Genere MWV sur reception VWR") ;
							break ;
							
					case 'h' : fprintf(stderr,"Uasage %s -h (this help) -l (log) -d (debug)\n",argv[0]) ;
										 fprintf(stderr,"-r (genere RMB XTE sur RMC) -g (genere GLL sur GGA) -v (ajoute VWV apres VWR)\n") ;		
										 fprintf(stderr,"-f filter_value (Nombre de phrases RMC pour lisser COG et SOG)\n") ;		
					 					 fprintf(stderr,"-p port (default %d) (port ... + 3)\n",PORT_IP) ;	
					 					 fprintf(stderr,"port (default %d ... %d)\n",PORT_IP,PORT_IP+3) ;	
										 exit(1) ;
      	}
      	
myLog("Set filterValue to %d",filterValue) ;
for (c = 0 ; c < MAX_CONNEXIONS ; c++) {
	memset(&connexions[c],0,sizeof(struct connexion)) ;
	}
	

if ( (api_udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1 ||
				(conn_udp = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1 ) {
				myLog("Cannot start udp listener ") ;
				exit(1) ;
				}
				
for (c = 0 ; c < MAX_CONN_TCP ; c++) {
	if ((conn_tcp[c] = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP)) == -1 ) {
			myLog("Cannot start tcp listener ") ;
			exit(1) ;
			}	
		}
optval = 1 ;
setsockopt(api_udp, SOL_SOCKET, SO_REUSEADDR, (void *)&optval, sizeof(optval));
setsockopt(conn_udp, SOL_SOCKET, SO_REUSEADDR, (void *)&optval, sizeof(optval));
for (c = 0 ; c < MAX_CONN_TCP ; c++) {
	setsockopt(conn_tcp[c], SOL_SOCKET, SO_REUSEADDR, (void *)&optval, sizeof(optval));
	}
bzero(&si_me,sizeof(si_me));
si_me.sin_family = AF_INET;
si_me.sin_port = htons(PORT_API);
si_me.sin_addr.s_addr = htonl(INADDR_ANY);

if (bind(api_udp , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1) {
     myLog("Cannot bind udp API_XBEE on port %d ",PORT_API) ;
     exit(1) ;
		}
flags = fcntl(api_udp,F_GETFL,0) ;
fcntl(api_udp,F_SETFL,flags | O_NDELAY) ;

si_me.sin_port = htons(PORT_API);
if (bind(conn_udp , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1) {
     myLog("Cannot bind udp PORT_XBEE on port %d ",PORT_API) ;
     exit(1) ;
		}
flags = fcntl(conn_udp,F_GETFL,0) ;
fcntl(conn_udp,F_SETFL,flags | O_NDELAY) ;

for (c = 0 ; c < MAX_CONN_TCP ; c++) {
	si_me.sin_port = htons(portIP + c) ;
	if (bind(conn_tcp[c] , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1) {
     myLog("Cannot bind tcp  on port %d ",portIP + c) ;
     exit(1) ;
		}
	if ( listen( conn_tcp[c], 20) == -1 ) {
        printf( "listen() error %d", errno );
        exit(1);
    		}
	}


    		
// Polling des files descripteurs
lastScanAndStat = 0 ;
lastScanPhpStreamIo = 0 ;
readConfig(LOAD_ALL_CONFIG) ;
lastReadConfig = time(0) ;

while (1) {
if (time(0) - lastScanAndStat > 10) {
		scanAndStat() ;
		lastScanAndStat = time(0) ;
		}
		
if (time(0) - lastScanPhpStreamIo > 1) {
		struct stat st ;
		if (stat("/var/www/data/nmeaHub/nmeaHub.conf",&st)) {
			if (st.st_mtime > lastReadConfig) {
				readConfig(LOAD_ALL_CONFIG) ;
				lastReadConfig = time(0) ;
				}
			}
		scanPhpStreamIo() ;
		lastScanPhpStreamIo = time(0) ;
		}
				
	max_fd = 0 ;
	FD_ZERO(&input);
	FD_SET(api_udp, &input) ;
	FD_SET(conn_udp, &input) ;
	for (c = 0 ; c < MAX_CONN_TCP ; c++) {
		FD_SET(conn_tcp[c], &input) ;
		}
	
	if (api_udp > max_fd) max_fd = api_udp ;
	if (conn_udp > max_fd) max_fd = conn_udp ;
	for (c = 0 ; c < MAX_CONN_TCP ; c++) {
		if (conn_tcp[c] > max_fd) max_fd = conn_tcp[c] ;
		}
	
	for (c = 0 ; c < top_connexion ; c++) {
		if (!*connexions[c].name || connexions[c].fd_in == -1)
			 continue ;
		FD_SET(connexions[c].fd_in, &input) ;
		if (connexions[c].fd_in > max_fd) max_fd = connexions[c].fd_in ;
		}
		
	struct timeval tval = { 1L, 0L };
	x = select (max_fd + 1,&input,NULL,NULL,&tval) ;
  if (x == -1) {
	if (errno == EINTR) continue ;
  	else {
  		perror("select in main nmeaHub") ;
  		exit(0) ;
  		}
	}
  if (FD_ISSET(api_udp, &input)) readApiUDP(api_udp) ;
  if (FD_ISSET(conn_udp, &input)) readUDP(conn_udp) ;
  for (c = 0 ; c < MAX_CONN_TCP ; c++)
  	if (FD_ISSET(conn_tcp[c], &input)) acceptTCP(conn_tcp[c],portIP + c) ;
  
	for (c = 0 ; c < top_connexion ; c++) {
		if (!*connexions[c].name) continue ;
		if (FD_ISSET(connexions[c].fd_in, &input)) {
			errno = 0 ;
			x = read(connexions[c].fd_in,buf,sizeof(buf) - 1) ;
			if (debugLevel >= 8) myLog("read fd = %d name %s x = %d",connexions[c].fd_in,
																	*connexions[c].nickname ? connexions[c].nickname : connexions[c].name,
																	x) ;
			if (x == -1 && errno == EINTR) continue ;
			if (x <= 0) {
				if (connexions[c].source != CHILD_SOURCE) { // sera traite par SIGCLD
					if (debugLevel > 6) myLog("close Connexion %s",
																			*connexions[c].nickname ? connexions[c].nickname : connexions[c].name) ;
					closeConnexion(&connexions[c]) ;
					}
				else {
		   			perror("Lecture child") ;
					close(connexions[c].fd_in) ;
					connexions[c].fd_in = - 1 ;
					}
				}
			buf[x] = 0 ;
			for (n = 0 ; n < x ; n++) 
				messageAddChar(&connexions[c],buf[n]) ;
			}
		}
	
	}	
return 0 ;
}



	






