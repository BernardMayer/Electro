var ais = function(canvasId,paramsInstrument) {
	this.width = 0  ;
	this.height = 0 ;
	this.rayon = 8.0	; // 6 milles de rayon
	this.mouseX = -1 ;
	this.mouseY = -1 ;
	this.scale = 1 ;
	this.cog = 0 
	this.sog = 0 ;
	this.lat = 0 
	this.lng = 0 ;
	this.mouseX = -1 ;
	this.mouseY = -1 ;
	this.startMouseX = -1 ;
	this.startMouseY = -1 ;
	this.aisDecoder = new aivdmDecode({returnJson: false, aivdmPassthrough: true});
	this.aisTargets = new Array() ;
	this.targetPointed = null ;
	this.mmsiPointed = null ;
	this.touches = null ;
	this.lastDoubleTouch = null ;
	this.memoValue = true ; // propriete permettant de recevoir les evenements meme si invisible
	var mainCtx ;
	var c ;
	var nCibles ;
	var lastMouseWeel = Date.now() ;

	var aisStatus = [	{ type: 0 , txt: 'Under way using engine' } ,
										{ type: 1 , txt: 'At anchor' } ,
										{ type: 2 , txt: 'Not under command' } ,
										{ type: 3 , txt: 'Restricted manoeuverability' } ,
										{ type: 4 , txt: 'Constrained by her draught' } ,
										{ type: 5 , txt: 'Moored' } ,
										{ type: 6 , txt: 'Aground' } ,
										{ type: 7 , txt: 'Engaged in Fishing' } ,
										{ type: 8 , txt: 'Under way sailing' } ,
										{ type: 9 , txt: ' ' } ,
										{ type: 10 , txt: ' ' } ,
										{ type: 11 , txt: ' ' } ,
										{ type: 12 , txt: ' ' } ,
										{ type: 13 , txt: ' ' } ,
										{ type: 14 , txt: 'AIS-SART is active' } ,
										{ type: 15 , txt: '' } 
										] ;
										
	if (paramsInstrument.old) this.aisTargets = paramsInstrument.old.aisTargets ;
	
   // Set the size - also clears the canvas
	 mainCtx =  document.getElementById(canvasId).getContext('2d');
   this.width = mainCtx.width = $('#' + canvasId).width() ;
   this.height = mainCtx.height = $('#' + canvasId).height() ;
		
   this.repaint = function(params) {
   		 var me = this ;
   		 var tmpTargets = new Array() ;
   		 if ( (params == undefined || params.forcePaint == undefined) &&  !$('#' + canvasId).is(":visible")) return ;
   		 
   		 this.scale = (((this.height > this.width ? this.width : this.height) * 0.8) / 2) / this.rayon  ;
   		 mainCtx.fillStyle = $(body).css("background-color") ;
   		 mainCtx.fillRect(0,0,mainCtx.width,mainCtx.height) ;
   		 
   		 
   		 if (!this.aisTargets) {
   		 	console.log("this ") ;
   		 	console.log(this) ;
   		 	return ;
   		 	}
   		 
   		 this.targetPointed = null ;
   		 for (c = 0 ; c < this.aisTargets.length ; c++) {
   				if ( ((Date.now() - this.aisTargets[c].timestamp) / 1000) > 600) continue ;
   				if (this.mmsiPointed == this.aisTargets[c].mmsi)
   					this.targetPointed = this.aisTargets[c] ;
   				tmpTargets.push(this.aisTargets[c]) ;
   				}
   		 this.aisTargets = tmpTargets ;
   		 
   		 mainCtx.fillStyle = "#00cc66" ;
   		 // Point central cercle du bateau
   		 mainCtx.beginPath() ;
   		 mainCtx.arc (mainCtx.width / 2,mainCtx.height / 2,2,0,2 * Math.PI) ;
   		 mainCtx.fill() ;
   		 // Creation des cercles de distance 
   		 mainCtx.strokeStyle = '#00cc66'
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(mainCtx.width / 2,mainCtx.height / 2,(this.rayon * this.scale) * 4 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(mainCtx.width / 2,mainCtx.height / 2,(this.rayon * this.scale) * 3 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(mainCtx.width / 2,mainCtx.height / 2,(this.rayon * this.scale) * 2 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 mainCtx.beginPath() ;
   		 mainCtx.arc(mainCtx.width / 2,mainCtx.height / 2,(this.rayon * this.scale) * 1 / 4,0,2 * Math.PI) ;
   		 mainCtx.stroke() ; 			
   		 
    		mainCtx.font="20px Georgia" ;
    		mainCtx.fillStyle = "white" ;

			// COG et SOG et cibles
			mainCtx.font="20px Georgia" ;
    	mainCtx.fillStyle = "white" ;
			var startX = (((this.width - (this.height * 0.8)) / 2 )- mainCtx.measureText("RAYON : 36 Mn").width) / 2 ;
			if (startX < 0) startX = 2 ;
			if (this.rayon >= 1)
				mainCtx.fillText("RAYON : " + parseInt(this.rayon) + ' Mn', startX,this.height * 0.2 + 5) ;
			else mainCtx.fillText("RAYON : " + this.rayon.toFixed(2) + ' Mn°', startX,this.height * 0.2 + 5) ;
			mainCtx.fillText("COG : " + parseInt(this.cog) + ' °', startX,this.height * 0.2 + 25) ;
			mainCtx.fillText("SOG : " + parseFloat(this.sog).toFixed( 1 ) + ' Kn', startX,this.height * 0.2 + 45) ;

			if (this.targetPointed) {
					var p1, p2, b, d ;
    			mainCtx.font="16px Georgia" ;
    			mainCtx.fillStyle = "white" ;
    			startX = (((this.width - (this.height * 0.8)) / 2 ) - mainCtx.measureText("Nom : abcdefghijklm").width ) / 2 ;
    			if (startX < 0) startX = 2 ;
    			startX += (this.width / 2) + (this.height * 0.8 / 2) ;
    			var p1 = new LatLon(this.lat,this.lng) ;
    			var p2 = new LatLon(this.targetPointed.lat,this.targetPointed.lon) ;
    			var d = (p1.distanceTo(p2) / 1.852).toFixed( 2 ) ; 
					var b = p1.bearingTo(p2).toFixed( 2 ) ; 
					if (d > this.rayon) { // En cas de zoom -
						this.mmsiPointed = null ;
						this.targetPointed = null ;
						this.repaint() ;
						return ;
						}
					var name = this.targetPointed.shipname ;
					if (this.targetPointed.name) name = this.targetPointed.name ;
					if (!name) name = '' ;
					if (!this.targetPointed.mmsi) this.targetPointed.mmsi = '' ;
					if (!this.targetPointed.speed) this.targetPointed.speed = '0' ;
					if (this.targetPointed.course == NaN) this.targetPointed.course = '0' ;
					if (!this.targetPointed.classe) this.targetPointed.classe = '-' ;
					var cpa = this.getCpa(this.targetPointed) ;
					var lineY = 5 ;
					var dY = 20 ;
					mainCtx.fillText("Nom : " + name,startX,this.height * 0.2 + lineY) ; 
					lineY += dY ;
					mainCtx.fillText("MMSI : " + this.targetPointed.mmsi,startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("Bearing : " + b + ' °',startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("Distance : " + d + " Mn",startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("Cog : " + this.targetPointed.course % 360 + ' °',startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("Sog : " + this.targetPointed.speed + ' Kn',startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("TCPA : " + cpa.tcpa +" ' ",startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("CPA : " + cpa.cpa +" Mn",startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					var min = parseInt(((Date.now() - me.targetPointed.timestamp) / 1000) / 60) ;
					var sec = parseInt(((Date.now() - me.targetPointed.timestamp) / 1000) % 60) ;
					mainCtx.fillText("Last receive : " + min +"' " + sec + "\"",startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					if (me.targetPointed.type > 0 && me.targetPointed.type < 15)
						mainCtx.fillText("Status : " + aisStatus[me.targetPointed.type-1].txt,startX,this.height * 0.2 + lineY) ;
					lineY += dY ;
					mainCtx.fillText("CLASSE : " + this.targetPointed.classe,startX,this.height * 0.2 + lineY) ;
   		 		}
			// Dessine les cibles
			nCibles = 0 ;
			if (me.lat && me.lng) {
				for (c = 0 ; c < me.aisTargets.length ; c++) {
						if (!this.aisTargets[c].lat || !this.aisTargets[c].lon) continue ;
						var p1 = new LatLon(me.lat,me.lng) ;
						var p2 = new LatLon(me.aisTargets[c].lat,me.aisTargets[c].lon) ;
						var d = p1.distanceTo(p2)  / 1.852 ; 
						var b = p1.bearingTo(p2); 
						if (d < me.rayon) nCibles++ ;
						else continue ;
						this.aisTargets[c].polygon = this.drawTarget( { me: me, target: me.aisTargets[c] } ) ;
					}
				if (this.targetPointed) this.drawTarget( { me: me, target: me.targetPointed } ) ;
				}	
		
			// Cibles
			mainCtx.font="20px Georgia" ;
    	mainCtx.fillStyle = "white" ;
			mainCtx.fillText(nCibles + " / " + this.aisTargets.length + " Cibles",(this.width / 6) + 10,this.height - 10) ;

			// touch point
			if (this.mouseX >= 0 && this.mouseY >= 0) {
   						mainCtx.beginPath() ;
   						mainCtx.fillStyle = "red" ;
   						mainCtx.arc (this.mouseX,this.mouseY,4,0,2 * Math.PI) ;
   						mainCtx.fill() ;
   						}
				
			// Handlers
   		$('#' + canvasId).unbind('mousemove') ;
   		$('#' + canvasId).bind('mousemove',function(event) {
   				var ais = me ;
   				var c ;
   				me.event = event ;
   				event.preventDefault() ;
   				var point = { x: event.pageX, y: event.pageY - $('#noVNC_status_bar').height() } ;
   				for (c = 0 ; c < me.aisTargets.length ; c++) {
   					if (!me.aisTargets[c].polygon) continue ;
	   				if (me.isPointInPoly (point,me.aisTargets[c].polygon)) {
	   							if (ais.mmsiPointed == me.aisTargets[c]) return ;
	   							ais.mmsiPointed = me.aisTargets[c].mmsi ;
	   							me.repaint() ;
	   							return ;
   								} 
   							}
   				} ) ;
   	
   		
   		$('#' + canvasId).unbind('mousewheel') ;
   		$('#' + canvasId).bind('mousewheel',function(event) {
   				var ais = me ;
   				var delta = 0 ;
   				me.event = event ;
   				event.preventDefault() ;
   				if (Date.now() - me.lastMouseWeel < 1000) return ;
   				me.lastMouseWeel = Date.now() ;
   				if (event.originalEvent) event = event.originalEvent ;
   				delta = event.deltaY ? -event.deltaY : event.wheelDelta/40 ;
   				if (delta > 0) {
   					if (ais.rayon < 32) ais.rayon *= 2 ;
   					}
   				else if (ais.rayon > 0.25) ais.rayon /= 2 ;
   				ais.repaint() ;
   				} ) ;
   	

   		$('#' + canvasId).unbind('touchmove') ;
   		$('#' + canvasId).bind('touchmove',function(event) {
   				var ais = me ;
   				var dx ;
   				var dy ;
   				event.preventDefault() ;

   				if (event.touches.length == 2) {
   					var touches = event.touches ;
   					if (!ais.touches) return ;
   					if (Date.now() - ais.lastDoubleTouch < 300) return ;
   					ais.lastDoubleTouch = Date.now() ;
   					var dx0 = Math.sqrt ( ( (ais.touches[0].screenX - ais.touches[1].screenX) * (ais.touches[0].screenX - ais.touches[1].screenX) ) +
   																( (ais.touches[0].screenY - ais.touches[1].screenY) * (ais.touches[0].screenY - ais.touches[1].screenY) )) ;
   					var dx1 = Math.sqrt ( ( (touches[0].screenX - touches[1].screenX) * (touches[0].screenX - touches[1].screenX) ) +
   																( (touches[0].screenY - touches[1].screenY) * (touches[0].screenY - touches[1].screenY) )) ;
						if ((dx1 - dx0) > 0 ) {
							if (ais.rayon < 32) ais.rayon *= 2 ;
							}
   					else if (ais.rayon > 0.25) ais.rayon /= 2 ;
   					ais.startMouseX = ais.mouseX = -1 ;
	   				ais.startMouseY = ais.mouseY = -1 ;
   					ais.repaint() ;
   					return ;
   					}
   				ais.touches = null ;

					if (ais.startMouseX == -1 || ais.startMouseY == -1) return ;
   				dx = event.touches[0].pageX - ais.startMouseX ;
   				dy = (event.touches[0].pageY - $('#noVNC_status_bar').height()) - ais.startMouseY ;
   				ais.mouseX += dx ;
   				ais.mouseY += dy ;
					var d = Math.sqrt( (ais.mouseX - ais.width / 2) * (ais.mouseX - ais.width / 2) +
														 (ais.mouseY - ais.height / 2) * (ais.mouseY - ais.height / 2) ) ;
					if (d > ais.rayon * ais.scale * 1.2) { // ne pas prende en compte  
						ais.mouseX -= dx ;
   					ais.mouseY -= dy ;
   					}
   				ais.startMouseX += dx ;
   				ais.startMouseY += dy ;
   				var point = { x: ais.mouseX, y: ais.mouseY } ;
   				for (var c = 0 ; c < ais.aisTargets.length ; c++) {
   					if (!ais.aisTargets[c].polygon) continue ;
	   				if (ais.isPointInPoly (point,ais.aisTargets[c].polygon)) {
	   							if (ais.mmsiPointed == ais.aisTargets[c]) break ;
	   							ais.mmsiPointed = ais.aisTargets[c].mmsi ;
	   							break ;
   								} 
   							}
   				ais.repaint() ;
   				} ) ;
   				
   		$('#' + canvasId).unbind('touchstart') ;
   		$('#' + canvasId).bind('touchstart',function(event) {
   				var ais = me ;
   				event.preventDefault() ;
   				if (event.touches.length > 1) { // Deux touches gestion du zoom
   					ais.touches = event.touches ;
   					ais.lastDoubleTouch = null ;
   					return ;
   					}
   				ais.touches = null ;
   				if (ais.startMouseX == -1 || ais.startMouseY == -1) {
   					ais.mouseX = event.touches[0].pageX ;
   					ais.mouseY = event.touches[0].pageY - $('#noVNC_status_bar').height();
						var d = Math.sqrt( (ais.mouseX - ais.width / 2) * (ais.mouseX - ais.width / 2) +
														 (ais.mouseY - ais.height / 2) * (ais.mouseY - ais.height / 2) ) ;
						if (d > ais.rayon * ais.scale * 1.2) { // ne pas prende en compte 
							ais.mouseX = ais.mouseY = -1 ;
							return ;
							} 
   					}
   				ais.startMouseX = event.touches[0].pageX ;
   				ais.startMouseY = event.touches[0].pageY - $('#noVNC_status_bar').height() ;
   				ais.repaint() ;
   				} ) ;
   	}	// reapaint
   	
   	
   	this.drawTarget = function (params) {
   			var me = params.me ;
   			var target = params.target ;
   			if (!target.lat || !target.lon) return new Array() ;
   			if (target.type == 21) return me.drawFixTarget(params) ;
   			if (!target.course) target.course = 0 ;
   			var mainCtx =  document.getElementById(canvasId).getContext('2d');
   			if (!me.lat || !me.lng) return new Array() ;
				var p1 = new LatLon(me.lat,me.lng) ;
				var p2 = new LatLon(target.lat,target.lon) ;
				var d = p1.distanceTo(p2)  / 1.852 ; 
				var b = p1.bearingTo(p2); 
				var course = target.course ;
				var angle = (course * Math.PI / 180) - (Math.PI / 2) ;
				var x , y ; // Centre du bateau cible
				var x1 , y1 ;
				var l = 8 ; // largeur bateau a dessiner
				var L = 30 ; // longueur bateau a dessiner
				polygon = new Array() ;
				age = (Date.now() - target.timestamp) / 1000  ;
				if (age  < 180) mainCtx.fillStyle = "#00ff00" ;
				else if (age < 300) mainCtx.fillStyle = "yellow" ;
				else if (age < 480) mainCtx.fillStyle = "orange" ;
				else  mainCtx.fillStyle = "red" ;
				if (me.targetPointed && me.targetPointed.mmsi == target.mmsi) mainCtx.fillStyle = "#ff33cc" ;
				mainCtx.beginPath() ;
				x = (mainCtx.width / 2) + Math.cos((b - 90) * Math.PI / 180) * d * me.scale ;
				y = (mainCtx.height / 2) + Math.sin((b - 90) * Math.PI / 180) * d * me.scale ;
				polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.moveTo(x,y) ;
   		 	x1 = x + (l * Math.cos(angle + (Math.PI / 2))) ;
   		 	y1 = y + (l * Math.sin(angle + (Math.PI / 2))) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + (L * Math.cos(angle)) ;
   		 	y1 = y + (L * Math.sin(angle)) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + (l * Math.cos(angle + (3 * Math.PI / 2))) ;
   		 	y1 = y + (l * Math.sin(angle + (3 * Math.PI / 2))) ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	mainCtx.lineTo(x,y) ;
   		 	polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.fill() ;
				return polygon ;
	   		}
 
 this.drawFixTarget = function (params) {
   			var me = params.me ;
   			var target = params.target ;
   			var mainCtx =  document.getElementById(canvasId).getContext('2d');
   			if (!me.lat || !me.lng) return new Array() ;
				var p1 = new LatLon(me.lat,me.lng) ;
				var p2 = new LatLon(target.lat,target.lon) ;
				var d = p1.distanceTo(p2)  / 1.852 ; 
				var b = p1.bearingTo(p2); 
				var x , y ; // Centre de la cible
				var x1 , y1 ;
				var l = 12 ; // largeur bateau a dessiner
				polygon = new Array() ;
				age = (Date.now() - target.timestamp) / 1000  ;
				mainCtx.fillStyle = "#FAFAFA" ;
				if (me.targetPointed && me.targetPointed.mmsi == target.mmsi) mainCtx.fillStyle = "#ff33cc" ;
				mainCtx.beginPath() ;
				x = (mainCtx.width / 2) + Math.cos((b - 90) * Math.PI / 180) * d * me.scale ;
				y = (mainCtx.height / 2) + Math.sin((b - 90) * Math.PI / 180) * d * me.scale ;
				polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.moveTo(x,y) ;
   		 	x1 = x + l ;
   		 	y1 = y ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x + l ;
   		 	y1 = y + l ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	x1 = x  ;
   		 	y1 = y + l ;
				polygon.push( { x: x1, y: y1 } ) ;
   		 	mainCtx.lineTo(x1,y1) ;
   		 	mainCtx.lineTo(x,y) ;
   		 	polygon.push( { x: x, y: y } ) ;
   		 	mainCtx.fill() ;
				return polygon ;
	   		}
	   		
	   		  		   		
   	this.setValue = function(value,params) {
   		var decoded ;
   		var me      ;
   		var phrase  ;
   		if (!params) params = {} ;
   		if (!params.scope ) params.scope = this  ;
   		me = params.scope ;
   		phrase = params.nmeaParams.nmeaValues.phrase ;
   		if (phrase == "VDM" || phrase == "VDO") {
   			decoded = me.aisDecoder.decode(value) ;
   			decoded.timestamp = Date.now() ;
   			if (decoded.type == 18 || decoded.type == 19 ||  decoded.type == 24) decoded.classe = 'B' ;
   			if (decoded.type == 1 || decoded.type == 2 ||  decoded.type == 3 ||
   						decoded.type == 5) decoded.classe = 'A' ;
   			for (var c = 0 ; c < me.aisTargets.length ; c++) { 
   				if (me.aisTargets[c].mmsi == decoded.mmsi) {
   					// Joint le message
   					for(var key in decoded) { me.aisTargets[c][key] = decoded[key] ; }
   					break ;
   					}
   				}
   			if (c == this.aisTargets.length) {
   				me.aisTargets.push(decoded) ;
   				}
   			}
   		if (phrase == "RMC") {
   			me.lat = params.data.lat / 100 ;
   			var deg = parseInt(me.lat) ;
   			var min = ((me.lat - deg) * 100) ;
   			me.lat = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.lat_sens == "S") me.lat = me.lat * -1 ;
   			me.lng = params.data.lng / 100 ;
   			deg = parseInt(me.lng) ;
   			min = ((me.lng - deg) * 100) ;
   			me.lng = deg + ((min / 60 * 100)) / 100 ;
   			if (params.data.lng_sens == "W") me.lng = me.lng * -1 ;
   			me.sog = params.data.sog ;
   			me.cog = params.data.cog ;
   			}
   		me.repaint() ;
   		}

		this.isPointInPoly = function (pt, poly) {
    	for(var c = false, i = -1, l = poly.length, j = l - 1; ++i < l; j = i)
        ((poly[i].y <= pt.y && pt.y < poly[j].y) || (poly[j].y <= pt.y && pt.y < poly[i].y))
        && (pt.x < (poly[j].x - poly[i].x) * (pt.y - poly[i].y) / (poly[j].y - poly[i].y) + poly[i].x)
        && (c = !c);
    	return c;
			}
		   
	 this.getCpa = function(cible) {
	 		var p1 = new LatLon(this.lat,this.lng) ;
	 		var p2 = new LatLon(cible.lat,cible.lon) ;
	 
	 		var d = p1.distanceTo(p2) ; 

		 for (var t = 0 ; t < 60 ; t++) {
					p1 = p1.destinationPoint(Number(this.cog), this.sog * 1.852 / 60) ;	 	 				 
					p2 = p2.destinationPoint(Number(cible.course), parseFloat(cible.speed) * 1.852 / 60) ;	
					var d1 = p1.distanceTo(p2) ;  
					if (d1 >= d) break ;
					d = d1 ;
				}
			return ( { tcpa: t == 0 ? '-' : t , cpa: t == 0 ? '-' : parseFloat(d / 1.852).toFixed(2) } ) ;
		}
	
		 				 
   this.repaint( { forcePaint: 1 } ) ;  
  }
   			
   

