#include "nmeaHub.h"
#include <sys/wait.h>

void scanAndStat() {
	static	time_t lastTime = 0 ;
	time_t  now ;
	struct  stat st	;
	int c ;

	now = time(0) ;
	if (stat("/var/www/data/nmeaHub.conf",&st) >= 0 && lastTime < st.st_mtime) {
		readConfig(LOAD_ALL_CONFIG) ;
		lastTime = st.st_mtime ;
		}
	// Verification des connexions tty passes en mode ICANON vitesse ok
	for (c = 0 ; c < top_connexion ; c++) {
		if (!*connexions[c].name) continue ; 
		if (connexions[c].source != TTY_SOURCE) continue ;
		if (connexions[c].speedOk == 0 && connexions[c].lastRead == 0) {
			changeSpeed(&connexions[c]) ;
			continue ;
			}			
		if (connexions[c].lastRead <= now - 10) {
			myLog("%s endormis => close speedOk %d lastRead %d",*connexions[c].nickname ? connexions[c].nickname : connexions[c].name,connexions[c].speedOk,connexions[c].lastRead) ;
			closeConnexion(&connexions[c]) ;
			}
		}
	writeStats() ;
	scanusbtty("/dev/serial/by-path","") ;
	scanusbtty("/dev","ttyUSB") ;
	}
	
void sigusr1(int signum) {
	int c ;
	signal(SIGUSR1,sigusr1) ;
	for (c = 0 ; c < top_connexion ; c++) {
		if (!*connexions[c].name) continue ;
		myLog("Queue %s %s %d mesages",connexions[c].name,connexions[c].nickname,connexions[c].nPool) ;
		}
	}
	
void sigchld(int signum) {
	int status 	;
	int	pid			;
	int	c				;
	int	find = 0 ;
	struct connexion saveConnexion ;
	
	pid = wait(&status) ;
	myLog("CHILD %d dead",pid) ;
	for (c = 0 ; c < top_connexion ; c++) {
		if (pid == connexions[c].pidChild) {
			find = 1 ;
			memcpy(&saveConnexion,&connexions[c],sizeof(saveConnexion)) ;
			closeConnexion(&connexions[c]) ;
			break ;
			}
		}
	if (find) {
			pid = createChildProcess(saveConnexion.name,saveConnexion.args) ;
			myLog("Create ChildProcess %s %s pid %d\n",saveConnexion.name,saveConnexion.args[0],pid) ;
		}
	signal(SIGCHLD,sigchld) ;
	}
	
void sigusr2(int signum) {
	int c ;
	signal(SIGUSR2,sigusr2) ;
	debugLevel++ ;
	if (debugLevel >= 10) debugLevel = 0 ;
	myLog("debugLevel = %d",debugLevel) ;
	}
		
void sigpipe(int sig) {
	signal(SIGPIPE,sigpipe) ;
	myLog("receive signal SIGPIPE") ;
	}
	
