/*
* File: main.cpp
* Author: al *
* Testing for CAN and RPI *
* See: https://github.com/thomasonw/NMEA2000_socketCAN *
* Created on February 12, 2017, 2:37 PM */
#include <cstdlib> 
#include <stdio.h> 
#include <iostream> 
#include "NMEA2000_CAN.h"

using namespace std;

int main(void) {
	cout << "Starting CAN watching" << endl;
	setvbuf (stdout, NULL, _IONBF, 0); 
	NMEA2000.SetCANPort("can0");
	NMEA2000.SetForwardStream(&serStream);
	NMEA2000.SetDebugMode(tNMEA2000::dm_ClearText);
	NMEA2000.SetForwardType(tNMEA2000::fwdt_Text);

	if (!NMEA2000.Open()) {
		cout << "Failed to open CAN port" << endl; 
		return 1;
		}
	cout << endl << "CAN started, going to watch it now" << endl;
	while(1) {	
		 NMEA2000.ParseMessages();
		 return 0;
		 }
	return 0 ;
	}
