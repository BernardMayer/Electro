# NMEA0183
NMEA0183 library for Arduino, Teensy and RPi

Object oriented NMEA0183 library for Arduino, Teensy and RPi

Library gives you a e.g. easy way to make NMEA0183->NMEA2000 interface like Actisense device.

Currently there are most common NMEA0183 messages parser/create function.

To compile example NMEA0183ToN2k or NMEA2000ToNMEA0183 you need also 
NMEA2000 library https://github.com/ttlappalainen/NMEA2000 and board dependent
driver libraries. See more on NMEA2000 library document.

