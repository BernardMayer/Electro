/*
N2kDataToNMEA0183.cpp

Copyright (c) 2015-2018 Timo Lappalainen, Kave Oy, www.kave.fi

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the
Software, and to permit persons to whom the Software is furnished to do so,
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF
CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

#include <math.h>
#include "N2kDataToNMEA0183.h"
#include <N2kMessages.h>
#include <NMEA0183Messages.h>

#define radToDeg 180.0 / M_PI


//*****************************************************************************
void tN2kDataToNMEA0183::HandleMsg(const tN2kMsg &N2kMsg) {
//printf("PGN %d\n",N2kMsg.PGN) ;
  switch (N2kMsg.PGN) {
    case 127250UL: HandleHeading(N2kMsg); break ;
    case 127258UL: HandleVariation(N2kMsg); break ;
    case 128259UL: HandleBoatSpeed(N2kMsg); break ;
    case 128267UL: HandleDepth(N2kMsg); break ;
    case 129025UL: HandlePosition(N2kMsg); break ;
    case 129026UL: HandleCOGSOG(N2kMsg); break ;
    case 129029UL: HandleGNSS(N2kMsg); break ;
    case 130306UL: HandleWind(N2kMsg) ; break ;
    case 130311UL : HandleEnviron(N2kMsg) ; break ;
    case 130310UL : HandleEnvironBis(N2kMsg) ; break ;
  }
  Update() ;
  SendRMC() ;
}

//*****************************************************************************
void tN2kDataToNMEA0183::Update() {
  if ( LastHeadingTime+2000<millis() ) Heading=N2kDoubleNA;
  if ( LastCOGSOGTime+2000<millis() ) { COG=N2kDoubleNA; SOG=N2kDoubleNA; }
  if ( LastPositionTime+4000<millis() ) { Latitude=N2kDoubleNA; Longitude=N2kDoubleNA; }
}

//*****************************************************************************
void tN2kDataToNMEA0183::SendMessage(const tNMEA0183Msg &NMEA0183Msg) {
  if ( pNMEA0183!=0 ) pNMEA0183->SendMessage(NMEA0183Msg);
  if ( SendNMEA0183MessageCallback!=0 ) SendNMEA0183MessageCallback(NMEA0183Msg);
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandleHeading(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kHeadingReference ref;
double _Deviation=0;
double _Variation;
tNMEA0183Msg NMEA0183Msg;

  if ( ParseN2kHeading(N2kMsg, SID, Heading, _Deviation, _Variation, ref) ) {
    if ( ref==N2khr_magnetic ) {
      if ( !N2kIsNA(_Variation) ) Variation=_Variation; // Update Variation
      if ( !N2kIsNA(Heading) && !N2kIsNA(Variation) ) Heading-=Variation;
    }
    LastHeadingTime=millis();
    if ( NMEA0183SetHDG(NMEA0183Msg,Heading,_Deviation,Variation,ref == N2khr_true ? 'T' : 'M',"AP") ) {
      SendMessage(NMEA0183Msg);
    }
  }
}

// PP HandleWind
void tN2kDataToNMEA0183::HandleWind(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kWindReference WindReference;
double WindAngle=0;
double WindSpeed ;
char	 bord[2]	 ;
tNMEA0183Msg NMEA0183Msg;

if (ParseN2kWindSpeed(N2kMsg,SID,WindSpeed,WindAngle,WindReference)) {
	strcpy(bord,"R") ;
	WindAngle *= radToDeg  ;
	if (WindAngle > 180) {
		WindAngle = 360 - WindAngle ;
		strcpy(bord,"L") ;
		}
	switch(WindReference) {
		case N2kWind_Apparent : NMEA0183Msg.Init("VWR","II") ; break ;
		case N2kWind_True_water : NMEA0183Msg.Init("VWT","II") ; break ;
		default : return ;
		}

	NMEA0183Msg.AddDoubleField(WindAngle,1,"%.0f",bord) ;
	NMEA0183Msg.AddDoubleField(WindSpeed,3.6 / 1.852,"%.1f","N") ;
	NMEA0183Msg.AddDoubleField(WindSpeed,1,"%.1f","M") ;
	NMEA0183Msg.AddDoubleField(WindSpeed,3.6,"%.1f","K") ;
 	SendMessage(NMEA0183Msg);
	}
}

// PP
void tN2kDataToNMEA0183::HandleEnviron(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kTempSource TempSource ;
double Temperature ;
tN2kHumiditySource HumiditySource ;
double Humidity ;
double AtmosphericPressure ;
tNMEA0183Msg NMEA0183Msg;

if (!ParseN2kEnvironmentalParameters(N2kMsg,SID,
		TempSource,Temperature,HumiditySource,Humidity, AtmosphericPressure)) return ;
switch (TempSource) {
	case N2kts_SeaTemperature : NMEA0183Msg.Init("MTW","II") ; break ;
	case N2kts_OutsideTemperature : NMEA0183Msg.Init("MTA","II") ; break ;
	default : return ;
	}
NMEA0183Msg.AddDoubleField(KelvinToC(Temperature),1,"%.1f","C") ;
SendMessage(NMEA0183Msg);
}

// PP
void tN2kDataToNMEA0183::HandleEnvironBis(const tN2kMsg &N2kMsg) {
unsigned char SID;
double WaterTemperature ;
double OutsideAmbientAirTemperature ;
double AtmosphericPressure ;
tNMEA0183Msg NMEA0183MsgA ;
tNMEA0183Msg NMEA0183MsgW ;

if (!ParseN2kOutsideEnvironmentalParameters(N2kMsg, SID, WaterTemperature,
                     OutsideAmbientAirTemperature, AtmosphericPressure)) return ;
NMEA0183MsgW.Init("MTW","II") ;
NMEA0183MsgW.AddDoubleField(KelvinToC(WaterTemperature),1,"%.1f","C") ;
SendMessage(NMEA0183MsgW);

NMEA0183MsgA.Init("MTA","II") ;
NMEA0183MsgA.AddDoubleField(KelvinToC(OutsideAmbientAirTemperature),1,"%.1f","C") ;
SendMessage(NMEA0183MsgA);
}


//*****************************************************************************
void tN2kDataToNMEA0183::HandleVariation(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kMagneticVariation Source;

  ParseN2kMagneticVariation(N2kMsg,SID,Source,DaysSince1970,Variation);
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandleBoatSpeed(const tN2kMsg &N2kMsg) {
unsigned char SID;
double WaterReferenced;
double GroundReferenced;
tN2kSpeedWaterReferenceType SWRT;

  if ( ParseN2kBoatSpeed(N2kMsg,SID,WaterReferenced,GroundReferenced,SWRT) ) {
    tNMEA0183Msg NMEA0183Msg;
    double MagneticHeading=( !N2kIsNA(Heading) && !N2kIsNA(Variation)?Heading+Variation: NMEA0183DoubleNA);
    if ( NMEA0183SetVHW(NMEA0183Msg,Heading,MagneticHeading,WaterReferenced) ) {
      SendMessage(NMEA0183Msg);
    }
  }
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandleDepth(const tN2kMsg &N2kMsg) {
unsigned char SID;
double DepthBelowTransducer;
double Offset;
double Range;

  if ( ParseN2kWaterDepth(N2kMsg,SID,DepthBelowTransducer,Offset,Range) ) {
      tNMEA0183Msg NMEA0183Msg;
      if ( NMEA0183SetDPT(NMEA0183Msg,DepthBelowTransducer,Offset) ) {
        SendMessage(NMEA0183Msg);
      }
      if ( NMEA0183SetDBx(NMEA0183Msg,DepthBelowTransducer,Offset) ) {
        SendMessage(NMEA0183Msg);
      }
  }
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandlePosition(const tN2kMsg &N2kMsg) {

  if ( ParseN2kPGN129025(N2kMsg, Latitude, Longitude) ) {
  	tNMEA0183Msg NMEA0183Msg;
  	struct tm *tm_now ;
  	time_t now ;
  	char	dateBuf[16] ;
  	
  	now = time(NULL) ;
  	tm_now = gmtime(&now) ;
		sprintf(dateBuf,"%02d%02d%02d",tm_now->tm_hour,tm_now->tm_min,tm_now->tm_sec) ;
    LastPositionTime=millis();
    NMEA0183Msg.Init("GLL","GP") ; 
		NMEA0183Msg.AddLatitudeField(Latitude) ;
		NMEA0183Msg.AddLongitudeField(Longitude) ;
		NMEA0183Msg.AddStrField(dateBuf) ;
		NMEA0183Msg.AddStrField("A") ;
		SendMessage(NMEA0183Msg);
  	}
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandleCOGSOG(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kHeadingReference HeadingReference;
tNMEA0183Msg NMEA0183Msg;

  if ( ParseN2kCOGSOGRapid(N2kMsg,SID,HeadingReference,COG,SOG) ) {
    LastCOGSOGTime=millis();
    double MCOG=( !N2kIsNA(COG) && !N2kIsNA(Variation)?COG-Variation:NMEA0183DoubleNA );
    if ( HeadingReference==N2khr_magnetic ) {
      MCOG=COG;
      if ( !N2kIsNA(Variation) ) COG-=Variation;
    }
    if ( NMEA0183SetVTG(NMEA0183Msg,COG,MCOG,SOG) ) {
      SendMessage(NMEA0183Msg);
    }
  }
}

//*****************************************************************************
void tN2kDataToNMEA0183::HandleGNSS(const tN2kMsg &N2kMsg) {
unsigned char SID;
tN2kGNSStype GNSStype;
tN2kGNSSmethod GNSSmethod;
unsigned char nSatellites;
double HDOP;
double PDOP;
double GeoidalSeparation;
unsigned char nReferenceStations;
tN2kGNSStype ReferenceStationType;
uint16_t ReferenceSationID;
double AgeOfCorrection;

  if ( ParseN2kGNSS(N2kMsg,SID,DaysSince1970,SecondsSinceMidnight,Latitude,Longitude,Altitude,GNSStype,GNSSmethod,
                    nSatellites,HDOP,PDOP,GeoidalSeparation,
                    nReferenceStations,ReferenceStationType,ReferenceSationID,AgeOfCorrection) ) {
    LastPositionTime=millis();
    
    // PP Generation message GGA
    tNMEA0183Msg NMEA0183Msg;
    char buf [16] ;
    sprintf(buf,"%02d%02d%02d",((int)SecondsSinceMidnight - ((int)SecondsSinceMidnight % 3600)) / 3600,
    															 ((int)SecondsSinceMidnight % 3600) / 60,(int)SecondsSinceMidnight % 60) ;
    NMEA0183Msg.Init("GLL","GP") ; 
    NMEA0183Msg.AddStrField(buf) ;
		NMEA0183Msg.AddLatitudeField(Latitude) ;
		NMEA0183Msg.AddLongitudeField(Longitude) ;
		NMEA0183Msg.AddStrField("1") ;
		NMEA0183Msg.AddDoubleField((double)nSatellites,1,"%.0f",NULL) ;
		NMEA0183Msg.AddDoubleField(HDOP,1,"%.1f",NULL) ;
		NMEA0183Msg.AddDoubleField(Altitude,1,"%.1f","M") ;
		NMEA0183Msg.AddDoubleField(GeoidalSeparation,1,"%.1f","M") ;
		NMEA0183Msg.AddEmptyField() ;
		NMEA0183Msg.AddEmptyField() ;
		SendMessage(NMEA0183Msg);
  }
}

//*****************************************************************************
void tN2kDataToNMEA0183::SendRMC() {
    if ( NextRMCSend<=millis() && !N2kIsNA(Latitude) ) {
      tNMEA0183Msg NMEA0183Msg;
      if ( NMEA0183SetRMC(NMEA0183Msg,SecondsSinceMidnight,Latitude,Longitude,COG,SOG,DaysSince1970,Variation) ) {
        SendMessage(NMEA0183Msg);
      }
      SetNextRMCSend();
    }
}

