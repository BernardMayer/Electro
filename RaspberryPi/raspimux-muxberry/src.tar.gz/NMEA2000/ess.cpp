#include "stdio.h"
#include "Point.h"

main() {

tPoint a(1,2) ;
tPoint b(3,4) ;

printf("distance : %.2f\n",a.distance(b)) ;
printf("bearing : %.2f\n",a.bearing(b)) ;
}
