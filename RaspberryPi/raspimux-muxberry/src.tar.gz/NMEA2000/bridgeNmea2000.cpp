/*
* File: main.cpp
* Author: al *
* Testing for CAN and RPI *
* See: https://github.com/thomasonw/NMEA2000_socketCAN *
* Created on February 12, 2017, 2:37 PM */
#include <cstdlib> 
#include <stdio.h> 
#include <iostream> 
#include <signal.h> 
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <NMEA2000_CAN.h>
#include <NMEA0183.h>
#include "BoatData.h"
#include "NMEA0183LinuxStream.h"
#include "NMEA0183Handlers.h"
#include "N2kDataToNMEA0183.h"

#define DEBUG_FILE "/tmp/bridgeNmea2000.log"


// Set the information for other bus devices, which messages we support
const unsigned long TransmitMessages[] PROGMEM={0};
const unsigned long ReceiveMessages[] PROGMEM={/*126992L,*/127250L,127258L,128259UL,128267UL,129025UL,129026L,129029L,0};
using namespace std;

tNMEA0183 NMEA0183_Out ;
tN2kDataToNMEA0183 N2kDataToNMEA0183(&NMEA2000 , &NMEA0183_Out);
tNMEA0183LinuxStream NMEA0183_debug ;
tNMEA0183LinuxStream NMEA0183_Out_Stream ;

int	saveStderr ;
int	nullStderr ;

void sigUSR2(int signum) {
	static	int state = 0 ;
	if (state == 1) { // Mode debug
		fflush(stderr) ;
		fprintf(stderr,"DEBUG -> 0\n") ;
		fflush(stderr) ;
		dup2(nullStderr,2) ;
		state = 0 ;
		}
	else {
		state = 1 ; // mode silent
		fflush(stderr) ;
		dup2(saveStderr,2) ;
		fprintf(stderr,"DEBUG -> 1\n") ;
		fflush(stderr) ;
		}
	signal (SIGUSR2,sigUSR2) ;
	}
	


int main(void) {
	char SnoStr[33] ;
	int	isOpen = 0	;
	
	signal (SIGUSR2,sigUSR2) ;
	umask(0) ;
	saveStderr = open(DEBUG_FILE,O_RDWR|O_CREAT|O_TRUNC,0666) ;
	nullStderr = open ("/dev/null",O_RDWR) ;
	dup2(nullStderr,2) ;
	uint32_t SerialNumber= 1 ;
	snprintf(SnoStr,32,"%lu",(long unsigned int)SerialNumber);
	cerr << "Starting CAN watching" << endl;
	//setvbuf (stdout, NULL, _IONBF, 0); 
	tBoatData BoatData;
	tNMEA0183 NMEA0183_in ;
	tNMEA0183LinuxStream linuxInStream  ;
	
	NMEA2000.SetN2kCANSendFrameBufSize(40) ;
	NMEA2000.SetProductInformation(SnoStr, // Manufacturer's Model serial code
                                 120, // Manufacturer's product code
                                 "N2k->NMEA0183",  // Manufacturer's Model ID
                                 "1.0.0.0 (2018-12-08)",  // Manufacturer's Software version code
                                 "1.0.0.0 (2018-12-08)" // Manufacturer's Model version
                                 );
  // Det device information
  NMEA2000.SetDeviceInformation(SerialNumber, // Unique number. Use e.g. Serial number.
                                135,//130, // Device function=PC Gateway. See codes on http://www.nmea.org/Assets/20120726%20nmea%202000%20class%20%26%20function%20codes%20v%202.00.pdf
                                25, // Device class=Inter/Intranetwork Device. See codes on http://www.nmea.org/Assets/20120726%20nmea%202000%20class%20%26%20function%20codes%20v%202.00.pdf
                                2046 // Just choosen free from code list on http://www.nmea.org/Assets/20121020%20nmea%202000%20registration%20list.pdf
                               );

		//NMEA2000.SetCANPort("can0");
		/* Permet un log sur stderr de l'activite du bus */
		serStream.setPort(2) ; // PP
    NMEA2000.SetForwardStream(&serStream) ; // Permet d'avoir les mesages d debug
		NMEA2000.SetForwardType(tNMEA2000::fwdt_Text);
		
	
		NMEA2000.ExtendTransmitMessages(TransmitMessages);
    NMEA2000.ExtendReceiveMessages(ReceiveMessages);
		NMEA2000.AttachMsgHandler(&N2kDataToNMEA0183);
		NMEA2000.SetMode(tNMEA2000::N2km_ListenAndNode,100);
		
	if (!NMEA2000.Open()) {
		cerr << "Failed to open CAN port" << endl; 
		}
	else {
		isOpen = 1 ;
		cerr << endl << "CAN started, going to watch it now" << endl;
		}
	// Setup NMEA0183 out ports and handlers
    NMEA0183_Out.SetMessageStream(&NMEA0183_Out_Stream);
    NMEA0183_Out.Open();
	//NMEA0183_Out_Stream.dupFile(1) ;
	
	// Setup NMEA0183 in  ports and handlers
	NMEA0183_in.SetMessageStream(&linuxInStream  , 0 ) ;
	//FILE *fd = fopen("../traces/tracesGps.log","r") ;
	//linuxInStream.dupFile(fileno(fd)) ;
	NMEA0183_in.Open();
	NMEA0183_in.SetMsgHandler(HandleNMEA0183Msg) ;
	// Les logs NMEA0183 sortent sur stderr
	NMEA0183_debug.setPort(2) ;
	DebugNMEA0183Handlers(&NMEA0183_debug) ;
  InitNMEA0183Handlers(&NMEA2000, &BoatData);

	while(1) {	
		 if (isOpen) NMEA2000.ParseMessages() ;
		 else usleep(300000) ;
		 NMEA0183_in.ParseMessages() ;
		 reapeatMessages() ;
		 }
	return 0 ;
	}
