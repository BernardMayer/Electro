#include "Point.h"
#include "stdio.h"
#include "math.h"

tPoint::tPoint(double latitude, double longitude) {
	lng = longitude ;
	lat = latitude ;	
	}
	
double tPoint::distance(tPoint destination) {
	double R = 6378000 ; // Distance en metres
  double dLat = destination.lat - lat;
  double dLon = destination.lng - lng;

  double a = sin(dLat/2) * sin(dLat/2) +
          cos(lat) * cos(destination.lat) * 
          sin(dLon/2) * sin(dLon/2);
  double c = 2 * atan2(sqrt(a), sqrt(1-a));
  double d = R * c;
	return d ;
	}
	
double tPoint::bearing(tPoint destination) {
  double dLon = (destination.lng - lng) ;
 	double y = sin(dLon) * cos(destination.lat) ;
  double x = cos(lat) * sin(destination.lat) -
          sin(lat) * cos(destination.lat) * cos(dLon);
  double brng = atan2(y, x) ;
	return brng ;
	}
	