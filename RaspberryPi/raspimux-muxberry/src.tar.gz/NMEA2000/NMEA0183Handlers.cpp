/* 
NMEA0183Handlers.cpp

2015 Copyright (c) Kave Oy, www.kave.fi  All right reserved.

Author: Timo Lappalainen

  This library is free software; you can redistribute it and/or
  modify it as you like.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/
 
#include <N2kMsg.h>
#include <NMEA2000.h>
#include <N2kMessages.h>
#include <NMEA0183Messages.h>
#include "NMEA0183Handlers.h"

const double knToms=1852.0/3600.0;
const double nmTom=1.852*1000;

extern tNMEA0183 NMEA0183_Out;

#define	MAX_MEMO_MESSAGES 128 // Max types messages NMEA0123
#define	TIME_TO_REAPEAT	2 // Temps apres lequel on repete
#define	TIME_NO_DATA 10 // Temps apres lequel on considere qu'il n'y a plus de data

// Fonction de memorisation et repetition des message
// Pour eviter les pertes d'infos sur repetiteur GARMIN
struct MemoMessage {
	char Code[4] ;
  tNMEA0183Msg NMEA0183Msg ;
  time_t lastSend	;
  time_t origSend ;
  } MemoMessages [MAX_MEMO_MESSAGES] ;

void memoNMEA0183Message(const tNMEA0183Msg NMEA0183Msg) {
	static int init = 0 ;
	int c ;
	if (!init) {
		for (c = 0 ; c < MAX_MEMO_MESSAGES ; c++) *MemoMessages[c].Code = 0 ;
		init++ ;
		}
	for (c = 0 ; c < MAX_MEMO_MESSAGES && 
								*MemoMessages[c].Code && 
								!NMEA0183Msg.IsMessageCode(MemoMessages[c].Code) ; c++) ;
	if (!*MemoMessages[c].Code) { // Non memorise
		strncpy(MemoMessages[c].Code,NMEA0183Msg.MessageCode(),3) ;
		*(MemoMessages[c].Code + 3) = 0 ;
		}
	else {
		if (NMEA0183Msg.MessageTime() == MemoMessages[c].NMEA0183Msg.MessageTime()) {
				MemoMessages[c].lastSend = time(0) ;
				return ;
				}
			}
	MemoMessages[c].origSend = MemoMessages[c].lastSend = time(0) ;
	MemoMessages[c].NMEA0183Msg = NMEA0183Msg ;
	}
	
void reapeatMessages() {
	int c ;
	for (c = 0 ;  c < MAX_MEMO_MESSAGES && *MemoMessages[c].Code ; c++) {
		int delta = time(0) - MemoMessages[c].origSend ;
		if (delta > TIME_NO_DATA) continue ; // Plus de donnees
		delta = time(0) - MemoMessages[c].lastSend ;
		if (delta >= TIME_TO_REAPEAT) {
 			fprintf(stderr,"          resend %s\n",MemoMessages[c].Code) ;
			HandleNMEA0183Msg(MemoMessages[c].NMEA0183Msg) ;
			MemoMessages[c].lastSend =time(0) ;
			}
		}
	}
	
struct tNMEA0183Handler {
  const char *Code;
  void (*Handler)(const tNMEA0183Msg &NMEA0183Msg); 
};

// Predefinition for functions to make it possible for constant definition for NMEA0183Handlers
void HandleRMC(const tNMEA0183Msg &NMEA0183Msg);
void HandleGGA(const tNMEA0183Msg &NMEA0183Msg);
void HandleHDT(const tNMEA0183Msg &NMEA0183Msg);
void HandleVTG(const tNMEA0183Msg &NMEA0183Msg);
void HandleDBT(const tNMEA0183Msg &NMEA0183Msg);
void HandleHDM(const tNMEA0183Msg &NMEA0183Msg);
void HandleHDT(const tNMEA0183Msg &NMEA0183Msg);
void HandleVHW(const tNMEA0183Msg &NMEA0183Msg);
void HandleVWR(const tNMEA0183Msg &NMEA0183Msg);
void HandleVWT(const tNMEA0183Msg &NMEA0183Msg);
void HandleGLL(const tNMEA0183Msg &NMEA0183Msg);
void HandleMTA(const tNMEA0183Msg &NMEA0183Msg);
void HandleMTW(const tNMEA0183Msg &NMEA0183Msg);
void HandleXTE(const tNMEA0183Msg &NMEA0183Msg);
void HandleRMB(const tNMEA0183Msg &NMEA0183Msg);
void HandleAPA(const tNMEA0183Msg &NMEA0183Msg);
void HandleBWC(const tNMEA0183Msg &NMEA0183Msg);
void HandleMWV(const tNMEA0183Msg &NMEA0183Msg);

void 	sendSystemTime() ; // PP
double PPGPTimeToSeconds() ; // PP
void	GGAFrompBD() ; // PP
void	 sendNavigationInfos() ; // PP
void 	sendXTE() ; // PP
	
// Internal variables
tNMEA2000 *pNMEA2000=0;
tBoatData *pBD=0;
Stream* NMEA0183HandlersDebugStream=0;

tNMEA0183Handler NMEA0183Handlers[]={
  {"HDM",&HandleHDM}, // Heading magnetic
  {"HDT",&HandleHDT}, // Heading true
  {"GGA",&HandleGGA}, // Position GPS SOG SOHG HDOP Quality
  {"GLL",&HandleGLL}, // Pos lat lng
  {"VTG",&HandleVTG}, // Track made good and speed over ground
  {"RMC",&HandleRMC}, // Pos + sog cog
  {"DBT",&HandleDBT}, // Profondeur
  {"VHW",&HandleVHW}, // VHW - Water speed and heading
  {"VWR",&HandleVWR}, // Wind relatif
  {"VWT",&HandleVWT}, // Wind true
  {"MWV",&HandleMWV}, // Wind true
  {"XTE",&HandleXTE}, // Ecart de route
  {"RMB",&HandleRMB}, // Ecart de route
  {"APA",&HandleAPA}, // Ecart de route
  {"APB",&HandleAPA}, // Ecart de route
  {"BWC",&HandleBWC}, // Ecart de route
  {"MTA",&HandleMTA}, // Temperature air
  {"MTW",&HandleMTW}, // Temperature eau
  {0,0}
};

// *****************************************************************************
void InitNMEA0183Handlers(tNMEA2000 *_NMEA2000, tBoatData *_BoatData) {
  pNMEA2000=_NMEA2000;
  pBD=_BoatData;
}

// *****************************************************************************
void DebugNMEA0183Handlers(Stream* _stream) {
  NMEA0183HandlersDebugStream=_stream;
}

// *****************************************************************************
tN2kGNSSmethod GNSMethofNMEA0183ToN2k(int Method) {
  switch (Method) {
    case 0: return N2kGNSSm_noGNSS;
    case 1: return N2kGNSSm_GNSSfix;
    case 2: return N2kGNSSm_DGNSS;
    default: return N2kGNSSm_GNSSfix;  
  }
}

// *****************************************************************************
void HandleNMEA0183Msg(const tNMEA0183Msg &NMEA0183Msg) {
  int iHandler;
  // Find handler
  if (NMEA0183HandlersDebugStream!=0) { 
  		char msg[128] ;
  		NMEA0183Msg.GetMessage(msg,sizeof(msg)) ;
  		NMEA0183HandlersDebugStream->println(msg) ;
  		}
  for (iHandler=0; NMEA0183Handlers[iHandler].Code!=0 && !NMEA0183Msg.IsMessageCode(NMEA0183Handlers[iHandler].Code); iHandler++);
  
  if (NMEA0183Handlers[iHandler].Code!=0) {
  fprintf (stderr,"    send %s\n",NMEA0183Handlers[iHandler].Code) ;
    NMEA0183Handlers[iHandler].Handler(NMEA0183Msg); 
    memoNMEA0183Message(NMEA0183Msg) ;
  }
  // Forward all NMEA0183 messages to the NMEA0183 out stream
  // PP NMEA0183_Out.SendMessage(NMEA0183Msg);
}

// NMEA0183 message Handler functions

// *****************************************************************************
void HandleRMC(const tNMEA0183Msg &NMEA0183Msg) {
  if (pBD==0) return;
  
  if (NMEA0183ParseRMC_nc(NMEA0183Msg,pBD->GPSTime,pBD->Latitude,pBD->Longitude,pBD->COG,pBD->SOG,pBD->DaysSince1970,pBD->Variation)) {
  } else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse RMC"); }
  // COG SOG
  tN2kMsg N2kMsg;
 	SetN2kCOGSOGRapid(N2kMsg ,1, N2khr_true, pBD->COG,pBD->SOG) ;
  pNMEA2000->SendMsg(N2kMsg); 
	}

// PP // $IIDBT,32.0,f,10.5,M,5.7,F*hh
void HandleDBT(const tNMEA0183Msg &NMEA0183Msg) {
  bool result=( NMEA0183Msg.FieldCount()>=6 );
  if (result) {
  	double DBT = atof(NMEA0183Msg.Field(2)) ;
  	if (NMEA0183HandlersDebugStream!=0) { 
  		NMEA0183HandlersDebugStream->print("DBT: "); 
  		NMEA0183HandlersDebugStream->println(DBT); 
  		}
  	tN2kMsg N2kMsg;
  	SetN2kPGN128267(N2kMsg,1,DBT,0.0,0.0) ;
  	pNMEA2000->SendMsg(N2kMsg); 
  	}
	else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Error DBT "); }
	}

// PP HDM
void HandleHDM(const tNMEA0183Msg &NMEA0183Msg) {
  double Heading ;
  if (NMEA0183ParseHDM_nc(NMEA0183Msg, Heading)) {
  	tN2kMsg N2kMsg;
  	SetN2kMagneticHeading(N2kMsg,1,Heading) ;
  	pNMEA2000->SendMsg(N2kMsg); 
  	if (NMEA0183HandlersDebugStream!=0) { 
  		NMEA0183HandlersDebugStream->print("HDM: "); 
  		NMEA0183HandlersDebugStream->println(Heading); 
  		}
  	}
	else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Error HDM "); }
  }

// PP VHW
// $--VHW,Heading,T,heading,M,speed,N,speed,K*hh<CR><LF>  
void HandleVHW(const tNMEA0183Msg &NMEA0183Msg) {
  double HeadingTrue ;
  double HeadingMag ;
  double speedK , speedN ;
  bool result=( NMEA0183Msg.FieldCount()>=8 );

  if ( result && pBD) {
  	tN2kMsg N2kMsg;
  	HeadingTrue=atof(NMEA0183Msg.Field(0)) * degToRad ;
  	HeadingMag=atof(NMEA0183Msg.Field(2)) * degToRad ;
  	speedK=atof(NMEA0183Msg.Field(6)); // Km/h
  	speedN=atof(NMEA0183Msg.Field(4)); // Nm/h
	 	SetN2kBoatSpeed(N2kMsg,1,speedN * knToms,pBD->SOG) ;
  	pNMEA2000->SendMsg(N2kMsg); 
  	
  	if (HeadingTrue && HeadingMag) {
  		if (pBD) {
  			pBD->TrueHeading = HeadingTrue ;
  			}
  			tN2kMsg N2kMsgT ;
  			SetN2kTrueHeading(N2kMsgT,1,HeadingTrue) ;
  			pNMEA2000->SendMsg(N2kMsgT); 
  			tN2kMsg N2kMsgM ;
  			SetN2kMagneticHeading(N2kMsgM,1,HeadingMag) ;
  			pNMEA2000->SendMsg(N2kMsgM);   			
  		}
  	if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("SpeedN="); NMEA0183HandlersDebugStream->println(speedN);
    	NMEA0183HandlersDebugStream->print("True="); NMEA0183HandlersDebugStream->println(HeadingTrue);
    	NMEA0183HandlersDebugStream->print("Mag="); NMEA0183HandlersDebugStream->println(HeadingMag);
    	}
  	}
	else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Error VHW "); }
  }

// PP VWR
// $--VWR,Direction,L/R,Speed,N,speed,M,speed,K*hh<CR><LF>  
void HandleVWR(const tNMEA0183Msg &NMEA0183Msg) {
  double Direction ;
  const char	 *bord     ;
  double speedM , speedN   ;
  bool result=( NMEA0183Msg.FieldCount()>=8 );

  if ( result ) {
  	tN2kMsg N2kMsg;
  	Direction= atof(NMEA0183Msg.Field(0)) ; 
  	bord = NMEA0183Msg.Field(1) ;
  	if (*bord == 'L') Direction = 360 - Direction ;
  	speedM=atof(NMEA0183Msg.Field(4)); // M/s
  	speedN=atof(NMEA0183Msg.Field(2)); // Knots/h
   	SetN2kWindSpeed(N2kMsg,1,speedM,Direction * degToRad, N2kWind_Apparent) ;
		pNMEA2000->SendMsg(N2kMsg);   
			
  	if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Wind Speed A = "); NMEA0183HandlersDebugStream->println(speedN);
    	NMEA0183HandlersDebugStream->print("Wind Dir A =  "); NMEA0183HandlersDebugStream->println(Direction);
    	}
  	}
	else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Error VWR "); }
  }

// PP VWT
// $--VWT,Direction,L/R,Speed,N,speed,M,speed,K*hh<CR><LF>  
void HandleVWT(const tNMEA0183Msg &NMEA0183Msg) {
  double Direction ;
  const char	 *bord     ;
  double speedM , speedN   ;
  bool result=( NMEA0183Msg.FieldCount()>=8 );

  if ( result ) {
  	tN2kMsg N2kMsg;
  	Direction=atof(NMEA0183Msg.Field(0)) ;
  	bord=NMEA0183Msg.Field(1) ;
  	if (*bord == 'L') Direction = 360 - Direction ;
  	speedM=atof(NMEA0183Msg.Field(4)); // M/s
  	speedN=atof(NMEA0183Msg.Field(2)); // Knots/h
  	SetN2kWindSpeed(N2kMsg,1,speedM,Direction * degToRad, N2kWind_True_water) ;
		if (pNMEA2000) pNMEA2000->SendMsg(N2kMsg);   
			
  	if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Wind Speed T = "); NMEA0183HandlersDebugStream->println(speedN);
    	NMEA0183HandlersDebugStream->print("Wind Dir T = "); NMEA0183HandlersDebugStream->println(Direction);
    	}
  	}
	else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Error VWT "); }
  }
  
// PP MWV
void HandleMWV(const tNMEA0183Msg &NMEA0183Msg) {
  double WindAngle ;
  tNMEA0183WindReference Reference ;
  double WindSpeed ;
	
	if (NMEA0183ParseMWV_nc(NMEA0183Msg,WindAngle,Reference,WindSpeed)) {
			tN2kMsg N2kMsg;
		 	SetN2kWindSpeed(N2kMsg,1,WindSpeed,WindAngle * degToRad,
		 			Reference ==  NMEA0183Wind_Apparent ? N2kWind_Apparent : N2kWind_True_water) ;
		if (pNMEA2000) pNMEA2000->SendMsg(N2kMsg);   
 		}
} 		

// *****************************************************************************
void HandleGGA(const tNMEA0183Msg &NMEA0183Msg) {
  if (pBD==0) return;
  if (NMEA0183ParseGGA_nc(NMEA0183Msg,pBD->GPSTime,pBD->Latitude,pBD->Longitude,
                   pBD->GPSQualityIndicator,pBD->SatelliteCount,pBD->HDOP,pBD->Altitude,pBD->GeoidalSeparation,
                   pBD->DGPSAge,pBD->DGPSReferenceStationID)) {
    // Force GPSTime
    pBD->GPSTime = PPGPTimeToSeconds() ;
    if (pNMEA2000!=0) {
      tN2kMsg N2kMsgGnss ;
      // PP Envoi l'heure
      sendSystemTime() ;
      // PP Pas de variation
      //SetN2kMagneticVariation(N2kMsgVar,1,N2kmagvar_Calc,pBD->DaysSince1970,pBD->Variation);
      //pNMEA2000->SendMsg(N2kMsgVar); 
      SetN2kGNSS(N2kMsgGnss,1,pBD->DaysSince1970,pBD->GPSTime,pBD->Latitude,pBD->Longitude,pBD->Altitude,
                N2kGNSSt_GPS,GNSMethofNMEA0183ToN2k(pBD->GPSQualityIndicator),pBD->SatelliteCount,pBD->HDOP,0,
                pBD->GeoidalSeparation,1,N2kGNSSt_GPS,pBD->DGPSReferenceStationID,pBD->DGPSAge
                );
      pNMEA2000->SendMsg(N2kMsgGnss); 
    }

    if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Days="); NMEA0183HandlersDebugStream->println((int)pBD->DaysSince1970);
      NMEA0183HandlersDebugStream->print("Time="); NMEA0183HandlersDebugStream->println(pBD->GPSTime);
      NMEA0183HandlersDebugStream->print("Latitude="); NMEA0183HandlersDebugStream->println(pBD->Latitude);
      NMEA0183HandlersDebugStream->print("Longitude="); NMEA0183HandlersDebugStream->println(pBD->Longitude);
      NMEA0183HandlersDebugStream->print("Altitude="); NMEA0183HandlersDebugStream->println(pBD->Altitude);
      NMEA0183HandlersDebugStream->print("GPSQualityIndicator="); NMEA0183HandlersDebugStream->println(pBD->GPSQualityIndicator);
      NMEA0183HandlersDebugStream->print("SatelliteCount="); NMEA0183HandlersDebugStream->println(pBD->SatelliteCount);
      NMEA0183HandlersDebugStream->print("HDOP="); NMEA0183HandlersDebugStream->println(pBD->HDOP);
      NMEA0183HandlersDebugStream->print("GeoidalSeparation="); NMEA0183HandlersDebugStream->println(pBD->GeoidalSeparation);
      NMEA0183HandlersDebugStream->print("DGPSAge="); NMEA0183HandlersDebugStream->println(pBD->DGPSAge);
      NMEA0183HandlersDebugStream->print("DGPSReferenceStationID="); NMEA0183HandlersDebugStream->println(pBD->DGPSReferenceStationID);
      NMEA0183HandlersDebugStream->print("COG="); NMEA0183HandlersDebugStream->println(pBD->COG);
      NMEA0183HandlersDebugStream->print("SOG="); NMEA0183HandlersDebugStream->println(pBD->SOG);
    }
  } else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse GGA"); }
}


// *****************************************************************************
void GGAFrompBD() {
	static int sid = 1000 ;
  if (pBD==0) return;
    // Force GPSTime
    pBD->GPSTime = PPGPTimeToSeconds() ;
    if (pNMEA2000!=0) {
      tN2kMsg N2kMsgGnss ;
      // PP Envoi l'heure
      sendSystemTime() ;
      SetN2kGNSS(N2kMsgGnss,1,pBD->DaysSince1970,pBD->GPSTime,pBD->Latitude,pBD->Longitude,pBD->Altitude,
                N2kGNSSt_GPS,GNSMethofNMEA0183ToN2k(pBD->GPSQualityIndicator),pBD->SatelliteCount,pBD->HDOP,0,
                pBD->GeoidalSeparation,1,N2kGNSSt_GPS,pBD->DGPSReferenceStationID,pBD->DGPSAge
                );
      pNMEA2000->SendMsg(N2kMsgGnss); 
    }

    if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Days="); NMEA0183HandlersDebugStream->println((int)pBD->DaysSince1970);
      NMEA0183HandlersDebugStream->print("Time="); NMEA0183HandlersDebugStream->println(pBD->GPSTime);
      NMEA0183HandlersDebugStream->print("Latitude="); NMEA0183HandlersDebugStream->println(pBD->Latitude);
      NMEA0183HandlersDebugStream->print("Longitude="); NMEA0183HandlersDebugStream->println(pBD->Longitude);
      NMEA0183HandlersDebugStream->print("Altitude="); NMEA0183HandlersDebugStream->println(pBD->Altitude);
      NMEA0183HandlersDebugStream->print("GPSQualityIndicator="); NMEA0183HandlersDebugStream->println(pBD->GPSQualityIndicator);
      NMEA0183HandlersDebugStream->print("SatelliteCount="); NMEA0183HandlersDebugStream->println(pBD->SatelliteCount);
      NMEA0183HandlersDebugStream->print("HDOP="); NMEA0183HandlersDebugStream->println(pBD->HDOP);
      NMEA0183HandlersDebugStream->print("GeoidalSeparation="); NMEA0183HandlersDebugStream->println(pBD->GeoidalSeparation);
      NMEA0183HandlersDebugStream->print("DGPSAge="); NMEA0183HandlersDebugStream->println(pBD->DGPSAge);
      NMEA0183HandlersDebugStream->print("DGPSReferenceStationID="); NMEA0183HandlersDebugStream->println(pBD->DGPSReferenceStationID);
      NMEA0183HandlersDebugStream->print("COG="); NMEA0183HandlersDebugStream->println(pBD->COG);
      NMEA0183HandlersDebugStream->print("SOG="); NMEA0183HandlersDebugStream->println(pBD->SOG);
    }
}




// *****************************************************************************
void HandleGLL(const tNMEA0183Msg &NMEA0183Msg) {
  tGLL GLL ;
  tN2kMsg N2kMsg;
  if (!NMEA0183ParseGLL_nc(NMEA0183Msg,GLL)) {
  	if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse GLL"); }	
		return ;
		}
	pBD->Latitude = GLL.latitude ;
	pBD->Longitude = GLL.longitude ;

  SetN2kLatLonRapid(N2kMsg,GLL.latitude, GLL.longitude) ;
  sendSystemTime() ;
  pNMEA2000->SendMsg(N2kMsg) ;

    if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Latitude="); NMEA0183HandlersDebugStream->println(GLL.latitude);
      NMEA0183HandlersDebugStream->print("Longitude="); NMEA0183HandlersDebugStream->println(GLL.longitude);
			}
	}

// *****************************************************************************
void HandleMTA(const tNMEA0183Msg &NMEA0183Msg) {
  double temperature ;
  tN2kMsg N2kMsg;
  temperature = atof(NMEA0183Msg.Field(0)) ;
  SetN2kEnvironmentalParameters(N2kMsg,1, N2kts_OutsideTemperature,  CToKelvin(temperature)) ;
  pNMEA2000->SendMsg(N2kMsg); 
  if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Temperature= AIR="); NMEA0183HandlersDebugStream->println(temperature);
			}
}

void HandleMTW(const tNMEA0183Msg &NMEA0183Msg) {
  double temperature ;
  tN2kMsg N2kMsg;
  temperature = atof(NMEA0183Msg.Field(0)) ;
  SetN2kEnvironmentalParameters(N2kMsg,1, N2kts_SeaTemperature,  CToKelvin(temperature)) ;
  pNMEA2000->SendMsg(N2kMsg); 
  if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("Temperature WATER="); NMEA0183HandlersDebugStream->println(temperature);
			}
}

#define PI_2 6.283185307179586476925286766559

// *****************************************************************************
void HandleHDT(const tNMEA0183Msg &NMEA0183Msg) {
  if (pBD==0) return;
  
  if (NMEA0183ParseHDT_nc(NMEA0183Msg,pBD->TrueHeading)) {
    if (pNMEA2000!=0) { 
      tN2kMsg N2kMsg;
      double MHeading=pBD->TrueHeading-pBD->Variation;
      while (MHeading<0) MHeading+=PI_2;
      while (MHeading>=PI_2) MHeading-=PI_2;
//      SetN2kMagneticHeading(N2kMsg,1,MHeading,0,pBD->Variation);
      SetN2kTrueHeading(N2kMsg,1,pBD->TrueHeading);
      pNMEA2000->SendMsg(N2kMsg);
    }
    if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("True heading="); NMEA0183HandlersDebugStream->println(pBD->TrueHeading);
    }
  } else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse HDT"); }
}

// *****************************************************************************
void HandleVTG(const tNMEA0183Msg &NMEA0183Msg) {
 double MagneticCOG;
  if (pBD==0) return;
  if (NMEA0183ParseVTG_nc(NMEA0183Msg,pBD->COG,MagneticCOG,pBD->SOG)) {
      pBD->Variation=pBD->COG-MagneticCOG; // Save variation for Magnetic heading
    if (pNMEA2000!=0) { 
      tN2kMsg N2kMsg;
      SetN2kCOGSOGRapid(N2kMsg,1,N2khr_true,pBD->COG,pBD->SOG);
      pNMEA2000->SendMsg(N2kMsg);
    }
    if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("VTG COG="); NMEA0183HandlersDebugStream->println(pBD->COG);
      NMEA0183HandlersDebugStream->print("VTG SOG="); NMEA0183HandlersDebugStream->println(pBD->SOG);
    }
  } else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse VTG"); }
}

// *****************************************************************************
// $--XTE,A,A,Error.Left/right,N,m,*hh<CR><LF>
// $GPXTE,A,A,0.03,L,N*6d
void HandleXTE(const tNMEA0183Msg &NMEA0183Msg) { // PP
 double xte				;
 char sens 				;
  char buf [128] 	;
  bool arrival = false ;
  
  if (!pBD) return ;
  NMEA0183Msg.GetMessage(buf,sizeof(buf)) ;
  pBD->xte = atof(NMEA0183Msg.Field(2)) ; // Nm
  *NMEA0183Msg.Field(3) == 'R' ? -1 : 1 ; // sens
	if (pBD->arrivalAlarm == 'A' || pBD->PerpendicularCrossed == 'A') arrival = true ;
	sendXTE() ;
}

void sendXTE() { // PP
  if (!pBD) return ;
  bool arrival ;
	if (pBD->arrivalAlarm == 'A' || pBD->PerpendicularCrossed == 'A') arrival = true ;
    if (pNMEA2000!=0) { 
      tN2kMsg N2kMsg;
      SetN2kPGN129283(N2kMsg, 1, N2kxtem_Autonomous, arrival, pBD->xte * nmTom) ;
      pNMEA2000->SendMsg(N2kMsg);
    }
        
   if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("XTE="); NMEA0183HandlersDebugStream->println(pBD->xte);
    }
}

//*****************************************************************************
//$GPRMB,A,0.15,R,WOUBRG,WETERB,5213.400,N,00438.400,E,009.4,180.2,,V*07
void HandleRMB(const tNMEA0183Msg &NMEA0183Msg) { // PP
 tRMB RMB ;
	
 if (pBD && NMEA0183ParseRMB_nc(NMEA0183Msg, RMB)) {
 		pBD->dtw = RMB.dtw ;
 		pBD->btw = RMB.btw ;
 		pBD->xte = RMB.xte ;
 		pBD->arrivalAlarm = RMB.arrivalAlarm ;
 		pBD->vmg = RMB.vmg ;
 		pBD->dstLatitude = RMB.latitude ;
 		pBD->dstLongitude = RMB.longitude ;
 		pBD->originID = atoi(RMB.originID) ? atoi(RMB.originID) : 1,
 		pBD->destID = atoi(RMB.destID) ? atoi(RMB.destID) : 2,
 		pBD->botw = N2kInt32NA ;
 		sendNavigationInfos() ;
 		sendXTE() ;
 	}
 }

void sendNavigationInfos() { // PP
 	tN2kMsg N2kMsg;
 	if (pBD) {
	 	if (pNMEA2000!=0) { 
      tN2kMsg N2kMsg;
 			SetN2kNavigationInfo(N2kMsg,1, pBD->dtw, 
 											N2khr_true , // N2khr_true
 											pBD->PerpendicularCrossed == 'A' ? true : false, 
                      pBD->arrivalAlarm == 'A' ? true : false,
                      N2kdct_GreatCircle, // tN2kdct_GreatCircle
                      N2kInt32NA , // ETATime
                      N2kInt16NA, // ETADate
                      pBD->botw, // BearingOriginToDestinationWaypoint
                      pBD->btw, // BearingPositionToDestinationWaypoin
                      pBD->originID,  // OriginWaypointNumber
                      pBD->destID, // OriginWaypointNumber
                      pBD->dstLatitude, pBD->dstLongitude, pBD->vmg) ;
      pNMEA2000->SendMsg(N2kMsg);
			}    
   if (NMEA0183HandlersDebugStream!=0) {
      NMEA0183HandlersDebugStream->print("DTW="); NMEA0183HandlersDebugStream->println(pBD->dtw);
      NMEA0183HandlersDebugStream->print("BTW="); NMEA0183HandlersDebugStream->println(pBD->btw);
    }
  } else if (NMEA0183HandlersDebugStream!=0) { NMEA0183HandlersDebugStream->println("Failed to parse RMB") ; }
}
//*****************************************************************************
//$GPAPA,(0)Status-1,(1)Status-2,(2)xte,(3)L/R,(4)xte-unit(M/K),(5)A=Circle_arrival(6)A=perpendiclaire,
//		(7)Bearing orig to dest,(8)Mag/True,(9)WayPointId
void HandleAPA(const tNMEA0183Msg &NMEA0183Msg) { // PP
 if ( NMEA0183Msg.FieldCount() < 10 ) return ;
 if (pBD) {
 	pBD->xte = atof(NMEA0183Msg.Field(2)) * nmTom ; // Nm or Km
 	if (*NMEA0183Msg.Field(3) == 'R') pBD->xte *= -1 ;
 	if (*NMEA0183Msg.Field(4) == 'K') pBD->xte *= 1.852 ;
 	pBD->arrivalAlarm = *NMEA0183Msg.Field(5) ;
 	pBD->PerpendicularCrossed = *NMEA0183Msg.Field(6) ;
 	pBD->botw = atof(NMEA0183Msg.Field(7))*degToRad;
 	pBD->btw = N2kInt32NA ;
 	pBD->dtw = N2kInt32NA ;
 	pBD->vmg = N2kInt32NA ; 	
 	pBD->dstLatitude = N2kInt32NA ; 	
 	pBD->dstLongitude = N2kInt32NA ; 	
 	pBD->destID = atoi(NMEA0183Msg.Field(9)) ? atoi(NMEA0183Msg.Field(9)) : 2,
 	sendNavigationInfos() ;
 	sendXTE() ;
	}
}

//*****************************************************************************
// Cap en true
// $GPAPB,(0)Status-1,(1)Status-2,(2)xte,(3)L/R,(4)xte-unit(M/K),(5)A=Circle_arrival(6)A=perpendiclaire,
//		(7)Bearing orig to dest,(8)Mag/True,(9)WayPointId,(10)Bearing, present position to Destination,
//		(11)Mag/True,(12)Heading to steer,(13))Mag/True
void HandleAPB(const tNMEA0183Msg &NMEA0183Msg) { // PP
 if ( NMEA0183Msg.FieldCount() < 11 ) return ;
 if (pBD) {
 	pBD->xte = atof(NMEA0183Msg.Field(2)) * nmTom ; // Nm or Km
 	if (*NMEA0183Msg.Field(3) == 'R') pBD->xte *= -1 ;
 	if (*NMEA0183Msg.Field(4) == 'K') pBD->xte *= 1.852 ;
 	pBD->arrivalAlarm = *NMEA0183Msg.Field(5) ;
 	pBD->botw = atof(NMEA0183Msg.Field(7))*degToRad;
 	pBD->btw = atof(NMEA0183Msg.Field(10))*degToRad;
 	pBD->PerpendicularCrossed = *NMEA0183Msg.Field(6) ;
 	pBD->dtw = N2kInt32NA ;
 	pBD->vmg = N2kInt32NA ;
 	pBD->dstLatitude = N2kInt32NA ; 	
 	pBD->dstLongitude = N2kInt32NA ; 	
 	pBD->destID = atoi(NMEA0183Msg.Field(9)) ? atoi(NMEA0183Msg.Field(9)) : 2,
 	sendNavigationInfos() ;
 	sendXTE() ;
	}
}


//*****************************************************************************
// Cap en true
// $GPAPB,(0)UTC TIME,(1)WP lat,(2)N/S,(3)WP lng,(4)E/W,(5)Bearing T,(6)T,
//		(7)Bearing M,(8)M,(9)Distance,(10)M,(11)Way Point ID
void HandleBWC(const tNMEA0183Msg &NMEA0183Msg) { // PP
 if ( NMEA0183Msg.FieldCount() < 12 ) return ;
 if (pBD) {
 	pBD->dstLatitude = atof(NMEA0183Msg.Field(1)) ;
 	if (*NMEA0183Msg.Field(2) == 'S') pBD->dstLatitude *= -1.0 ;
 	pBD->dstLatitude = atof(NMEA0183Msg.Field(3)) ;
 	if (*NMEA0183Msg.Field(4) == 'W') pBD->dstLatitude *= -1.0 ;
 	pBD->btw = atof(NMEA0183Msg.Field(5))*degToRad;
 	pBD->dtw = atof(NMEA0183Msg.Field(9))*nmTom;
 	pBD->destID = atoi(NMEA0183Msg.Field(11)) ? atoi(NMEA0183Msg.Field(11)) : 2,
 	sendNavigationInfos() ;
	}
}
// PP Systeme time
// SystemDate jours depuis le 01/01/1970
// SystemTime secondes depuis minuit

//*****************************************************************************
double PPGPTimeToSeconds() {
	struct tm *tm ; // PP
	time_t now ; // PP
	char buf[16] ; // PP
	now = time(NULL) ; // PP
	tm = gmtime(&now) ; // PP
	sprintf(buf,"%02d%02d%02d.0000",tm->tm_hour,tm->tm_min,tm->tm_sec) ; // PP
	
  double val=atof(buf); // PP
  double hh=floor(val/10000);
  double mm=floor((val-hh*10000)/100);

  val=hh*3600+mm*60+(val-hh*10000.0-mm*100);

  return val;
}

void sendSystemTime() {
	tN2kMsg N2kMsg ;
	time_t heure = time(0) ;

	if (!pBD) return ;
	
	pBD->DaysSince1970 = tNMEA0183Msg::elapsedDaysSince1970(time(0)) ;
  pBD->GPSTime = PPGPTimeToSeconds() ;

		
	SetN2kPGN126992(N2kMsg, 1, 
								pBD->DaysSince1970 ,
                pBD->GPSTime ,
                N2ktimes_GPS) ;
	if (pNMEA2000!=0)
		pNMEA2000->SendMsg(N2kMsg);
}
