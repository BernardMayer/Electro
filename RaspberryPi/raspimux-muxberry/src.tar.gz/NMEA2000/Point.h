class tPoint {
	protected:
		 double lng , lat ;
	
	public:
		tPoint(double latitude,double longitude) ;
		double distance	(tPoint destination) ;
		double bearing 	(tPoint destination) ;
	} ;
	
