#ifndef _BoatData_H_
#define _BoatData_H_

struct tBoatData {
  unsigned long DaysSince1970;   // Days since 1970-01-01
  
  double TrueHeading,SOG,COG,Variation,
         GPSTime,// Secs since midnight,
         Latitude, Longitude, Altitude, HDOP, GeoidalSeparation, DGPSAge,
         dstLatitude,dstLongitude,dtw,btw,xte,botw,vmg;
  int GPSQualityIndicator, SatelliteCount, DGPSReferenceStationID,
  		originID,destID;
  bool MOBActivated;
  char arrivalAlarm, PerpendicularCrossed ;

public:
  tBoatData() {
    TrueHeading=0;
    SOG=0;
    COG=0; 
    Variation=0.0;
    GPSTime=0;
    Altitude=0;
    HDOP=3.8;
    DGPSAge=0;
    DaysSince1970=0; 
    MOBActivated=false; 
    SatelliteCount=5; 
    DGPSReferenceStationID=0;
    dstLatitude=0 ;
    dstLongitude=0 ;
    dtw=0;
    btw=0 ;
    botw=0;
    vmg=0;
    xte=0 ;
    arrivalAlarm=0;
    PerpendicularCrossed=0;
    originID=1;
    destID=1;
  };
};

#endif // _BoatData_H_

