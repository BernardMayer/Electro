ntpserver
=========

A Python based ntp server.

Tested on Linux and Windows7.

Based on ntplib(https://pypi.python.org/pypi/ntplib/), thanks for their work.

If you have any question, please contact me at limifly@gmail.com.
